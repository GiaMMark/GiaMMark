-- The two original UIs share one resource-level CEF focus. A late close from
-- another module must never release the interface currently in use.
local owner = nil
local nativeSend = SendNUIMessage
local nativeRegister = RegisterNUICallback
local nativeFocus = SetNuiFocus

GiaMMarKUI = {}

function GiaMMarKUI.available(module)
    return owner == nil or owner == module
end

function GiaMMarKUI.bind(module)
    local function send(payload)
        nativeSend({module = module, payload = payload})
    end

    local function register(name, callback)
        nativeRegister(module .. '_' .. name, callback)
    end

    local function focus(hasFocus, hasCursor)
        if hasFocus then
            if not GiaMMarKUI.available(module) then return false end
            owner = module
            nativeFocus(hasFocus, hasCursor)
            return true
        end

        if owner ~= module then return false end
        owner = nil
        nativeFocus(false, false)
        return true
    end

    return send, register, focus
end

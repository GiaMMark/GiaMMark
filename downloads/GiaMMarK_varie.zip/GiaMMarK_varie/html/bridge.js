'use strict';

// The FiveM callback hostname is the owning resource, including from an iframe.
if (typeof window.GetParentResourceName !== 'function'
    && window.parent !== window
    && typeof window.parent.GetParentResourceName === 'function') {
    window.GetParentResourceName = () => window.parent.GetParentResourceName();
}

(() => {
    let ready = false;
    const announceReady = () => {
        const module = window.frameElement?.dataset.module;
        if (module && window.parent !== window) {
            window.parent.postMessage({type: 'giammark:ready', module}, '*');
        }
    };

    window.addEventListener('message', event => {
        if (ready && event.source === window.parent && event.data?.type === 'giammark:checkReady') {
            announceReady();
        }
    });

    const loaded = () => {
        ready = true;
        announceReady();
    };

    // Loaded before each original app.js; DOMContentLoaded follows its listener
    // registration, so messages queued during initial loading are not lost.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loaded, {once: true});
    } else {
        loaded();
    }
})();

'use strict';

(() => {
    const applications = {
        crafting: {frame: document.getElementById('crafting'), ready: false, queue: []},
        payphones: {frame: document.getElementById('payphones'), ready: false, queue: []}
    };
    const openingActions = {crafting: new Set(['openCraft', 'openAdmin']), payphones: new Set(['open', 'openCall'])};

    window.addEventListener('message', event => {
        const data = event.data;
        if (!data || typeof data !== 'object' || !Object.hasOwn(applications, data.module)) return;
        const app = applications[data.module];

        if (data.type === 'giammark:ready') {
            // Only that actual iframe can announce that its app listener exists.
            if (event.source !== app.frame.contentWindow) return;
            app.ready = true;
            for (const payload of app.queue) app.frame.contentWindow.postMessage(payload, '*');
            app.queue.length = 0;
            if (!app.frame.hidden) app.frame.focus();
            return;
        }

        // Game messages originate at the root CEF window. Children only send
        // the readiness handshake; their own UI state cannot switch modules.
        if (event.source && event.source !== window) return;
        const payload = data.payload;
        if (!payload || typeof payload !== 'object') return;

        if (payload.action === 'close') {
            app.frame.hidden = true;
        } else if (openingActions[data.module].has(payload.action)) {
            app.frame.hidden = false;
            app.frame.focus();
        }

        // A call result or admin refresh updates the existing UI only. It must
        // not reveal a surface the player has already closed.
        if (app.ready) app.frame.contentWindow.postMessage(payload, '*');
        else app.queue.push(payload);
    });

    // Cached child documents may finish before this external router script.
    // Probe now and after each load so an early ready handshake is recoverable.
    for (const app of Object.values(applications)) {
        const probe = () => app.frame.contentWindow.postMessage({type: 'giammark:checkReady'}, '*');
        app.frame.addEventListener('load', () => {
            app.ready = false;
            probe();
        });
        probe();
    }
})();

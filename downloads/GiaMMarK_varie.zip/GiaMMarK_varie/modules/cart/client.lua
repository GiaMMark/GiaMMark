local Config = CartConfig
local active = nil    -- {uid, slot, netId, mode = 'pushing' | 'parked'}
local trolley = nil   -- handle locale (puo' cambiare con lo streaming)
local targetNetId = nil
local currentModel = 1
local currentAnimation = 1
local perModelOffset = {}
local busy = false
local lastAutoParkAttempt = 0
local HINT_TEXT = '[E] Magazzino  |  [X] Lascia a terra  |  /carrello_riponi'

local requestResume, requestStow, openStash

local function notify(message, kind)
    lib.notify({
        title = 'Carrello', description = message,
        type = kind or 'inform', position = Config.NotificationPosition,
    })
end

local function selectedAnimation()
    return (Config.AnimationPresets and Config.AnimationPresets[currentAnimation]) or Config.Animation
end

local function stopAnimation()
    local anim = selectedAnimation()
    if not anim or not anim.enabled then return end
    local ped = PlayerPedId()
    if IsEntityPlayingAnim(ped, anim.dict, anim.clip, 3) then
        StopAnimTask(ped, anim.dict, anim.clip, 2.0)
    end
end

local function playAnimation()
    local anim = selectedAnimation()
    if not anim or not anim.enabled then return end
    lib.requestAnimDict(anim.dict)
    TaskPlayAnim(PlayerPedId(), anim.dict, anim.clip, 4.0, -4.0, -1,
        anim.flag or 49, 0.0, false, false, false)
    RemoveAnimDict(anim.dict)
end

local function getTrolley()
    if active and active.netId then
        if NetworkDoesNetworkIdExist(active.netId) then
            local entity = NetworkGetEntityFromNetworkId(active.netId)
            if entity ~= 0 and DoesEntityExist(entity) then
                trolley = entity
                return entity
            end
        end
        return nil -- il prop e' fuori dallo scope: non usare handle riciclati
    end
    if trolley and DoesEntityExist(trolley) then return trolley end
    return nil
end

local function setHint(show)
    local isOpen, text = lib.isTextUIOpen()
    if show then
        if not (isOpen and text == HINT_TEXT) then
            lib.showTextUI(HINT_TEXT, {position = 'right-center', icon = 'cart-shopping'})
        end
    elseif isOpen and text == HINT_TEXT then
        lib.hideTextUI()
    end
end

local function removeTarget()
    if targetNetId then
        exports.ox_target:removeEntity(targetNetId, {
            'mobile_cart_resume', 'mobile_cart_open', 'mobile_cart_stow'
        })
        targetNetId = nil
    end
end

local function deleteTrolley()
    removeTarget()
    local entity = getTrolley()
    trolley = nil
    if entity and DoesEntityExist(entity) then
        if IsEntityAttached(entity) then DetachEntity(entity, true, true) end
        SetEntityAsMissionEntity(entity, true, true)
        DeleteEntity(entity)
    end
end

local function cleanup()
    setHint(false)
    stopAnimation()
    deleteTrolley()
    active = nil
end

local function modelAttach(modelName)
    local offsets = perModelOffset[modelName]
        or (Config.ModelAttachOverrides and Config.ModelAttachOverrides[modelName])
        or Config.Attach
    return {
        x = offsets.x or 0.0, y = offsets.y or 0.0, z = offsets.z or 0.0,
        rx = offsets.rx or 0.0, ry = offsets.ry or 0.0, rz = offsets.rz or 0.0,
    }
end

local function applyTrolleyAttachment()
    local entity = getTrolley()
    if not entity then return false end
    FreezeEntityPosition(entity, false)
    SetEntityCollision(entity, false, false)
    local offset = modelAttach(Config.PropModels[currentModel])
    AttachEntityToEntity(entity, PlayerPedId(), 0,
        offset.x, offset.y, offset.z,
        offset.rx, offset.ry, offset.rz,
        false, false, false, false, 2, true)
    return true
end

local function ensureControl(entity)
    if NetworkHasControlOfEntity(entity) then return true end
    for i = 1, 20 do
        NetworkRequestControlOfEntity(entity)
        Wait(50)
        if NetworkHasControlOfEntity(entity) then return true end
    end
    return false
end

local function registerTarget(netId)
    removeTarget()
    targetNetId = netId
    exports.ox_target:addEntity(netId, {
        {
            name = 'mobile_cart_resume', icon = 'fa-solid fa-person-walking',
            label = 'Riprendi e spingi il carrello', distance = Config.InteractDistance,
            canInteract = function(entity)
                return active ~= nil and not busy and active.mode == 'parked'
                    and NetworkGetNetworkIdFromEntity(entity) == active.netId
            end,
            onSelect = function()
                requestResume()
            end,
        },
        {
            name = 'mobile_cart_open', icon = 'fa-solid fa-box-open',
            label = 'Apri magazzino', distance = Config.InteractDistance,
            canInteract = function(entity)
                return active ~= nil and not busy and active.mode == 'parked'
                    and NetworkGetNetworkIdFromEntity(entity) == active.netId
            end,
            onSelect = function()
                openStash()
            end,
        },
        {
            name = 'mobile_cart_stow', icon = 'fa-solid fa-cart-shopping',
            label = 'Riponi il carrello nell\'inventario', distance = Config.InteractDistance,
            canInteract = function(entity)
                return active ~= nil and not busy and active.mode == 'parked'
                    and NetworkGetNetworkIdFromEntity(entity) == active.netId
            end,
            onSelect = function()
                requestStow()
            end,
        },
    })
end

local function spawnTrolley()
    local modelName = Config.PropModels[currentModel]
    if not modelName then return false end
    local hash = joaat(modelName)
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then
        notify(('Modello non disponibile: %s'):format(modelName), 'error')
        return false
    end
    lib.requestModel(hash)
    local coords = GetEntityCoords(PlayerPedId())
    local entity = CreateObject(hash, coords.x, coords.y, coords.z, true, true, false)
    SetModelAsNoLongerNeeded(hash)
    if entity == 0 or not DoesEntityExist(entity) then
        notify('Impossibile creare il prop.', 'error')
        return false
    end
    trolley = entity
    active.netId = nil
    SetEntityAsMissionEntity(entity, true, true)
    SetEntityInvincible(entity, true)
    applyTrolleyAttachment()

    local netId = NetworkGetNetworkIdFromEntity(entity)
    if not netId or netId == 0 then
        notify('Il carrello non ha un ID di rete valido.', 'error')
        return false
    end
    -- L'ID puo' cambiare proprietario quando il giocatore si allontana.
    SetNetworkIdCanMigrate(netId, true)
    local bound = false
    for attempt = 1, 15 do
        if lib.callback.await('mobile_cart:bindProp', false, active.uid, netId) then
            bound = true
            break
        end
        Wait(150)
    end
    if not bound then
        notify('Impossibile sincronizzare il carrello col server.', 'error')
        return false
    end
    active.netId = netId
    registerTarget(netId)
    playAnimation()
    return true
end

local function requestPark()
    if not active or active.mode ~= 'pushing' or busy then return end
    busy = true
    local entity = getTrolley()
    if not entity or not ensureControl(entity) then
        busy = false
        notify('Non riesco a controllare il carrello.', 'error')
        return
    end
    local result = lib.callback.await('mobile_cart:park', false, active.uid)
    if not result or not result.ok then
        busy = false
        notify(result and result.error or 'Impossibile lasciare il carrello.', 'error')
        return
    end

    -- Mantieni la posizione e la direzione prima di staccarlo dal ped.
    local coords = GetEntityCoords(entity)
    local heading = GetEntityHeading(entity)
    DetachEntity(entity, true, true)
    stopAnimation()
    SetEntityCollision(entity, true, true)
    FreezeEntityPosition(entity, false)
    SetEntityCoordsNoOffset(entity, coords.x, coords.y,
        coords.z + (Config.ParkHeightOffset or 0.0) + 0.1, false, false, false)
    SetEntityHeading(entity, heading)
    PlaceObjectOnGroundProperly(entity)
    FreezeEntityPosition(entity, true)

    active.mode = 'parked'
    setHint(false)
    busy = false
    notify('Carrello lasciato qui. Usa il target per spingerlo, aprirlo o riporlo.', 'success')
end

requestResume = function()
    if not active or active.mode ~= 'parked' or busy then return end
    if IsEntityDead(PlayerPedId()) or IsPedInAnyVehicle(PlayerPedId(), false) then
        notify('Devi essere vivo e a piedi.', 'error')
        return
    end
    busy = true
    local entity = getTrolley()
    if not entity or not ensureControl(entity) then
        busy = false
        notify('Carrello fuori portata: avvicinati e riprova.', 'error')
        return
    end
    local result = lib.callback.await('mobile_cart:resume', false, active.uid)
    if not result or not result.ok then
        busy = false
        notify(result and result.error or 'Impossibile riprendere il carrello.', 'error')
        return
    end
    active.mode = 'pushing'
    applyTrolleyAttachment()
    playAnimation()
    setHint(true)
    busy = false
    notify('Hai ripreso il carrello.', 'success')
end

requestStow = function()
    if not active or busy then return end
    busy = true
    local result = lib.callback.await('mobile_cart:stow', false, active.uid)
    busy = false
    if result and result.ok then
        cleanup()
        notify('Carrello riposto: il magazzino mantiene gli oggetti.', 'success')
    else
        notify(result and result.error or 'Impossibile riporre il carrello.', 'error')
    end
end

openStash = function()
    if not active or busy then return end
    busy = true
    local stash = lib.callback.await('mobile_cart:open', false)
    busy = false
    if not stash then
        notify('Avvicinati al carrello per aprire il magazzino.', 'error')
        return
    end
    exports.ox_inventory:openInventory('stash', stash)
end

local function requestDeploy(slot)
    if busy then return end
    if active then
        if active.mode == 'pushing' then
            requestPark()
        else
            notify('Il carrello e gia a terra: avvicinati e usa il target.', 'inform')
        end
        return
    end
    if IsPedInAnyVehicle(PlayerPedId(), false) or IsEntityDead(PlayerPedId()) then
        notify('Scendi dal veicolo prima di estrarre il carrello.', 'error')
        return
    end
    busy = true
    local result = lib.callback.await('mobile_cart:toggle', false, slot)
    if not result or not result.ok or result.action ~= 'deploy' then
        busy = false
        notify(result and result.error or 'Operazione non riuscita.', 'error')
        return
    end
    active = {uid = result.uid, slot = slot, mode = 'pushing'}
    if not spawnTrolley() then
        TriggerServerEvent('mobile_cart:cancel', active.uid)
        cleanup()
        busy = false
        return
    end
    busy = false
    setHint(true)
    notify('Carrello estratto. X = lascialo qui, E = magazzino.', 'success')
end

exports('useCart', function(_data, slot)
    if not slot or type(slot.slot) ~= 'number' then return end
    requestDeploy(slot.slot)
end)

RegisterCommand('mobilecart_open', function()
    if active and active.mode == 'pushing' then openStash() end
end, false)
RegisterKeyMapping('mobilecart_open', 'Carrello: apri magazzino mentre lo spingi', 'keyboard', 'E')

RegisterCommand('mobilecart_store', function()
    requestPark()
end, false)
RegisterKeyMapping('mobilecart_store', 'Carrello: lascia a terra', 'keyboard', 'X')

RegisterCommand('carrello_lascia', requestPark, false)
RegisterCommand('carrello_riponi', function() requestStow() end, false)
RegisterCommand('carrello_riprendi', function() requestResume() end, false)
RegisterCommand('carrello_modello', function()
    if not active or active.mode ~= 'pushing' or busy then
        notify('Devi prima spingere il carrello.', 'error')
        return
    end
    local choices = {}
    for i, model in ipairs(Config.PropModels) do
        choices[#choices + 1] = {
            title = (Config.PropLabels and Config.PropLabels[i]) or model,
            description = (i == currentModel and 'Attualmente selezionato: ' or 'Modello: ') .. model,
            icon = 'cart-shopping',
            onSelect = function()
                if not active or active.mode ~= 'pushing' or busy then return end
                busy = true
                deleteTrolley()
                stopAnimation()
                currentModel = i
                if not spawnTrolley() then
                    TriggerServerEvent('mobile_cart:cancel', active.uid)
                    cleanup()
                end
                busy = false
            end
        }
    end
    lib.registerContext({ id = 'mobile_cart_models', title = 'Modello del carrello', options = choices })
    lib.showContext('mobile_cart_models')
end, false)

-- Regola il prop in TEMPO REALE senza toccare il magazzino.
-- Esempio /carrello_offset 0 0.85 -0.8 180
-- I valori restano fino al riavvio del client; copiali in config.lua quando
-- la posizione ti soddisfa. /carrello_offset reset ripristina i valori.
RegisterCommand('carrello_offset', function(_, args)
    if not active or active.mode ~= 'pushing' or not getTrolley() then
        notify('Estrai prima il carrello.', 'error')
        return
    end

    local model = Config.PropModels[currentModel]
    if args[1] == 'reset' then
        perModelOffset[model] = nil
        applyTrolleyAttachment()
        notify('Posizione ripristinata dal config.', 'success')
        return
    end

    local x, y, z, rz = tonumber(args[1]), tonumber(args[2]), tonumber(args[3]), tonumber(args[4])
    if not x or not y or not z or not rz or math.abs(x) > 3 or math.abs(y) > 3
        or math.abs(z) > 3 or math.abs(rz) > 360 then
        notify('Uso: /carrello_offset x y z rz (es. 0 0.85 -0.80 180)', 'inform')
        return
    end
    local attach = modelAttach(model)
    attach.x, attach.y, attach.z, attach.rz = x, y, z, rz
    perModelOffset[model] = attach
    applyTrolleyAttachment()
    local line = ("['%s'] = { x = %.2f, y = %.2f, z = %.2f, rx = %.1f, ry = %.1f, rz = %.1f },")
        :format(model, attach.x, attach.y, attach.z, attach.rx, attach.ry, attach.rz)
    print('[mobile_cart_fivem] Salva in Config.ModelAttachOverrides: ' .. line)
    notify('Posizione aggiornata. Valori stampati nella console F8.', 'success')
end, false)

-- Cambia la posa senza modificare l'inventario.
-- /carrello_anim spingi|scatola|off oppure /carrello_anim 1|2|3
RegisterCommand('carrello_anim', function(_, args)
    if not active or active.mode ~= 'pushing' then
        notify('Devi prima spingere il carrello.', 'error')
        return
    end
    local options = Config.AnimationPresets or {}
    if #options == 0 then return end
    local a = tostring(args[1] or ''):lower()
    local index = tonumber(a)
    if a == 'spingi' then index = 1 end
    if a == 'scatola' then index = 2 end
    if a == 'off' then index = 3 end
    if not index then index = (currentAnimation % #options) + 1 end
    index = math.floor(index)
    if index < 1 or index > #options then
        notify('Uso: /carrello_anim spingi | scatola | off', 'error')
        return
    end
    stopAnimation()
    currentAnimation = index
    playAnimation()
    notify('Posa: ' .. (options[index].label or tostring(index)), 'success')
end, false)

-- Finestra di regolazione con 6 valori, senza editare il codice e fare restart.
-- Le modifiche sono locali; i valori per salvarle vengono stampati in F8.
RegisterCommand('carrello_regola', function()
    if not active or active.mode ~= 'pushing' or not getTrolley() then
        notify('Estrai prima il carrello.', 'error')
        return
    end
    local model = Config.PropModels[currentModel]
    local offset = modelAttach(model)
    local result = lib.inputDialog('Allinea il manico alle mani', {
        { type = 'number', label = 'Destra/sinistra (X)', default = offset.x, min = -3, max = 3, step = 0.05, required = true },
        { type = 'number', label = 'Avanti/indietro (Y)', default = offset.y, min = -3, max = 3, step = 0.05, required = true },
        { type = 'number', label = 'Altezza (Z)', default = offset.z, min = -3, max = 3, step = 0.05, required = true },
        { type = 'number', label = 'Inclinazione (RX)', default = offset.rx, min = -360, max = 360, step = 5, required = true },
        { type = 'number', label = 'Inclinazione (RY)', default = offset.ry, min = -360, max = 360, step = 5, required = true },
        { type = 'number', label = 'Rotazione orizzontale (RZ)', default = offset.rz, min = -360, max = 360, step = 15, required = true },
    })
    if not result then return end
    for i = 1, 6 do
        if type(result[i]) ~= 'number' then
            notify('Uno o piu valori non sono validi.', 'error')
            return
        end
    end
    perModelOffset[model] = {
        x = result[1], y = result[2], z = result[3],
        rx = result[4], ry = result[5], rz = result[6],
    }
    applyTrolleyAttachment()
    local value = perModelOffset[model]
    local line = ("['%s'] = { x = %.2f, y = %.2f, z = %.2f, rx = %.1f, ry = %.1f, rz = %.1f },")
        :format(model, value.x, value.y, value.z, value.rx, value.ry, value.rz)
    print('[mobile_cart_fivem] Copia in Config.ModelAttachOverrides: ' .. line)
    notify('Regolazione applicata. Copia i valori dalla console F8 per salvarla.', 'success')
end, false)


RegisterNetEvent('mobile_cart:stopped', function()
    cleanup()
end)

CreateThread(function()
    while true do
        if not active then
            Wait(600)
        elseif busy then
            -- Evita cancellazioni automatiche mentre cambia modello / stato.
            Wait(50)
        elseif active.mode == 'parked' then
            -- Il carrello rimane nel mondo anche se il proprietario si allontana.
            Wait(600)
        else
            local ped = PlayerPedId()
            DisableControlAction(0, 21, true)
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 44, true)
            local entity = getTrolley()
            if not entity or not DoesEntityExist(entity) then
                local uid = active.uid
                cleanup()
                TriggerServerEvent('mobile_cart:cancel', uid)
            elseif IsEntityDead(ped) or IsPedInAnyVehicle(ped, false)
                or IsPedRagdoll(ped) or not IsEntityAttachedToEntity(entity, ped) then
                -- Non distruggere il carrello: lascialo fermo sul posto.
                local now = GetGameTimer()
                if now - lastAutoParkAttempt > 1500 then
                    lastAutoParkAttempt = now
                    CreateThread(requestPark)
                end
            else
                local anim = selectedAnimation()
                if anim and anim.enabled and not IsEntityPlayingAnim(ped,
                    anim.dict, anim.clip, 3) and not IsNuiFocused() then
                    playAnimation()
                end
            end
            Wait(0)
        end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name == GetCurrentResourceName() then cleanup() end
end)

CartConfig = {}
local Config = CartConfig

-- NON modificare nome item/stash: i vecchi carrelli e oggetti rimangono validi.
Config.ItemName = 'carrello'
Config.StashSlots = 20
Config.StashMaxWeight = 40000 -- grammi = 40 kg

-- Prima scelta: il carrello ORIGINALE richiesto, non quello metallico vuoto.
-- Gli altri modelli rimangono selezionabili con /carrello_modello.
Config.PropModels = {
    'prop_skid_trolley_2', -- originale (piante/sacchi)
    'prop_skid_trolley_1', -- originale alternativo
    'prop_rub_trolley02a', -- supermercato vuoto
    'prop_rub_trolley01a', -- plastica
}
Config.PropLabels = {
    'Originale: trolley 2',
    'Originale: trolley 1',
    'Supermercato vuoto',
    'Plastica',
}

-- Gli oggetti sono collegati al PED, quindi il posizionamento e la rotazione
-- devono far arrivare il MANICO all'altezza delle mani del personaggio.
-- rz = 180 ruota il manico verso il ped, se il prop lo prevede.
-- Usa /carrello_regola mentre lo spingi per centrarlo sul tuo modello ped.
Config.Attach = {
    x = 0.0,
    y = 0.85,
    z = -0.80,
    rx = 0.0,
    ry = 0.0,
    rz = 180.0,
}

-- Correzioni INIZIALI per ogni modello. Da affinare direttamente in game.
Config.ModelAttachOverrides = {
    ['prop_skid_trolley_2'] = { x = 0.0, y = 1.3, z = -0.40, rx = 0.0, ry = 0.0, rz = 180.0 },
    ['prop_skid_trolley_1'] = { x = 0.0, y = 1.3, z = -0.40, rx = 0.0, ry = 0.0, rz = 180.0 },
    ['prop_rub_trolley02a'] = { x = 0.0, y = 1.3, z = -0.40, rx = 0.0, ry = 0.0, rz = 180.0 },
    ['prop_rub_trolley01a'] = { x = 0.0, y = 1.3, z = -0.40, rx = 0.0, ry = 0.0, rz = 180.0 },
}

-- L'animazione precedente (box_carry) fa tenere un pacco in mano,
-- quindi NON va bene per spingere il carrello.
-- Questa e' una animazione di spinta usata anche nei resource di vehicle push.
-- 49 = loop + upper body + task secondario: puoi continuare a camminare.
-- Non e' l'animazione proprietaria del Cylex Menu: per quella servono dict/clip.
Config.AnimationPresets = {
    {
        label = 'Spingi (consigliata)',
        enabled = true,
        dict = 'missfinale_c2ig_11',
        clip = 'pushcar_offcliff_m',
        flag = 49,
    },
    {
        label = 'Animazione originale (scatola)',
        enabled = true,
        dict = 'anim@heists@box_carry@',
        clip = 'idle',
        flag = 49,
    },
    {
        label = 'Nessuna animazione (test posizione)',
        enabled = false,
    },
}
Config.Animation = Config.AnimationPresets[1] -- fallback compatibilita'
Config.NotificationPosition = 'top'

-- Distanza consentita per usare il target e il magazzino.
Config.InteractDistance = 3.0
-- Eventuale piccolo aggiustamento dell'altezza quando si lascia il prop.
Config.ParkHeightOffset = 0.0

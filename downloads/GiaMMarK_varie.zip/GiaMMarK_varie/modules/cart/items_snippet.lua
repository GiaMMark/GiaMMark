-- AGGIUNGERE questa entry alla tabella in ox_inventory/data/items.lua.
-- Non caricare questo file direttamente come resource.
['carrello'] = {
    label = 'Carrello della spesa',
    weight = 2500, -- peso dell'item nel proprio inventario (grammi)
    stack = false,
    close = true,
    consume = 0,   -- NON consumare l'item quando si usa
    description = 'Carrello pieghevole con magazzino personale',
    client = {
        image = 'mobile_cart.png',
        export = 'GiaMMarK_varie.useCart'
    }
},

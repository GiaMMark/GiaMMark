local Config = CartConfig
local Ox = exports.ox_inventory
local active = {}        -- [source] = { uid, slot, stash, entity, mode }
local activeByUid = {}   -- [uid] = source
local registered = {}    -- stash registrati durante l'esecuzione
local counter = 0

math.randomseed(os.time() + GetGameTimer())

local function newUid()
    counter = counter + 1
    return ('%08x%08x%08x%08x'):format(
        os.time(), math.random(0, 0x7fffffff), math.random(0, 0x7fffffff), counter
    )
end

local function isValidUid(uid)
    return type(uid) == 'string' and #uid == 32 and uid:match('^[%da-f]+$') ~= nil
end

local function registerStash(uid)
    local id = 'mc_cart_' .. uid
    if not registered[id] then
        Ox:RegisterStash(id, 'Carrello della spesa', Config.StashSlots,
            Config.StashMaxWeight, nil)
        registered[id] = true
    end
    return id
end

local function getCartSlot(src, slot)
    if type(slot) ~= 'number' or slot < 1 or slot % 1 ~= 0 then return end
    local item = Ox:GetSlot(src, slot)
    if not item or item.name ~= Config.ItemName or item.count ~= 1 then return end
    return item
end

local function isCarried(src, state)
    if not state then return false end
    local item = getCartSlot(src, state.slot)
    return item and item.metadata and item.metadata.cart_uid == state.uid or false
end

local function playerIsValid(src)
    local ped = GetPlayerPed(src)
    if ped == 0 or GetEntityHealth(ped) <= 0 or GetVehiclePedIsIn(ped, false) ~= 0 then
        return false
    end
    return true
end

local function nearTrolley(src, state, maxDistance)
    if not state or not state.entity or not DoesEntityExist(state.entity) then return false end
    local ped = GetPlayerPed(src)
    if ped == 0 then return false end
    return #(GetEntityCoords(ped) - GetEntityCoords(state.entity)) <= maxDistance
end

local function canAccess(src, stashId)
    local state = active[src]
    return state ~= nil and state.stash == stashId and isCarried(src, state)
        and playerIsValid(src) and nearTrolley(src, state, Config.InteractDistance)
end

local function removeProp(state)
    if not state or not state.entity then return end
    local entity = state.entity
    state.entity = nil
    if DoesEntityExist(entity) then
        local model = GetEntityModel(entity)
        for i = 1, #Config.PropModels do
            if model == joaat(Config.PropModels[i]) then
                DeleteEntity(entity)
                break
            end
        end
    end
end

local function stopCart(src)
    local state = active[src]
    if not state then return end
    active[src] = nil
    if activeByUid[state.uid] == src then activeByUid[state.uid] = nil end
    removeProp(state)
    TriggerClientEvent('ox_inventory:closeInventory', src)
    TriggerClientEvent('mobile_cart:stopped', src)
end

-- Gli item nuovi hanno ciascuno un proprio UID. Per gli item gia' esistenti
-- senza metadata, l'UID viene assegnato alla prima estrazione.
Ox:registerHook('createItem', function(payload)
    local metadata = payload.metadata or {}
    metadata.cart_uid = newUid()
    metadata.description = 'ID carrello: ' .. metadata.cart_uid:sub(-8)
    return metadata
end, { itemFilter = { [Config.ItemName] = true } })

-- Nessuna apertura o trasferimento senza item valido e distanza dal prop.
Ox:registerHook('openInventory', function(payload)
    if payload.inventoryType == 'stash'
        and type(payload.inventoryId) == 'string'
        and payload.inventoryId:sub(1, 8) == 'mc_cart_' then
        return canAccess(payload.source, payload.inventoryId)
    end
end, { inventoryFilter = { '^mc_cart_' } })

local function inventoryId(value)
    if type(value) == 'table' then return value.id end
    return value
end

Ox:registerHook('swapItems', function(payload)
    local src = payload.source
    local from = inventoryId(payload.fromInventory)
    local to = inventoryId(payload.toInventory)
    local fromCart = type(from) == 'string' and from:sub(1, 8) == 'mc_cart_'
    local toCart = type(to) == 'string' and to:sub(1, 8) == 'mc_cart_'

    if fromCart and not canAccess(src, from) then return false end
    if toCart and not canAccess(src, to) then return false end

    local fromItem = payload.fromSlot
    local toItem = type(payload.toSlot) == 'table' and payload.toSlot or nil
    local movedCart = (fromItem and fromItem.name == Config.ItemName)
        or (toItem and toItem.name == Config.ItemName)

    if movedCart then
        if fromCart or toCart then return false end -- no carrelli dentro carrelli
        local firstUid = fromItem and fromItem.metadata and fromItem.metadata.cart_uid
        local secondUid = toItem and toItem.metadata and toItem.metadata.cart_uid
        if (firstUid and activeByUid[firstUid]) or (secondUid and activeByUid[secondUid]) then
            return false
        end
    end
end)

lib.callback.register('mobile_cart:toggle', function(src, slot)
    local item = getCartSlot(src, slot)
    if not item then return { ok = false, error = 'Item carrello non trovato.' } end

    local metadata = item.metadata or {}
    local uid = metadata.cart_uid
    if not isValidUid(uid) then
        uid = newUid()
        metadata.cart_uid = uid
        metadata.description = 'ID carrello: ' .. uid:sub(-8)
        Ox:SetMetadata(src, slot, metadata)
    end

    local current = active[src]
    if current then
        return { ok = false, error = 'Hai gia un carrello fuori. Usa X per lasciarlo o il target per riprenderlo.' }
    end
    if activeByUid[uid] then
        return { ok = false, error = 'Questo carrello e gia in uso.' }
    end
    if not playerIsValid(src) then
        return { ok = false, error = 'Devi essere vivo e a piedi.' }
    end

    local stash = registerStash(uid)
    active[src] = { uid = uid, slot = slot, stash = stash, mode = 'pushing' }
    activeByUid[uid] = src
    return { ok = true, action = 'deploy', uid = uid }
end)

-- Handshake: il client riprova finche' OneSync vede effettivamente il prop.
-- Controlliamo proprietario del network entity, modello e prossimita'.
lib.callback.register('mobile_cart:bindProp', function(src, uid, netId)
    local state = active[src]
    if not state or state.uid ~= uid or state.mode ~= 'pushing' or not isCarried(src, state)
        or type(netId) ~= 'number' or netId < 1 then return false end
    local entity = NetworkGetEntityFromNetworkId(netId)
    if entity == 0 or not DoesEntityExist(entity) or GetEntityType(entity) ~= 3 then return false end
    if NetworkGetEntityOwner(entity) ~= src then return false end

    local validModel = false
    for i = 1, #Config.PropModels do
        if GetEntityModel(entity) == joaat(Config.PropModels[i]) then
            validModel = true
            break
        end
    end
    if not validModel or not nearTrolley(src, { entity = entity }, 5.0) then return false end

    if state.entity and state.entity ~= entity then removeProp(state) end
    state.entity = entity
    -- Non far sparire il carrello mentre il proprietario si allontana.
    -- Si elimina comunque su logout/riavvio/reimballaggio.
    SetEntityOrphanMode(entity, 2)
    return true
end)

lib.callback.register('mobile_cart:park', function(src, uid)
    local state = active[src]
    if not state or state.uid ~= uid or not isCarried(src, state)
        or state.mode ~= 'pushing' or not nearTrolley(src, state, 5.0) then
        return { ok = false, error = 'Non puoi lasciare questo carrello.' }
    end
    state.mode = 'parked'
    return { ok = true }
end)

lib.callback.register('mobile_cart:resume', function(src, uid)
    local state = active[src]
    if not state or state.uid ~= uid or not isCarried(src, state)
        or state.mode ~= 'parked' or not playerIsValid(src)
        or not nearTrolley(src, state, Config.InteractDistance) then
        return { ok = false, error = 'Avvicinati al tuo carrello per riprenderlo.' }
    end
    state.mode = 'pushing'
    return { ok = true }
end)

lib.callback.register('mobile_cart:stow', function(src, uid)
    local state = active[src]
    if not state or state.uid ~= uid or not isCarried(src, state)
        or not nearTrolley(src, state, Config.InteractDistance) then
        return { ok = false, error = 'Avvicinati al carrello per riporlo.' }
    end
    stopCart(src)
    return { ok = true }
end)

lib.callback.register('mobile_cart:open', function(src)
    local state = active[src]
    if state and canAccess(src, state.stash) then return state.stash end
    return false
end)

RegisterNetEvent('mobile_cart:cancel', function(uid)
    local src = source
    local state = active[src]
    if state and state.uid == uid then stopCart(src) end
end)

AddEventHandler('playerDropped', function()
    stopCart(source)
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    for src in pairs(active) do stopCart(src) end
end)

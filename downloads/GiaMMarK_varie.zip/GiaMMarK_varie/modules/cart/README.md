# Mobile Cart FiveM v1.3 — Lascia a terra e recupera con ox_target

**Partenza:** ZIP inviato dall'utente; mantiene modello, animazioni, offsets, inventario e metadata originali. Questo aggiornamento aggiunge lo stato **parcheggiato** e l'interazione con **ox_target**.

## Requisiti

- `ox_lib`
- `ox_inventory`
- `ox_target` (obbligatorio per il target)
- OneSync (per la sincronizzazione del prop tra i giocatori)

Nel server.cfg l'ordine consigliato e':

```cfg
ensure ox_lib
ensure ox_inventory
ensure ox_target
ensure mobile_cart_fivem
```

## Utilizzo

1. Usa l'item nell'inventario per **estrarre e spingere** il carrello.
2. Mentre lo spingi, **X** (oppure `/carrello_lascia`) per **lasciarlo fermo sul posto**. Il prop resta nel mondo: **non viene cancellato**.
3. Avvicinati al prop parcheggiato e usa **ox_target (occhio)**. Seleziona:
   - **Riprendi e spingi il carrello**: lo riaggancia al ped, riparte l'animazione;
   - **Apri magazzino**: apri lo stash mentre il carrello resta parcheggiato;
   - **Riponi il carrello nell'inventario**: elimina il prop dal mondo e rende nuovamente disponibile lo stesso item nello zaino.
4. Puoi anche digitare `/carrello_riponi` mentre lo spingi o da vicino quando e' parcheggiato; `/carrello_riprendi` fa ripartire la spinta quando sei vicino.
5. **E** apre il magazzino *quando lo stai spingendo*. Mentre e' parcheggiato usa il target.
6. Usare di nuovo l'item mentre lo spingi lo **lascia a terra**, non lo distrugge. Usare l'item mentre e' parcheggiato mostra un messaggio per usare il target.

Il **target appare solo al proprietario** dell'item. Un altro giocatore non puo' sottrarre quel magazzino tramite questo script.

## Inventario

- `Config.ItemName = 'carrello'` nel `config.lua` **del tuo ZIP**. La definizione in `items_snippet.lua` e' ora coerente con questo nome. Se il tuo item ha un nome diverso, modifica la configurazione e la voce in ox_inventory insieme.
- Slot: 20; peso massimo: 40.000 grammi (40 kg), modificabili in `config.lua`.
- I dati del magazzino rimangono nello stash `mc_cart_<uid>` di `ox_inventory` anche dopo il riposizionamento, il ritiro o il logout.
- L'item non viene duplicato: resta in ox_inventory durante il trasporto e mentre e' parcheggiato, ma i tentativi di trasferirlo sono bloccati mentre e' estratto.
- L'ID dell'item (`cart_uid`) e il nome dello stash non sono cambiati: **non cancellare il database** di ox_inventory per aggiornare lo script.

## Configurazione prop / animazioni

- Modello predefinito: `prop_skid_trolley_2`, come nel tuo ZIP. `prop_skid_trolley_1` e gli altri rimangono selezionabili.
- `/carrello_modello` — cambia modello (solo mentre stai spingendo il carrello).
- `/carrello_regola` — offsets di posizione e rotazione (solo mentre lo spingi).
- `/carrello_offset x y z rz` oppure `/carrello_offset reset` — regolazione manuale.
- `/carrello_anim spingi|scatola|off` — scelta animazione.
- `Config.InteractDistance = 3.0` — raggio massimo del target e dell'inventario.
- `Config.ParkHeightOffset = 0.0` — correzione opzionale altezza prop lasciato a terra.

## Installazione aggiornamento

1. Esegui un backup della cartella `mobile_cart_fivem` e sostituiscila con quella di questo ZIP (stesso nome cartella).
2. Verifica di avere `ox_target` installato e avviato prima del carrello.
3. Non creare un nuovo item se e' gia' registrato. Per installazioni nuove, incolla la voce `['carrello']` di `items_snippet.lua` in `ox_inventory/data/items.lua`.
4. La PNG e' in `ox_inventory_images/mobile_cart.png`; copiala in `ox_inventory/web/images/`. Lo snippet indica `client.image = 'mobile_cart.png'` perché il nome dell'item è `carrello`.
5. **Riavvia il server** (raccomandato dopo aver modificato l'item), oppure `restart mobile_cart_fivem` se le dipendenze erano gia' attive.

## Limiti noti e test in gioco

- Il prop parcheggiato rimane sul posto mentre il proprietario e' connesso, anche se cammina via. **A logout, stop della risorsa o riavvio del server il prop nel mondo viene eliminato**; il contenuto dello stash rimane salvato nell'inventario ox_inventory e riappare riestraendo l'item.
- Per rendere i carrelli parcheggiati persistenti **anche dopo logout/reboot** serve una registrazione aggiuntiva in database del prop/dei suoi proprietari, non prevista in questa versione.
- Un'altra risorsa che elimina gli oggetti del mondo o una configurazione OneSync particolare puo' interferire con i prop parcheggiati.
- I modelli originali GTA V hanno pivot diversi: verifica visivamente l'appoggio a terra e l'allineamento; correggi con `Config.ParkHeightOffset` e `/carrello_regola`.
- **Non testato su un server FiveM reale**. Esegui almeno: estrai → X → target riprendi → X → target stash → target riponi → estrai, poi prova allontanamento/ritorno e logout/login.

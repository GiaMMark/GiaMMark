local Config = PayphoneConfig
local SendNUIMessage, RegisterNUICallback, SetNuiFocus = GiaMMarKUI.bind('payphones')
local registeredTarget = nil
local registeredZones = {}
local dialOpen = false
local selectedPhone = nil
local activePhone = nil
local lastNumber = nil
local callPhase = 'ringing'
local requestPending = false
local grid = {}

local function validCoords(pos)
    if not pos then return false end
    local x, y, z = pos.x, pos.y, pos.z
    return type(x) == 'number' and type(y) == 'number' and type(z) == 'number'
        and x == x and y == y and z == z
        and math.abs(x) < 10000 and math.abs(y) < 10000 and math.abs(z) < 2000
end

local function toPlainCoords(pos)
    if not validCoords(pos) then return nil end
    return {x = pos.x, y = pos.y, z = pos.z}
end

local function distanceSq(a, b)
    local x, y, z = a.x - b.x, a.y - b.y, a.z - b.z
    return x * x + y * y + z * z
end

local function gridKey(x, y, z)
    return ('%d:%d:%d'):format(math.floor(x / 12), math.floor(y / 12), math.floor(z / 12))
end

for id, loc in ipairs(PhoneLocations) do
    local key = gridKey(loc.x, loc.y, loc.z)
    grid[key] = grid[key] or {}
    grid[key][#grid[key] + 1] = {id = id, coords = loc}
end

-- IMPORTANT: ox_target already selects the model. NEVER call GetEntityModel here.
-- No geographical whitelist is applied in canInteract: it used to hide almost all booths.
local function knownBoothAt(pos)
    local cx, cy, cz = math.floor(pos.x / 12), math.floor(pos.y / 12), math.floor(pos.z / 12)
    local bestId, bestSq = nil, Config.ClientPropMatchDistance * Config.ClientPropMatchDistance
    for ix = -1, 1 do
        for iy = -1, 1 do
            for iz = -1, 1 do
                local key = ('%d:%d:%d'):format(cx + ix, cy + iy, cz + iz)
                for _, booth in ipairs(grid[key] or {}) do
                    local d = distanceSq(pos, booth.coords)
                    if d < bestSq then
                        bestId, bestSq = booth.id, d
                    end
                end
            end
        end
    end
    return bestId
end

local function conflictName()
    for _, resource in ipairs(Config.ConflictingResources) do
        if GetResourceState(resource) == 'started' then return resource end
    end
    return nil
end

local function validPed()
    local ped = PlayerPedId()
    return ped ~= 0 and not IsEntityDead(ped) and not IsPedInAnyVehicle(ped, false)
end

local function notify(message, kind)
    lib.notify({
        title = 'TELEFONO PUBBLICO',
        description = message,
        type = kind or 'info',
        position = Config.NotifyPosition or 'top-right',
        icon = (kind == 'error' and 'triangle-exclamation' or 'phone'),
        duration = kind == 'error' and 5500 or 3600
    })
end

local function closeDial()
    dialOpen = false
    selectedPhone = nil
    SetNuiFocus(false, false)
    SendNUIMessage({action = 'close'})
end

local function targetPosition(entity, coords)
    if validCoords(coords) then return toPlainCoords(coords) end
    -- qb-target does not provide coords to its action. Guard against invalid handles.
    if type(entity) ~= 'number' or entity == 0 then return nil end
    local okExists, exists = pcall(DoesEntityExist, entity)
    if not okExists or not exists then return nil end
    local okCoords, found = pcall(GetEntityCoords, entity)
    if not okCoords then return nil end
    return toPlainCoords(found)
end

local function dialEntity(entity, coords)
    if dialOpen or activePhone or requestPending or not validPed() or not GiaMMarKUI.available('payphones') then return end
    local conflicting = conflictName()
    if conflicting then return notify('Telefoni pubblici gestiti da ' .. conflicting) end
    local pos = targetPosition(entity, coords)
    if not pos then return notify('Impossibile rilevare la posizione della cabina.') end
    local id = knownBoothAt(pos)
    selectedPhone = {id = id or 0, coords = pos}
    dialOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({action = 'open', minDigits = Config.MinDigits, maxDigits = Config.MaxDigits})
end

local function hangupEntity(entity, coords)
    if not activePhone then return end
    local pos = targetPosition(entity, coords)
    if not pos or distanceSq(pos, activePhone.coords) > Config.ClientHangupMatchDistance ^ 2 then
        return notify('Usa la stessa cabina con cui hai iniziato la chiamata.')
    end
    TriggerServerEvent('public_payphones:hangup')
end

local function canDial()
    return not dialOpen and not activePhone and not requestPending and not conflictName() and validPed()
end

local function canViewCall()
    return activePhone ~= nil and not dialOpen and not conflictName() and validPed()
end

local function viewCall(entity, coords)
    if not canViewCall() or not GiaMMarKUI.available('payphones') then return end
    local pos = targetPosition(entity, coords)
    if not pos or distanceSq(pos, activePhone.coords) > Config.ClientHangupMatchDistance ^ 2 then
        return notify('Usa il telefono pubblico da cui hai chiamato.', 'warning')
    end
    dialOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({action = 'openCall', number = lastNumber or '', phase = callPhase})
end

local function canHangup()
    return activePhone ~= nil and not dialOpen and not conflictName() and validPed()
end

local function chooseTarget()
    if Config.Target == 'auto' then
        if GetResourceState('ox_target') == 'started' then return 'ox_target' end
        if GetResourceState('qb-target') == 'started' then return 'qb-target' end
        return nil
    end
    if GetResourceState(Config.Target) == 'started' then return Config.Target end
    return nil
end

-- Extra MLO entries are authoritative whitelist positions with their own target zones.
-- Some MLO telephones are built into large collision meshes, so addModel cannot see them.
local function unregisterTarget()
    if not registeredTarget then return end
    local target = registeredTarget
    registeredTarget = nil
    if GetResourceState(target) ~= 'started' then
        registeredZones = {}
        return
    end
    if target == 'ox_target' then
        exports.ox_target:removeModel(Config.Models, {'public_payphones_dial', 'public_payphones_view', 'public_payphones_hangup'})
        for _, zone in ipairs(registeredZones) do
            exports.ox_target:removeZone(zone)
        end
    elseif target == 'qb-target' then
        exports['qb-target']:RemoveTargetModel(Config.Models, {'Effettua chiamata gratuita', 'Controlla chiamata in corso', 'Riaggancia telefono pubblico'})
        for _, zone in ipairs(registeredZones) do
            exports['qb-target']:RemoveZone(zone)
        end
    end
    registeredZones = {}
end

local function registerManualZones(target)
    for id, loc in ipairs(PhoneLocations) do
        if loc.manual and validCoords(loc) then
            local pos = toPlainCoords(loc)
            local radius = math.max(0.3, math.min(1.5, tonumber(loc.radius) or Config.CustomZoneRadius or 0.8))
            if target == 'ox_target' then
                local zoneId = exports.ox_target:addSphereZone({
                    coords = vector3(pos.x, pos.y, pos.z + 0.65),
                    radius = radius,
                    debug = false,
                    options = {
                        {
                            name = 'public_payphones_custom_dial_' .. id,
                            icon = 'fa-solid fa-phone',
                            label = 'Effettua chiamata gratuita',
                            distance = Config.TargetDistance,
                            canInteract = function() return canDial() end,
                            onSelect = function() dialEntity(nil, pos) end
                        },
                        {
                            name = 'public_payphones_custom_view_' .. id,
                            icon = 'fa-solid fa-display',
                            label = 'Controlla chiamata in corso',
                            distance = Config.TargetDistance,
                            canInteract = function() return canViewCall() end,
                            onSelect = function() viewCall(nil, pos) end
                        },
                        {
                            name = 'public_payphones_custom_hangup_' .. id,
                            icon = 'fa-solid fa-phone-slash',
                            label = 'Riaggancia telefono pubblico',
                            distance = Config.TargetDistance,
                            canInteract = function() return canHangup() end,
                            onSelect = function() hangupEntity(nil, pos) end
                        }
                    }
                })
                if zoneId then registeredZones[#registeredZones + 1] = zoneId end
            elseif target == 'qb-target' then
                local zoneName = ('public_payphones_custom_%d'):format(id)
                exports['qb-target']:AddCircleZone(zoneName, vector3(pos.x, pos.y, pos.z + 0.65), radius, {
                    name = zoneName, useZ = true, debugPoly = false
                }, {
                    options = {
                        {
                            icon = 'fas fa-phone',
                            label = 'Effettua chiamata gratuita',
                            action = function() dialEntity(nil, pos) end,
                            canInteract = function() return canDial() end
                        },
                        {
                            icon = 'fas fa-display',
                            label = 'Controlla chiamata in corso',
                            action = function() viewCall(nil, pos) end,
                            canInteract = function() return canViewCall() end
                        },
                        {
                            icon = 'fas fa-phone-slash',
                            label = 'Riaggancia telefono pubblico',
                            action = function() hangupEntity(nil, pos) end,
                            canInteract = function() return canHangup() end
                        }
                    },
                    distance = Config.TargetDistance
                })
                registeredZones[#registeredZones + 1] = zoneName
            end
        end
    end
end

local function registerTarget()
    if conflictName() then
        unregisterTarget()
        return
    end
    local target = chooseTarget()
    if target == registeredTarget then return end
    if registeredTarget then unregisterTarget() end
    if not target then return end

    if target == 'ox_target' then
        exports.ox_target:addModel(Config.Models, {
            {
                name = 'public_payphones_dial',
                icon = 'fa-solid fa-phone',
                label = 'Effettua chiamata gratuita',
                distance = Config.TargetDistance,
                canInteract = function() return canDial() end,
                onSelect = function(data) dialEntity(data.entity, data.coords) end
            },
            {
                name = 'public_payphones_view',
                icon = 'fa-solid fa-display',
                label = 'Controlla chiamata in corso',
                distance = Config.TargetDistance,
                canInteract = function() return canViewCall() end,
                onSelect = function(data) viewCall(data.entity, data.coords) end
            },
            {
                name = 'public_payphones_hangup',
                icon = 'fa-solid fa-phone-slash',
                label = 'Riaggancia telefono pubblico',
                distance = Config.TargetDistance,
                canInteract = function() return canHangup() end,
                onSelect = function(data) hangupEntity(data.entity, data.coords) end
            }
        })
    elseif target == 'qb-target' then
        exports['qb-target']:AddTargetModel(Config.Models, {
            options = {
                {
                    icon = 'fas fa-phone',
                    label = 'Effettua chiamata gratuita',
                    action = function(entity) dialEntity(entity) end,
                    canInteract = function() return canDial() end
                },
                {
                    icon = 'fas fa-display',
                    label = 'Controlla chiamata in corso',
                    action = function(entity) viewCall(entity) end,
                    canInteract = function() return canViewCall() end
                },
                {
                    icon = 'fas fa-phone-slash',
                    label = 'Riaggancia telefono pubblico',
                    action = function(entity) hangupEntity(entity) end,
                    canInteract = function() return canHangup() end
                }
            },
            distance = Config.TargetDistance
        })
    end
    registeredTarget = target
    registerManualZones(target)
    print(('[public_payphones] Target registrato con %s (%d modelli, %d zone MLO).'):format(target, #Config.Models, #registeredZones))
end

RegisterCommand('payphoneclose', function()
    closeDial()
end, false)

RegisterCommand('payphonehangup', function()
    if activePhone then
        TriggerServerEvent('public_payphones:hangup')
    else
        notify('Nessuna chiamata attiva.', 'warning')
    end
end, false)

-- Used to collect positions for payphones that are part of custom MLO geometry.
-- Does not raycast or call GetEntityModel (previously caused native exceptions).
RegisterCommand('payphonecoords', function()
    local ped = PlayerPedId()
    if ped == 0 then return end
    local pos = GetEntityCoords(ped)
    if not validCoords(pos) then return end
    local value = ('{ x = %.3f, y = %.3f, z = %.3f, radius = 0.8 },'):format(pos.x, pos.y, pos.z)
    print('[public_payphones] Incolla in Config.ExtraPayphones: ' .. value)
    notify('Coordinate stampate in F8. Copiale in config.lua / ExtraPayphones.', 'info')
end, false)

-- F8: payphonedebug ; does not use GetEntityModel, safe even with invalid raycast handles.
RegisterCommand('payphonedebug', function()
    local target = chooseTarget() or 'NESSUNO'
    local conflict = conflictName() or 'nessuno'
    local ped = PlayerPedId()
    local coords = ped ~= 0 and GetEntityCoords(ped) or nil
    local nearest = 'n/d'
    if validCoords(coords) then
        local minSq = math.huge
        for _, loc in ipairs(PhoneLocations) do
            local dsq = distanceSq(coords, loc)
            if dsq < minSq then minSq = dsq end
        end
        nearest = ('%.1fm'):format(math.sqrt(minSq))
    end
    print(('[public_payphones] Target=%s | registrato=%s | conflitto=%s | whitelist=%d | cabina lista piu vicina=%s | consenti cabine fuori lista=%s'):format(
        target, tostring(registeredTarget), conflict, #PhoneLocations, nearest, tostring(Config.AllowUnlistedBooths)))
    print(('[public_payphones] Modelli registrati: %d | zone personalizzate registrate: %d. Per telefoni custom usa payphonecoords.'):format(#Config.Models, #registeredZones))
    notify('Payphone debug: controlla F8. Apri target con ALT sinistro.', 'info')
end, false)

RegisterNUICallback('close', function(_, cb)
    closeDial()
    cb({ok = true})
end)

RegisterNUICallback('dial', function(data, cb)
    local selected = selectedPhone
    if not dialOpen or not selected or activePhone or requestPending then
        cb({ok = false, error = 'Telefono non disponibile.'})
        return
    end
    local raw = data and data.number
    if type(raw) ~= 'string' then
        cb({ok = false, error = 'Inserisci un numero valido.'})
        return
    end
    local number = raw:gsub('[%s%+%(%)%-]', '')
    if not number:match('^%d+$') or #number < Config.MinDigits or #number > Config.MaxDigits then
        cb({ok = false, error = 'Numero non valido.'})
        return
    end
    requestPending = true
    lastNumber = number
    SendNUIMessage({action = 'sending', number = number})
    TriggerServerEvent('public_payphones:requestCall', selected.id, number, selected.coords)
    cb({ok = true})
    SetTimeout(Config.DialRequestTimeoutMs or 15000, function()
        if not requestPending then return end
        requestPending = false
        notify('La richiesta non ha ricevuto risposta dal server. Controlla console e LB Phone.', 'error')
        if dialOpen then SendNUIMessage({action = 'error', message = 'Connessione non riuscita. Riprova.'}) end
    end)
end)

RegisterNUICallback('hangup', function(_, cb)
    if activePhone then
        TriggerServerEvent('public_payphones:hangup')
    else
        notify('Nessuna chiamata attiva da riagganciare.', 'warning')
    end
    cb({ok = true})
end)

RegisterNetEvent('public_payphones:result', function(ok, message, phoneId, boothCoords, number)
    requestPending = false
    if ok and validCoords(boothCoords) then
        activePhone = {id = phoneId, coords = toPlainCoords(boothCoords)}
        lastNumber = number or lastNumber
        callPhase = 'ringing'
        if dialOpen then SendNUIMessage({action = 'call', number = lastNumber or '', phase = 'ringing'}) end
        notify(message or 'Chiamata inoltrata tramite LB Phone.', 'success')
    else
        if dialOpen then SendNUIMessage({action = 'error', message = message or 'LB Phone non ha avviato la chiamata.'}) end
        notify(message or 'Chiamata non disponibile.', 'error')
    end
end)

RegisterNetEvent('public_payphones:callState', function(phase)
    if not activePhone then return end
    callPhase = phase == 'answered' and 'answered' or 'ringing'
    if dialOpen then SendNUIMessage({action = 'state', phase = callPhase}) end
    if callPhase == 'answered' then notify('La chiamata è stata risposta.', 'success') end
end)

RegisterNetEvent('public_payphones:callFinished', function(reason)
    activePhone = nil
    requestPending = false
    lastNumber = nil
    callPhase = 'ringing'
    if dialOpen then closeDial() end
    notify(reason or 'Chiamata terminata.', 'info')
end)

CreateThread(function()
    Wait(900)
    registerTarget()
    if not registeredTarget then
        print('[public_payphones] ATTENZIONE: target non disponibile oppure risorsa di telefoni pubblici in conflitto. Usa F8: payphonedebug')
    end
    while true do
        Wait(5000)
        registerTarget()
    end
end)

AddEventHandler('onClientResourceStart', function(resource)
    if resource == 'ox_target' or resource == 'qb-target' then
        Wait(300)
        registerTarget()
    end
    for _, name in ipairs(Config.ConflictingResources) do
        if resource == name then unregisterTarget() end
    end
end)

AddEventHandler('onClientResourceStop', function(resource)
    if resource == registeredTarget then
        registeredTarget = nil
        registeredZones = {} -- target resource was stopped and discarded its zones
    end
    if resource == GetCurrentResourceName() then
        unregisterTarget()
        if dialOpen then closeDial() end
    end
end)

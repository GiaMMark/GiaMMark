#!/usr/bin/env python3
"""Optional build-time import of base-map public phone booths.

Run once on your own PC/server (Python 3, Internet required):
    python tools/import_locations.py

Updates data/locations.lua. NOT executed by FiveM; no runtime network usage.
Source: https://fivem-minimaps.com/data/public-phones.json
"""
import json
import urllib.request
from pathlib import Path

URL = 'https://fivem-minimaps.com/data/public-phones.json'
DEST = Path(__file__).resolve().parents[1] / 'data' / 'locations.lua'
MODELS = {
    'prop_phonebox_01a', 'prop_phonebox_01b', 'prop_phonebox_01c',
    'prop_phonebox_02', 'prop_phonebox_03', 'prop_phonebox_04',
}


def main():
    with urllib.request.urlopen(URL, timeout=25) as response:
        payload = json.load(response)
    rows = payload['rows']
    entries = [r for r in rows if r.get('model') in MODELS]
    if not 350 <= len(entries) <= 500:
        raise RuntimeError(f'Unexpected source dataset size: {len(entries)}')
    lines = [
        'local Config = PayphoneConfig',
        '-- Generated from ' + URL,
        '-- Validate placements if your server uses a modified map/MLO.',
        'PhoneLocations = {',
    ]
    for r in entries:
        model = r['model']
        xyz = [float(r[axis]) for axis in ('x', 'y', 'z')]
        if not all(-10000 < n < 10000 for n in xyz):
            raise ValueError('Coordinate outside map range')
        lines.append("    { model = '%s', x = %.3f, y = %.3f, z = %.3f }," % (model, *xyz))
    lines.extend([
        '}',
        '',
        'for _, loc in ipairs(Config.ExtraPayphones) do',
        '    PhoneLocations[#PhoneLocations + 1] = loc',
        'end',
        '',
    ])
    DEST.write_text('\n'.join(lines), encoding='utf-8')
    print(f'Imported {len(entries)} booths into {DEST}')


if __name__ == '__main__':
    main()

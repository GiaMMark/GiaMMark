# Correzione v1.0.3 — Nessuna interazione sulla cabina

**Problema verificato nel codice precedente:** il `canInteract` nascondeva l'opzione se il raycast non corrispondeva a una delle sole 39 coordinate iniziali in `data/locations.lua`. Di conseguenza la maggioranza delle cabine della mappa non mostrava nulla, pur usando uno dei modelli GTA previsti.

**Fix:** il target è registrato sui 6 modelli di cabine, senza filtrare per coordinata in `canInteract`. Una volta selezionato, il server controlla distanza, formato numero, conflitti e chiamate in corso. Per far funzionare subito anche le cabine non censite è abilitato `Config.AllowUnlistedBooths = true`. La versione precedente non aveva questa modalità.

**Limite di sicurezza importante:** le cabine statiche mappate non sono verificabili autorevolmente come entità networked dal server. Con `AllowUnlistedBooths = true`, un client modificato potrebbe simulare la posizione della cabina, pur dovendo essere il proprio ped entro 3 m dalla posizione dichiarata. Le chiamate sono gratuite ma ciò può permettere telefonate da punti senza cabina. Per un server che richiede una whitelist **obbligatoria**, usa `Config.AllowUnlistedBooths = false` e importa tutte le posizioni usando `tools/import_locations.py` (il target continuerà a comparire, ma le cabine non autorizzate riceveranno un errore quando provi a chiamare). 

## Guida di diagnosi

1. Avvia nell'ordine `ox_lib`, `ox_target`, `lb-phone` (solo se lo usi) e `public_payphones`.
2. In gioco tieni premuto **ALT sinistro**, mira alla cabina e seleziona «Effettua chiamata gratuita». È normale che la NUI non si apra con il semplice avvicinamento.
3. Se non compare: premi F8 e digita `payphonedebug`. In F8 vedi `Target`, `registrato`, eventuali risorse in conflitto, numero di coordinate note e distanza dalla cabina nella lista più vicina.
4. Se `Target=NESSUNO`, controlla che ox_target/qb-target siano avviati. Se c'è `conflitto=lb-payphone`, ferma la risorsa duplicata o usa direttamente quella.
5. Se tutto risulta avviato ma ancora non vedi l'opzione, verifica che la cabina sia davvero uno dei modelli di `Config.Models` (mappe custom potrebbero usare altri oggetti) e che il target abbia il binding ALT sinistro.
6. Se esce «Il sistema telefonico non è disponibile», occorre controllare `Config.PhoneSystem`/`server/bridge.lua`: le API incluse sono quelle di LB Phone.

Dopo un aggiornamento esegui `stop public_payphones`, sostituisci completamente la cartella, poi `refresh` e `ensure public_payphones`. Rientra in FiveM se continua a usare file cache vecchi.

# public_payphones v1.0.5 · Telefoni pubblici FiveM

Resource indipendente per cabine pubbliche GTA V / MLO: **chiamate gratis**, interazione `ox_target` o `qb-target`, NUI vintage a tastierino, notifiche `ox_lib`, e bridge **server** ufficiale LB Phone. **Non** modifica LB Phone, database telefonico, `pma-voice` o soldi del giocatore.

## Dipendenze e avvio

- `ox_lib` (obbligatoria)
- `lb-phone` (questa versione integra LB Phone via export ufficiali)
- `ox_target` **oppure** `qb-target`
- Le risorse audio/voce necessarie a LB Phone secondo la configurazione esistente del tuo server

`server.cfg` (nell'ordine; ovviamente conserva anche le altre risorse che usi):

```cfg
ensure ox_lib
ensure ox_target
ensure lb-phone
ensure public_payphones
```

Copia **l'intera cartella** `public_payphones` dalla ZIP dentro `resources`; non aggiungere una seconda copia con un nome diverso. Se sostituisci v1.0.4:

```txt
stop public_payphones
refresh
ensure public_payphones
```

Se `lb-payphone` è già avviato, `public_payphones` disattiva il target per evitare un conflitto con la risorsa LB ufficiale. Usane uno solo.

## Come si usa

1. Avvicinati a un telefono della mappa e usa ALT sinistro con `ox_target` (oppure il tasto target del tuo server).
2. Seleziona **Effettua chiamata gratuita**.
3. Componi le cifre usando i pulsanti a schermo o la tastiera numerica. `Backspace` cancella una cifra; `Canc` cancella tutto.
4. Premi il pulsante **CHIAMA** (o Invio). La NUI mostra `CONNESSIONE`, `IN ATTESA DI RISPOSTA`, `CHIAMATA ATTIVA`. Il destinatario riceve una chiamata tramite **LB Phone**, se raggiungibile e compatibile con la configurazione esistente.
5. Riaggancia dal tasto rosso o dall'opzione target. `Esc` **nasconde** la NUI senza interrompere la chiamata. Per riaprirla seleziona **Controlla chiamata in corso** sullo stesso telefono.
6. Restare entro `Config.MaxCallDistance` dalla cabina durante la chiamata.

Comandi:

- `payphoneclose`: chiude solamente l'interfaccia NUI / sblocca il focus
- `payphonehangup`: termina la propria chiamata pubblica, se attiva
- `payphonedebug`: diagnostica target / numero di modelli / whitelist (F8)
- `payphonecoords`: stampa in F8 le coordinate per i telefoni in MLO

## Configurazione

Modifica `config.lua`:

```lua
Config.Target = 'auto' -- ox_target prima di qb-target
Config.PhoneSystem = 'lb-phone'
Config.FreeCalls = true
Config.CallerLabel = 'CABINA PUBBLICA'
Config.HideCallerNumber = false
Config.RequireOnlineRecipient = false
Config.DebugCalls = true
```

`Config.HideCallerNumber = false` mostra un identificativo di cabina al destinatario invece di un chiamante anonimo. `RequireOnlineRecipient = false` **non blocca** preventivamente numeri di compagnie, inoltri o numeri personalizzati. Con `true`, la risorsa rifiuta numeri per cui `GetSourceFromNumber` non trova un giocatore online con telefono equipaggiato (può escludere numeri speciali).

Le chiamate sono sempre gratis: lo script non addebita soldi né oggetti. `Config.Models` include 12 varianti standard di telefoni, comprese alcune nere/a colonnina; per prop custom non rilevati, aggiungi le posizioni a `Config.ExtraPayphones`, come spiegato nei file `ADDON_TELEFONI_NERI.md`.

### Note sulla sicurezza

Per supportare subito anche i telefoni statici fuori dalla lista iniziale, `Config.AllowUnlistedBooths = true` è il valore predefinito ereditato dalla v1.0.4. Il server controlla comunque distanza, cooldown e chiamate concorrenti. **Una cabina non networked fuori whitelist non può essere verificata in modo indipendente lato server.** Per maggiore sicurezza in produzione, censisci le posizioni e imposta `Config.AllowUnlistedBooths = false`.

## LB Phone non chiama: diagnosi

Verifica che chiamare lo **stesso numero LB Phone** da uno smartphone normale funzioni (perché lo script riutilizza le chiamate LB invece di crearne un'altra). Nella console **server** ora vengono stampati, a `Config.DebugCalls=true`:

- `Chiamata richiesta ... dest=***123 ... destinatario_online_con_telefono=true/false/unknown` — controllo tramite `GetSourceFromNumber`. Il valore `false` non esclude servizi/compagnie.
- `CreateCall OK ... callId=...` — l'export ha restituito un ID. In questo caso, controlla LB Phone / audio / telefono del destinatario.
- `ERRORE LB Phone ...` — export non disponibile, numero rifiutato, destinatario non raggiungibile, ecc.

I numeri in console sono mascherati. Se `CreateCall` restituisce `nil`, **soltanto LB Phone conosce il motivo specifico**: il messaggio lo segnala senza inventare una causa certa.

API ufficiali utilizzate:

- Server: https://docs.lbscripts.com/phone/exports/server-exports/ (`CreateCall`, `GetSourceFromNumber`, `GetCall`, `IsInCall`, `EndCall`)
- Eventi: https://docs.lbscripts.com/phone/exports/server-events/ (`lb-phone:callAnswered`, `lb-phone:callEnded`)
- `ox_lib` notifiche: https://overextended.dev/docs/ox_lib/Interface/Client/notify

## Test eseguiti

- Sintassi Lua di config, client, server e bridge
- Simulazioni Lua delle interazioni target e della chiamata LB Phone (parametri, riaggancio, eventi)
- Test Chromium del tastierino, stati, Esc, chiusura e **trasparenza del frame senza menu**

**Non equivale a un test in gioco**: una chiamata reale deve essere provata sul tuo server e sulla tua versione di LB Phone.

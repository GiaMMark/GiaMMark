# v1.0.4 — telefoni pubblici neri a colonnina e MLO

La schermata inviata mostra due telefoni pubblici neri. **Non è possibile determinare con certezza il modello GTA/YMAP da uno screenshot**.

Sono inclusi sei modelli aggiuntivi di telefoni pubblici GTA/DLC oltre ai sei iniziali:

- `p_phonebox_01b_s`
- `p_phonebox_02_s`
- `sf_prop_sf_phonebox_01b_s`
- `sf_prop_sf_phonebox_01b_straight`
- `ch_chint02_phonebox001`
- `m25_2_prop_m52_phonebox_01a`

Questi vengono registrati globalmente in `ox_target:addModel` o `qb-target:AddTargetModel`. I telefoni presenti in una MLO custom potrebbero **non essere prop autonomi**, e in quel caso non basta aggiungere nomi di modelli.

## Se un telefono resta non interattivo (MLO)

1. Avvicinati a ciascun telefono e apri **F8**.
2. Esegui `payphonecoords`. Copia la riga stampata in console.
3. Inserisci i valori in `config.lua` nella lista `Config.ExtraPayphones`:

```lua
Config.ExtraPayphones = {
    { x = 100.000, y = 200.000, z = 30.000, radius = 0.8 },
    { x = 101.000, y = 200.000, z = 30.000, radius = 0.8 },
}
```

**Sostituisci l'esempio con le coordinate vere**. Le zone sono registrate su entrambi i target e validate lato server. `payphonecoords` usa la posizione del giocatore: conviene stare davanti alla colonnina e, se necessario, regolare Z e radius di 0.3–0.8 per centrare il telefono. Un singolo modello MLO composto di più oggetti può richiedere una zona per ogni telefono.

Il target resta quello originale (`ALT` su ox_target), non compare automaticamente camminando vicino.

## Sicurezza / compatibilità

- Chiamate gratuite, nessun pagamento.
- Nessun `GetEntityModel` nel client.
- Zone custom autorizzate dalle coordinate della configurazione, non da richieste arbitrarie del giocatore.
- LB Phone bridge invariato.
- Le zone non vengono registrate se è avviata `lb-payphone` per evitare doppi menu.

## Installazione

`stop public_payphones`, sostituisci completamente la cartella, `refresh`, `ensure public_payphones`.

# Fix schermata nera FiveM NUI — v1.0.1

Causa probabile identificata nel pacchetto v1.0.0: `html/style.css` dichiarava
`color-scheme: dark` a livello `:root`. Questo può colorare di nero il canvas
CEF anche quando il corpo è impostato a `background: transparent`.

La v1.0.1 rimuove il color scheme scuro dalla pagina e imposta html/body/root
esplicitamente trasparenti. Tutta la logica delle chiamate, target e whitelist
resta invariata. In `client/main.lua` è aggiunto solo il comando F8 `payphoneclose`
per liberare il focus NUI in caso di interfaccia bloccata.

ISTRUZIONI
1. stop public_payphones
2. Sostituisci la cartella public_payphones con la versione corretta.
3. refresh
4. ensure public_payphones
5. Se vedi ancora nero, riconnettiti al server per forzare l'aggiornamento NUI.
6. Se non si risolve, invia errori F8 e log console server.

RISULTATO ATTESO
- All'avvio dello script: nessuna schermata o background visibile.
- Target su cabina abilitata: compare solo la finestra del numero.
- Esc o X chiude l'interfaccia; F8 payphoneclose sblocca il focus.

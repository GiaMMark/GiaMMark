# Fix crash native GetEntityModel - v1.0.2

## Sintomo

```
SCRIPT ERROR: native 9f47b058362c84b5: exception at address gta-streaming-five.dll+2BC8E
> GetEntityModel (GetEntityModel.lua:6)
> findPhone (@public_payphones/client/main.lua:25)
> shouldHide (@ox_target/client/main.lua:127)
```

## Causa e soluzione

`GetEntityModel` riceveva un handle di entita potenzialmente non valido
nell'istante in cui ox_target eseguiva `canInteract`. La v1.0.2 non legge
piu il modello del prop dal callback: `ox_target:addModel(Config.Models, ...)`
esegue gia il filtro. Per trovare la cabina associata alla whitelist,
`findPhone(entity, coords)` usa le coordinate del raycast fornite da ox_target.
`qb-target` usa come fallback GetEntityCoords protetto da pcall.

Il server continua a rifiutare chiamate da posizioni non autorizzate.

## Installazione

1. Nella console server: `stop public_payphones`.
2. Sostituisci completamente la cartella `public_payphones` con quella di questo ZIP.
3. Nella console server: `refresh` e `ensure public_payphones`.
4. Se F8 mostra ancora GetEntityModel dentro `public_payphones`, il client sta
   caricando una vecchia copia dello script: controlla le cartelle duplicate,
   poi esci e rientra nel server.

## Verifica

- Avvicinati a una delle cabine incluse nella whitelist.
- Apri e chiudi piu volte l'occhio di ox_target.
- Controlla che l'opzione di chiamata appaia e che non ci siano errori F8.
- Effettua una chiamata di prova e riaggancia.

Non sono state modificate tariffe, gestione chiamate, bridge o sistema NUI.

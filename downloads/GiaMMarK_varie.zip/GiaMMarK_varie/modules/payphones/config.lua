PayphoneConfig = {}
local Config = PayphoneConfig

-- Automatically select ox_target or qb-target (prefer ox_target if both run).
Config.Target = 'auto' -- 'auto' | 'ox_target' | 'qb-target'

-- Directly supported integration: LB Phone.
-- For a different phone resource, use 'custom' and implement server/bridge.lua.
Config.PhoneSystem = 'lb-phone' -- 'lb-phone' | 'custom'

-- Do not register duplicate interactions where an existing payphone resource is active.
Config.ConflictingResources = {'lb-payphone'}

-- Payment: ALWAYS free. This resource contains no wallet/inventory transactions.
Config.FreeCalls = true

-- Phone booths and public handsets, including scripted/DLC public booths.
-- Do not register office or household telephones as public payphones.
Config.Models = {
    'prop_phonebox_01a',
    'prop_phonebox_01b',
    'prop_phonebox_01c',
    'prop_phonebox_02',
    'prop_phonebox_03',
    'prop_phonebox_04',
    -- GTA scripted booths and San Andreas DLC phones.
    'p_phonebox_01b_s',
    'p_phonebox_02_s',
    'sf_prop_sf_phonebox_01b_s',
    'sf_prop_sf_phonebox_01b_straight',
    'ch_chint02_phonebox001',
    'm25_2_prop_m52_phonebox_01a'
}

Config.TargetDistance = 2.5
Config.ClientPropMatchDistance = 2.6 -- entity origin -> whitelisted model placement
-- true: allow dialing from ANY matching world model (including custom map placements).
-- false: only allow the STATIC data/locations.lua whitelist (higher server-side assurance).
-- In permissive mode, the static map-prop itself cannot be independently verified
-- by the server: a modified client could spoof the location; server checks that
-- the player is close, applies a rate limit, and disallows concurrent calls.
Config.AllowUnlistedBooths = true
Config.ClientHangupMatchDistance = 3.0
Config.BoothBusyDistance = 1.5

Config.ServerUseDistance = 3.0     -- player ped -> whitelisted booth, authoritative
Config.MaxCallDistance = 4.0      -- move farther away and the payphone call is hung up
Config.CooldownSeconds = 7        -- anti-spam per player
Config.MinDigits = 3
Config.MaxDigits = 15
Config.CallerLabel = 'CABINA PUBBLICA' -- LB Phone caller display
Config.HideCallerNumber = false -- show a public caller label instead of 'Sconosciuto'

-- For custom MLO phones / props baked into a map and not detected by addModel:
-- 1. Stand directly at the phone, run `payphonecoords` in F8.
-- 2. Copy the coordinates into this list (use the location of the handset).
-- 3. Both ox_target and qb-target will offer a phone option at that spot.
--    Two handsets 0.7m apart may each receive their own entry.
-- 4. This is a server-validated static whitelist, not a client-only location.
Config.ExtraPayphones = {
    -- { x = 0.0, y = 0.0, z = 0.0, radius = 0.75 },
}

Config.CustomZoneRadius = 0.8 -- manual zone size on custom maps, in metres


-- Additional whitelisted locations can be produced with tools/import_locations.py.
-- The shipped data/locations.lua contains only a verified SMALL STARTER LIST.

-- Enable to reject a call BEFORE CreateCall when the target does not have an
-- equipped LB Phone online. Keep false for company / forwarded / custom numbers.
Config.RequireOnlineRecipient = false

-- Log reasons for failed calls in server console (numbers are masked).
Config.DebugCalls = true

-- Optional NUI / ox_lib settings.
Config.NotifyPosition = 'top-right'
Config.DialRequestTimeoutMs = 15000

local Config = PayphoneConfig
local callBySource = {}
local lastRequest = {}

local function conflictName()
    for _, resource in ipairs(Config.ConflictingResources) do
        if GetResourceState(resource) == 'started' then return resource end
    end
end

local function validCoords(pos)
    return type(pos) == 'table' and type(pos.x) == 'number' and type(pos.y) == 'number'
        and type(pos.z) == 'number' and pos.x == pos.x and pos.y == pos.y and pos.z == pos.z
        and math.abs(pos.x) < 10000 and math.abs(pos.y) < 10000 and math.abs(pos.z) < 2000
end

local function distSq(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return dx * dx + dy * dy + dz * dz
end

local function playerAt(src, pos, radius)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end
    local playerCoords = GetEntityCoords(ped)
    return playerCoords ~= nil and distSq(playerCoords, pos) <= radius * radius
end

local function resolveBooth(src, phoneId, clientCoords)
    if type(phoneId) ~= 'number' or phoneId ~= math.floor(phoneId) then return nil end
    if phoneId > 0 then
        local allowed = PhoneLocations[phoneId]
        if not allowed or not playerAt(src, allowed, Config.ServerUseDistance) then return nil end
        if not validCoords(clientCoords) or distSq(clientCoords, allowed) > Config.ClientPropMatchDistance ^ 2 then return nil end
        return {id = phoneId, coords = {x = allowed.x, y = allowed.y, z = allowed.z}}
    end
    if phoneId ~= 0 or not Config.AllowUnlistedBooths or not validCoords(clientCoords) then return nil end
    if not playerAt(src, clientCoords, Config.ServerUseDistance) then return nil end
    -- Unlisted static props cannot be authenticated server-side. See README.
    return {id = 0, coords = {x = clientCoords.x, y = clientCoords.y, z = clientCoords.z}}
end

local function occupied(pos)
    for _, session in pairs(callBySource) do
        if distSq(pos, session.coords) <= Config.BoothBusyDistance ^ 2 then return true end
    end
    return false
end

local function result(src, ok, message, id, coords, dialled)
    TriggerClientEvent('public_payphones:result', src, ok, message, id, coords, dialled)
end

local function state(src, phase)
    TriggerClientEvent('public_payphones:callState', src, phase)
end

local function finishCall(src, reason)
    if not callBySource[src] then return end
    callBySource[src] = nil
    TriggerClientEvent('public_payphones:callFinished', src, reason or 'Chiamata terminata.')
end

local function dialledNumber(value)
    if type(value) ~= 'string' then return nil end
    -- Accept common punctuation from the physical keypad / copied numbers.
    local number = value:gsub('[%s%+%(%)%-]', '')
    if not number:match('^%d+$') or #number < Config.MinDigits or #number > Config.MaxDigits then
        return nil
    end
    return number
end

local function masked(number)
    return number and ('***%s'):format(number:sub(-3)) or '???'
end

RegisterNetEvent('public_payphones:requestCall', function(phoneId, input, clientCoords)
    local src = source
    if conflictName() then return result(src, false, 'Un altro script gestisce già i telefoni pubblici.') end
    local booth = resolveBooth(src, phoneId, clientCoords)
    if not booth then return result(src, false, 'Telefono pubblico non autorizzato oppure sei troppo lontano.') end

    local number = dialledNumber(input)
    if not number then return result(src, false, 'Numero non valido. Inserisci da ' .. Config.MinDigits .. ' a ' .. Config.MaxDigits .. ' cifre.') end
    if callBySource[src] then return result(src, false, 'Hai già una chiamata attiva dalla cabina.') end
    if occupied(booth.coords) then return result(src, false, 'Questo telefono pubblico è già occupato.') end

    local now = os.time()
    if lastRequest[src] and now - lastRequest[src] < Config.CooldownSeconds then
        return result(src, false, 'Attendi qualche secondo prima di riprovare.')
    end
    lastRequest[src] = now

    if not PayphoneBridge.isReady() then
        return result(src, false, 'LB Phone non disponibile. Controlla che sia avviato prima di public_payphones.')
    end

    if Config.DebugCalls then
        local checked, reachable = pcall(PayphoneBridge.recipientStatus, number)
        local status = (checked and reachable ~= nil) and tostring(reachable) or 'unknown'
        print(('[public_payphones] Chiamata richiesta src=%s dest=%s booth=%s destinatario_online_con_telefono=%s'):format(
            src, masked(number), booth.id, status))
    end

    -- pcall isolates errors in external LB Phone exports and sends a useful notice.
    local ok, callId, err = pcall(PayphoneBridge.start, src, number, booth.id)
    if not ok or callId == nil or callId == false then
        local detail = ok and (err or 'CreateCall non ha restituito un ID') or tostring(callId)
        print(('[public_payphones] ERRORE LB Phone: src=%s, dest=%s: %s'):format(src, masked(number), detail))
        return result(src, false, ok and tostring(detail) or 'Errore nell’export di LB Phone: controlla la console server.')
    end

    callBySource[src] = {id = booth.id, coords = booth.coords, callId = callId, startedAt = now, phase = 'ringing'}
    if Config.DebugCalls then
        print(('[public_payphones] CreateCall OK src=%s callId=%s'):format(src, tostring(callId)))
    end
    result(src, true, 'Chiamata inviata tramite LB Phone. In attesa di risposta...', booth.id, booth.coords, number)
end)

RegisterNetEvent('public_payphones:hangup', function()
    local src = source
    local session = callBySource[src]
    if not session then return end
    local ok, err = pcall(PayphoneBridge.hangup, src, session.callId)
    if not ok then print('[public_payphones] Errore EndCall: ' .. tostring(err)) end
    finishCall(src, 'Hai riagganciato il telefono pubblico.')
end)

local function belongsToSession(call, session)
    return type(call) == 'table' and call.callId ~= nil and tostring(call.callId) == tostring(session.callId)
end

-- Official LB Phone events, no custom voice/audio channels are created.
AddEventHandler('lb-phone:callAnswered', function(call)
    for src, session in pairs(callBySource) do
        if belongsToSession(call, session) and session.phase ~= 'answered' then
            session.phase = 'answered'
            state(src, 'answered')
        end
    end
end)

AddEventHandler('lb-phone:callEnded', function(call)
    local finishing = {}
    for src, session in pairs(callBySource) do
        if belongsToSession(call, session) then finishing[#finishing + 1] = src end
    end
    for _, src in ipairs(finishing) do finishCall(src, 'Chiamata terminata.') end
end)

CreateThread(function()
    Wait(1500)
    print(('[public_payphones] v1.0.5 | Target=%s | LB=%s | Telefoni=%d'):format(
        Config.Target, tostring(PayphoneBridge.isReady()), #PhoneLocations))
    if conflictName() then print('[public_payphones] ATTENZIONE: risorsa pubblica concorrente avviata.') end
    if Config.AllowUnlistedBooths then
        print('[public_payphones] SICUREZZA: telefoni fuori whitelist abilitati; i prop statici non sono verificabili lato server.')
    end

    while true do
        Wait(2000)
        local finishing = {}
        for src, session in pairs(callBySource) do
            if not GetPlayerName(src) then
                finishing[#finishing + 1] = {src, 'Chiamata terminata.'}
            elseif not playerAt(src, session.coords, Config.MaxCallDistance) then
                pcall(PayphoneBridge.hangup, src, session.callId)
                finishing[#finishing + 1] = {src, 'Ti sei allontanato dal telefono pubblico.'}
            else
                local ok, info = pcall(PayphoneBridge.info, session.callId)
                if ok and type(info) == 'table' then
                    if info.answered and session.phase ~= 'answered' then
                        session.phase = 'answered'
                        state(src, 'answered')
                    end
                elseif os.time() - session.startedAt > 6 then
                    -- GetCall no longer exists: the call may have ended before answer.
                    -- Do not hang up somebody else's private call on a stale ID.
                    finishing[#finishing + 1] = {src, 'La chiamata è terminata o non è raggiungibile.'}
                end
            end
        end
        for _, item in ipairs(finishing) do finishCall(item[1], item[2]) end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local session = callBySource[src]
    if session then pcall(PayphoneBridge.hangup, src, session.callId) end
    finishCall(src)
    lastRequest[src] = nil
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for src, session in pairs(callBySource) do
        pcall(PayphoneBridge.hangup, src, session.callId)
    end
end)

local Config = PayphoneConfig
-- LB Phone is the only authoritative call manager. This resource never opens
-- Mumble channels, bypasses voice exports or changes lb-phone files.
PayphoneBridge = {}

local function onlineRecipient(number)
    if GetResourceState('lb-phone') ~= 'started' then return nil end
    local ok, src = pcall(function()
        return exports['lb-phone']:GetSourceFromNumber(number)
    end)
    if not ok then return nil end -- older/custom builds may omit this export
    return src ~= false and src ~= nil and src ~= 0
end

function PayphoneBridge.isReady()
    return Config.PhoneSystem == 'lb-phone' and GetResourceState('lb-phone') == 'started'
end

function PayphoneBridge.recipientStatus(number)
    return onlineRecipient(number) -- nil means no reliable result
end

function PayphoneBridge.start(src, number, phoneId)
    if not PayphoneBridge.isReady() then
        return nil, 'LB Phone non è avviato: controlla server.cfg.'
    end

    local inCall = exports['lb-phone']:IsInCall(src)
    if inCall then
        return nil, 'Sei già impegnato in una chiamata.'
    end

    local reachable = onlineRecipient(number)
    if Config.RequireOnlineRecipient and reachable == false then
        return nil, 'Il destinatario non ha un telefono LB Phone attivo o non è online.'
    end

    -- Official server export, intended also for public payphones.
    -- Do NOT use the client CreateCall export: that depends on the smartphone UI.
    local callId = exports['lb-phone']:CreateCall({
        source = src,
        phoneNumber = ('%s %s'):format(Config.CallerLabel, tostring(phoneId))
    }, number, {
        requirePhone = false,
        hideNumber = Config.HideCallerNumber == true
    })

    if not callId then
        if reachable == false then
            return nil, 'LB Phone non ha avviato la chiamata. Il numero potrebbe non essere online o non avere il telefono equipaggiato.'
        end
        return nil, 'LB Phone ha rifiutato la chiamata (CreateCall ha restituito nil). Controlla console server e numero.'
    end
    return callId
end

-- LB Phone GetCall can track API-created calls independently of phone UI.
function PayphoneBridge.info(callId)
    if not PayphoneBridge.isReady() then return nil end
    return exports['lb-phone']:GetCall(callId)
end

function PayphoneBridge.active(src)
    if not PayphoneBridge.isReady() then return false, nil end
    local inCall, callId = exports['lb-phone']:IsInCall(src)
    return inCall == true, callId
end

function PayphoneBridge.hangup(src, expectedId)
    if not PayphoneBridge.isReady() then return false end
    local inCall, callId = PayphoneBridge.active(src)
    if inCall and tostring(callId) == tostring(expectedId) then
        return exports['lb-phone']:EndCall(src)
    end
    return false
end

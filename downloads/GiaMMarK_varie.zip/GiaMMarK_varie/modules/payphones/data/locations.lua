local Config = PayphoneConfig
-- Starter locations from the published GTA V base-map placements.
-- Only these booths are enabled until you add locations or generate all ~430
-- street booths with tools/import_locations.py. The whitelist is intentional:
-- FiveM server cannot authoritatively trust client-reported static prop positions.
-- Source: https://fivem-minimaps.com/data/public-phones.json
PhoneLocations = {
    { model = 'prop_phonebox_01b', x = 120.37, y = -205.13, z = 53.62 },
    { model = 'prop_phonebox_01b', x = 121.18, y = -205.42, z = 53.62 },
    { model = 'prop_phonebox_01b', x = -178.85, y = -52.06, z = 51.10 },
    { model = 'prop_phonebox_01b', x = -147.62, y = -287.15, z = 39.43 },
    { model = 'prop_phonebox_01b', x = -147.38, y = -286.44, z = 39.50 },
    { model = 'prop_phonebox_01b', x = -53.45, y = -94.17, z = 56.77 },
    { model = 'prop_phonebox_04', x = -544.18, y = -157.39, z = 37.54 },
    { model = 'prop_phonebox_04', x = -360.34, y = -267.18, z = 32.74 },
    { model = 'prop_phonebox_01a', x = -524.44, y = -300.72, z = 34.27 },
    { model = 'prop_phonebox_01a', x = -523.64, y = -300.41, z = 34.26 },
    { model = 'prop_phonebox_01a', x = -522.87, y = -300.11, z = 34.26 },
    { model = 'prop_phonebox_01a', x = -449.44, y = -272.82, z = 34.94 },
    { model = 'prop_phonebox_01a', x = -448.88, y = -274.13, z = 34.96 },
    { model = 'prop_phonebox_01a', x = -448.37, y = -275.32, z = 34.97 },
    { model = 'prop_phonebox_01c', x = -1348.82, y = -1192.14, z = 3.55 },
    { model = 'prop_phonebox_03', x = -3039.80, y = 594.15, z = 6.83 },
    { model = 'prop_phonebox_04', x = -2969.43, y = 397.46, z = 14.10 },
    { model = 'prop_phonebox_01b', x = 779.84, y = -1755.39, z = 28.48 },
    { model = 'prop_phonebox_01b', x = 780.23, y = -1755.45, z = 28.47 },
    { model = 'prop_phonebox_02', x = 815.37, y = -2160.24, z = 29.94 },
    { model = 'prop_phonebox_01c', x = 1039.28, y = -2119.51, z = 31.61 },
    { model = 'prop_phonebox_01c', x = 1039.33, y = -2118.95, z = 31.61 },
    { model = 'prop_phonebox_03', x = 136.64, y = -1545.74, z = 28.14 },
    { model = 'prop_phonebox_02', x = 93.52, y = -1548.66, z = 29.83 },
    { model = 'prop_phonebox_02', x = 147.41, y = -1726.33, z = 29.84 },
    { model = 'prop_phonebox_01c', x = -128.44, y = -1994.48, z = 21.78 },
    { model = 'prop_phonebox_01c', x = -128.44, y = -1993.45, z = 21.78 },
    { model = 'prop_phonebox_01a', x = 110.08, y = -1694.21, z = 28.29 },
    { model = 'prop_phonebox_01a', x = 173.46, y = -1547.12, z = 28.25 },
    { model = 'prop_phonebox_01a', x = 215.72, y = -1783.21, z = 28.00 },
    { model = 'prop_phonebox_01a', x = 215.95, y = -1518.96, z = 28.29 },
    { model = 'prop_phonebox_01a', x = 228.62, y = -1545.96, z = 28.28 },
    { model = 'prop_phonebox_01a', x = 229.14, y = -1545.68, z = 28.28 },
    { model = 'prop_phonebox_03', x = -1569.34, y = -922.33, z = 12.02 },
    { model = 'prop_phonebox_03', x = -1568.77, y = -921.65, z = 12.02 },
    { model = 'prop_phonebox_03', x = -1540.35, y = -899.12, z = 9.16 },
    { model = 'prop_phonebox_03', x = -1539.80, y = -899.58, z = 9.16 },
    { model = 'prop_phonebox_03', x = -1506.40, y = -953.26, z = 7.53 },
    { model = 'prop_phonebox_01b', x = 903.52, y = 3646.13, z = 31.71 },
}

-- ExtraPayphones are intentionally also in the server-side whitelist.
-- The `manual` flag tells the client to register target *zones* for them.
for _, loc in ipairs(Config.ExtraPayphones or {}) do
    if type(loc) == 'table' and type(loc.x) == 'number' and type(loc.y) == 'number' and type(loc.z) == 'number' then
        PhoneLocations[#PhoneLocations + 1] = {
            x = loc.x, y = loc.y, z = loc.z,
            model = loc.model or 'custom', manual = true, radius = loc.radius
        }
    end
end

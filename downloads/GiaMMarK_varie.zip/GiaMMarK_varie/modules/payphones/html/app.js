'use strict';
const app = document.querySelector('#app');
const digits = document.querySelector('#screenNumber');
const statusText = document.querySelector('#status');
const hint = document.querySelector('#screenHint');
const label = document.querySelector('#displayLabel');
const error = document.querySelector('#error');
const dialButton = document.querySelector('#call');
const hangupButton = document.querySelector('#hangup');
const clock = document.querySelector('#clock');
const keys = [...document.querySelectorAll('[data-key]')];
let number = '';
let phase = 'idle'; // idle | sending | ringing | answered
let minDigits = 3;
let maxDigits = 15;
let answeredAt = 0;

function gamePost(endpoint, body = {}) {
    // A working static preview is possible outside FiveM.
    if (typeof GetParentResourceName !== 'function') return Promise.resolve({ok:true});
    return fetch(`https://${GetParentResourceName()}/payphones_${endpoint}`, {
        method:'POST', headers:{'Content-Type':'application/json; charset=UTF-8'}, body:JSON.stringify(body)
    }).then(response => response.json());
}
function paint() {
    const busy = phase !== 'idle';
    const formatted = number ? (number.match(/.{1,3}/g) || []).join(' ') : '_ _ _   _ _ _ _';
    digits.textContent = formatted;
    statusText.textContent = ({idle:'PRONTO A CHIAMARE',sending:'CONNESSIONE...',ringing:'IN ATTESA DI RISPOSTA',answered:'CHIAMATA ATTIVA'})[phase];
    hint.textContent = ({idle:'Digita il numero',sending:'Verifica LB Phone...',ringing:'Il telefono sta squillando',answered:'Puoi parlare · resta vicino'})[phase];
    label.textContent = phase === 'idle' ? 'NUMERO DESTINATARIO' : 'CONNESSIONE CON';
    dialButton.disabled = busy || number.length < minDigits;
    hangupButton.disabled = phase === 'idle' || phase === 'sending';
    keys.forEach(key => {key.disabled = busy;});
    if (phase !== 'answered') clock.textContent = '00:00';
}
function setPhase(next) {
    if (next === 'answered' && phase !== 'answered') answeredAt = Date.now();
    phase = next;
    paint();
}
function show(mode, options = {}) {
    app.hidden = false;
    error.textContent = '';
    if (mode === 'idle') {
        number = '';
        setPhase('idle');
    } else {
        number = String(options.number || number).replace(/\D/g,'').slice(0,maxDigits);
        setPhase(options.phase === 'answered' ? 'answered' : 'ringing');
    }
}
function hide(sendCallback) {
    app.hidden = true;
    error.textContent = '';
    if (sendCallback) gamePost('close').catch(()=>{});
}
function push(value) {
    if (phase !== 'idle') return;
    error.textContent = '';
    if (value === '#') number = number.slice(0,-1);
    else if (value === '*') number = '';
    else if (/^\d$/.test(value) && number.length < maxDigits) number += value;
    paint();
}
async function dial() {
    if (phase !== 'idle') return;
    if (number.length < minDigits || number.length > maxDigits) {
        error.textContent = `Numero richiesto: ${minDigits}-${maxDigits} cifre.`;
        return;
    }
    setPhase('sending');
    error.textContent = '';
    try {
        const response = await gamePost('dial', {number});
        if (!response.ok) {
            setPhase('idle');
            error.textContent = response.error || 'Richiesta non valida.';
        }
    } catch (e) {
        setPhase('idle');
        error.textContent = 'Errore di connessione con la risorsa.';
    }
}
keys.forEach(button => button.addEventListener('click',()=>push(button.dataset.key)));
dialButton.addEventListener('click', dial);
hangupButton.addEventListener('click',()=>{if (phase === 'ringing' || phase === 'answered') gamePost('hangup').catch(()=>{});});
document.querySelector('#close').addEventListener('click',()=>hide(true));
window.addEventListener('keydown',event=>{
    if (app.hidden) return;
    if (event.key === 'Escape') {event.preventDefault(); hide(true); return;}
    if (event.key === 'Backspace') {event.preventDefault(); push('#'); return;}
    if (event.key === 'Delete') {event.preventDefault(); push('*'); return;}
    if (event.key === 'Enter') {event.preventDefault(); dial(); return;}
    if (/^\d$/.test(event.key)) {event.preventDefault(); push(event.key);}
});
window.addEventListener('message',({data})=>{
    if (!data || typeof data !== 'object') return;
    if (data.action === 'open') {
        minDigits = Number(data.minDigits) || 3;
        maxDigits = Number(data.maxDigits) || 15;
        show('idle');
    } else if (data.action === 'openCall') {
        show('call', data);
    } else if (data.action === 'close') {
        hide(false);
    } else if (data.action === 'sending') {
        if (typeof data.number === 'string') number = data.number;
        setPhase('sending');
    } else if (data.action === 'call') {
        show('call', data);
    } else if (data.action === 'state') {
        if (phase === 'ringing' || phase === 'answered') setPhase(data.phase === 'answered' ? 'answered' : 'ringing');
    } else if (data.action === 'error') {
        setPhase('idle');
        error.textContent = data.message || 'Impossibile avviare la chiamata.';
    }
});
setInterval(()=>{
    if (!app.hidden && phase === 'answered') {
        const elapsed = Math.max(0, Math.floor((Date.now() - answeredAt) / 1000));
        clock.textContent = `${String(Math.floor(elapsed / 60)).padStart(2,'0')}:${String(elapsed % 60).padStart(2,'0')}`;
    }
},1000);
paint();

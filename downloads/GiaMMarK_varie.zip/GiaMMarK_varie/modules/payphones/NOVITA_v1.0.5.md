# Novità v1.0.5

- Verificato l'uso corretto dell'export ufficiale LB Phone `CreateCall` con `requirePhone=false`.
- Impostato `HideCallerNumber=false` e un caller label riconoscibile.
- Log server più espliciti su CreateCall (ID o nil) e presenza del destinatario; numeri mascherati.
- Aggiunta opzione `RequireOnlineRecipient` (false di default per i numeri speciali).
- Aggiunto controllo di stato via `lb-phone:callAnswered`, `lb-phone:callEnded`, `GetCall`.
- Notifiche GTA sostituite da `ox_lib` tramite `lib.notify`.
- Interfaccia NUI ridisegnata come terminale telefonico fisico (display vintage, cornetta, pulsantiera 12 tasti, chiama/riaggancia).
- L'interfaccia resta visibile durante squillo e conversazione; Esc la nasconde soltanto.
- Nuove interazioni target "Controlla chiamata in corso" e comando `payphonehangup`.
- Mantiene 12 modelli, supporto MLO, correzioni della trasparenza e dell'errore `GetEntityModel`.

**Importante:** non è possibile garantire il funzionamento dell'audio/chiamata reale senza un test dentro il server con LB Phone e il suo sistema vocale. Leggi README per la diagnosi.

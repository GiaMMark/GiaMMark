local Config = TrashConfig
local ESX = exports['es_extended']:getSharedObject()

local cooldowns = {} -- [bucket:model:coords] = os.time() di scadenza
local pending = {}   -- [source] = { key, token, coords, startedMs, expires }
local locks = {}     -- [key] = source, per evitare due ricerche simultanee
local lastStart = {} -- [source] = os.time()
local knownModels = {}
local itemExists = {}

local function hasRequiredJob(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    return xPlayer and xPlayer.job and xPlayer.job.name == Config.RequiredJob
end

local function fail(message)
    return { ok = false, message = message }
end

local function clearPending(src)
    local job = pending[src]
    if not job then return end
    pending[src] = nil
    if locks[job.key] == src then locks[job.key] = nil end
end

local function validNumber(value)
    return type(value) == 'number' and value == value and math.abs(value) < 20000
end

local function coordsFromTable(t)
    if type(t) ~= 'table' then return end
    if not (validNumber(t.x) and validNumber(t.y) and validNumber(t.z)) then return end
    return vector3(t.x, t.y, t.z)
end

local function nearestTenth(v)
    return math.floor(v * 10 + 0.5)
end

local function whitelistIndex(model, coords)
    if #Config.VerifiedBins == 0 then return nil end

    for i = 1, #Config.VerifiedBins do
        local entry = Config.VerifiedBins[i]
        local hash = type(entry.model) == 'string' and joaat(entry.model) or entry.model
        if hash == model and #(coords - entry.coords) <= Config.VerifiedBinTolerance then
            return i
        end
    end

    return false
end

local function makeKey(src, model, coords)
    local bucket = Config.ShareCooldownBetweenBuckets and 0 or GetPlayerRoutingBucket(src)
    local listedIndex = whitelistIndex(model, coords)
    if listedIndex == false then return nil end

    if listedIndex then
        return ('%s:approved:%d'):format(bucket, listedIndex)
    end

    -- Coordinate del centro del prop (non del punto colpito dal raycast).
    -- Il rounding al decimetro evita micro-differenze tra i client.
    return ('%s:%d:%d:%d:%d'):format(
        bucket, model, nearestTenth(coords.x), nearestTenth(coords.y), nearestTenth(coords.z)
    )
end

local totalChance = 0
for _, name in ipairs(Config.BinModels) do
    knownModels[joaat(name)] = true
end

for i, loot in ipairs(Config.Loot) do
    assert(type(loot.item) == 'string' and loot.item ~= '', 'Loot invalido alla riga ' .. i)
    assert(type(loot.chance) == 'number' and loot.chance >= 0 and loot.chance <= 100, 'Chance invalida per ' .. loot.item)
    assert(type(loot.min) == 'number' and type(loot.max) == 'number'
        and loot.min >= 1 and loot.max >= loot.min and loot.min % 1 == 0 and loot.max % 1 == 0,
        'Quantita non valida per ' .. loot.item)
    totalChance = totalChance + loot.chance
end
assert(totalChance <= 100.00001, ('Somma chance %.2f%% superiore a 100%%'):format(totalChance))
print(('[trash_search] Loot: %.2f%% oggetti, %.2f%% vuoto'):format(totalChance, 100 - totalChance))

CreateThread(function()
    for _, loot in ipairs(Config.Loot) do
        local definition = exports.ox_inventory:Items(loot.item)
        itemExists[loot.item] = definition ~= nil
        if not definition then
            print(('[trash_search] ATTENZIONE: item mancante in ox_inventory: %s; questa chance diventa loot vuoto.'):format(loot.item))
        end
    end
end)

local function pickLoot()
    local roll = math.random() * 100.0
    local accumulated = 0
    for _, loot in ipairs(Config.Loot) do
        accumulated = accumulated + loot.chance
        if roll < accumulated then
            if itemExists[loot.item] then return loot end
            return nil
        end
    end
    return nil
end

local function checkPlayer(src, coords)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 or not DoesEntityExist(ped) or GetEntityHealth(ped) <= 0 then
        return false
    end
    return #(GetEntityCoords(ped) - coords) <= Config.ServerMaxDistance
end

local function verifyNetworkObject(data, model, coords)
    local netId = data.netId
    if netId == nil or netId == 0 then
        -- I prop statici della mappa sono spesso NON networked: in tal caso
        -- si controllano distanza, model allowlist e (se abilitata) whitelist.
        return true
    end
    if type(netId) ~= 'number' or netId % 1 ~= 0 or netId < 0 then return false end

    local entity = NetworkGetEntityFromNetworkId(netId)
    return entity and entity ~= 0 and DoesEntityExist(entity)
        and GetEntityModel(entity) == model
        and #(GetEntityCoords(entity) - coords) <= 1.0
end

lib.callback.register('trash_search:begin', function(src, data)
    if not hasRequiredJob(src) then
        return fail('Solo chi ha il lavoro barbone puo cercare nei bidoni.')
    end

    if type(data) ~= 'table' or type(data.model) ~= 'number' then
        return fail('Bidone non valido.')
    end

    local model = data.model
    local coords = coordsFromTable(data.coords)
    if not coords or not knownModels[model] then return fail('Questo oggetto non e un bidone ricercabile.') end
    if not checkPlayer(src, coords) then return fail('Sei troppo lontano dal bidone.') end
    if not verifyNetworkObject(data, model, coords) then return fail('Bidone non verificabile.') end

    local key = makeKey(src, model, coords)
    if not key then return fail('Questo bidone non e abilitato alla ricerca.') end

    local now = os.time()
    if pending[src] and pending[src].expires <= now then clearPending(src) end
    if pending[src] then return fail('Stai gia cercando in un bidone.') end

    if lastStart[src] and lastStart[src] + Config.PlayerCooldownSeconds > now then
        return fail(('Attendi %d secondi prima di cercare ancora.'):format(lastStart[src] + Config.PlayerCooldownSeconds - now))
    end

    if cooldowns[key] and cooldowns[key] > now then
        return fail(('Questo bidone e vuoto. Riprova tra %d secondi.'):format(cooldowns[key] - now))
    end

    local occupying = locks[key]
    if occupying then
        local job = pending[occupying]
        if not job or job.expires <= now then
            clearPending(occupying)
        else
            return fail('Un altro giocatore sta gia cercando qui.')
        end
    end

    local token = ('%d:%d:%d'):format(src, GetGameTimer(), math.random(100000, 999999))
    pending[src] = {
        key = key,
        coords = coords,
        model = model,
        bucket = GetPlayerRoutingBucket(src),
        token = token,
        startedMs = GetGameTimer(),
        expires = now + Config.PendingTimeoutSeconds,
    }
    locks[key] = src
    lastStart[src] = now
    return { ok = true, token = token }
end)

RegisterNetEvent('trash_search:cancel', function(token)
    local src = source
    if pending[src] and pending[src].token == token then
        clearPending(src)
    end
end)

lib.callback.register('trash_search:finish', function(src, token)
    local job = pending[src]
    if not job or type(token) ~= 'string' or job.token ~= token then
        return fail('Ricerca non valida o gia conclusa.')
    end

    -- Controllo ripetuto: il lavoro potrebbe essere cambiato durante la ricerca.
    if not hasRequiredJob(src) then
        clearPending(src)
        return fail('Solo chi ha il lavoro barbone puo cercare nei bidoni.')
    end

    if os.time() > job.expires then
        clearPending(src)
        return fail('La ricerca e scaduta.')
    end

    if GetGameTimer() - job.startedMs < Config.SearchDurationMs - 250 then
        return fail('Devi completare la ricerca prima di ritirare il loot.')
    end

    if not checkPlayer(src, job.coords) or GetPlayerRoutingBucket(src) ~= job.bucket then
        clearPending(src)
        return fail('Ti sei allontanato dal bidone.')
    end

    local loot = pickLoot()
    local now = os.time()
    if not loot then
        cooldowns[job.key] = now + Config.BinCooldownSeconds
        clearPending(src)
        return { ok = true, empty = true }
    end

    local amount = math.random(loot.min, loot.max)
    -- Anche con inventario pieno il bidone va in cooldown, cosi' non si
    -- possono usare fallimenti intenzionali per ripetere il tiro del loot.
    cooldowns[job.key] = now + Config.BinCooldownSeconds
    if not exports.ox_inventory:CanCarryItem(src, loot.item, amount) then
        clearPending(src)
        return fail('Inventario pieno: la ricerca e stata comunque consumata.')
    end

    -- Il lock resta attivo durante AddItem e viene rilasciato solo alla fine.
    local success, reason = exports.ox_inventory:AddItem(src, loot.item, amount)
    if not success then
        cooldowns[job.key] = nil
        clearPending(src)
        print(('[trash_search] AddItem fallito per %s x%d (player %d): %s'):format(loot.item, amount, src, tostring(reason)))
        return fail('Impossibile consegnare la ricompensa. Riprova.')
    end

    clearPending(src)
    local definition = exports.ox_inventory:Items(loot.item)
    return { ok = true, empty = false, label = loot.label or (definition and definition.label) or loot.item, count = amount }
end)

AddEventHandler('playerDropped', function()
    local src = source
    clearPending(src)
    lastStart[src] = nil
end)

-- Rilascia i vecchi cooldown e le ricerche interrotte (per evitare crescita di memoria).
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for key, endsAt in pairs(cooldowns) do
            if endsAt <= now then cooldowns[key] = nil end
        end
        for src, job in pairs(pending) do
            if job.expires <= now then clearPending(src) end
        end
    end
end)

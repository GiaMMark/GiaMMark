TrashConfig = {}
local Config = TrashConfig

-- Solo i giocatori con questo lavoro ESX possono rovistare nei bidoni.
Config.RequiredJob = 'barbone'

-- Ogni bidone (non ogni giocatore) va in cooldown dopo una ricerca riuscita,
-- anche quando il risultato e' 'non hai trovato nulla'. Non persiste al riavvio.
Config.BinCooldownSeconds = 20 * 60
Config.PlayerCooldownSeconds = 10 -- antibot/antispam per chi cerca bidoni diversi
Config.SearchDurationMs = 6500
Config.PendingTimeoutSeconds = 30
Config.TargetDistance = 2.1
Config.ServerMaxDistance = 4.0 -- tolleranza rispetto al centro del prop
Config.ShareCooldownBetweenBuckets = false

-- I bidoni sono prop statici GTA. Integrare i nomi dei prop custom presenti sulla mappa.
Config.BinModels = {
    'prop_bin_01a', 'prop_bin_02a', 'prop_bin_03a', 'prop_bin_04a',
    'prop_bin_05a', 'prop_bin_06a', 'prop_bin_07a', 'prop_bin_07b',
    'prop_bin_07c', 'prop_bin_07d', 'prop_bin_08a', 'prop_bin_08open',
    'prop_bin_09a', 'prop_bin_10a', 'prop_bin_10b', 'prop_bin_11a',
    'prop_bin_11b', 'prop_bin_12a', 'prop_bin_13a', 'prop_bin_14a',
    'prop_cs_bin_01', 'prop_cs_bin_02', 'prop_cs_bin_03',
    'prop_dumpster_01a', 'prop_dumpster_02a', 'prop_dumpster_02b',
    'prop_dumpster_3a', 'prop_dumpster_4a', 'prop_dumpster_4b',
    'prop_skip_01a', 'prop_skip_02a', 'prop_skip_05a',
    'prop_skip_06a', 'prop_skip_08a',
}

-- OPZIONALE, consigliato sui server con rischio di exploit.
-- Se non vuoto, SOLO i bidoni elencati (e validati sul server) saranno lootabili.
-- Esempio: { model = 'prop_bin_01a', coords = vector3(215.2, -925.8, 30.6) },
Config.VerifiedBins = {}
Config.VerifiedBinTolerance = 0.8

-- Percentuali ASSOLUTE su un singolo lancio 0-100 (massimo UN item per ricerca).
-- La probabilita' di NON trovare nulla e' 100 - SOMMA(chance).
-- In questa configurazione la somma e' 96.8%, quindi il vuoto e' 3.2%.
-- Modificando una percentuale cambia automaticamente la probabilita' del vuoto.
-- IMPORTANTE: la somma non deve superare 100.
-- min/max: quantita' trovata, indipendente dalla chance.
Config.Loot = {
    { item = 'trash_rags',           chance = 14.0, min = 1, max = 2 },
    { item = 'trash_glass_bottle',   chance = 12.0, min = 1, max = 2 },
    { item = 'trash_food_leftovers', chance = 9.0,  min = 1, max = 1 },
    { item = 'cartone',      chance = 8.0,  min = 1, max = 2 },
    { item = 'trash_bottle_dregs',   chance = 6.0,  min = 1, max = 1 },
    { item = 'trash_dead_rat',       chance = 4.0,  min = 1, max = 1 },
    { item = 'scrapmetal',           chance = 3.0,  min = 1, max = 2 },
    { item = 'plastic',              chance = 2.5,  min = 1, max = 2 },
    { item = 'alcohol',              chance = 2.0,  min = 1, max = 1 },
    { item = 'glass',                chance = 1.5,  min = 1, max = 2 },
    { item = 'copperwire',           chance = 1.0,  min = 1, max = 1 },
    { item = 'air_filter',           chance = 0.8,  min = 1, max = 1 }, -- JG Mechanic
    { item = 'spark_plug',           chance = 0.6,  min = 1, max = 1 }, -- JG Mechanic
    { item = 'duct_tape',            chance = 0.4,  min = 1, max = 1 }, -- JG Mechanic
    -- Ricambi auto: percentuali aumentate, quantita' fisse richieste.
    { item = 'vehicle_sheet_metal',  chance = 8.0,  min = 8, max = 8, label = 'Lamiere' },
    { item = 'vehicle_door',         chance = 5.0,  min = 2, max = 2, label = 'Portiere' },
    { item = 'vehicle_tire',         chance = 6.0,  min = 4, max = 4, label = 'Gomme' },
    { item = 'vehicle_plastic',      chance = 8.0,  min = 6, max = 6, label = 'Pezzi di plastica' },
    { item = 'vehicle_carbon',       chance = 4.0,  min = 2, max = 2, label = 'Pezzi di carbonio' },
    { item = 'v8_engine',            chance = 1.0,  min = 1, max = 1, label = 'Motore V8' },
    -- Esempio per aggiungerne un altro: inserire una riga,
    -- e ricordare che la somma totale non deve superare 100.
    -- { item = 'brakepad_replacement', chance = 0.2, min = 1, max = 1 },
}

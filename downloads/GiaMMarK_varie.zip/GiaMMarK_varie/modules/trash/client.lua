local Config = TrashConfig
local ESX = exports['es_extended']:getSharedObject()
local searching = false
local optionName = 'trash_search:search_bin'

local function notice(message, kind)
    lib.notify({ title = 'Raccolta rifiuti', description = message, type = kind or 'inform' })
end

local function hasRequiredJob()
    local playerData = ESX.GetPlayerData()
    return playerData and playerData.job and playerData.job.name == Config.RequiredJob
end

local function onWhitelist(model, coords)
    if #Config.VerifiedBins == 0 then return true end

    for i = 1, #Config.VerifiedBins do
        local entry = Config.VerifiedBins[i]
        local expectedModel = type(entry.model) == 'string' and joaat(entry.model) or entry.model
        if expectedModel == model and #(coords - entry.coords) <= Config.VerifiedBinTolerance then
            return true
        end
    end

    return false
end

local function searchBin(data)
    if searching then return end
    if not hasRequiredJob() then
        return notice('Solo chi ha il lavoro barbone puo cercare nei bidoni.', 'error')
    end
    local entity = data.entity
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end

    local ped = PlayerPedId()
    if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) then
        return notice('Non puoi cercare nei bidoni in questo momento.', 'error')
    end

    searching = true
    local coords = GetEntityCoords(entity)
    local model = GetEntityModel(entity)
    local netId
    if NetworkGetEntityIsNetworked(entity) then
        netId = NetworkGetNetworkIdFromEntity(entity)
    end

    local started = lib.callback.await('trash_search:begin', false, {
        model = model,
        coords = { x = coords.x, y = coords.y, z = coords.z },
        netId = netId,
    })

    if not started or not started.ok then
        searching = false
        return notice(started and started.message or 'Impossibile iniziare la ricerca.', 'error')
    end

    local completed = lib.progressCircle({
        duration = Config.SearchDurationMs,
        label = 'Stai rovistando nella spazzatura...',
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = { dict = 'amb@prop_human_bum_bin@base', clip = 'base' },
    })

    if not completed then
        TriggerServerEvent('trash_search:cancel', started.token)
        searching = false
        return notice('Ricerca annullata.', 'inform')
    end

    local result = lib.callback.await('trash_search:finish', false, started.token)
    searching = false

    if not result or not result.ok then
        return notice(result and result.message or 'Ricerca non riuscita.', 'error')
    end

    if result.empty then
        notice('Hai rovistato nel bidone, ma non hai trovato nulla.', 'inform')
    else
        notice(('Hai trovato: %s x%d'):format(result.label, result.count), 'success')
    end
end

exports.ox_target:addModel(Config.BinModels, {{
    name = optionName,
    icon = 'fa-solid fa-trash-can',
    label = 'Cerca nel bidone',
    distance = Config.TargetDistance,
    canInteract = function(entity)
        local ped = PlayerPedId()
        return hasRequiredJob()
            and not searching
            and DoesEntityExist(entity)
            and not IsEntityDead(ped)
            and not IsPedInAnyVehicle(ped, false)
            and onWhitelist(GetEntityModel(entity), GetEntityCoords(entity))
    end,
    onSelect = searchBin,
}})

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() and GetResourceState('ox_target') == 'started' then
        exports.ox_target:removeModel(Config.BinModels, optionName)
    end
end)

MuscleConfig = {}
local Config = MuscleConfig

-- SOSTITUIRE 'dukes' con lo spawn name del modello CUSTOM fornito da BubbaTV.
-- 'dukes' e' soltanto una muscle car GTA di test e NON e' gia' rovinata.
Config.VehicleModel = 'dukes'

-- JG Advanced Garages v4: MODALITA' TUTTI I GARAGE PUBBLICI PER AUTO.
-- In /garageadmin > Settings > Garages disattiva:
-- "Require transfers between public garages".
-- NOTA: questa e' un'impostazione GLOBALE DI JG; non puo' essere cambiata
-- tramite questa risorsa. Disattivandola, il ritiro globale vale per le
-- auto personali nei garage PUBBLICI idonei, non per impound/job/privati.
--
-- Per registrare la macchina JG richiede comunque un garage ID iniziale
-- valido, che NON vincola il successivo ritiro quando JG usa deposito comune.
-- Esegui 'mr_jg4_list' dalla console e scegli in /garageadmin un garage
-- PUBBLICO di categoria car, attivo (NON impound, job o privato).
Config.JG = {
    version = 4,
    initialGarageId = 'INSERISCI_ID_GARAGE_PUBBLICO',
}


-- Condizioni iniziali salvate nel JSON del veicolo (il garage potrebbe sovrascriverle).
Config.VehicleProps = {
    fuelLevel = 40.0,
    engineHealth = 800.0,
    bodyHealth = 650.0,
    petrolTankHealth = 800.0,
    dirtLevel = 15.0,
}

Config.ItemName = 'car_rottame'
Config.CraftDuration = 30000 -- millisecondi: 30 secondi
Config.MaxDistance = 4.0 -- distanza massima permessa dal server

-- Nome lavoro ESX e grado minimo per usare la postazione.
Config.MechanicJobs = {
    lsc = 0,
     bennys = 0,
     angels = 0,
}

-- Un solo tavolo da lavoro fisico. Puoi cambiare modello, coordinate e rotazione.
-- Modello GTA V standard, senza download di oggetti aggiuntivi.
Config.BenchModel = 'prop_tool_bench02'
Config.Benches = {
    {
        coords = vec3(2381.604492, 3084.685791, 48.1516112),
        rotation = 70.0,
        label = 'Usa banco da lavoro',
    },
}

-- Tutti gli ingredienti sono gia' definiti nel file items(7).lua fornito.
-- Nessuna modifica al tuo items.lua e' necessaria per i materiali.
-- Unico item di uscita: car_rottame (vedi extras/item_car_rottame.lua).
Config.Recipe = {
    { name = 'vehicle_sheet_metal', count = 8, label = 'Lamiere' },
    { name = 'vehicle_door', count = 2, label = 'Portiere' },
    { name = 'vehicle_tire', count = 4, label = 'Gomme' },
    { name = 'vehicle_plastic', count = 6, label = 'Pezzi di plastica' },
    { name = 'vehicle_carbon', count = 2, label = 'Pezzi di carbonio' },
    { name = 'v8_engine', count = 1, label = 'Motore V8' },
}


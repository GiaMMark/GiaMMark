# Muscle Rebuild - Solo tavolo da lavoro

Versione 2.3.0 per FiveM (ESX Legacy).

## Come funziona

- In gioco compare **un solo tavolo da lavoro** alle coordinate impostate in `config.lua`.
- Il meccanico lo usa con **ox_target**.
- Si apre un **menu semplice di ox_lib**: `Assembla veicolo` oppure `Materiali richiesti`.
- Con tutti i materiali disponibili parte un montaggio di 30 secondi, diviso in tre animazioni: sistemazione componenti, martellatura e saldatura. Ogni fase ha una barra annullabile con ESC.
- A montaggio finito ricevi `car_rottame`; usando l'item, il veicolo viene registrato nel garage JG v4.

Niente NUI HTML, auto di esposizione, marker o decorazioni aggiuntive. Solo il tavolo GTA `prop_tool_bench02` e le animazioni del personaggio durante il lavoro.

## Ricetta con item gia' esistenti

I 9 item qui sotto sono stati verificati nel file `items(7).lua` fornito:

| Materiale | Nome item | Quantita' |
|---|---|---:|
| Lamiere | `vehicle_sheet_metal` | 8 |
| Portiere | `vehicle_door` | 2 |
| Gomme | `vehicle_tire` | 4 |
| Pezzi di plastica | `vehicle_plastic` | 6 |
| Pezzi di carbonio | `vehicle_carbon` | 2 |
| Rottame di metallo | `scrapmetal` | 10 |
| Motore V8 | `v8_engine` | 1 |
| Kit Frizione | `clutch_replacement` | 1 |
| Componenti Sospensioni | `suspension_parts` | 4 |

Totale **38 pezzi**. Lo script controlla e consuma questi item da `ox_inventory`.
Non duplicarli e non sostituire `items.lua`: li hai gia'.

**Nota ricompensa:** `car_rottame` *non e' presente* nel file `items(7).lua` fornito. Lo script lo usa come item finale con seriale unico, quindi devi aggiungere **solo** `extras/item_car_rottame.lua` dentro la tua tabella `ox_inventory/data/items.lua`, come nelle versioni precedenti. Non rinominare un token esistente (per esempio `token_auto`), perche' potrebbe gia' servire ad altre risorse.

## Installazione

1. Sostituisci completamente la vecchia cartella con `muscle_rebuild` (mantieni **lo stesso nome**).
2. Assicurati che siano avviati `es_extended`, `ox_lib`, `ox_inventory`, `ox_target`, `oxmysql` e `jg-advancedgarages` v4.
3. Importa `install.sql` una sola volta se la tabella `mr_car_tokens` non esiste.
4. Inserisci il contenuto di `extras/item_car_rottame.lua` dentro la tabella `ox_inventory/data/items.lua`, soltanto se l'item non esiste gia'. **Non sostituire il file items.lua completo.**
5. In `config.lua` imposta `Config.JG.initialGarageId` con un garage pubblico auto reale (usa `mr_jg4_list` dalla console del server).
6. In `config.lua` scegli `Config.VehicleModel` (attualmente `dukes` di prova) e, se vuoi, cambia la posizione e la rotazione dell'unico tavolo.
7. Avvia `ensure muscle_rebuild` dopo tutte le dipendenze e riavvia `ox_inventory` se hai aggiunto un item.

## Personalizzazione rapida

Apri `config.lua`:

- `Config.BenchModel`: modello del tavolo, predefinito `prop_tool_bench02`.
- `Config.Benches[1].coords` e `.rotation`: posizione e rotazione del tavolo; posizione originale mantenuta a `2381.604492, 3084.685791, 48.1516112`.
- `Config.MechanicJobs`: lavori autorizzati; per impostazione originale solo `lsc` grado 0 o superiore.
- `Config.Recipe`: usa soltanto 9 materiali gia presenti nel tuo `items(7).lua` (38 pezzi totali).
- `Config.CraftDuration`: durata TOTALE delle tre animazioni in millisecondi, default `30000` (12 s + 9 s + 9 s).

## JG Advanced Garages v4

Il sistema del riscatto e del garage e' lo stesso della versione originale.
Per rendere il mezzo ritirabile da tutti i garage pubblici auto, gestisci in `/garageadmin > Settings` l'opzione globale **Require transfers between public garages** (disattivala se desideri deposito comune).

Comandi diagnostici da console server: `mr_jg4_list` e `mr_jg4_check`.

## Nota

Non e' stato possibile testare il risultato dentro un server FiveM con le tue risorse. Prova su un ambiente di sviluppo prima di andare in produzione.


## Correzione spazio inventario
Se il giocatore possiede tutti i materiali, il crafting puo' essere avviato
anche quando l'inventario e' inizialmente pieno. Al termine delle animazioni
il server rimuove i materiali e **solo dopo** controlla se puo' inserire
`car_rottame`. Se l'item non entra neppure dopo aver liberato peso e slot,
la procedura si annulla e il server tenta di restituire i materiali.
Il controllo del possesso degli ingredienti resta effettuato sul server.

-- Importa QUESTO file nel database ESX con HeidiSQL, phpMyAdmin o equivalente.
-- NON ricrea owned_vehicles: usa la tabella gia' presente nel server.
CREATE TABLE IF NOT EXISTS `mr_car_tokens` (
  `serial` CHAR(36) NOT NULL,
  `status` ENUM('issued', 'processing', 'redeemed') NOT NULL DEFAULT 'issued',
  `minted_by` VARCHAR(80) NOT NULL,
  `claimed_by` VARCHAR(80) DEFAULT NULL,
  `plate` VARCHAR(12) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `redeemed_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`serial`),
  INDEX `idx_token_status` (`status`),
  INDEX `idx_token_plate` (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

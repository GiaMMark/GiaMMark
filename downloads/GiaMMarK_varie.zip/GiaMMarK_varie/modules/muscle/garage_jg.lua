local Config = MuscleConfig
-- Adapter ESX per JG Advanced Garages v4.
-- Per il garage iniziale usa getAllGarages (API ufficiale).
-- Il veicolo e' ritirabile in ogni garage PUBBLICO auto solo se l'amministratore
-- disabilita 'Require transfers between public garages' in /garageadmin > Settings.
-- Il garage iniziale e' un riferimento SQL, NON un limite di prelievo in modalita' condivisa.
-- Non si basa su ID ricavati dal label e non prosegue se l'API v4 non e' disponibile.
-- Nota: l'attribuzione del veicolo avviene via owned_vehicles ESX/JG, non tramite
-- un export giveVehicle (non presente nella API pubblica JG v4).
GarageJG = {}

local cachedColumns
local required = { 'owner', 'plate', 'vehicle', 'garage_id', 'in_garage' }

local function readColumns()
    if cachedColumns then return cachedColumns end

    local rows = MySQL.query.await('SHOW COLUMNS FROM `owned_vehicles`')
    assert(type(rows) == 'table' and #rows > 0,
        'Impossibile leggere owned_vehicles: installa prima lo schema SQL ESX di JG v4')

    local columns = {}
    for _, row in ipairs(rows) do
        if type(row.Field) == 'string' then
            columns[row.Field] = row
        end
    end

    for _, name in ipairs(required) do
        assert(columns[name], 'Manca colonna owned_vehicles.' .. name ..
            ': esegui la migrazione SQL JG v4 per ESX prima di questa risorsa')
    end

    cachedColumns = columns
    return columns
end

local function getGarages()
    if GetResourceState('jg-advancedgarages') ~= 'started' then
        return nil, 'JG Advanced Garages v4 non avviato: controlla server.cfg.'
    end

    local ok, garages = pcall(function()
        return exports['jg-advancedgarages']:getAllGarages()
    end)
    if not ok then
        return nil, 'API getAllGarages non disponibile: controlla che JG sia la v4 e che la risorsa sia avviata.'
    end
    if type(garages) ~= 'table' then
        return nil, 'L\'API JG v4 non ha restituito una lista garage valida.'
    end

    return garages
end

function GarageJG.listGarages()
    return getGarages()
end

local function validateGarage()
    local id = Config.JG and Config.JG.initialGarageId
    if type(id) ~= 'string' or id == '' or id:find('INSERISCI_', 1, true) then
        return false, 'Imposta Config.JG.initialGarageId con un garage PUBBLICO auto reale da /garageadmin (usa mr_jg4_list dalla console).'
    end

    local garages, errorMessage = getGarages()
    if not garages then return false, errorMessage end

    for _, entry in pairs(garages) do
        if type(entry) == 'table' and entry.name == id then
            -- L'API ufficiale definisce type/vehicle come categoria car, air o sea.
            local category = entry.vehicle or entry.type
            if category ~= 'car' then
                return false, ('JG garage "%s" non e\' un garage auto (tipo: %s).'):
                    format(id, tostring(category))
            end
            return true
        end
    end

    return false, ('Garage "%s" non trovato in JG v4. Usa l\'ID ESATTO di /garageadmin.'):
        format(id)
end

function GarageJG.preflight()
    if not Config.JG or Config.JG.version ~= 4 then
        return false, 'Questo adapter richiede Config.JG.version = 4.'
    end

    local ok, message = validateGarage()
    if not ok then return false, message end

    local schemaOK, schemaError = pcall(readColumns)
    if not schemaOK then
        print('[muscle_rebuild] Schema JG v4 non compatibile: ' .. tostring(schemaError))
        return false, 'Schema database JG v4 non pronto. Controlla la console.'
    end

    return true
end

function GarageJG.insertVehicle(owner, plate, properties)
    local columns = readColumns()
    local keys, params = {}, {}

    local function add(name, value)
        if columns[name] then
            keys[#keys + 1] = ('`%s`'):format(name)
            params[#params + 1] = value
        end
    end

    add('owner', owner)
    add('plate', plate)
    add('vehicle', json.encode(properties))
    add('garage_id', Config.JG.initialGarageId)
    add('in_garage', 1)
    add('impound', 0)
    add('job_vehicle', 0)
    add('job_vehicle_rank', 0)
    add('gang_vehicle', 0)
    add('gang_vehicle_rank', 0)

    -- Campi ESX legacy / versioni schema JG: usa solo quelli realmente presenti.
    add('type', 'car')
    add('garage_type', 'car')
    add('stored', 1)
    add('fuel', math.floor(properties.fuelLevel or 100.0))
    add('engine', math.floor(properties.engineHealth or 1000.0))
    add('body', math.floor(properties.bodyHealth or 1000.0))

    local placeholders = {}
    for i = 1, #params do placeholders[i] = '?' end

    local sql = ('INSERT INTO `owned_vehicles` (%s) VALUES (%s)'):format(
        table.concat(keys, ', '), table.concat(placeholders, ', '))
    return MySQL.update.await(sql, params)
end

-- Comandi riservati alla console server, nessun giocatore puo' elencare i garage.
RegisterCommand('mr_jg4_list', function(src)
    if src ~= 0 then return end
    local garages, err = GarageJG.listGarages()
    if not garages then
        print('[muscle_rebuild] ' .. tostring(err))
        return
    end

    local list = {}
    for _, garage in pairs(garages) do
        if type(garage) == 'table' and type(garage.name) == 'string' then
            list[#list + 1] = {
                id = garage.name,
                category = garage.vehicle or garage.type or 'sconosciuto',
            }
        end
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    print(('[muscle_rebuild] JG v4: trovati %d garage/impound. Scegli un garage PUBBLICO auto come punto iniziale.'):format(#list))
    for _, item in ipairs(list) do
        print(('[muscle_rebuild] ID: %s | categoria: %s'):format(item.id, tostring(item.category)))
    end
end, false)

RegisterCommand('mr_jg4_check', function(src)
    if src ~= 0 then return end
    local ok, message = GarageJG.preflight()
    if ok then
        print(('[muscle_rebuild] OK: JG v4 disponibile, garage iniziale "%s" valido, colonne ESX verificate.'):
            format(Config.JG.initialGarageId))
        print('[muscle_rebuild] ATTENZIONE: verifica MANUALMENTE in /garageadmin > Settings che "Require transfers between public garages" sia OFF.')
        print('[muscle_rebuild] L\'API getAllGarages NON conferma le opzioni dei permessi e deposito globale.')
    else
        print('[muscle_rebuild] CONFIGURAZIONE NON PRONTA: ' .. tostring(message))
    end
end, false)

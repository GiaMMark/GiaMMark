-- AGGIUNGI QUESTA ENTRATA dentro al return { ... } di ox_inventory/data/items.lua
-- Non incollare un secondo "return {" e NON modificare gli altri item JG Mechanic.
['car_rottame'] = {
    label = 'Muscle Car Rottame',
    weight = 1000, -- grammi in ox_inventory
    stack = false,
    close = true,
    consume = 0, -- viene consumato SOLO quando il veicolo e' nel database
    description = 'Muscle car ricostruita. Usala una sola volta per ritirare la proprieta\'.',
    client = { export = 'GiaMMarK_varie.useCarToken' },
},

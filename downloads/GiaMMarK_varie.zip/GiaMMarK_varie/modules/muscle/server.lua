local Config = MuscleConfig
local ESX = exports['es_extended']:getSharedObject()
local inv = exports.ox_inventory
local sessions = {}
local working = {}
local redeeming = {}

local function notify(src, message, kind)
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Ricostruzione auto',
        description = message,
        type = kind or 'inform'
    })
end

local function authorised(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return false end
    local job = xPlayer.job
    local minGrade = job and Config.MechanicJobs[job.name]
    if minGrade == nil or (tonumber(job.grade) or -1) < minGrade then return false end

    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end
    local position = GetEntityCoords(ped)
    for _, bench in ipairs(Config.Benches) do
        if #(position - bench.coords) <= Config.MaxDistance then
            return true, xPlayer
        end
    end
    return false
end

local function hasAllParts(src)
    for _, component in ipairs(Config.Recipe) do
        if (inv:Search(src, 'count', component.name) or 0) < component.count then
            return false
        end
    end
    return true
end

local function canCarryToken(src)
    return inv:CanCarryItem(src, Config.ItemName, 1)
end

lib.callback.register('muscle_rebuild:getStatus', function(src)
    local ok = authorised(src)
    if not ok then
        return { allowed = false, message = 'Solo i meccanici presso il banco possono assemblare l\'auto.' }
    end

    local ingredients = {}
    local all = true
    for _, part in ipairs(Config.Recipe) do
        local have = inv:Search(src, 'count', part.name) or 0
        if have < part.count then all = false end
        ingredients[#ingredients + 1] = {
            label = part.label, name = part.name, need = part.count, have = have
        }
    end

    return {
        allowed = true,
        -- Lo spazio per il token si controlla DOPO aver consumato i pezzi,
        -- perche' questi liberano peso e slot nell'inventario.
        canCraft = all and not sessions[src] and not working[src],
        ingredients = ingredients
    }
end)

lib.callback.register('muscle_rebuild:beginCraft', function(src)
    local allowed = authorised(src)
    if not allowed then return { ok = false, message = 'Devi essere un meccanico vicino al banco.' } end
    if working[src] then return { ok = false, message = 'Stai gia\' creando un oggetto.' } end

    if sessions[src] then
        if os.time() - sessions[src].createdAt < math.ceil(Config.CraftDuration / 1000) + 120 then
            return { ok = false, message = 'Assemblaggio gia\' in corso.' }
        end
        sessions[src] = nil -- sessione scaduta
    end

    if not hasAllParts(src) then return { ok = false, message = 'Non hai tutti i materiali richiesti.' } end
    if not inv:Items(Config.ItemName) then
        return { ok = false, message = 'Item car_rottame non registrato in ox_inventory.' }
    end

    local nonce = MySQL.scalar.await('SELECT UUID()')
    if not nonce then return { ok = false, message = 'Database non disponibile.' } end

    sessions[src] = { nonce = nonce, createdAt = os.time() }
    return { ok = true, nonce = nonce }
end)

RegisterNetEvent('muscle_rebuild:cancelCraft', function(nonce)
    local src = source
    if sessions[src] and sessions[src].nonce == nonce and not working[src] then
        sessions[src] = nil
    end
end)

local function rollbackParts(src, removed)
    if not GetPlayerName(src) then
        print(('[muscle_rebuild] ATTENZIONE: player %s disconnesso; restituzione manuale richiesta: %s')
            :format(src, json.encode(removed)))
        return
    end
    for i = #removed, 1, -1 do
        local part = removed[i]
        local ok, result = pcall(function()
            return inv:AddItem(src, part.name, part.count)
        end)
        if not ok or not result then
            print(('[muscle_rebuild] ERRORE rimborso: %s x%s player %s'):format(part.name, part.count, src))
        end
    end
end

local function executeCraft(src, xPlayer)
    if not hasAllParts(src) then return false, 'I componenti non sono piu\' disponibili.' end
    if not inv:Items(Config.ItemName) then return false, 'Item car_rottame non registrato in ox_inventory.' end

    local removed = {}
    -- Riserva i componenti sul server (nessun client puo' decidere le quantita').
    for _, part in ipairs(Config.Recipe) do
        local ok, success = pcall(function()
            return inv:RemoveItem(src, part.name, part.count)
        end)
        if not ok or not success then
            rollbackParts(src, removed)
            return false, 'Impossibile consumare i materiali. Operazione annullata.'
        end
        removed[#removed + 1] = { name = part.name, count = part.count }
    end

    -- Verifica il peso e gli slot solo ORA: i materiali sono stati rimossi
    -- e hanno liberato spazio. Se il token comunque non entra, rimborsa tutto.
    if not canCarryToken(src) then
        rollbackParts(src, removed)
        return false, 'Inventario pieno anche dopo aver utilizzato i materiali. Materiali restituiti.'
    end

    local serial
    local success, failureReason = pcall(function()
        serial = MySQL.scalar.await('SELECT UUID()')
        assert(serial, 'UUID non generato')
        local inserted = MySQL.update.await(
            'INSERT INTO mr_car_tokens (serial, status, minted_by) VALUES (?, ?, ?)',
            { serial, 'issued', xPlayer.identifier }
        )
        assert(inserted == 1, 'Impossibile registrare il token')
        local added, response = inv:AddItem(src, Config.ItemName, 1, {
            serial = serial,
            description = 'Riscattabile una sola volta. Seriale: ' .. serial,
        })
        assert(added, tostring(response or 'Impossibile aggiungere l\'item'))
    end)

    if not success then
        print(('[muscle_rebuild] Craft fallito per %s: %s'):format(src, tostring(failureReason)))
        -- Se AddItem ha fallito, non deve restare una registrazione riscattabile.
        if serial then
            pcall(function()
                MySQL.update.await('DELETE FROM mr_car_tokens WHERE serial = ? AND status = ?', { serial, 'issued' })
            end)
        end
        rollbackParts(src, removed)
        return false, 'Assemblaggio fallito: materiali restituiti, controlla la console in caso di problemi.'
    end

    print(('[muscle_rebuild] %s ha creato car_rottame seriale %s'):format(xPlayer.identifier, serial))
    return true, 'Muscle car assemblata! Hai ricevuto 1x car_rottame.'
end

lib.callback.register('muscle_rebuild:finishCraft', function(src, nonce)
    if type(nonce) ~= 'string' then return { ok = false, message = 'Sessione non valida.' } end
    local session = sessions[src]
    if not session or session.nonce ~= nonce or working[src] then
        return { ok = false, message = 'Assemblaggio non autorizzato o scaduto.' }
    end
    local seconds = math.ceil(Config.CraftDuration / 1000)
    local elapsed = os.time() - session.createdAt
    if elapsed < seconds - 1 then
        return { ok = false, message = 'Attendi il completamento del montaggio.' }
    end
    if elapsed > seconds + 120 then
        sessions[src] = nil
        return { ok = false, message = 'Sessione scaduta, riprova dal banco.' }
    end
    sessions[src] = nil
    working[src] = true

    local allowed, xPlayer = authorised(src)
    if not allowed then
        working[src] = nil
        return { ok = false, message = 'Sei troppo lontano dal banco o non sei piu\' meccanico.' }
    end

    local callOK, success, message = pcall(executeCraft, src, xPlayer)
    working[src] = nil
    if not callOK then
        print('[muscle_rebuild] Errore crafting: ' .. tostring(success))
        return { ok = false, message = 'Errore inatteso. Contatta lo staff.' }
    end
    return { ok = success, message = message }
end)

local function uniquePlate()
    for _ = 1, 30 do
        local plate = ('RB%06d'):format(math.random(0, 999999))
        local taken = MySQL.scalar.await('SELECT 1 FROM owned_vehicles WHERE plate = ? LIMIT 1', { plate })
        if not taken then return plate end
    end
    return nil
end

local function markRedeemed(serial, plate, identifier)
    return MySQL.update.await([[
        UPDATE mr_car_tokens SET status = 'redeemed', redeemed_at = CURRENT_TIMESTAMP
        WHERE serial = ? AND status = 'processing' AND plate = ? AND claimed_by = ?
    ]], { serial, plate, identifier })
end

local function tryRecoverInsert(serial, plate, identifier)
    -- In caso di errore SQL non consideriamo il token libero finche' non siamo
    -- sicuri che NON esista un veicolo creato per questa richiesta.
    local found = MySQL.single.await('SELECT owner, vehicle FROM owned_vehicles WHERE plate = ? LIMIT 1', { plate })
    if found and found.owner == identifier and type(found.vehicle) == 'string' then
        local decodedOK, decoded = pcall(json.decode, found.vehicle)
        -- Una collisione della targa su un'altra auto dello stesso player
        -- NON deve consumare il secondo token.
        if decodedOK and type(decoded) == 'table' and decoded.muscleRebuildSerial == serial then
            markRedeemed(serial, plate, identifier)
            return true
        end
    end
    MySQL.update.await([[
        UPDATE mr_car_tokens SET status = 'issued', claimed_by = NULL, plate = NULL
        WHERE serial = ? AND status = 'processing' AND plate = ? AND claimed_by = ?
    ]], { serial, plate, identifier })
    return false
end

local function redeem(src, slot)
    if type(slot) ~= 'number' or slot % 1 ~= 0 then
        return false, 'Slot non valido.'
    end
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return false, 'Giocatore non disponibile.' end

    local token = inv:GetSlot(src, slot)
    if not token or token.name ~= Config.ItemName or token.count ~= 1 then
        return false, 'L\'item non si trova piu\' nello slot.'
    end
    local serial = token.metadata and token.metadata.serial
    if type(serial) ~= 'string' or #serial ~= 36 then
        return false, 'Rottame privo di seriale valido: usa un item ottenuto dal crafting.'
    end
    if not inv:Items(Config.ItemName) then return false, 'Item non registrato.' end
    if type(Config.VehicleModel) ~= 'string' or Config.VehicleModel == '' then
        return false, 'Modello veicolo non configurato.'
    end

    -- Prima di impegnare il seriale, verifica schema e garage JG.
    local garageOK, garageError = GarageJG.preflight()
    if not garageOK then return false, garageError end

    local plate = uniquePlate()
    if not plate then return false, 'Impossibile generare una targa libera.' end

    local owner = xPlayer.identifier
    local claim = MySQL.update.await([[
        UPDATE mr_car_tokens
        SET status = 'processing', claimed_by = ?, plate = ?
        WHERE serial = ? AND status = 'issued'
    ]], { owner, plate, serial })
    if claim ~= 1 then
        return false, 'Questo rottame e\' gia\' stato riscattato o non e\' valido.'
    end

    local props = {
        model = joaat(Config.VehicleModel),
        plate = plate,
        muscleRebuildSerial = serial, -- provenance per recovery/collisioni di targa
        fuelLevel = Config.VehicleProps.fuelLevel,
        engineHealth = Config.VehicleProps.engineHealth,
        bodyHealth = Config.VehicleProps.bodyHealth,
        petrolTankHealth = Config.VehicleProps.petrolTankHealth,
        dirtLevel = Config.VehicleProps.dirtLevel,
    }

    local insertedOK, rows = pcall(function()
        return GarageJG.insertVehicle(owner, plate, props)
    end)

    if not insertedOK or rows ~= 1 then
        print(('[muscle_rebuild] JG INSERT fallita (plate=%s): %s'):format(plate, tostring(rows)))
        if not tryRecoverInsert(serial, plate, owner) then
            return false, 'Salvataggio garage fallito; l\'item non e\' stato consumato.'
        end
    else
        local ok, affected = pcall(markRedeemed, serial, plate, owner)
        if not ok or affected ~= 1 then
            print(('[muscle_rebuild] ATTENZIONE: veicolo %s inserito ma stato token non finalizzato. Recupero al riavvio.'):format(plate))
        end
    end

    -- Se il token e' stato spostato, la registrazione nel DB impedisce comunque duplicazioni.
    local removed, reason = inv:RemoveItem(src, Config.ItemName, 1, { serial = serial }, slot)
    if not removed then
        print(('[muscle_rebuild] AVVISO: token %s riscattato ma non rimosso (%s). Non sara\' riscattabile ancora.'):format(serial, tostring(reason)))
    end

    print(('[muscle_rebuild] Token %s riscattato da %s: modello %s, targa %s'):format(serial, owner, Config.VehicleModel, plate))
    return true, ("Auto registrata! Targa: %s. Ritirala da qualsiasi garage PUBBLICO per auto (se la modalita comune JG e attiva)."):format(plate)
end

RegisterNetEvent('muscle_rebuild:redeemToken', function(slot)
    local src = source
    if redeeming[src] or working[src] then return end
    redeeming[src] = true
    local success, ok, message = pcall(redeem, src, slot)
    redeeming[src] = nil
    if not success then
        print(('[muscle_rebuild] ERRORE riscatto player %s: %s'):format(src, tostring(ok)))
        notify(src, 'Errore durante il riscatto. Non usare altri item e contatta lo staff.', 'error')
        return
    end
    notify(src, message, ok and 'success' or 'error')
end)

AddEventHandler('playerDropped', function()
    sessions[source] = nil
    -- Non resettare working/redeeming: una coroutine DB ancora in esecuzione
    -- deve poter terminare e poi liberare i lock in modo ordinato.
end)

CreateThread(function()
    -- Recupero dopo crash: verifica il seriale nella proprieta' JSON,
    -- non soltanto la targa, per non attribuire un'altra auto per collisione.
    local ok, err = pcall(function()
        local processing = MySQL.query.await([[ 
            SELECT serial, plate, claimed_by FROM mr_car_tokens WHERE status = 'processing'
        ]]) or {}

        for _, token in ipairs(processing) do
            local vehicle = token.plate and MySQL.single.await(
                'SELECT owner, vehicle FROM owned_vehicles WHERE plate = ? LIMIT 1', { token.plate }
            )
            if vehicle then
                local decodedOK, properties = pcall(json.decode, vehicle.vehicle or '')
                if vehicle.owner == token.claimed_by and decodedOK and type(properties) == 'table'
                    and properties.muscleRebuildSerial == token.serial then
                    markRedeemed(token.serial, token.plate, token.claimed_by)
                else
                    -- Token legacy o targa riutilizzata: non sbloccare automaticamente.
                    print(('[muscle_rebuild] RISCATTO DA VERIFICARE manualmente: serial=%s plate=%s'):
                        format(tostring(token.serial), tostring(token.plate)))
                end
            else
                MySQL.update.await([[
                    UPDATE mr_car_tokens SET status = 'issued', claimed_by = NULL, plate = NULL
                    WHERE serial = ? AND status = 'processing' AND plate = ?
                ]], { token.serial, token.plate })
            end
        end
    end)
    if not ok then
        print('[muscle_rebuild] ERRORE recupero token DB: ' .. tostring(err))
    end
end)

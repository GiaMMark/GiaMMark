local Config = MuscleConfig
-- Muscle Rebuild: un tavolo fisico, ox_target e un menu ox_lib essenziale.
local benches = {}
local crafting = false
local requesting = false
local finishing = false
local activeNonce = nil
local selectedBench = nil

local function notify(message, kind)
    lib.notify({
        title = 'Banco da lavoro',
        description = message,
        type = kind or 'inform',
    })
end

-- Tre animazioni consecutive al banco: riparazione, martellatura e saldatura.
-- Le durate sommate sono sempre Config.CraftDuration (verificata dal server).
-- I tool delle scenario sono quelli di GTA: nessun prop extra piazzato nella mappa.
local function playAssemblyAnimations()
    local total = math.max(3000, math.floor(tonumber(Config.CraftDuration) or 30000))
    local repairTime = math.floor(total * 0.40)
    local hammerTime = math.floor(total * 0.30)
    local weldingTime = total - repairTime - hammerTime

    local stages = {
        {
            label = 'Sistemazione dei componenti...',
            duration = repairTime,
            anim = { dict = 'mini@repair', clip = 'fixing_a_ped' },
        },
        {
            label = 'Montaggio e fissaggio dei pezzi...',
            duration = hammerTime,
            anim = { scenario = 'WORLD_HUMAN_HAMMERING' },
        },
        {
            label = 'Saldatura e rifiniture finali...',
            duration = weldingTime,
            anim = { scenario = 'WORLD_HUMAN_WELDING' },
        },
    }

    for _, stage in ipairs(stages) do
        local finished = lib.progressCircle({
            duration = stage.duration,
            label = stage.label,
            position = 'bottom',
            canCancel = true,
            useWhileDead = false,
            disable = { move = true, car = true, combat = true },
            anim = stage.anim,
        })
        if not finished then return false end
    end

    return true
end

local function beginCraft()
    if crafting or requesting or finishing then return end
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        return notify('Scendi dal veicolo per usare il banco.', 'error')
    end

    requesting = true
    local session = lib.callback.await('muscle_rebuild:beginCraft', false)
    requesting = false

    if not session or not session.ok or not session.nonce then
        return notify(session and session.message or 'Impossibile iniziare il montaggio.', 'error')
    end

    crafting = true
    activeNonce = session.nonce
    local nonce = session.nonce

    -- Rivolgi il personaggio verso il tavolo prima del montaggio.
    if selectedBench and DoesEntityExist(selectedBench) then
        TaskTurnPedToFaceEntity(PlayerPedId(), selectedBench, 700)
        Wait(700)
    end

    -- Riproduci tutte le fasi; ESC annulla in qualsiasi momento.
    -- Protezione pcall: non lasciare una sessione attiva se l'animazione fallisce.
    local ok, complete = pcall(playAssemblyAnimations)
    if not ok then
        print('[muscle_rebuild] Animazione crafting non riuscita: ' .. tostring(complete))
    end

    if not ok or not complete then
        if activeNonce == nonce then
            TriggerServerEvent('muscle_rebuild:cancelCraft', nonce)
            activeNonce = nil
        end
        crafting = false
        return notify(ok and 'Montaggio annullato. Nessun materiale consumato.' or
            'Animazione interrotta. Nessun materiale consumato.', ok and 'inform' or 'error')
    end

    finishing = true
    local result = lib.callback.await('muscle_rebuild:finishCraft', false, nonce)
    if activeNonce == nonce then activeNonce = nil end
    crafting = false
    finishing = false
    notify(result and result.message or 'Errore durante l\'assemblaggio.', result and result.ok and 'success' or 'error')
end

local function openWorkbench(targetEntity)
    if crafting or requesting or finishing then return end
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        return notify('Scendi dal veicolo per usare il banco.', 'error')
    end
    selectedBench = targetEntity and DoesEntityExist(targetEntity) and targetEntity or nil

    requesting = true
    local status = lib.callback.await('muscle_rebuild:getStatus', false)
    requesting = false
    if not status then return notify('Impossibile controllare i materiali.', 'error') end
    if not status.allowed then return notify(status.message or 'Non puoi utilizzare il banco.', 'error') end

    local parts = {}
    local missing = 0
    for _, item in ipairs(status.ingredients or {}) do
        local have = tonumber(item.have) or 0
        local needed = tonumber(item.need) or 0
        local ready = have >= needed
        if not ready then missing = missing + 1 end
        parts[#parts + 1] = {
            title = item.label or item.name,
            description = ('%d / %d disponibili'):format(have, needed),
            icon = ready and 'circle-check' or 'circle-xmark',
            iconColor = ready and '#36b37e' or '#e87566',
            readOnly = true,
        }
    end

    lib.registerContext({
        id = 'muscle_rebuild:parts',
        title = 'Materiali necessari',
        menu = 'muscle_rebuild:bench',
        options = parts,
    })

    local hint
    if missing > 0 then
        hint = ('Ti mancano materiali di %d tipi.'):format(missing)
    elseif not status.canCraft then
        hint = 'Un assemblaggio e\' gia\' in corso. Riprova tra poco.'
    else
        hint = 'Hai tutti i pezzi. Pronto per il montaggio.'
    end

    lib.registerContext({
        id = 'muscle_rebuild:bench',
        title = 'Banco da lavoro',
        options = {
            {
                title = 'Assembla veicolo',
                description = hint,
                icon = 'car-side',
                disabled = not status.canCraft,
                onSelect = beginCraft,
            },
            {
                title = 'Materiali richiesti',
                description = 'Controlla i pezzi necessari.',
                icon = 'screwdriver-wrench',
                menu = 'muscle_rebuild:parts',
            },
        },
    })
    lib.showContext('muscle_rebuild:bench')
end

-- ox_inventory: client.export = 'GiaMMarK_varie.useCarToken', consume = 0.
exports('useCarToken', function(data, slot)
    if crafting or requesting or finishing then return end
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        return notify('Scendi dal veicolo prima di riscattare il rottame.', 'error')
    end

    local hash = joaat(Config.VehicleModel)
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then
        return notify('Modello auto non installato. Contatta lo staff.', 'error')
    end

    exports.ox_inventory:useItem(data, function(usedItem)
        if usedItem and type(usedItem.slot) == 'number' then
            TriggerServerEvent('muscle_rebuild:redeemToken', usedItem.slot)
        end
    end)
end)

-- Spawna SOLO il tavolo, quando qualcuno e' nei pressi: nessuna zona invisibile
-- o altro prop. Creazione locale per non duplicare oggetti in rete.
local function spawnBench(index, bench)
    local model = joaat(bench.model or Config.BenchModel)
    if not IsModelInCdimage(model) or not IsModelValid(model) then
        print(('[muscle_rebuild] Modello tavolo non valido: %s'):format(tostring(bench.model or Config.BenchModel)))
        return
    end

    RequestModel(model)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(model) and GetGameTimer() < timeout do Wait(50) end
    if not HasModelLoaded(model) then
        print('[muscle_rebuild] Impossibile caricare il modello del tavolo.')
        return
    end

    local coords = bench.coords
    RequestCollisionAtCoord(coords.x, coords.y, coords.z)
    local obj = CreateObjectNoOffset(model, coords.x, coords.y, coords.z, false, false, false)
    SetModelAsNoLongerNeeded(model)
    if obj == 0 or not DoesEntityExist(obj) then
        print('[muscle_rebuild] Creazione tavolo fallita.')
        return
    end

    SetEntityHeading(obj, bench.rotation or 0.0)
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)

    local optionName = ('muscle_rebuild_bench_%d'):format(index)
    exports.ox_target:addLocalEntity(obj, {
        {
            name = optionName,
            label = bench.label or 'Usa banco da lavoro',
            icon = 'fa-solid fa-screwdriver-wrench',
            groups = Config.MechanicJobs,
            distance = 2.0,
            canInteract = function()
                return not crafting and not requesting and not finishing
            end,
            onSelect = function(data)
                openWorkbench(data and data.entity)
            end,
        },
    })
    benches[index] = { entity = obj, option = optionName }
end

local function deleteBench(index)
    local entry = benches[index]
    if not entry then return end
    if DoesEntityExist(entry.entity) then
        pcall(function()
            exports.ox_target:removeLocalEntity(entry.entity, entry.option)
        end)
        SetEntityAsMissionEntity(entry.entity, true, true)
        DeleteEntity(entry.entity)
    end
    benches[index] = nil
end

CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())
        for index, bench in ipairs(Config.Benches) do
            local distance = #(playerCoords - bench.coords)
            if distance <= 85.0 and not benches[index] then
                spawnBench(index, bench)
            elseif distance > 110.0 and benches[index] then
                deleteBench(index)
            end
        end
        Wait(2500)
    end
end)

-- Utile solo nel passaggio dalla vecchia versione con NUI.
RegisterCommand('mr_uifix', function()
    if not GiaMMarKUI.available('muscle') then
        notify('Chiudi prima il crafting o il telefono pubblico.', 'inform')
        return
    end
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    notify('Focus interfaccia ripristinato.')
end, false)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if activeNonce and not finishing then
        TriggerServerEvent('muscle_rebuild:cancelCraft', activeNonce)
    end
    for index in pairs(benches) do deleteBench(index) end
end)

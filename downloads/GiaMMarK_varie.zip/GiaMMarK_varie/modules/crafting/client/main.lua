local Config = CraftingConfig
local SendNUIMessage, RegisterNUICallback, SetNuiFocus = GiaMMarKUI.bind('crafting')
local ESX = exports.es_extended:getSharedObject()

local Stations = {}
local TargetZones = {}
local NuiOpen = false
local CurrentMode = nil
local CurrentStationId = nil
local CraftInProgress = false

local function showNotification(message, notificationType)
    lib.notify({
        title = 'Crafting',
        description = message,
        type = notificationType or 'inform'
    })
end

local function getCraftVisuals(animationId)
    local selectedAnimation

    for i = 1, #Config.Animations do
        local animation = Config.Animations[i]
        if animation.id == animationId then
            selectedAnimation = animation
            break
        end
    end

    if not selectedAnimation then
        for i = 1, #Config.Animations do
            local animation = Config.Animations[i]
            if animation.id == Config.DefaultAnimation then
                selectedAnimation = animation
                break
            end
        end
    end

    if not selectedAnimation then return nil, nil end

    local anim
    if selectedAnimation.scenario then
        anim = { scenario = selectedAnimation.scenario }
    elseif selectedAnimation.dict and selectedAnimation.clip then
        local dict = selectedAnimation.dict
        local clip = selectedAnimation.clip
        if selectedAnimation.femaleDict and selectedAnimation.femaleClip and not IsPedMale(PlayerPedId()) then
            dict = selectedAnimation.femaleDict
            clip = selectedAnimation.femaleClip
        end

        anim = {
            dict = dict,
            clip = clip,
            flag = selectedAnimation.flag or 49
        }
    end

    local prop
    if selectedAnimation.prop and selectedAnimation.prop.model then
        prop = {
            model = selectedAnimation.prop.model,
            bone = selectedAnimation.prop.bone or 60309,
            pos = selectedAnimation.prop.pos or { x = 0.0, y = 0.0, z = 0.0 },
            rot = selectedAnimation.prop.rot or { x = 0.0, y = 0.0, z = 0.0 },
            rotOrder = selectedAnimation.prop.rotOrder or 0
        }
    end

    return anim, prop
end

local function getCurrentCoords()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    return {
        x = math.floor(coords.x * 10000 + 0.5) / 10000,
        y = math.floor(coords.y * 10000 + 0.5) / 10000,
        z = math.floor(coords.z * 10000 + 0.5) / 10000,
        w = math.floor(GetEntityHeading(ped) * 10000 + 0.5) / 10000
    }
end

local function getStationPoints(station)
    if type(station) ~= 'table' then return {} end
    if type(station.points) == 'table' and #station.points > 0 then return station.points end
    if type(station.coords) == 'table' then return { station.coords } end
    return {}
end

local function isNearAnyStationPoint(coords, station, extraDistance)
    local maximumDistance = (station.radius or Config.DefaultInteractionRadius) + (extraDistance or 0.0)
    local points = getStationPoints(station)

    for i = 1, #points do
        local point = points[i]
        if #(coords - vec3(point.x, point.y, point.z)) <= maximumDistance then
            return true
        end
    end

    return false
end

local function closeNui()
    NuiOpen = false
    CurrentMode = nil
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

local function setNui(open, mode)
    NuiOpen = open
    CurrentMode = open and mode or nil
    SetNuiFocus(open, open)
end

local function getLocalJob()
    local playerData = ESX.GetPlayerData()
    return playerData and playerData.job
end

local function hasLocalAccess(station)
    if station.accessType == 'public' then return true end

    local job = getLocalJob()
    if not job then return false end

    for i = 1, #(station.jobs or {}) do
        local allowed = station.jobs[i]
        if allowed.name == job.name and (tonumber(job.grade) or 0) >= tonumber(allowed.minGrade or 0) then
            return true
        end
    end

    return false
end

local function openStation(stationId)
    if NuiOpen or CraftInProgress or not GiaMMarKUI.available('crafting') then return end

    local stationData, errorMessage = lib.callback.await('giammark_crafting:server:getStation', false, stationId)
    if not stationData then
        showNotification(errorMessage or 'Non puoi usare questa postazione.', 'error')
        return
    end

    -- Another UI may have opened while the server callback was awaiting.
    if not GiaMMarKUI.available('crafting') then return end
    CurrentStationId = stationId
    setNui(true, 'craft')
    SendNUIMessage({
        action = 'openCraft',
        station = stationData
    })
end

local function removeTargetZones()
    if GetResourceState('ox_target') ~= 'started' then
        TargetZones = {}
        return
    end

    for _, zoneId in pairs(TargetZones) do
        pcall(function()
            exports.ox_target:removeZone(zoneId)
        end)
    end
    TargetZones = {}
end

local function rebuildTargetZones()
    removeTargetZones()
    if not Config.UseOxTarget or GetResourceState('ox_target') ~= 'started' then return end

    for stationId, station in pairs(Stations) do
        local capturedId = stationId
        local capturedStation = station
        local points = getStationPoints(station)

        for pointIndex = 1, #points do
            local point = points[pointIndex]
            TargetZones[#TargetZones + 1] = exports.ox_target:addSphereZone({
                coords = vec3(point.x, point.y, point.z),
                radius = station.radius or Config.DefaultInteractionRadius,
                debug = false,
                options = {
                    {
                        name = ('giammark_crafting_%s_%s'):format(stationId, pointIndex),
                        icon = Config.TargetIcon,
                        label = Config.TargetLabel,
                        distance = station.radius or Config.DefaultInteractionRadius,
                        canInteract = function()
                            return not CraftInProgress and hasLocalAccess(capturedStation)
                        end,
                        onSelect = function()
                            openStation(capturedId)
                        end
                    }
                }
            })
        end
    end
end

local function indexStations(stations)
    Stations = {}
    for i = 1, #(stations or {}) do
        Stations[tonumber(stations[i].id)] = stations[i]
    end
    rebuildTargetZones()
end

local function getAdminData()
    local adminData, errorMessage = lib.callback.await('giammark_crafting:server:getAdminData', false)
    if not adminData then
        showNotification(errorMessage or 'Non puoi aprire il pannello admin.', 'error')
        return nil
    end
    adminData.currentCoords = getCurrentCoords()
    return adminData
end

local function openAdmin()
    if NuiOpen or CraftInProgress or not GiaMMarKUI.available('crafting') then return end

    local adminData = getAdminData()
    if not adminData or not GiaMMarKUI.available('crafting') then return end

    setNui(true, 'admin')
    SendNUIMessage({
        action = 'openAdmin',
        data = adminData
    })
end

local function refreshAdminInterface()
    local adminData = getAdminData()
    if not adminData then
        closeNui()
        return
    end

    SendNUIMessage({
        action = 'adminData',
        data = adminData
    })
end

RegisterNetEvent('giammark_crafting:client:setStations', function(stations)
    indexStations(stations)
end)

RegisterNetEvent('esx:setJob', function()
    rebuildTargetZones()
end)

RegisterCommand(Config.AdminCommand, function()
    openAdmin()
end, false)

RegisterNUICallback('close', function(_, callback)
    closeNui()
    callback({ ok = true })
end)

RegisterNUICallback('craft', function(data, callback)
    if CraftInProgress or CurrentMode ~= 'craft' or not CurrentStationId then
        callback({ ok = false })
        return
    end

    local recipeId = type(data) == 'table' and data.recipeId or nil
    local quantity = type(data) == 'table' and tonumber(data.quantity) or 1
    local craftData, errorMessage = lib.callback.await(
        'giammark_crafting:server:startCraft',
        false,
        CurrentStationId,
        recipeId,
        quantity
    )

    if not craftData then
        showNotification(errorMessage or 'Non puoi iniziare questa lavorazione.', 'error')
        callback({ ok = false })
        return
    end

    callback({ ok = true })
    CraftInProgress = true
    local stationId = CurrentStationId
    closeNui()

    local craftAnim, craftProp = getCraftVisuals(craftData.animation)

    local completed = lib.progressCircle({
        duration = craftData.duration,
        position = 'bottom',
        label = ('Creazione: %s'):format(craftData.label),
        useWhileDead = false,
        canCancel = true,
        disable = {
            move = true,
            car = true,
            combat = true
        },
        anim = craftAnim,
        prop = craftProp
    })

    if completed then
        local success, finishMessage = lib.callback.await(
            'giammark_crafting:server:finishCraft',
            false,
            craftData.token
        )
        showNotification(finishMessage or (success and 'Oggetto creato.' or 'Creazione non riuscita.'), success and 'success' or 'error')
    else
        TriggerServerEvent('giammark_crafting:server:cancelCraft', craftData.token)
        showNotification('Lavorazione annullata.', 'error')
    end

    CraftInProgress = false

    Wait(250)
    local pedCoords = GetEntityCoords(PlayerPedId())
    local station = Stations[tonumber(stationId)]
    if station and isNearAnyStationPoint(pedCoords, station, Config.ServerDistanceTolerance) then
        openStation(stationId)
    end
end)

RegisterNUICallback('adminUseCurrentCoords', function(_, callback)
    callback({ ok = true, coords = getCurrentCoords() })
end)

RegisterNUICallback('adminSave', function(data, callback)
    if CurrentMode ~= 'admin' then
        callback({ ok = false, message = 'Pannello non attivo.' })
        return
    end

    local success, result = lib.callback.await('giammark_crafting:server:saveStation', false, data)
    if not success then
        showNotification(result or 'Salvataggio non riuscito.', 'error')
        callback({ ok = false, message = result })
        return
    end

    showNotification('Postazione salvata correttamente.', 'success')
    callback({ ok = true, id = result })
    refreshAdminInterface()
end)

RegisterNUICallback('adminDelete', function(data, callback)
    if CurrentMode ~= 'admin' then
        callback({ ok = false })
        return
    end

    local success, errorMessage = lib.callback.await(
        'giammark_crafting:server:deleteStation',
        false,
        data and data.id
    )

    if not success then
        showNotification(errorMessage or 'Eliminazione non riuscita.', 'error')
        callback({ ok = false, message = errorMessage })
        return
    end

    showNotification('Postazione eliminata.', 'success')
    callback({ ok = true })
    refreshAdminInterface()
end)

RegisterNUICallback('adminTeleport', function(data, callback)
    local station = data and Stations[tonumber(data.id)]
    if not station then
        callback({ ok = false })
        return
    end

    local points = getStationPoints(station)
    local pointIndex = math.max(1, math.floor(tonumber(data.pointIndex) or 1))
    local point = points[pointIndex] or points[1]
    if not point then
        callback({ ok = false })
        return
    end

    closeNui()
    local ped = PlayerPedId()
    SetEntityCoords(ped, point.x, point.y, point.z + 0.2, false, false, false, false)
    SetEntityHeading(ped, point.w or 0.0)
    callback({ ok = true })
end)

CreateThread(function()
    Wait(1000)
    local stations = lib.callback.await('giammark_crafting:server:getStations', false)
    indexStations(stations or {})

    while true do
        local useFallback = not Config.UseOxTarget or GetResourceState('ox_target') ~= 'started'
        if not useFallback or NuiOpen or CraftInProgress then
            Wait(600)
        else
            local sleep = 600
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)

            for stationId, station in pairs(Stations) do
                if hasLocalAccess(station) then
                    local points = getStationPoints(station)
                    for pointIndex = 1, #points do
                        local point = points[pointIndex]
                        local stationCoords = vec3(point.x, point.y, point.z)
                        local distance = #(coords - stationCoords)

                        if distance <= Config.DrawDistance then
                            sleep = 0
                            DrawMarker(
                                Config.Marker.type,
                                point.x,
                                point.y,
                                point.z + 0.15,
                                0.0, 0.0, 0.0,
                                0.0, 0.0, 0.0,
                                Config.Marker.scale.x,
                                Config.Marker.scale.y,
                                Config.Marker.scale.z,
                                Config.Marker.color.r,
                                Config.Marker.color.g,
                                Config.Marker.color.b,
                                Config.Marker.color.a,
                                false, true, 2, false, nil, nil, false
                            )

                            if distance <= (station.radius or Config.DefaultInteractionRadius) then
                                ESX.ShowHelpNotification(('[E] %s'):format(Config.TargetLabel))
                                if IsControlJustReleased(0, 38) then openStation(stationId) end
                            end
                        end
                    end
                end
            end

            Wait(sleep)
        end
    end
end)

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == 'ox_target' and Config.UseOxTarget then
        rebuildTargetZones()
    elseif resourceName == GetCurrentResourceName() then
        TriggerServerEvent('giammark_crafting:server:requestSync')
    end
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        removeTargetZones()
        SetNuiFocus(false, false)
    end
end)

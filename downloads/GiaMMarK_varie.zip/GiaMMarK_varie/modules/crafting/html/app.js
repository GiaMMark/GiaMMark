const resourceName = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'GiaMMarK_varie';

const app = document.getElementById('app');
const craftView = document.getElementById('craft-view');
const adminView = document.getElementById('admin-view');
const toast = document.getElementById('toast');

let mode = null;
let station = null;
let selectedRecipeId = null;
let quantity = 1;
let adminData = null;
let editingStation = null;
let saving = false;

const post = async (event, data = {}) => {
    try {
        const response = await fetch(`https://${resourceName}/crafting_${event}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify(data)
        });
        return await response.json();
    } catch (_) {
        return { ok: false };
    }
};

const escapeHtml = (value) => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

const deepCopy = (value) => JSON.parse(JSON.stringify(value));
const itemImage = (name) => `nui://ox_inventory/web/images/${encodeURIComponent(name)}.png`;
const secondsLabel = (milliseconds) => {
    const seconds = Math.ceil(Number(milliseconds || 0) / 1000);
    if (seconds < 60) return `${seconds} sec`;
    const minutes = Math.floor(seconds / 60);
    const remainder = seconds % 60;
    return remainder ? `${minutes} min ${remainder} sec` : `${minutes} min`;
};

const showToast = (message) => {
    toast.textContent = message || 'Controlla i dati inseriti.';
    toast.classList.remove('hidden');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2800);
};

const closeInterface = () => post('close');

const hideAll = () => {
    mode = null;
    app.classList.add('hidden');
    craftView.classList.add('hidden');
    adminView.classList.add('hidden');
    toast.classList.add('hidden');
};

const openCraft = (newStation) => {
    mode = 'craft';
    station = newStation;
    selectedRecipeId = station.recipes?.[0]?.id || null;
    quantity = 1;
    app.classList.remove('hidden');
    adminView.classList.add('hidden');
    craftView.classList.remove('hidden');
    document.getElementById('craft-title').textContent = station.name || 'Banco da lavoro';
    renderCraft();
};

const renderCraft = () => {
    const recipes = station?.recipes || [];
    document.getElementById('recipe-count').textContent = recipes.length;
    document.getElementById('recipe-list').innerHTML = recipes.map(recipe => `
        <button class="recipe-card ${recipe.id === selectedRecipeId ? 'active' : ''}" data-recipe="${escapeHtml(recipe.id)}">
            <img class="item-picture" src="${itemImage(recipe.item)}" onerror="this.style.opacity='.18'" alt="">
            <span>
                <strong>${escapeHtml(recipe.label)}</strong>
                <small>${escapeHtml(recipe.itemLabel)} · ${secondsLabel(recipe.duration)}</small>
            </span>
            <span class="output-badge">×${Number(recipe.amount || 1)}</span>
        </button>
    `).join('') || '<div class="free-recipe">Nessuna ricetta disponibile.</div>';

    document.querySelectorAll('[data-recipe]').forEach(button => {
        button.addEventListener('click', () => {
            selectedRecipeId = button.dataset.recipe;
            quantity = 1;
            renderCraft();
        });
    });

    renderRecipeDetail();
};

const renderRecipeDetail = () => {
    const detail = document.getElementById('recipe-detail');
    const recipe = station?.recipes?.find(entry => entry.id === selectedRecipeId);
    if (!recipe) {
        detail.innerHTML = '<div class="detail-empty"><div><span>⚒</span><p>Seleziona un oggetto da produrre.</p></div></div>';
        return;
    }

    const ingredients = recipe.ingredients || [];
    const canCraft = ingredients.every(entry => Number(entry.owned || 0) >= Number(entry.amount || 0) * quantity);
    const ingredientHtml = ingredients.length ? ingredients.map(entry => {
        const needed = Number(entry.amount || 0) * quantity;
        const owned = Number(entry.owned || 0);
        const missing = owned < needed;
        return `
            <div class="ingredient ${missing ? 'missing' : ''}">
                <img src="${itemImage(entry.item)}" onerror="this.style.opacity='.18'" alt="">
                <span><strong>${escapeHtml(entry.label)}</strong><small>Disponibili: ${owned}</small></span>
                <b>${owned}/${needed}</b>
            </div>
        `;
    }).join('') : '<div class="free-recipe">Questa ricetta non richiede ingredienti.</div>';

    detail.innerHTML = `
        <div class="product-head">
            <img class="item-picture" src="${itemImage(recipe.item)}" onerror="this.style.opacity='.18'" alt="">
            <div>
                <span class="eyebrow">PRODOTTO FINALE</span>
                <h2>${escapeHtml(recipe.label)}</h2>
                <p>Otterrai <strong>${Number(recipe.amount || 1) * quantity}× ${escapeHtml(recipe.itemLabel)}</strong>.</p>
                <div class="meta-row">
                    <span class="pill">⏱ ${secondsLabel(Number(recipe.duration || 0) * quantity)}</span>
                    <span class="pill">▦ ${ingredients.length} ingredienti</span>
                    <span class="pill">⚒ ${escapeHtml(recipe.animationLabel || 'Lavorazione')}</span>
                </div>
            </div>
        </div>
        <div class="ingredients-title">
            <h3>Materiali necessari</h3>
            <span>Le quantità cambiano in base al numero scelto</span>
        </div>
        <div class="ingredient-grid">${ingredientHtml}</div>
        <div class="craft-footer">
            <div class="quantity-wrap">
                <label>QUANTITÀ LAVORAZIONI</label>
                <div class="quantity-control">
                    <button id="qty-minus">−</button><span>${quantity}</span><button id="qty-plus">＋</button>
                </div>
            </div>
            <button id="craft-button" class="button primary large" ${canCraft ? '' : 'disabled'}>
                ${canCraft ? `Crea ${Number(recipe.amount || 1) * quantity}× oggetto` : 'Materiali insufficienti'}
            </button>
        </div>
    `;

    document.getElementById('qty-minus').onclick = () => {
        quantity = Math.max(1, quantity - 1);
        renderRecipeDetail();
    };
    document.getElementById('qty-plus').onclick = () => {
        quantity = Math.min(Number(station.maxQuantity || 10), quantity + 1);
        renderRecipeDetail();
    };
    document.getElementById('craft-button').onclick = async (event) => {
        event.currentTarget.disabled = true;
        const result = await post('craft', { recipeId: recipe.id, quantity });
        if (!result?.ok) event.currentTarget.disabled = !canCraft;
    };
};

const openAdmin = (data) => {
    mode = 'admin';
    adminData = data;
    editingStation = null;
    app.classList.remove('hidden');
    craftView.classList.add('hidden');
    adminView.classList.remove('hidden');
    renderAdmin();
};

const renderAdmin = () => {
    const stations = adminData?.stations || [];
    document.getElementById('station-count').textContent = stations.length;
    document.getElementById('station-list').innerHTML = stations.map(entry => `
        <div class="station-card ${Number(editingStation?.id) === Number(entry.id) ? 'active' : ''}">
            <button class="station-main" data-edit-station="${Number(entry.id)}">
                <strong>${escapeHtml(entry.name)}</strong>
                <small>${entry.accessType === 'job' ? `🔒 ${entry.jobs?.length || 0} job` : '🌐 Pubblico'} · ${entry.recipes?.length || 0} ricette · ${(entry.points?.length || (entry.coords ? 1 : 0))} punti</small>
            </button>
            <div class="station-actions">
                <button data-teleport="${Number(entry.id)}">Raggiungi P1</button>
                <button class="delete" data-delete="${Number(entry.id)}">Elimina</button>
            </div>
        </div>
    `).join('') || '<div class="free-recipe">Nessuna postazione creata.</div>';

    document.querySelectorAll('[data-edit-station]').forEach(button => {
        button.onclick = () => editExistingStation(Number(button.dataset.editStation));
    });
    document.querySelectorAll('[data-teleport]').forEach(button => {
        button.onclick = () => post('adminTeleport', { id: Number(button.dataset.teleport) });
    });
    document.querySelectorAll('[data-delete]').forEach(button => {
        button.onclick = () => deleteStation(Number(button.dataset.delete));
    });

    if (editingStation) renderStationEditor();
    else {
        document.getElementById('admin-empty').classList.remove('hidden');
        document.getElementById('station-editor').classList.add('hidden');
    }
};

const newStation = () => {
    editingStation = {
        id: null,
        name: 'Nuovo banco da lavoro',
        points: [deepCopy(adminData.currentCoords || { x: 0, y: 0, z: 0, w: 0 })],
        radius: 2,
        accessType: 'public',
        jobs: [],
        recipes: [{ label: '', item: '', amount: 1, duration: 5000, animation: adminData.defaultAnimation || 'hammering', ingredients: [{ item: '', amount: 1 }] }]
    };
    renderAdmin();
};

const editExistingStation = (stationId) => {
    const found = adminData.stations.find(entry => Number(entry.id) === Number(stationId));
    if (!found) return;
    editingStation = deepCopy(found);
    if (!Array.isArray(editingStation.points) || !editingStation.points.length) {
        editingStation.points = editingStation.coords ? [deepCopy(editingStation.coords)] : [];
    }
    renderAdmin();
};

const optionsForJobs = (selected) => (adminData.jobs || []).map(job =>
    `<option value="${escapeHtml(job.name)}" ${job.name === selected ? 'selected' : ''}>${escapeHtml(job.label)} (${escapeHtml(job.name)})</option>`
).join('');

const optionsForGrades = (jobName, selectedGrade) => {
    const job = (adminData.jobs || []).find(entry => entry.name === jobName);
    const grades = job?.grades?.length ? job.grades : [{ grade: 0, label: 'Grado 0' }];
    return grades.map(grade =>
        `<option value="${Number(grade.grade)}" ${Number(grade.grade) === Number(selectedGrade) ? 'selected' : ''}>Da ${escapeHtml(grade.label)} (${Number(grade.grade)})</option>`
    ).join('');
};

const optionsForAnimations = (selectedAnimation) => (adminData.animations || []).map(animation =>
    `<option value="${escapeHtml(animation.id)}" ${animation.id === (selectedAnimation || adminData.defaultAnimation || 'hammering') ? 'selected' : ''}>${escapeHtml(animation.label)}</option>`
).join('');

const itemDatalist = () => `<datalist id="craft-items">${(adminData.items || []).map(item =>
    `<option value="${escapeHtml(item.name)}">${escapeHtml(item.label)}</option>`
).join('')}</datalist>`;

const renderStationEditor = () => {
    const editor = document.getElementById('station-editor');
    document.getElementById('admin-empty').classList.add('hidden');
    editor.classList.remove('hidden');

    const jobsHtml = (editingStation.jobs || []).map((job, index) => `
        <div class="job-row" data-job-row="${index}">
            <select class="job-name" data-job-select="${index}">${optionsForJobs(job.name)}</select>
            <select class="job-grade">${optionsForGrades(job.name, job.minGrade)}</select>
            <button class="remove-row" data-remove-job="${index}">×</button>
        </div>
    `).join('');

    if (!Array.isArray(editingStation.points) || !editingStation.points.length) {
        editingStation.points = editingStation.coords ? [deepCopy(editingStation.coords)] : [deepCopy(adminData.currentCoords || { x: 0, y: 0, z: 0, w: 0 })];
    }

    const pointsHtml = editingStation.points.map((point, pointIndex) => `
        <div class="craft-point" data-point-row="${pointIndex}">
            <div class="point-head"><strong>PUNTO ${pointIndex + 1}</strong><span>Lo stesso crafting sara' disponibile qui.</span></div>
            <div class="coord-row">
                <div class="field"><label>X</label><input class="point-x" type="number" step="0.0001" value="${Number(point.x || 0)}"></div>
                <div class="field"><label>Y</label><input class="point-y" type="number" step="0.0001" value="${Number(point.y || 0)}"></div>
                <div class="field"><label>Z</label><input class="point-z" type="number" step="0.0001" value="${Number(point.z || 0)}"></div>
                <div class="field"><label>Direzione</label><input class="point-w" type="number" step="0.0001" value="${Number(point.w || 0)}"></div>
                <button class="button primary" data-use-current-point="${pointIndex}">Usa posizione attuale</button>
                <button class="button danger" data-remove-point="${pointIndex}">Rimuovi</button>
            </div>
        </div>
    `).join('');

    const recipesHtml = (editingStation.recipes || []).map((recipe, recipeIndex) => `
        <article class="admin-recipe" data-recipe-row="${recipeIndex}">
            <div class="recipe-admin-head">
                <strong>RICETTA ${recipeIndex + 1}</strong>
                <button class="button danger" data-remove-recipe="${recipeIndex}">Elimina ricetta</button>
            </div>
            <div class="form-grid">
                <div class="field wide"><label>Nome mostrato</label><input class="recipe-label" value="${escapeHtml(recipe.label)}" placeholder="Es. Kit riparazione"></div>
                <div class="field"><label>Item prodotto</label><input class="recipe-item" list="craft-items" value="${escapeHtml(recipe.item)}" placeholder="fixkit"></div>
                <div class="field"><label>Quantità ottenuta</label><input class="recipe-amount" type="number" min="1" value="${Number(recipe.amount || 1)}"></div>
                <div class="field"><label>Durata (secondi)</label><input class="recipe-duration" type="number" min="1" value="${Math.max(1, Number(recipe.duration || 1000) / 1000)}"></div>
                <div class="field"><label>Animazione player</label><select class="recipe-animation">${optionsForAnimations(recipe.animation)}</select></div>
            </div>
            <div class="ingredients-admin">
                <label>INGREDIENTI RICHIESTI</label>
                ${(recipe.ingredients || []).map((ingredient, ingredientIndex) => `
                    <div class="ingredient-row-admin" data-ingredient-row="${ingredientIndex}">
                        <input class="ingredient-item" list="craft-items" value="${escapeHtml(ingredient.item)}" placeholder="Nome item">
                        <input class="ingredient-amount" type="number" min="1" value="${Number(ingredient.amount || 1)}" placeholder="Quantità">
                        <button class="remove-row" data-remove-ingredient="${recipeIndex}:${ingredientIndex}">×</button>
                    </div>
                `).join('')}
                <button class="add-row" data-add-ingredient="${recipeIndex}">＋ Aggiungi ingrediente</button>
                <div class="helper">Puoi lasciare la lista vuota per creare una ricetta gratuita.</div>
            </div>
        </article>
    `).join('');

    editor.innerHTML = `
        ${itemDatalist()}
        <div class="editor-head">
            <div><span class="eyebrow">${editingStation.id ? `POSTAZIONE #${Number(editingStation.id)}` : 'NUOVA POSTAZIONE'}</span><h2>${editingStation.id ? 'Modifica banco crafting' : 'Crea banco crafting'}</h2></div>
            <div class="editor-actions"><button id="cancel-editor" class="button ghost">Annulla</button><button id="save-station-top" class="button primary">Salva modifiche</button></div>
        </div>

        <div class="form-section">
            <div class="form-section-title"><h3>Informazioni generali</h3><span>Nome, accesso e raggio d'interazione</span></div>
            <div class="form-grid">
                <div class="field wide"><label>Nome postazione</label><input id="station-name-input" value="${escapeHtml(editingStation.name)}"></div>
                <div class="field"><label>Raggio interazione</label><input id="station-radius-input" type="number" min="1" max="5" step="0.1" value="${Number(editingStation.radius || 2)}"></div>
                <div class="field"><label>Tipo accesso</label><select id="access-type-input"><option value="public" ${editingStation.accessType !== 'job' ? 'selected' : ''}>Pubblico</option><option value="job" ${editingStation.accessType === 'job' ? 'selected' : ''}>Limitato per job</option></select></div>
            </div>
        </div>

        <div class="form-section">
            <div class="form-section-title"><h3>Punti in gioco</h3><span>Puoi usare lo stesso crafting in piu' posizioni</span></div>
            <div id="points-container">${pointsHtml}</div>
            <button id="add-current-point" class="add-row">＋ Aggiungi la posizione attuale</button>
            <div class="helper">Tutti i punti condividono nome, accessi e ricette della stessa postazione.</div>
        </div>

        <div id="jobs-section" class="form-section ${editingStation.accessType === 'job' ? '' : 'hidden'}">
            <div class="form-section-title"><h3>Job autorizzati</h3><span>Puoi consentire più lavori e impostare il grado minimo</span></div>
            <div id="jobs-container">${jobsHtml}</div>
            <button id="add-job" class="add-row">＋ Aggiungi job</button>
        </div>

        <div class="form-section">
            <div class="form-section-title"><h3>Ricette disponibili</h3><span>Oggetti prodotti, tempi e materiali necessari</span></div>
            <div id="recipes-container">${recipesHtml}</div>
            <button id="add-recipe" class="add-row">＋ Aggiungi ricetta</button>
        </div>

        <div class="editor-save-bar"><button id="save-station-bottom" class="button primary large">Salva postazione</button></div>
    `;

    bindEditorEvents();
};

const syncEditor = () => {
    if (!editingStation) return;
    editingStation.name = document.getElementById('station-name-input')?.value || '';
    editingStation.radius = Number(document.getElementById('station-radius-input')?.value || 2);
    editingStation.accessType = document.getElementById('access-type-input')?.value || 'public';
    editingStation.points = [...document.querySelectorAll('[data-point-row]')].map(row => ({
        x: Number(row.querySelector('.point-x')?.value || 0),
        y: Number(row.querySelector('.point-y')?.value || 0),
        z: Number(row.querySelector('.point-z')?.value || 0),
        w: Number(row.querySelector('.point-w')?.value || 0)
    }));
    editingStation.coords = editingStation.points[0] || null;

    editingStation.jobs = [...document.querySelectorAll('[data-job-row]')].map(row => ({
        name: row.querySelector('.job-name')?.value || '',
        minGrade: Number(row.querySelector('.job-grade')?.value || 0)
    }));

    editingStation.recipes = [...document.querySelectorAll('[data-recipe-row]')].map(row => ({
        label: row.querySelector('.recipe-label')?.value || '',
        item: row.querySelector('.recipe-item')?.value || '',
        amount: Number(row.querySelector('.recipe-amount')?.value || 1),
        duration: Math.round(Number(row.querySelector('.recipe-duration')?.value || 1) * 1000),
        animation: row.querySelector('.recipe-animation')?.value || adminData.defaultAnimation || 'hammering',
        ingredients: [...row.querySelectorAll('[data-ingredient-row]')].map(ingredientRow => ({
            item: ingredientRow.querySelector('.ingredient-item')?.value || '',
            amount: Number(ingredientRow.querySelector('.ingredient-amount')?.value || 1)
        }))
    }));
};

const bindEditorEvents = () => {
    document.getElementById('cancel-editor').onclick = () => { editingStation = null; renderAdmin(); };
    document.getElementById('save-station-top').onclick = saveStation;
    document.getElementById('save-station-bottom').onclick = saveStation;
    document.getElementById('add-current-point').onclick = addCurrentPoint;
    document.getElementById('access-type-input').onchange = (event) => {
        syncEditor();
        document.getElementById('jobs-section').classList.toggle('hidden', event.target.value !== 'job');
    };
    document.getElementById('add-job').onclick = () => {
        syncEditor();
        const firstJob = adminData.jobs?.[0];
        if (!firstJob) return showToast('Non risultano job ESX configurati.');
        editingStation.jobs.push({ name: firstJob.name, minGrade: 0 });
        renderStationEditor();
    };
    document.getElementById('add-recipe').onclick = () => {
        syncEditor();
        editingStation.recipes.push({ label: '', item: '', amount: 1, duration: 5000, animation: adminData.defaultAnimation || 'hammering', ingredients: [{ item: '', amount: 1 }] });
        renderStationEditor();
        document.querySelectorAll('.admin-recipe')[editingStation.recipes.length - 1]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    };

    document.querySelectorAll('[data-use-current-point]').forEach(button => {
        button.onclick = () => useCurrentCoords(Number(button.dataset.useCurrentPoint));
    });
    document.querySelectorAll('[data-remove-point]').forEach(button => {
        button.onclick = () => {
            syncEditor();
            if (editingStation.points.length <= 1) return showToast('La postazione deve avere almeno un punto.');
            editingStation.points.splice(Number(button.dataset.removePoint), 1);
            renderStationEditor();
        };
    });

    document.querySelectorAll('[data-job-select]').forEach(select => {
        select.onchange = () => {
            syncEditor();
            renderStationEditor();
        };
    });
    document.querySelectorAll('[data-remove-job]').forEach(button => {
        button.onclick = () => {
            syncEditor();
            editingStation.jobs.splice(Number(button.dataset.removeJob), 1);
            renderStationEditor();
        };
    });
    document.querySelectorAll('[data-remove-recipe]').forEach(button => {
        button.onclick = () => {
            syncEditor();
            editingStation.recipes.splice(Number(button.dataset.removeRecipe), 1);
            renderStationEditor();
        };
    });
    document.querySelectorAll('[data-add-ingredient]').forEach(button => {
        button.onclick = () => {
            syncEditor();
            editingStation.recipes[Number(button.dataset.addIngredient)].ingredients.push({ item: '', amount: 1 });
            renderStationEditor();
        };
    });
    document.querySelectorAll('[data-remove-ingredient]').forEach(button => {
        button.onclick = () => {
            syncEditor();
            const [recipeIndex, ingredientIndex] = button.dataset.removeIngredient.split(':').map(Number);
            editingStation.recipes[recipeIndex].ingredients.splice(ingredientIndex, 1);
            renderStationEditor();
        };
    });
};

const useCurrentCoords = async (pointIndex) => {
    syncEditor();
    const result = await post('adminUseCurrentCoords');
    if (!result?.ok || !result.coords || !editingStation.points?.[pointIndex]) return;
    editingStation.points[pointIndex] = result.coords;
    renderStationEditor();
};

const addCurrentPoint = async () => {
    syncEditor();
    const maxPoints = Number(adminData?.limits?.maxPointsPerStation || 20);
    if ((editingStation.points?.length || 0) >= maxPoints) {
        return showToast(`Puoi inserire al massimo ${maxPoints} punti.`);
    }

    const result = await post('adminUseCurrentCoords');
    if (!result?.ok || !result.coords) return;
    editingStation.points.push(result.coords);
    renderStationEditor();
    document.querySelectorAll('.craft-point')[editingStation.points.length - 1]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
};

const saveStation = async () => {
    if (saving || !editingStation) return;
    syncEditor();

    if (!editingStation.name.trim()) return showToast('Inserisci il nome della postazione.');
    if (!editingStation.points?.length) return showToast('Aggiungi almeno un punto alla postazione.');
    if (!editingStation.recipes.length) return showToast('Aggiungi almeno una ricetta.');
    if (editingStation.accessType === 'job' && !editingStation.jobs.length) return showToast('Aggiungi almeno un job autorizzato.');

    saving = true;
    const result = await post('adminSave', editingStation);
    saving = false;
    if (!result?.ok) showToast(result?.message || 'Controlla i dati della postazione.');
};

const deleteStation = async (stationId) => {
    const entry = adminData.stations.find(station => Number(station.id) === Number(stationId));
    if (!entry || !window.confirm(`Eliminare definitivamente "${entry.name}"?`)) return;
    const result = await post('adminDelete', { id: stationId });
    if (!result?.ok) showToast(result?.message || 'Eliminazione non riuscita.');
    if (Number(editingStation?.id) === Number(stationId)) editingStation = null;
};

document.querySelectorAll('.close-button').forEach(button => button.addEventListener('click', closeInterface));
document.getElementById('new-station').addEventListener('click', newStation);

document.addEventListener('keyup', event => {
    if (event.key === 'Escape' && mode) closeInterface();
});

window.addEventListener('message', event => {
    const payload = event.data || {};
    if (payload.action === 'openCraft') openCraft(payload.station);
    if (payload.action === 'openAdmin') openAdmin(payload.data);
    if (payload.action === 'adminData') {
        const editedId = editingStation?.id;
        adminData = payload.data;
        if (editedId) {
            const refreshed = adminData.stations.find(entry => Number(entry.id) === Number(editedId));
            editingStation = refreshed ? deepCopy(refreshed) : null;
        }
        renderAdmin();
    }
    if (payload.action === 'close') hideAll();
});

CraftingConfig = {}
local Config = CraftingConfig

Config.AdminCommand = 'craftadmin'
Config.AdminAce = 'giammark.crafting.admin'
Config.AdminGroups = {
    admin = true,
    superadmin = true,
    owner = true
}
Config.UseOxTarget = true
Config.TargetIcon = 'fa-solid fa-hammer'
Config.TargetLabel = 'Apri banco da lavoro'

Config.DefaultInteractionRadius = 2.0
Config.DrawDistance = 20.0
Config.ServerDistanceTolerance = 3.0
Config.MaxCraftQuantity = 10

Config.Marker = {
    type = 2,
    scale = vec3(0.22, 0.22, 0.22),
    color = { r = 176, g = 54, b = 255, a = 205 }
}
Config.DefaultAnimation = 'hammering'
Config.Animations = {
    {
        id = 'hammering',
        label = 'Lavorazione del ferro / martello',
        scenario = 'WORLD_HUMAN_HAMMERING'
    },
    {
        id = 'cooking',
        label = 'Cucinare / griglia',
        scenario = 'PROP_HUMAN_BBQ'
    },
    {
        id = 'shaker',
        label = 'Bere / shaker cocktail',
        dict = 'anim@scripted@freemode@postertag@graffiti_spray@male@',
        clip = 'shake_can_male',
        femaleDict = 'anim@scripted@freemode@postertag@graffiti_spray@heeled@',
        femaleClip = 'shake_can_female',
        flag = 49,
        prop = {
            model = 'prop_bar_cockshaker',
            bone = 28422,
            pos = { x = 0.0, y = 0.0, z = -0.17 },
            rot = { x = 0.0, y = 0.0, z = 0.0 }
        }
    },
    {
        id = 'welding',
        label = 'Saldatura',
        scenario = 'WORLD_HUMAN_WELDING'
    },
    {
        id = 'mechanic',
        label = 'Lavoro da meccanico',
        scenario = 'WORLD_HUMAN_VEHICLE_MECHANIC'
    },
    {
        id = 'drilling',
        label = 'Trapano / cantiere',
        scenario = 'WORLD_HUMAN_CONST_DRILL'
    },
    {
        id = 'gardening',
        label = 'Coltivazione / giardinaggio',
        scenario = 'WORLD_HUMAN_GARDENER_PLANT'
    },
    {
        id = 'cleaning',
        label = 'Pulizia del prodotto',
        scenario = 'WORLD_HUMAN_MAID_CLEAN'
    },
    {
        id = 'clipboard',
        label = 'Controllo / lavorazione tecnica',
        scenario = 'WORLD_HUMAN_CLIPBOARD'
    },
    {
        id = 'none',
        label = 'Nessuna animazione'
    }
}

Config.Limits = {
    maxStations = 150,
    maxPointsPerStation = 20,
    maxRecipesPerStation = 50,
    maxIngredientsPerRecipe = 20,
    minDuration = 1000,
    maxDuration = 600000,
    maxItemAmount = 1000
}

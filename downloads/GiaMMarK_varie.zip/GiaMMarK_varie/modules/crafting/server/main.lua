local Config = CraftingConfig
local ESX = exports.es_extended:getSharedObject()

local Stations = {}
local ItemCache = {}
local ActiveCrafts = {}
local DatabaseReady = false

local function notify(source, message, notificationType)
    TriggerClientEvent('ox_lib:notify', source, {
        title = 'Crafting',
        description = message,
        type = notificationType or 'inform'
    })
end

local function trim(value)
    if type(value) ~= 'string' then return '' end
    return value:match('^%s*(.-)%s*$') or ''
end

local function clampInteger(value, minimum, maximum)
    value = math.floor(tonumber(value) or 0)
    if value < minimum then return minimum end
    if value > maximum then return maximum end
    return value
end

local function clampNumber(value, minimum, maximum)
    value = tonumber(value) or minimum
    if value < minimum then return minimum end
    if value > maximum then return maximum end
    return value
end

local function isFinite(value)
    value = tonumber(value)
    return value and value == value and value ~= math.huge and value ~= -math.huge
end

local function decodeJson(value, fallback)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' or value == '' then return fallback end

    local success, decoded = pcall(json.decode, value)
    if success and type(decoded) == 'table' then return decoded end
    return fallback
end

local function normalizeStationPoints(rawCoords)
    if type(rawCoords) ~= 'table' then return {} end
    local sourcePoints = rawCoords
    if isFinite(rawCoords.x) and isFinite(rawCoords.y) and isFinite(rawCoords.z) then
        sourcePoints = { rawCoords }
    end

    local points = {}
    for i = 1, #sourcePoints do
        local point = sourcePoints[i]
        if type(point) == 'table' and isFinite(point.x) and isFinite(point.y) and isFinite(point.z) then
            points[#points + 1] = {
                x = tonumber(point.x),
                y = tonumber(point.y),
                z = tonumber(point.z),
                w = tonumber(point.w) or 0.0
            }
        end
    end

    return points
end

local function refreshItems()
    local items = exports.ox_inventory:Items() or {}
    ItemCache = {}

    for name, data in pairs(items) do
        ItemCache[name] = {
            name = name,
            label = data.label or name,
            stack = data.stack ~= false
        }
    end
end

local function itemExists(name)
    return type(name) == 'string' and ItemCache[name] ~= nil
end

local function getItemLabel(name)
    return ItemCache[name] and ItemCache[name].label or name
end

local function getAnimation(animationId)
    for i = 1, #Config.Animations do
        local animation = Config.Animations[i]
        if animation.id == animationId then return animation end
    end

    for i = 1, #Config.Animations do
        local animation = Config.Animations[i]
        if animation.id == Config.DefaultAnimation then return animation end
    end

    return Config.Animations[1]
end

local function getAnimationsForAdmin()
    local result = {}
    for i = 1, #Config.Animations do
        result[#result + 1] = {
            id = Config.Animations[i].id,
            label = Config.Animations[i].label
        }
    end
    return result
end

local function isAdmin(source)
    if source == 0 then return true end
    if Config.AdminAce and Config.AdminAce ~= '' and IsPlayerAceAllowed(source, Config.AdminAce) then
        return true
    end

    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end

    local group = xPlayer.getGroup and xPlayer.getGroup() or 'user'
    return Config.AdminGroups[group] == true
end

local function hasStationAccess(xPlayer, station)
    if station.accessType == 'public' then return true end
    if not xPlayer or not xPlayer.job then return false end

    for i = 1, #station.jobs do
        local allowed = station.jobs[i]
        if allowed.name == xPlayer.job.name and tonumber(xPlayer.job.grade) >= tonumber(allowed.minGrade or 0) then
            return true
        end
    end

    return false
end

local function isNearStation(source, station)
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return false end

    local playerCoords = GetEntityCoords(ped)
    local maximumDistance = (station.radius or Config.DefaultInteractionRadius) + Config.ServerDistanceTolerance
    local points = station.points or (station.coords and { station.coords }) or {}

    for i = 1, #points do
        local point = points[i]
        local stationCoords = vector3(point.x, point.y, point.z)
        if #(playerCoords - stationCoords) <= maximumDistance then
            return true
        end
    end

    return false
end

local function serializeStations()
    local result = {}
    for _, station in pairs(Stations) do
        result[#result + 1] = station
    end
    table.sort(result, function(a, b) return a.id < b.id end)
    return result
end

local function broadcastStations(target)
    TriggerClientEvent('giammark_crafting:client:setStations', target or -1, serializeStations())
end

local function loadStations()
    local rows = MySQL.query.await('SELECT * FROM `giammark_crafting_stations` ORDER BY `id` ASC') or {}
    Stations = {}

    for i = 1, #rows do
        local row = rows[i]
        local points = normalizeStationPoints(decodeJson(row.coords, {}))
        if #points > 0 then
            Stations[tonumber(row.id)] = {
                id = tonumber(row.id),
                name = row.name,
                coords = points[1],
                points = points,
                radius = tonumber(row.radius) or Config.DefaultInteractionRadius,
                accessType = row.access_type == 'job' and 'job' or 'public',
                jobs = decodeJson(row.jobs, {}),
                recipes = decodeJson(row.recipes, {})
            }
        end
    end
end

local function getJobsForAdmin()
    local result = {}
    local jobs = ESX.GetJobs and ESX.GetJobs() or {}

    for name, data in pairs(jobs) do
        local grades = {}
        for grade, gradeData in pairs(data.grades or {}) do
            grades[#grades + 1] = {
                grade = tonumber(grade) or 0,
                label = gradeData.label or tostring(grade)
            }
        end
        table.sort(grades, function(a, b) return a.grade < b.grade end)

        result[#result + 1] = {
            name = name,
            label = data.label or name,
            grades = grades
        }
    end

    table.sort(result, function(a, b) return a.label:lower() < b.label:lower() end)
    return result
end

local function getItemsForAdmin()
    local result = {}
    for name, data in pairs(ItemCache) do
        result[#result + 1] = {
            name = name,
            label = data.label
        }
    end
    table.sort(result, function(a, b) return a.label:lower() < b.label:lower() end)
    return result
end

local function sanitizeStation(payload)
    if type(payload) ~= 'table' then return nil, 'Dati della postazione non validi.' end

    local name = trim(payload.name)
    if #name < 2 or #name > 64 then
        return nil, 'Il nome deve contenere da 2 a 64 caratteri.'
    end

    local rawPoints = type(payload.points) == 'table' and payload.points or payload.coords
    local points = normalizeStationPoints(rawPoints)
    if #points == 0 then
        return nil, 'Aggiungi almeno un punto valido alla postazione.'
    end
    if #points > (Config.Limits.maxPointsPerStation or 20) then
        return nil, ('Puoi inserire al massimo %s punti per postazione.'):format(Config.Limits.maxPointsPerStation or 20)
    end

    local accessType = payload.accessType == 'job' and 'job' or 'public'
    local jobs = {}
    local knownJobs = ESX.GetJobs and ESX.GetJobs() or {}

    if accessType == 'job' then
        if type(payload.jobs) ~= 'table' or #payload.jobs == 0 then
            return nil, 'Seleziona almeno un lavoro autorizzato.'
        end

        local usedJobs = {}
        for i = 1, #payload.jobs do
            local entry = payload.jobs[i]
            local jobName = trim(entry.name)
            if knownJobs[jobName] and not usedJobs[jobName] then
                jobs[#jobs + 1] = {
                    name = jobName,
                    minGrade = clampInteger(entry.minGrade, 0, 100)
                }
                usedJobs[jobName] = true
            end
        end

        if #jobs == 0 then return nil, 'Nessun lavoro selezionato risulta valido.' end
    end

    if type(payload.recipes) ~= 'table' or #payload.recipes == 0 then
        return nil, 'Aggiungi almeno una ricetta.'
    end
    if #payload.recipes > Config.Limits.maxRecipesPerStation then
        return nil, ('Puoi inserire al massimo %s ricette.'):format(Config.Limits.maxRecipesPerStation)
    end

    local recipes = {}
    for recipeIndex = 1, #payload.recipes do
        local inputRecipe = payload.recipes[recipeIndex]
        local outputItem = trim(inputRecipe.item)
        if not itemExists(outputItem) then
            return nil, ('Oggetto di uscita non valido nella ricetta %s.'):format(recipeIndex)
        end

        local ingredients = {}
        local combinedIngredients = {}
        local rawIngredients = type(inputRecipe.ingredients) == 'table' and inputRecipe.ingredients or {}
        if #rawIngredients > Config.Limits.maxIngredientsPerRecipe then
            return nil, ('Troppi ingredienti nella ricetta %s.'):format(recipeIndex)
        end

        for ingredientIndex = 1, #rawIngredients do
            local inputIngredient = rawIngredients[ingredientIndex]
            local ingredientName = trim(inputIngredient.item)
            if not itemExists(ingredientName) then
                return nil, ('Ingrediente non valido nella ricetta %s.'):format(recipeIndex)
            end

            local ingredientAmount = clampInteger(inputIngredient.amount, 1, Config.Limits.maxItemAmount)
            combinedIngredients[ingredientName] = (combinedIngredients[ingredientName] or 0) + ingredientAmount
        end

        for ingredientName, ingredientAmount in pairs(combinedIngredients) do
            ingredients[#ingredients + 1] = {
                item = ingredientName,
                amount = ingredientAmount
            }
        end
        table.sort(ingredients, function(a, b) return a.item < b.item end)

        recipes[#recipes + 1] = {
            id = ('recipe_%s'):format(recipeIndex),
            label = trim(inputRecipe.label) ~= '' and trim(inputRecipe.label):sub(1, 64) or getItemLabel(outputItem),
            item = outputItem,
            amount = clampInteger(inputRecipe.amount, 1, Config.Limits.maxItemAmount),
            duration = clampInteger(inputRecipe.duration, Config.Limits.minDuration, Config.Limits.maxDuration),
            animation = getAnimation(inputRecipe.animation).id,
            ingredients = ingredients
        }
    end

    return {
        id = tonumber(payload.id),
        name = name,
        coords = points[1],
        points = points,
        radius = clampNumber(payload.radius, 1.0, 5.0),
        accessType = accessType,
        jobs = jobs,
        recipes = recipes
    }
end

local function findRecipe(station, recipeId)
    for i = 1, #station.recipes do
        if station.recipes[i].id == recipeId then return station.recipes[i] end
    end
end

local function decorateStationForPlayer(source, station)
    local result = {
        id = station.id,
        name = station.name,
        maxQuantity = Config.MaxCraftQuantity,
        recipes = {}
    }

    for i = 1, #station.recipes do
        local recipe = station.recipes[i]
        local decorated = {
            id = recipe.id,
            label = recipe.label,
            item = recipe.item,
            itemLabel = getItemLabel(recipe.item),
            amount = recipe.amount,
            duration = recipe.duration,
            animation = getAnimation(recipe.animation).id,
            animationLabel = getAnimation(recipe.animation).label,
            ingredients = {}
        }

        for ingredientIndex = 1, #recipe.ingredients do
            local ingredient = recipe.ingredients[ingredientIndex]
            decorated.ingredients[#decorated.ingredients + 1] = {
                item = ingredient.item,
                label = getItemLabel(ingredient.item),
                amount = ingredient.amount,
                owned = exports.ox_inventory:Search(source, 'count', ingredient.item) or 0
            }
        end
        result.recipes[#result.recipes + 1] = decorated
    end

    return result
end

local function validateCraftRequirements(source, recipe, quantity)
    for i = 1, #recipe.ingredients do
        local ingredient = recipe.ingredients[i]
        local needed = ingredient.amount * quantity
        local owned = exports.ox_inventory:Search(source, 'count', ingredient.item) or 0
        if owned < needed then
            return false, ('Ti mancano %sx %s.'):format(needed - owned, getItemLabel(ingredient.item))
        end
    end

    local outputAmount = recipe.amount * quantity
    if not exports.ox_inventory:CanCarryItem(source, recipe.item, outputAmount) then
        return false, 'Non hai abbastanza spazio o peso disponibile nell’inventario.'
    end

    return true
end

local function clearExpiredCraft(source)
    local active = ActiveCrafts[source]
    if active and os.time() > active.expiresAt then ActiveCrafts[source] = nil end
end

CreateThread(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `giammark_crafting_stations` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(64) NOT NULL,
            `coords` LONGTEXT NOT NULL,
            `radius` DECIMAL(4,2) NOT NULL DEFAULT 2.00,
            `access_type` VARCHAR(16) NOT NULL DEFAULT 'public',
            `jobs` LONGTEXT NULL,
            `recipes` LONGTEXT NOT NULL,
            `created_by` VARCHAR(80) NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ]])

    refreshItems()
    loadStations()
    DatabaseReady = true
    broadcastStations()
    print(('[GiaMMarK Crafting] Caricate %s postazioni.'):format(#serializeStations()))
end)

lib.callback.register('giammark_crafting:server:getStations', function()
    while not DatabaseReady do Wait(100) end
    return serializeStations()
end)

lib.callback.register('giammark_crafting:server:getStation', function(source, stationId)
    local station = Stations[tonumber(stationId)]
    local xPlayer = ESX.GetPlayerFromId(source)

    if not station then return nil, 'Questa postazione non esiste più.' end
    if not hasStationAccess(xPlayer, station) then return nil, 'Non sei autorizzato a usare questa postazione.' end
    if not isNearStation(source, station) then return nil, 'Sei troppo lontano dalla postazione.' end

    return decorateStationForPlayer(source, station)
end)

lib.callback.register('giammark_crafting:server:getAdminData', function(source)
    if not isAdmin(source) then return nil, 'Non hai i permessi per aprire il pannello.' end

    while not DatabaseReady do Wait(100) end

    refreshItems()
    return {
        stations = serializeStations(),
        items = getItemsForAdmin(),
        jobs = getJobsForAdmin(),
        animations = getAnimationsForAdmin(),
        defaultAnimation = Config.DefaultAnimation,
        limits = Config.Limits
    }
end)

lib.callback.register('giammark_crafting:server:saveStation', function(source, payload)
    if not isAdmin(source) then return false, 'Permessi insufficienti.' end

    local stationCount = #serializeStations()
    local station, validationError = sanitizeStation(payload)
    if not station then return false, validationError end

    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer and xPlayer.identifier or ('source:%s'):format(source)

    if station.id then
        if not Stations[station.id] then return false, 'Postazione da modificare non trovata.' end

        MySQL.update.await([[
            UPDATE `giammark_crafting_stations`
            SET `name` = ?, `coords` = ?, `radius` = ?, `access_type` = ?, `jobs` = ?, `recipes` = ?
            WHERE `id` = ?
        ]], {
            station.name,
            json.encode(station.points),
            station.radius,
            station.accessType,
            json.encode(station.jobs),
            json.encode(station.recipes),
            station.id
        })
    else
        if stationCount >= Config.Limits.maxStations then
            return false, ('Hai raggiunto il limite di %s postazioni.'):format(Config.Limits.maxStations)
        end

        station.id = MySQL.insert.await([[
            INSERT INTO `giammark_crafting_stations`
                (`name`, `coords`, `radius`, `access_type`, `jobs`, `recipes`, `created_by`)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ]], {
            station.name,
            json.encode(station.points),
            station.radius,
            station.accessType,
            json.encode(station.jobs),
            json.encode(station.recipes),
            identifier
        })
    end

    loadStations()
    broadcastStations()
    return true, station.id
end)

lib.callback.register('giammark_crafting:server:deleteStation', function(source, stationId)
    if not isAdmin(source) then return false, 'Permessi insufficienti.' end

    stationId = tonumber(stationId)
    if not stationId or not Stations[stationId] then return false, 'Postazione non trovata.' end

    MySQL.update.await('DELETE FROM `giammark_crafting_stations` WHERE `id` = ?', { stationId })
    Stations[stationId] = nil
    broadcastStations()
    return true
end)

lib.callback.register('giammark_crafting:server:startCraft', function(source, stationId, recipeId, quantity)
    clearExpiredCraft(source)
    if ActiveCrafts[source] then return nil, 'Hai già una lavorazione in corso.' end

    local station = Stations[tonumber(stationId)]
    local xPlayer = ESX.GetPlayerFromId(source)
    quantity = clampInteger(quantity, 1, Config.MaxCraftQuantity)

    if not station then return nil, 'Postazione non trovata.' end
    if not hasStationAccess(xPlayer, station) then return nil, 'Non sei autorizzato.' end
    if not isNearStation(source, station) then return nil, 'Sei troppo lontano.' end

    local recipe = findRecipe(station, recipeId)
    if not recipe then return nil, 'Ricetta non trovata.' end

    local valid, requirementError = validateCraftRequirements(source, recipe, quantity)
    if not valid then return nil, requirementError end

    local duration = recipe.duration * quantity
    local token = ('%s:%s:%s:%s'):format(source, station.id, math.random(100000, 999999), os.time())
    ActiveCrafts[source] = {
        token = token,
        stationId = station.id,
        recipeId = recipe.id,
        recipe = recipe,
        quantity = quantity,
        finishAt = os.time() + math.max(1, math.floor(duration / 1000)),
        expiresAt = os.time() + math.max(30, math.ceil(duration / 1000) + 60)
    }

    return {
        token = token,
        duration = duration,
        label = recipe.label,
        animation = getAnimation(recipe.animation).id
    }
end)

lib.callback.register('giammark_crafting:server:finishCraft', function(source, token)
    local active = ActiveCrafts[source]
    if not active or active.token ~= token then return false, 'Lavorazione non valida o scaduta.' end
    if os.time() < active.finishAt then return false, 'La lavorazione non è ancora terminata.' end

    local station = Stations[active.stationId]
    local xPlayer = ESX.GetPlayerFromId(source)
    if not station or not hasStationAccess(xPlayer, station) or not isNearStation(source, station) then
        ActiveCrafts[source] = nil
        return false, 'Lavorazione annullata: ti sei allontanato o non sei più autorizzato.'
    end

    local recipe = active.recipe
    if not recipe then
        ActiveCrafts[source] = nil
        return false, 'La ricetta non è più disponibile.'
    end

    local valid, requirementError = validateCraftRequirements(source, recipe, active.quantity)
    if not valid then
        ActiveCrafts[source] = nil
        return false, requirementError
    end

    local removed = {}
    for i = 1, #recipe.ingredients do
        local ingredient = recipe.ingredients[i]
        local amount = ingredient.amount * active.quantity
        local success = exports.ox_inventory:RemoveItem(source, ingredient.item, amount)

        if not success then
            for refundIndex = 1, #removed do
                exports.ox_inventory:AddItem(source, removed[refundIndex].item, removed[refundIndex].amount)
            end
            ActiveCrafts[source] = nil
            return false, 'Non è stato possibile rimuovere gli ingredienti.'
        end

        removed[#removed + 1] = { item = ingredient.item, amount = amount }
    end

    local outputAmount = recipe.amount * active.quantity
    local added = exports.ox_inventory:AddItem(source, recipe.item, outputAmount)
    if not added then
        for i = 1, #removed do
            exports.ox_inventory:AddItem(source, removed[i].item, removed[i].amount)
        end
        ActiveCrafts[source] = nil
        return false, 'Inventario pieno: gli ingredienti sono stati restituiti.'
    end

    ActiveCrafts[source] = nil
    return true, ('Hai creato %sx %s.'):format(outputAmount, getItemLabel(recipe.item))
end)

RegisterNetEvent('giammark_crafting:server:cancelCraft', function(token)
    local source = source
    if ActiveCrafts[source] and ActiveCrafts[source].token == token then
        ActiveCrafts[source] = nil
    end
end)

AddEventHandler('playerDropped', function()
    ActiveCrafts[source] = nil
end)

RegisterNetEvent('giammark_crafting:server:requestSync', function()
    broadcastStations(source)
end)

RegisterCommand('craftreload', function(source)
    if not isAdmin(source) then
        if source > 0 then notify(source, 'Permessi insufficienti.', 'error') end
        return
    end

    refreshItems()
    loadStations()
    broadcastStations()
    if source > 0 then notify(source, 'Postazioni ricaricate.', 'success') end
end, false)

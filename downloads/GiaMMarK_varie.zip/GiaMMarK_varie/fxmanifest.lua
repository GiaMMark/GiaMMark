shared_script '@0r-pack1/src/include/shared.lua'
fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'GiaMMarK_varie'
author 'GiaMMarK Dev / original module authors'
description 'Crafting, ricerca bidoni, telefoni pubblici, muscle rebuild e carrello'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'modules/crafting/config.lua',
    'modules/trash/config.lua',
    'modules/payphones/config.lua',
    'modules/payphones/data/locations.lua',
    'modules/muscle/config.lua',
    'modules/cart/config.lua'
}

client_scripts {
    'client/nui.lua',
    'modules/crafting/client/main.lua',
    'modules/trash/client.lua',
    'modules/payphones/client/main.lua',
    'modules/muscle/client.lua',
    'modules/cart/client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'modules/crafting/server/main.lua',
    'modules/trash/server.lua',
    'modules/payphones/server/bridge.lua',
    'modules/payphones/server/main.lua',
    'modules/muscle/garage_jg.lua',
    'modules/muscle/server.lua',
    'modules/cart/server.lua'
}

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/router.js',
    'html/bridge.js',
    'modules/crafting/html/index.html',
    'modules/crafting/html/style.css',
    'modules/crafting/html/app.js',
    'modules/crafting/html/assets/riverside-logo.png',
    'modules/payphones/html/index.html',
    'modules/payphones/html/style.css',
    'modules/payphones/html/app.js'
}

dependencies {
    'es_extended',
    'ox_lib',
    'ox_inventory',
    'ox_target',
    'oxmysql',
    'jg-advancedgarages'
}

import { access, readFile } from "node:fs/promises";
import { join } from "node:path";

const root = process.cwd();
const required = [
  "dist/index.html",
  "dist/menu/index.html",
  "dist/galleria/index.html",
  "dist/assets/gallery-page.css",
  "dist/assets/photographs.json",
  "dist/assets/translation.js",
  "dist/assets/locales/en.json",
  "dist/assets/locales/de.json",
  "dist/assets/locales/fr.json",
  "dist/assets/locales/es.json",
  "dist/allergeni/index.html",
  "dist/recensioni/index.html",
  "dist/privacy/index.html",
  "dist/qr/index.html",
  "dist/admin/index.html",
  "dist/assets/default-menu.json",
  "dist/assets/menu-qr.svg",
];

await Promise.all(required.map((file) => access(join(root, file))));
let catalogKeys;
for (const language of ['en', 'de', 'fr', 'es']) {
  const catalog = JSON.parse(await readFile(join(root, `dist/assets/locales/${language}.json`), 'utf8'));
  const keys = Object.keys(catalog).sort();
  if (keys.length < 490 || (catalogKeys && JSON.stringify(keys) !== JSON.stringify(catalogKeys))) throw new Error('Catalogo delle lingue incompleto');
  catalogKeys = keys;
  for (const [source, target] of Object.entries(catalog)) {
    if (typeof target !== 'string' || !target.trim()) throw new Error(`Traduzione vuota: ${language}`);
    const variables = (value) => JSON.stringify([...(value.matchAll(/\{(\w+)\}/g))].map((match) => match[1]).sort());
    if (variables(source) !== variables(target)) throw new Error(`Segnaposto della traduzione non coerente: ${language}`);
    const prices = (value) => JSON.stringify([...(value.matchAll(/(\d+(?:[,.]\d+)?)\s*€/g))].map((match) => match[1]));
    if (prices(source) !== prices(target)) throw new Error(`Importo modificato nella traduzione: ${language}`);
  }
}
const menu = JSON.parse(await readFile(join(root, "dist/assets/default-menu.json"), "utf8"));
if (!Array.isArray(menu.categories) || menu.categories.length < 10) {
  throw new Error("Menu incompleto");
}
const itemCount = menu.categories.reduce((total, category) => total + category.items.length, 0);
if (itemCount < 75 || menu.catalogRevision !== "esperienza-completa-2026-08-12-v2") {
  throw new Error("Listino fotografico incompleto");
}
if (!Array.isArray(menu.wines) || menu.wines.length < 4 || !Array.isArray(menu.degustations) || !Array.isArray(menu.events)) {
  throw new Error("Vini, degustazioni o eventi mancanti");
}

const html = await readFile(join(root, "dist/menu/index.html"), "utf8");
if (!html.includes("sommelier-launcher") || !html.includes("site-footer")) {
  throw new Error("Menu o footer non presenti");
}
if (!html.includes("wine-list") || !html.includes("degustation-list") || !html.includes("event-list")) {
  throw new Error("Esperienze del menu non presenti");
}

const styles = await readFile(join(root, "dist/assets/styles.css"), "utf8");
const menuScript = await readFile(join(root, "dist/assets/menu.js"), "utf8");
const siteScript = await readFile(join(root, "dist/assets/site.js"), "utf8");
if (!styles.includes("pointer-events: none") || !menuScript.includes('querySelector("#site-footer")')) {
  throw new Error("Protezione del footer dal Sommelier non presente");
}
if (!siteScript.includes("Developed by") || !siteScript.includes("https://giammarkdev.netlify.app/")) {
  throw new Error("Credito GiaMMarK non presente");
}
if (!siteScript.includes("booking-dialog") || !siteScript.includes("mobile-dock") || !siteScript.includes("gallery-dialog")) {
  throw new Error("Prenotazione, barra mobile o galleria non presenti");
}
if (!siteScript.includes("class SocialStage") || !siteScript.includes("brandIcon") || !siteScript.includes("socialProfiles")) {
  throw new Error("Esperienza social interattiva non presente");
}
const homeHtml = await readFile(join(root, "dist/index.html"), "utf8");
const photos = JSON.parse(await readFile(join(root, "dist/assets/photographs.json"), "utf8"));
if (photos.count !== 23 || photos.photos.length !== 23 || new Set(photos.photos.map((photo) => photo.id)).size !== 23 || !homeHtml.includes('id="galleria"')) {
  throw new Error("Raccolta fotografica in home incompleta");
}
for (const photo of photos.photos) {
  for (const path of [photo.src, photo.thumbnail]) {
    if (!/^assets\/images\/collection-2026\/[a-z0-9-]+\.webp$/.test(path)) throw new Error("Percorso fotografico non valido");
    await access(join(root, "dist", path));
  }
  if (!homeHtml.includes(`data-photo-id="${photo.id}"`) || !photo.alt) throw new Error("Foto o testo alternativo non presente nella home");
}
if (!homeHtml.includes("<site-footer></site-footer>")) {
  throw new Error("Footer (con contatti e social) non presente in home");
}
if (!homeHtml.includes("data-hero-showcase") || !homeHtml.includes("stage-links") || !styles.includes("Laguna Nocturne")) {
  throw new Error("Home Laguna Nocturne non presente");
}

console.log(`Controlli superati: ${menu.categories.length} categorie, ${itemCount} voci`);

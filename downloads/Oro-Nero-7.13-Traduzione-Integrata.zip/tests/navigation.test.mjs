import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { setupNavigation, isSitePage } from '../site/assets/navigation.js';

const page = (title, body, scripts = '', styles = '') => `<!doctype html><html lang="it"><head>${styles}<title>${title}</title><meta name="description" content="${title}"><link rel="canonical" href="https://oronero.test/${title}/"></head><body class="${title}-page"><site-header></site-header><main>${body}</main>${scripts}</body></html>`;

function browser({homeStyles = '', routeStyles = ''} = {}) {
  const dom = new JSDOM(page('home', '<a id="menu-link" href="/menu/">Menu</a>', '', homeStyles), { url: 'https://oronero.test/' });
  const {window: win} = dom;
  const doc = win.document;
  const audio = doc.createElement('audio');
  audio.dataset.persistentAudio = '';
  const music = doc.createElement('button');
  music.dataset.musicControl = '';
  doc.body.append(audio, music);
  const disconnected = [];
  const observer = new win.MutationObserver((records) => records.forEach((record) => {
    if ([...record.removedNodes].includes(audio)) disconnected.push(true);
  }));
  observer.observe(doc.body, {childList: true});
  const calls = [];
  const scrolled = [];
  win.scrollTo = (...args) => scrolled.push(args);
  win.HTMLElement.prototype.scrollIntoView = function () { scrolled.push(this.id); };
  win.fetch = async (url) => new Response(page('menu', '<h1>Menu</h1><a href="../privacy/">Privacy</a><img src="../assets/images/logo.webp"><section id="carta-vini">Vini</section>', '<script type="module" src="../assets/menu.js?v=7.3.0"></script>', routeStyles), {headers: {'content-type':'text/html'}});
  const router = setupNavigation({doc,win,root:new URL('https://oronero.test/'),initialize:() => calls.push('init'),cleanup:() => calls.push('cleanup'),loadModule:async (url) => { calls.push(url); return {cleanup:() => calls.push('route-cleanup')}; }});
  return {dom,win,doc,audio,music,router,calls,scrolled,disconnected,close(){router.destroy(); observer.disconnect();win.close();}};
}

test('only known same-origin pages qualify; assets and external sites stay native', () => {
  const root = new URL('https://oronero.test/');
  for (const path of ['/', '/index.html', '/menu/', '/menu/index.html', '/galleria/', '/galleria/index.html', '/admin/', '/qr/#print']) assert.equal(isSitePage(new URL(path, root),root),true,path);
  for (const path of ['/assets/photo.jpg', '/api/menu', '/downloads/site.zip', '/unknown/', 'https://outside.test/menu/']) assert.equal(isSitePage(new URL(path,root),root),false,path);
});

test('page swaps preserve the connected audio/player nodes, head data and relative links', async () => {
  const p=browser();
  try {
    assert.equal(await p.router.navigate('/menu/'),true);
    assert.equal(p.doc.querySelector('[data-persistent-audio]'),p.audio);
    assert.equal(p.doc.querySelector('[data-music-control]'),p.music);
    assert.equal(p.audio.isConnected,true);
    assert.deepEqual(p.disconnected,[]);
    assert.equal(p.doc.title,'menu');
    assert.equal(p.doc.body.className,'menu-page');
    assert.equal(p.doc.querySelector('main a').href,'https://oronero.test/privacy/');
    assert.equal(p.doc.querySelector('main img').src,'https://oronero.test/assets/images/logo.webp');
    assert.equal(p.doc.querySelector('script[type="module"]'),null);
    assert.match(p.calls.find((call)=>call.includes('menu.js')),/navigation=1/);
    await p.router.navigate('/privacy/');
    assert.equal(p.calls.filter((call)=>call==='route-cleanup').length,1);
    assert.deepEqual(p.disconnected,[]);
  } finally {p.close();}
});

test('hash links scroll without replacing page content or the player', async () => {
  const p=browser();
  try {
    await p.router.navigate('/menu/');
    const main=p.doc.querySelector('main');
    const count=p.calls.length;
    await p.router.navigate('/menu/#carta-vini');
    assert.equal(p.doc.querySelector('main'),main);
    assert.equal(p.calls.length,count);
    assert.equal(p.win.location.hash,'#carta-vini');
    assert.equal(p.scrolled.at(-1),'carta-vini');
  } finally {p.close();}
});

test('a superseded response cannot replace the newer destination', async () => {
  const p=browser();
  try {
    let release;
    p.win.fetch=undefined;
    // setupNavigation captures fetch at initialization, so override its existing
    // stub by constructing a second router around deferred responses.
    p.router.destroy();
    p.win.fetch=(url)=>url.includes('/menu/') ? new Promise((resolve)=>{release=resolve;}) : Promise.resolve(new Response(page('privacy','<h1>Privacy</h1>'),{headers:{'content-type':'text/html'}}));
    const router=setupNavigation({doc:p.doc,win:p.win,root:new URL('https://oronero.test/'),initialize(){},cleanup(){},loadModule:async()=>({})});
    const first=router.navigate('/menu/');
    const second=router.navigate('/privacy/');
    await second;
    release(new Response(page('menu','<h1>Menu</h1>'),{headers:{'content-type':'text/html'}}));
    await first;
    assert.equal(p.doc.title,'privacy');
    assert.equal(p.win.location.pathname,'/privacy/');
    assert.equal(p.doc.querySelector('[data-persistent-audio]'),p.audio);
    router.destroy();
  } finally {p.close();}
});


const styles = (names, prefix) => names.map((name) => `<link rel="stylesheet" href="${prefix}${name}.css?v=7.12.0">`).join('');
async function pendingStyle(p) {
  for (let attempt = 0; attempt < 30; attempt++) {
    const link = p.doc.querySelector('link[data-navigation-style-pending]');
    if (link) return link;
    await new Promise((resolve) => setImmediate(resolve));
  }
  throw new Error('Expected a pending route stylesheet');
}

test('first home-to-menu navigation keeps shared relative CSS and matches the direct-load cascade', async () => {
  const desired = ['styles', 'music', 'menu-text', 'refinements', 'languages'];
  const p = browser({homeStyles:styles(['styles', 'music', 'arrival', 'refinements', 'languages'], 'assets/'), routeStyles:styles(desired, '../assets/')});
  try {
    const oldMain = p.doc.querySelector('main');
    const navigation = p.router.navigate('/menu/');
    const loading = await pendingStyle(p);
    assert.equal(p.doc.querySelector('main'), oldMain, 'Old content remains until the menu CSS is ready');
    assert.equal(p.win.location.pathname, '/');
    assert.equal(loading.media, 'not all', 'The menu stylesheet cannot restyle the outgoing home');
    p.doc.querySelectorAll('link[data-navigation-style-pending]').forEach((link) => link.dispatchEvent(new p.win.Event('load')));
    assert.equal(await navigation, true);
    const links = [...p.doc.querySelectorAll('link[rel="stylesheet"]')];
    assert.deepEqual(links.map((link) => link.href), desired.map((name) => `https://oronero.test/assets/${name}.css?v=7.12.0`));
    assert.ok(links.every((link) => !link.hasAttribute('media') && !link.hasAttribute('data-navigation-style-pending')));
    assert.equal(p.doc.querySelector('[data-persistent-audio]'), p.audio);
    assert.deepEqual(p.disconnected, []);
  } finally { p.close(); }
});

test('a superseded stylesheet request is discarded instead of being reused before it finishes', async () => {
  const p = browser({homeStyles:styles(['styles'], 'assets/'),routeStyles:styles(['styles', 'menu-text'], '../assets/')});
  try {
    const first = p.router.navigate('/menu/');
    const obsolete = await pendingStyle(p);
    const second = p.router.navigate('/privacy/');
    await first;
    const current = await pendingStyle(p);
    assert.notEqual(current, obsolete);
    assert.equal(obsolete.isConnected, false);
    obsolete.dispatchEvent(new p.win.Event('load'));
    assert.equal(p.win.location.pathname, '/');
    p.doc.querySelectorAll('link[data-navigation-style-pending]').forEach((link) => link.dispatchEvent(new p.win.Event('load')));
    assert.equal(await second, true);
    assert.equal(p.win.location.pathname, '/privacy/');
    assert.equal(p.doc.querySelectorAll('link[href*="menu-text.css"]').length, 1);
    assert.equal(p.doc.querySelectorAll('[data-navigation-style-pending]').length, 0);
    assert.deepEqual(p.disconnected, []);
  } finally { p.close(); }
});


test('already absolute shared sheets stay connected and new CSS loads in its final cascade position', async () => {
  const shared = ['styles', 'music', 'refinements', 'languages'];
  const desired = ['styles', 'music', 'menu-text', 'refinements', 'languages'];
  const p = browser({homeStyles:styles(shared, 'https://oronero.test/assets/'),routeStyles:styles(desired, '../assets/')});
  const common = [...p.doc.querySelectorAll('link[rel="stylesheet"]')];
  const removed = [];
  const observer = new p.win.MutationObserver((records) => records.forEach((record) => removed.push(...[...record.removedNodes].filter((node) => common.includes(node)))));
  observer.observe(p.doc.head, {childList:true});
  try {
    const navigation = p.router.navigate('/menu/');
    const loading = await pendingStyle(p);
    assert.equal(p.doc.querySelectorAll('[data-navigation-style-pending]').length, 1);
    assert.deepEqual([...p.doc.querySelectorAll('link[rel="stylesheet"]')].map((link) => link.href), desired.map((name) => `https://oronero.test/assets/${name}.css?v=7.12.0`));
    loading.dispatchEvent(new p.win.Event('load'));
    assert.equal(await navigation, true);
    assert.deepEqual(removed, [], 'Shared CSS must never be detached and reloaded during commit');
    assert.ok(common.every((link) => link.isConnected));
    assert.equal(p.doc.querySelectorAll('[data-navigation-style-pending]').length, 0);
  } finally { observer.disconnect();p.close(); }
});

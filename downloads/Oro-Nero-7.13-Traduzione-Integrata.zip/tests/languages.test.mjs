import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { setupLanguages } from '../site/assets/languages.js';

function page(url = 'https://oronero.netlify.app/menu/', options = {}) {
  const dom = new JSDOM('<!doctype html><html lang="it"><body><button data-language-open>Lingua</button><main><h1>Il ristorante</h1></main><audio data-persistent-audio></audio></body></html>', { url, pretendToBeVisual: true });
  const controller = setupLanguages(dom.window.document, dom.window, { loadCatalog: async () => ({ 'Il ristorante': 'The restaurant', 'Lingua': 'Language' }), ...options });
  return { dom, doc: dom.window.document, win: dom.window, controller, close() { controller.destroy(); controller.translator.destroy(); dom.window.close(); } };
}
const settle = () => new Promise((resolve) => setTimeout(resolve, 15));

test('the accessible dialog offers exactly five native choices without external navigation', () => {
  const p = page();
  try {
    const trigger = p.doc.querySelector('[data-language-open]'); trigger.click();
    const dialog = p.controller.dialog;
    assert.equal(dialog.open, true);
    assert.equal(p.doc.activeElement, dialog.querySelector('[data-language-search]'));
    assert.equal(trigger.getAttribute('aria-expanded'), 'true');
    assert.deepEqual([...dialog.querySelectorAll('[data-translation-code]')].map((button) => button.dataset.translationCode), ['it', 'en', 'de', 'fr', 'es']);
    assert.equal(dialog.querySelectorAll('a[href], [target]').length, 0);
    assert.match(dialog.querySelector('#language-note').textContent, /direttamente sul sito/);
    assert.equal(dialog.querySelector('[data-translation-code="fr"] strong').textContent, 'Français');
    dialog.querySelector('[data-language-close]').click();
    assert.equal(dialog.open, false); assert.equal(p.doc.activeElement, trigger);
  } finally { p.close(); }
});

test('search supports autonyms and no results, then selection translates in place and restores focus', async () => {
  const p = page();
  try {
    const audio = p.doc.querySelector('audio'), trigger = p.doc.querySelector('[data-language-open]');
    p.controller.open(trigger);
    const dialog = p.controller.dialog, input = dialog.querySelector('[data-language-search]');
    input.value = 'francais'; input.dispatchEvent(new p.win.Event('input'));
    assert.equal(dialog.querySelectorAll('[data-translation-code]').length, 1);
    assert.equal(dialog.querySelector('[data-translation-code]').dataset.translationCode, 'fr');
    input.value = 'unknown'; input.dispatchEvent(new p.win.Event('input'));
    assert.equal(dialog.querySelector('[data-language-empty]').hidden, false);
    input.value = ''; input.dispatchEvent(new p.win.Event('input'));
    dialog.querySelector('[data-translation-code="en"]').click(); await settle();
    assert.equal(dialog.open, false);
    assert.equal(p.doc.querySelector('h1').textContent, 'The restaurant');
    assert.equal(p.doc.documentElement.lang, 'en');
    assert.equal(p.doc.querySelector('audio'), audio);
    assert.equal(p.doc.activeElement, trigger);
    p.controller.open(trigger);
    assert.equal(dialog.querySelector('[data-translation-code="en"]').getAttribute('aria-pressed'), 'true');
    assert.equal(dialog.querySelector('#language-title').textContent, 'Choose your language.');
    dialog.querySelector('[data-translation-code="it"]').click(); await settle();
    assert.equal(p.doc.querySelector('h1').textContent, 'Il ristorante');
    assert.equal(p.doc.documentElement.lang, 'it');
  } finally { p.close(); }
});

test('load errors restore enabled choices with a retry message and leave the current page usable', async () => {
  let fails = true;
  const p = page(undefined, { loadCatalog: async () => { if (fails) throw new Error('offline'); return { 'Il ristorante': 'The restaurant' }; } });
  try {
    p.controller.open();
    p.controller.dialog.querySelector('[data-translation-code="en"]').click(); await settle();
    assert.equal(p.controller.dialog.open, true);
    assert.match(p.controller.dialog.querySelector('[data-language-status]').textContent, /Riprova/);
    assert.equal(p.controller.dialog.querySelector('[data-translation-code="en"]').disabled, false);
    assert.equal(p.doc.querySelector('h1').textContent, 'Il ristorante');
    fails = false;
    p.controller.dialog.querySelector('[data-translation-code="en"]').click(); await settle();
    assert.equal(p.controller.dialog.open, false);
    assert.equal(p.doc.querySelector('h1').textContent, 'The restaurant');
  } finally { p.close(); }
});

test('local previews work directly while administrative pages remain in Italian', async () => {
  const local = page('http://127.0.0.1:8080/menu/');
  try {
    local.controller.open();
    assert.equal(local.controller.dialog.querySelector('[data-translation-code="en"]').disabled, false);
    local.controller.dialog.querySelector('[data-translation-code="en"]').click(); await settle();
    assert.equal(local.doc.querySelector('h1').textContent, 'The restaurant');
  } finally { local.close(); }
  const admin = page('https://oronero.netlify.app/admin/');
  try {
    admin.controller.open();
    assert.match(admin.controller.dialog.querySelector('[data-language-unavailable]').textContent, /amministrativa/);
    assert.equal(admin.controller.dialog.querySelectorAll('.language-choice:disabled').length, 5);
    assert.equal(admin.doc.documentElement.lang, 'it');
  } finally { admin.close(); }
});

test('SPA cleanup removes only modal handlers and reuses the persistent locale and audio', async () => {
  const p = page();
  try {
    const audio = p.doc.querySelector('audio'), translator = p.controller.translator;
    assert.equal(setupLanguages(p.doc, p.win), p.controller);
    await translator.setLanguage('en');
    p.controller.destroy();
    assert.equal(p.doc.querySelector('#language-dialog'), null);
    assert.equal(p.doc.body.classList.contains('language-open'), false);
    p.win.history.pushState({}, '', '/privacy/');
    p.doc.querySelector('main').innerHTML = '<h1>Il ristorante</h1>';
    p.doc.documentElement.lang = 'it';
    const next = setupLanguages(p.doc, p.win);
    assert.equal(next.translator, translator);
    assert.equal(p.doc.documentElement.lang, 'en');
    assert.equal(p.doc.querySelector('h1').textContent, 'The restaurant');
    assert.equal(p.doc.querySelectorAll('#language-dialog').length, 1);
    assert.equal(p.doc.querySelector('audio'), audio);
    next.destroy();
  } finally { p.close(); }
});

test('opening languages closes mobile navigation and Escape closes the dialog', () => {
  const p = page();
  try {
    const toggle = p.doc.createElement('button'); toggle.className = 'nav-toggle'; toggle.setAttribute('aria-expanded', 'true');
    let closed = 0;
    toggle.addEventListener('click', () => { closed++; toggle.setAttribute('aria-expanded', 'false'); });
    p.doc.body.prepend(toggle);
    p.controller.open();
    assert.equal(closed, 1);
    const event = new p.win.Event('cancel', { cancelable: true });
    p.controller.dialog.dispatchEvent(event);
    assert.equal(event.defaultPrevented, true);
    assert.equal(p.controller.dialog.open, false);
  } finally { p.close(); }
});

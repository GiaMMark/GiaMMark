import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM } from 'jsdom';
import { setupArrival } from '../site/assets/arrival.js';

const html = await readFile(new URL('../site/index.html',import.meta.url),'utf8');
const startup = await readFile(new URL('../site/assets/startup.js',import.meta.url),'utf8');

function page({seen=false,reduce=false,brandMotion=null,hash='',scripts=true,storageUnavailable=false}={}) {
  const timers=new Map();
  let next=0;
  const dom=new JSDOM(html,{
    url:`https://oronero.test/${hash}`,
    pretendToBeVisual:true,
    ...(scripts ? {runScripts:'dangerously'} : {}),
    beforeParse(win) {
      win.matchMedia=()=>({matches:reduce});
      win.setTimeout=(callback,delay)=>{timers.set(++next,{callback,delay});return next;};
      win.clearTimeout=(id)=>timers.delete(id);
      if (seen) win.sessionStorage.setItem('oronero-arrival-seen-v2','1');
      if (storageUnavailable) Object.defineProperty(win,'sessionStorage',{get(){throw new Error('Storage unavailable');}});
    },
  });
  if(brandMotion)dom.window.document.documentElement.dataset.brandMotion=brandMotion;
  else dom.window.document.documentElement.removeAttribute('data-brand-motion');
  if(scripts) dom.window.eval(startup);
  const {document:doc}=dom.window;
  return {dom,doc,boot:dom.window.__oroneroArrivalBoot,run(delay){for(const[id,task]of[...timers])if(task.delay===delay){timers.delete(id);task.callback();}},close(){dom.window.__oroneroArrivalBoot?.release('expired');dom.window.close();}};
}

test('the inline first-paint guard precedes styles and keeps only the intro accessible while modules load',()=>{
  const p=page();
  try {
    assert.ok(html.indexOf('data-arrival-bootstrap')<html.indexOf('<link rel="stylesheet"'));
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    assert.equal(p.doc.querySelector('main').inert,true);
    assert.equal(p.doc.activeElement,p.doc.querySelector('[data-arrival-skip]'));
    assert.match(p.doc.querySelector('[data-arrival-critical]').textContent,/visibility:\s*hidden/);
  }finally{p.close();}
});

test('direct hashes never acquire the startup cover',()=>{
  for(const options of [{hash:'#contatti'}]){
    const p=page(options);
    try{
      assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    }finally{p.close();}
  }
});
test('movimento ridotto conserva il benvenuto statico automatico e la copertura iniziale',()=>{
  const p=page({reduce:true});
  let controller;
  try {
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
    p.run(900);p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
  }finally{controller?.destroy();p.close();}
});
test('la politica full trasferisce la copertura iniziale alla sequenza animata completa con sistema reduce',()=>{
  const p=page({reduce:true,brandMotion:'full'});
  let controller;
  try {
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    p.run(900);p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    p.run(3000);
    assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-closing'),true);
    p.run(1100);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
  }finally{controller?.destroy();p.close();}
});

test('no JavaScript leaves the homepage accessible with the intro hidden',()=>{
  const p=page({scripts:false});
  try{
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
  }finally{p.close();}
});

test('the bounded startup fallback releases a failed module and prevents a late intro reopening',()=>{
  const p=page();
  let controller;
  try{
    p.run(8000);
    assert.equal(p.boot.preventIntro,true);
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
  }finally{controller?.destroy();p.close();}
});

test('skip and Escape work before the main modules and remain respected without storage',()=>{
  for(const action of ['click','Escape']){
    const p=page({storageUnavailable:true});
    let controller;
    try{
      if(action==='click')p.doc.querySelector('[data-arrival-bypass]').click();
      else p.doc.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:action,bubbles:true}));
      assert.equal(p.boot.preventIntro,true);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false);
      controller=setupArrival(p.doc,p.dom.window);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    }finally{controller?.destroy();p.close();}
  }
});

test('module takeover restores startup inert state before the normal intro owns and releases it',()=>{
  const p=page();
  let controller;
  try{
    const release=p.boot.release;
    let transferred=false;
    p.boot.release=(reason)=>{
      if(reason==='takeover'){
        assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
        assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
        assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
        transferred=true;
      }
      release(reason);
    };
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(transferred,true);
    assert.equal(p.boot.pending,false);
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
    assert.equal(p.doc.querySelector('main').inert,true);
    p.doc.querySelector('[data-arrival-skip]').click();p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    p.run(8000);
    assert.equal(p.boot.preventIntro,false);
  }finally{controller?.destroy();p.close();}
});
test('la freccia salta già prima dei moduli senza diventare un comando di avvio',()=>{
  const p=page();
  let controller;
  try{
    p.doc.querySelector('[data-arrival-skip]').click();
    assert.equal(p.boot.pending,false);
    assert.equal(p.boot.preventIntro,true);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    assert.equal('entryRequested' in p.boot,false);
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
  }finally{controller?.destroy();p.close();}
});
test('il primo disegno copre la home anche con vecchi flag di sessione salvati',()=>{
  const p=page({seen:true});
  try{
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
    assert.equal(p.boot.pending,true);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    assert.equal(p.dom.window.sessionStorage.getItem('oronero-arrival-seen-v2'),'1');
  }finally{p.close();}
});

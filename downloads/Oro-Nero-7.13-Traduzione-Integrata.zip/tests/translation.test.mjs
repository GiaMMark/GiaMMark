import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { getTranslator, isTranslationPage } from '../site/assets/translation.js';

const EN = {
  'Il ristorante': 'The restaurant', 'Pausa musica': 'Pause music', 'Avvia musica': 'Play music',
  'Foto precedente': 'Previous photo', 'Cerca nel menu': 'Search the menu',
  'Cerca un piatto…': 'Search for a dish…', 'Patate al forno': 'Roast potatoes',
  'Le mani in cucina': 'Hands in the kitchen', 'Mostra meno foto': 'Show fewer photos',
  '{count} proposte': '{count} dishes', 'Allergeni: {numbers}': 'Allergens: {numbers}',
  'Consulta gli allergeni di {dish}': 'View allergens for {dish}',
  'Apri foto: {description}': 'Open photo: {description}',
  'Foto {index} di {count}': 'Photo {index} of {count}',
  'Mostra tutte le {count} foto': 'Show all {count} photos',
  '{action} · Vivaldi, L’inverno': '{action} · Vivaldi, Winter',
};
function page(html = '<main><h1>Il ristorante</h1></main>', options = {}) {
  const dom = new JSDOM(`<!doctype html><html lang="it"><head><title>Il ristorante</title></head><body>${html}</body></html>`, { url: options.url || 'https://oronero.netlify.app/', pretendToBeVisual: true });
  if (options.saved) dom.window.localStorage.setItem('oronero.language.v1', options.saved);
  const translator = getTranslator(dom.window.document, dom.window, { loadCatalog: async () => EN, ...options });
  return { dom, doc: dom.window.document, win: dom.window, translator, close() { translator.destroy(); dom.window.close(); } };
}
const settle = async () => { await new Promise((resolve) => setTimeout(resolve, 15)); };

test('local phrases preserve inline structure, listeners, original spacing and user-entered data', async () => {
  const p = page('<main><h1>  Il   ristorante \n<em>Patate al forno</em></h1><button aria-label="Foto precedente">←</button><input aria-label="Cerca nel menu" placeholder="Cerca un piatto…"><textarea>Il ristorante</textarea><p contenteditable="true">Il ristorante</p><span translate="no">Il ristorante</span><p class="sommelier-message user">Il ristorante</p><script type="application/json">"Il ristorante"</script></main>');
  try {
    const heading = p.doc.querySelector('h1'), child = heading.querySelector('em'), original = heading.firstChild.data;
    const button = p.doc.querySelector('button'); let clicks = 0;
    button.addEventListener('click', () => clicks++);
    p.doc.querySelector('input').value = 'Il ristorante';
    await p.translator.setLanguage('en');
    assert.equal(heading.firstChild.data, '  The restaurant \n');
    assert.equal(heading.querySelector('em'), child);
    assert.equal(child.textContent, 'Roast potatoes');
    assert.equal(button.getAttribute('aria-label'), 'Previous photo');
    assert.equal(p.doc.querySelector('input').placeholder, 'Search for a dish…');
    assert.equal(p.doc.querySelector('input').value, 'Il ristorante');
    for (const selector of ['textarea', '[contenteditable]', '[translate="no"]', '.user']) assert.equal(p.doc.querySelector(selector).textContent, 'Il ristorante');
    assert.equal(p.doc.querySelector('script').textContent, '"Il ristorante"');
    assert.equal(p.doc.title, 'The restaurant');
    button.click(); assert.equal(clicks, 1);
    await p.translator.setLanguage('it');
    assert.equal(heading.firstChild.data, original);
    assert.equal(child.textContent, 'Patate al forno');
    assert.equal(button.getAttribute('aria-label'), 'Foto precedente');
  } finally { p.close(); }
});

test('authored complete templates translate changing counts, dish descriptions and decorative arrows', async () => {
  const p = page();
  try {
    await p.translator.setLanguage('en');
    for (const [source, expected] of [
      ['12 proposte', '12 dishes'], ['Allergeni: 1, 2, 14', 'Allergens: 1, 2, 14'],
      ['Consulta gli allergeni di Patate al forno', 'View allergens for Roast potatoes'],
      ['Apri foto: Le mani in cucina', 'Open photo: Hands in the kitchen'],
      ['Foto 2 di 23', 'Photo 2 of 23'], ['Mostra tutte le 23 foto ↓', 'Show all 23 photos ↓'],
      ['Mostra meno foto ↑', 'Show fewer photos ↑'], ['Pausa musica · Vivaldi, L’inverno', 'Pause music · Vivaldi, Winter'],
    ]) assert.equal(p.translator.t(source), expected, source);
    assert.equal(p.translator.t('Un nuovo piatto: Patate al forno'), 'Un nuovo piatto: Patate al forno');
    assert.equal(p.translator.t('   '), '   ');
    assert.equal(p.translator.t('80,00 €'), '80,00 €');
  } finally { p.close(); }
});

test('async menu nodes and repeatedly reset music attributes translate without replacing the player or looping', async () => {
  const p = page('<main></main><audio data-persistent-audio></audio><button data-music-control aria-label="Avvia musica"><strong>Avvia musica</strong></button>');
  try {
    const audio = p.doc.querySelector('audio'), button = p.doc.querySelector('button');
    await p.translator.setLanguage('en');
    p.doc.querySelector('main').innerHTML = '<h2>Il ristorante</h2><p>8 proposte</p>';
    button.querySelector('strong').textContent = 'Pausa musica';
    button.setAttribute('aria-label', 'Pausa musica · Vivaldi, L’inverno');
    await settle();
    assert.equal(p.doc.querySelector('h2').textContent, 'The restaurant');
    assert.equal(p.doc.querySelector('main p').textContent, '8 dishes');
    assert.equal(button.querySelector('strong').textContent, 'Pause music');
    assert.equal(button.getAttribute('aria-label'), 'Pause music · Vivaldi, Winter');
    assert.equal(p.doc.querySelector('audio'), audio);
    let mutations = 0;
    const observer = new p.win.MutationObserver((records) => { mutations += records.length; });
    observer.observe(p.doc.documentElement, { subtree: true, attributes: true, characterData: true });
    p.translator.refresh(); await settle(); p.translator.refresh(); await settle();
    observer.disconnect();
    assert.equal(mutations, 0);
    await p.translator.setLanguage('it');
    assert.equal(button.querySelector('strong').textContent, 'Pausa musica');
    assert.equal(p.doc.querySelector('main p').textContent, '8 proposte');
  } finally { p.close(); }
});

test('nodes rendered through t() and captions composed from translated attributes return to Italian', async () => {
  const p = page('<main><img alt="Le mani in cucina"></main>');
  try {
    await p.translator.setLanguage('en');
    const paragraph = p.doc.createElement('p'); paragraph.textContent = p.translator.t('12 proposte');
    const button = p.doc.createElement('button'); button.setAttribute('aria-label', 'Apri foto: ' + p.doc.querySelector('img').alt);
    p.doc.querySelector('main').append(paragraph, button); await settle();
    assert.equal(button.getAttribute('aria-label'), 'Open photo: Hands in the kitchen');
    await p.translator.setLanguage('it');
    assert.equal(paragraph.textContent, '12 proposte');
    assert.equal(button.getAttribute('aria-label'), 'Apri foto: Le mani in cucina');
    assert.equal(p.doc.querySelector('img').alt, 'Le mani in cucina');
  } finally { p.close(); }
});

test('one document manager survives page swaps and reapplies the locale after router lang reset', async () => {
  const p = page();
  try {
    await p.translator.setLanguage('en');
    p.win.history.pushState({}, '', '/menu/');
    p.doc.querySelector('main').outerHTML = '<main><h2>Patate al forno</h2></main>';
    p.doc.documentElement.lang = 'it';
    assert.equal(getTranslator(p.doc, p.win), p.translator);
    assert.equal(p.doc.documentElement.lang, 'en');
    assert.equal(p.doc.querySelector('h2').textContent, 'Roast potatoes');
    assert.equal(p.win.localStorage.getItem('oronero.language.v1'), 'en');
  } finally { p.close(); }
});

test('saved preference waits for the local catalog before changing document language', async () => {
  let resolve;
  const p = page(undefined, { saved: 'de', loadCatalog: () => new Promise((done) => { resolve = done; }) });
  try {
    await Promise.resolve();
    assert.equal(p.translator.locale, 'it'); assert.equal(p.doc.documentElement.lang, 'it');
    resolve({ 'Il ristorante': 'Das Restaurant' });
    await p.translator.ready;
    assert.equal(p.translator.locale, 'de');
    assert.equal(p.doc.querySelector('h1').textContent, 'Das Restaurant');
    assert.equal(p.doc.documentElement.lang, 'de');
  } finally { p.close(); }
});

test('catalog failures and bounded timeouts leave the page usable and allow retry', async () => {
  let mode = 'error';
  const p = page(undefined, { timeoutMs: 20, loadCatalog: () => mode === 'error' ? Promise.reject(new Error('offline')) : mode === 'wait' ? new Promise(() => {}) : Promise.resolve(EN) });
  try {
    await assert.rejects(p.translator.setLanguage('en'), /offline/);
    assert.equal(p.translator.locale, 'it');
    assert.equal(p.doc.querySelector('h1').textContent, 'Il ristorante');
    mode = 'wait';
    await assert.rejects(p.translator.setLanguage('en'), /Riprova/);
    assert.equal(p.translator.state, 'error');
    mode = 'success'; await p.translator.setLanguage('en');
    assert.equal(p.translator.state, 'ready');
    assert.equal(p.doc.querySelector('h1').textContent, 'The restaurant');
  } finally { p.close(); }
});

test('a superseded catalog cannot overwrite an immediate return to Italian', async () => {
  let resolve, signal;
  const p = page(undefined, { loadCatalog: (_, options) => { signal = options.signal; return new Promise((done) => { resolve = done; }); } });
  try {
    const pending = p.translator.setLanguage('en').catch((error) => error);
    await Promise.resolve();
    await p.translator.setLanguage('it');
    resolve(EN);
    assert.equal((await pending).name, 'AbortError');
    assert.equal(signal.aborted, true);
    assert.equal(p.translator.locale, 'it');
    assert.equal(p.doc.querySelector('h1').textContent, 'Il ristorante');
    assert.equal(p.win.localStorage.getItem('oronero.language.v1'), 'it');
  } finally { p.close(); }
});

test('unknown locales and administrative routes never translate credentials or user content', async () => {
  const p = page();
  try {
    await assert.rejects(p.translator.setLanguage('../../admin'), RangeError);
    await p.translator.setLanguage('en');
    p.win.history.pushState({}, '', '/admin/');
    p.doc.querySelector('main').innerHTML = '<h2>Il ristorante</h2><input value="private-password">';
    p.translator.refresh();
    assert.equal(p.translator.available, false);
    assert.equal(p.doc.documentElement.lang, 'it');
    assert.equal(p.doc.querySelector('h2').textContent, 'Il ristorante');
    assert.equal(p.translator.t('Il ristorante'), 'Il ristorante');
    await assert.rejects(p.translator.setLanguage('de'), /pubbliche/);
    assert.equal(p.doc.querySelector('input').value, 'private-password');
    p.win.history.pushState({}, '', '/'); p.translator.refresh();
    assert.equal(p.doc.querySelector('h2').textContent, 'The restaurant');
  } finally { p.close(); }
});

test('destroy restores Italian and disconnects late observers', async () => {
  const p = page();
  try {
    await p.translator.setLanguage('en');
    p.translator.destroy();
    assert.equal(p.doc.querySelector('h1').textContent, 'Il ristorante');
    p.doc.querySelector('main').innerHTML = '<p>Patate al forno</p>'; await settle();
    assert.equal(p.doc.querySelector('p').textContent, 'Patate al forno');
  } finally { p.close(); }
});

test('closing a window with an observer refresh queued detaches without asynchronous errors', async () => {
  const p = page();
  try {
    await p.translator.setLanguage('en');
    p.doc.querySelector('main').innerHTML = '<p>Patate al forno</p>';
    // Let MutationObserver enqueue its refresh, then close before that refresh.
    await Promise.resolve();
    p.win.close();
    await settle();
    assert.equal(isTranslationPage(p.win), false);
    assert.doesNotThrow(() => p.translator.refresh());
    await assert.rejects(p.translator.setLanguage('en'), { name: 'AbortError' });
  } finally { p.close(); }
});

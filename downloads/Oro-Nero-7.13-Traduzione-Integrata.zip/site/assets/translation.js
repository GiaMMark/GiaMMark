/** Local, authored translations. No visitor text is sent to another service. */
const MANAGERS = new WeakMap();
const SINGLETON = Symbol.for('oronero.translation.controller');
const STORAGE_KEY = 'oronero.language.v1';
const LOCALES = new Set(['it', 'en', 'de', 'fr', 'es']);
const ATTRIBUTES = ['aria-label', 'alt', 'placeholder', 'title', 'label'];
const EXCLUDED = 'script, style, noscript, template, textarea, [translate="no"], [data-no-translate], [contenteditable="true"], .sommelier-message.user, #language-dialog';
const PUBLIC_PAGES = new Set(['', 'menu', 'galleria', 'allergeni', 'recensioni', 'privacy', 'qr']);

export function isTranslationPage(win = window) {
  try {
    const pathname = win.location?.pathname;
    if (typeof pathname !== 'string') return false;
    const path = pathname.replace(/^\/+/, '').replace(/index\.html$/, '').replace(/\/+$/, '');
    return PUBLIC_PAGES.has(path);
  } catch { return false; /* A detached or closed window has no readable location. */ }
}

const normalized = (text) => String(text).replace(/\s+/g, ' ').trim();
const escapePattern = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function template(text) {
  const names = [];
  let index = 0;
  let pattern = '^';
  for (const match of text.matchAll(/\{([a-zA-Z][\w]*)\}/g)) {
    pattern += escapePattern(text.slice(index, match.index));
    names.push(match[1]);
    pattern += /^(?:count|index)$/.test(match[1]) ? '(\\d+)' : '(.+?)';
    index = match.index + match[0].length;
  }
  if (!names.length) return null;
  return { pattern: new RegExp(pattern + escapePattern(text.slice(index)) + '$'), names };
}
const fill = (text, values) => text.replace(/\{([a-zA-Z][\w]*)\}/g, (match, name) => values[name] ?? match);
const abortError = () => Object.assign(new Error('Cambio lingua annullato.'), { name: 'AbortError' });

export function getTranslator(doc = document, win = window, options = {}) {
  const previous = MANAGERS.get(doc) || doc[SINGLETON];
  if (previous) { previous.refresh(); return previous; }

  const textRecords = new WeakMap();
  const attributeRecords = new WeakMap();
  const catalogs = new Map();
  const reverse = new Map();
  const sourceKeys = new Set();
  const reverseTemplates = [];
  const remembered = new Map();
  let selected = 'it';
  let state = 'ready';
  let lastError = null;
  let generation = 0;
  let request;
  let destroyed = false;
  let scheduled = false;
  let ready;
  const timeoutMs = Number.isFinite(options.timeoutMs) ? Math.max(1, options.timeoutMs) : 3000;
  const loadCatalog = options.loadCatalog || (async (code, { signal }) => {
    const response = await win.fetch(new URL(`./locales/${code}.json?v=7.13.0`, import.meta.url), { signal, headers: { accept: 'application/json' } });
    if (!response.ok) throw new Error('Traduzione momentaneamente non disponibile.');
    return response.json();
  });

  function catalog(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Traduzione non disponibile.');
    const phrases = new Map();
    const templates = [];
    for (const [key, translation] of Object.entries(value)) {
      if (typeof translation !== 'string' || !normalized(key) || !normalized(translation)) continue;
      const source = normalized(key), target = normalized(translation);
      phrases.set(source, target);
      sourceKeys.add(source);
      if (!reverse.has(target)) reverse.set(target, source);
      const parsed = template(source);
      if (parsed) {
        templates.push({ source, target, ...parsed });
        const translated = template(target);
        if (translated) reverseTemplates.push({ source, ...translated });
      }
    }
    if (!phrases.size) throw new Error('Traduzione non disponibile.');
    return { phrases, templates };
  }

  function sourceText(value, depth = 0) {
    const text = normalized(value);
    if (depth > 4 || !text || sourceKeys.has(text)) return text;
    if (remembered.has(text)) return remembered.get(text);
    if (reverse.has(text)) return reverse.get(text);
    // New nodes may contain a previously translated photo description or dish.
    // Match only complete, authored templates, never individual words.
    const current = catalogs.get(selected);
    for (const entry of [...(current?.templates || []), ...reverseTemplates]) {
      const match = text.match(entry.pattern);
      if (!match) continue;
      const values = Object.fromEntries(entry.names.map((name, i) => [name, sourceText(match[i + 1], depth + 1)]));
      return fill(entry.source, values);
    }
    const arrow = text.match(/^(.*?)(\s*[↑↓←→↗↘↻])$/);
    if (arrow) return sourceText(arrow[1], depth + 1) + arrow[2];
    return text;
  }

  function translate(text, depth = 0) {
    const current = catalogs.get(selected);
    if (!current || depth > 4) return text;
    if (current.phrases.has(text)) return current.phrases.get(text);
    for (const entry of current.templates) {
      const match = text.match(entry.pattern);
      if (!match) continue;
      const values = Object.fromEntries(entry.names.map((name, i) => [name, translate(sourceText(match[i + 1]), depth + 1)]));
      return fill(entry.target, values);
    }
    const arrow = text.match(/^(.*?)(\s*[↑↓←→↗↘↻])$/);
    if (arrow) return translate(arrow[1].trim(), depth + 1) + arrow[2];
    return text;
  }

  function t(value) {
    const raw = String(value ?? '');
    if (!normalized(raw) || !isTranslationPage(win) || selected === 'it') return raw;
    const source = sourceText(raw);
    const result = translate(source);
    if (result !== source) {
      remembered.set(result, source);
      // Rendered public phrases only; bound memory when live menu data changes.
      if (remembered.size > 3000) remembered.delete(remembered.keys().next().value);
    }
    if (result === normalized(raw)) return raw;
    return raw.match(/^\s*/)[0] + result + raw.match(/\s*$/)[0];
  }

  function excluded(element) { return !element || Boolean(element.closest(EXCLUDED)); }
  function documentActive() {
    try { return win.document === doc && !win.closed; } catch { return false; }
  }
  function detach() {
    destroyed = true;
    generation++;
    request?.cancel(); request = null;
    observer?.disconnect();
    MANAGERS.delete(doc);
    if (doc[SINGLETON] === controller) delete doc[SINGLETON];
  }
  function update(value, record) {
    let source;
    if (record && value === record.last) source = record.source;
    else {
      const canonical = sourceText(value);
      source = canonical === normalized(value) ? value : value.match(/^\s*/)[0] + canonical + value.match(/\s*$/)[0];
    }
    const result = isTranslationPage(win) && selected !== 'it' ? t(source) : source;
    return { source, last: result };
  }
  const observer = typeof win.MutationObserver === 'function' ? new win.MutationObserver(() => {
    if (scheduled || destroyed) return;
    if (!documentActive()) { detach(); return; }
    scheduled = true;
    const enqueue = win.queueMicrotask?.bind(win) || ((fn) => Promise.resolve().then(fn));
    enqueue(() => { scheduled = false; if (!destroyed) refresh(); });
  }) : null;
  function observe() {
    if (!destroyed && doc.documentElement) observer?.observe(doc.documentElement, {
      subtree: true, childList: true, characterData: true, attributes: true,
      attributeFilter: [...ATTRIBUTES, 'lang', 'translate'],
    });
  }
  function refresh() {
    if (destroyed || !doc.documentElement) return;
    if (!documentActive()) { detach(); return; }
    // Disconnect during our own synchronous writes: no feedback loops, and
    // original Italian records remain available when application code rerenders.
    observer?.disconnect();
    try {
      const publicPage = isTranslationPage(win);
      const walker = doc.createTreeWalker(doc.documentElement, win.NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (excluded(node.parentElement) || !normalized(node.data)) continue;
        if (!publicPage && !textRecords.has(node)) continue;
        const record = update(node.data, textRecords.get(node));
        textRecords.set(node, record);
        if (node.data !== record.last) node.data = record.last;
      }
      for (const element of doc.querySelectorAll(ATTRIBUTES.map((name) => `[${name}]`).join(','))) {
        if (excluded(element)) continue;
        let records = attributeRecords.get(element);
        if (!publicPage && !records) continue;
        if (!records) attributeRecords.set(element, records = new Map());
        for (const name of ATTRIBUTES) {
          if (!element.hasAttribute(name) || (name === 'label' && element.tagName !== 'OPTGROUP')) continue;
          const value = element.getAttribute(name);
          const record = update(value, records.get(name));
          records.set(name, record);
          if (value !== record.last) element.setAttribute(name, record.last);
        }
      }
      const language = publicPage ? selected : 'it';
      if (doc.documentElement.lang !== language) doc.documentElement.lang = language;
    } finally { observe(); }
  }

  function notify(name, detail) {
    if (documentActive()) doc.dispatchEvent(new win.CustomEvent(name, { detail }));
  }
  async function setLanguage(code, { persist = true } = {}) {
    if (!LOCALES.has(code)) throw new RangeError('Lingua non disponibile.');
    if (destroyed || !documentActive()) { if (!destroyed) detach(); throw abortError(); }
    if (!isTranslationPage(win) && code !== 'it') throw new Error('La traduzione è disponibile nelle pagine pubbliche.');
    const token = ++generation;
    request?.cancel();
    state = 'loading'; lastError = null;
    try {
      if (code !== 'it' && !catalogs.has(code)) {
        const controller = new win.AbortController();
        let timer;
        let cancel;
        const cancelled = new Promise((_, reject) => { cancel = () => { controller.abort(); reject(abortError()); }; });
        request = { cancel };
        const timeout = new Promise((_, reject) => {
          timer = win.setTimeout(() => {
            controller.abort();
            reject(new Error('La lingua non è stata caricata. Riprova.'));
          }, timeoutMs);
        });
        let value;
        try { value = await Promise.race([Promise.resolve().then(() => loadCatalog(code, { signal: controller.signal })), cancelled, timeout]); }
        finally { win.clearTimeout(timer); if (token === generation) request = null; }
        if (!documentActive()) detach();
        if (destroyed || token !== generation) throw abortError();
        catalogs.set(code, catalog(value));
      }
      if (destroyed || token !== generation) throw abortError();
      selected = code;
      state = 'ready';
      if (persist) { try { win.localStorage.setItem(STORAGE_KEY, code); } catch { /* Optional preference storage. */ } }
      refresh();
      notify('oronero:languagechange', { locale: code });
      return code;
    } catch (error) {
      if (token === generation && !destroyed) {
        state = 'error'; lastError = error;
        notify('oronero:languageerror', { locale: code });
      }
      throw error;
    }
  }

  const controller = {
    t, setLanguage, refresh,
    get locale() { return selected; },
    get available() { return isTranslationPage(win); },
    get state() { return state; },
    get error() { return lastError; },
    get ready() { return ready; },
    destroy() {
      if (destroyed) return;
      generation++; request?.cancel(); request = null;
      selected = 'it'; refresh(); detach();
    },
  };
  MANAGERS.set(doc, controller);
  doc[SINGLETON] = controller;
  refresh();
  let saved;
  try { saved = win.localStorage.getItem(STORAGE_KEY); } catch { /* Storage may be unavailable. */ }
  ready = saved && saved !== 'it' && LOCALES.has(saved) && isTranslationPage(win)
    ? setLanguage(saved, { persist: false }).catch(() => selected)
    : Promise.resolve(selected);
  return controller;
}

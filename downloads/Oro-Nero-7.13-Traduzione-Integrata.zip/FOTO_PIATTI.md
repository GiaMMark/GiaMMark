# Fotografie · Oro Nero 7.13

Importati i 13 ZIP FOTO1–FOTO10 e FOTO12–FOTO14: 26 file JPEG, 23 fotografie uniche. Duplicati identici rimossi: DSC7932 (FOTO3/FOTO4), DSC8058 (FOTO7/FOTO8), DSC8072 (FOTO7/FOTO9).

## Foto nel sito

La galleria è nella home, sezione `#galleria`: sei anteprime e comando per espandere tutte le 23 foto. Il visualizzatore usa le immagini grandi e mantiene distinti il gruppo della raccolta e le due fotografie dell’atmosfera. Le nuove foto sostituiscono le precedenti in apertura, cucina, proposte, cantina, atmosfera e metadati sociali.

Gli asset sono in `site/assets/images/collection-2026/`: 23 WebP con lato massimo 2000 pixel e 23 anteprime da 720 pixel. Orientamento e colore rispettati, proporzioni originali, nessun EXIF/GPS nelle versioni web. I JPEG originali sono conservati nello staging dell’ambiente; gli ZIP di consegna includono le versioni ottimizzate.

`foto-sito.csv` associa ID, file originale, archivi, percorso web e didascalia. `site/assets/photographs.json` contiene i dati pubblici della raccolta. Per spostare o cambiare una foto modificare il markup in `site/index.html` e, per il collegamento precedente, `site/galleria/index.html`. Mantenere corretti testo alternativo, dimensioni, anteprima e `data-full-src`.

Le foto ricevute mostrano cucina, piatti, dessert e vini. Non contengono una nuova panoramica della sala o ritratti identificabili dello staff; non sono state inventate queste immagini né associati nomi personali.

## Dati fotografici dei piatti

Il menu pubblico rimane senza foto o segnaposti. Nomi, descrizioni, prezzi, allergeni e abbinamenti restano disponibili. I vecchi asset e le associazioni dei piatti nell’admin sono archiviati; la loro modifica non pubblica foto nel menu o nella galleria.

L’admin richiede il deploy completo Netlify con autenticazione, descritto in README_NETLIFY.md. `foto-piatti.csv` conserva il catalogo delle 80 voci per eventuale gestione futura; `foto-sito.csv` documenta invece le nuove foto pubbliche.

# Oro Nero 7.13.0 · Traduzione integrata

## Problema e soluzione

Il vecchio selettore apriva il servizio esterno Google Translate e richiedeva il caricamento di una seconda copia del sito, inclusi moduli, intro e richieste del menu. Il caricamento remoto segnalato dall’utente non è verificabile da questo ambiente, ma la versione attuale elimina completamente quel passaggio e le sue dipendenze.

Cinque lingue effettivamente disponibili nello stesso documento: italiano, inglese, tedesco, francese e spagnolo. Quattro cataloghi locali da 498 chiavi, con frasi e template per i contenuti attuali. Nessuna API, chiave, richiesta a un traduttore esterno o nuova scheda. Altre lingue richiedono nuovi cataloghi o un servizio configurato; non sono dichiarate disponibili tutte le precedenti 249 scelte.

## Build e test

Node.js 22.23.4: build e controllo dei contenuti riusciti. **99 test superati**, nessun fallimento o test saltato. Il controllo valida file, parità delle chiavi, segnaposto e conservazione degli importi nei quattro cataloghi. Il menu conserva 13 categorie e 80 voci; le 23 foto uniche e le relative 46 versioni WebP sono incluse.

I test coprono selezione e persistenza, markup e ascoltatori preservati, ripristino dell’italiano, testo alternativo e aria-label, aggiornamenti asincroni di menu e musica, navigazione interna, errori/timeout/retry, richieste superate, input e messaggi utente, area amministrativa e chiusura della finestra con osservatori pendenti. La ricerca trova i piatti tradotti e gli importi restano invariati. Restano verificati intro, animazioni del marchio e gestione dei CSS al primo ingresso nel menu.

## Verifiche browser

Chromium: 20 controlli pagina/lingua. Tutte le sette pagine pubbliche in inglese e tedesco a 1440 pixel; home, menu e allergeni in francese e spagnolo a 390 pixel. Nessuna chiave italiana nota rimasta, nessun popup, richiesta esterna o errore JavaScript. Le denominazioni proprie possono essere conservate intenzionalmente.

Controllati menu completo, nomi e descrizioni, testi e aria-label degli allergeni, campi di prenotazione, didascalie, contatori, espansione della galleria e comandi musicali durante pausa/riproduzione. La lingua segue i nuovi nodi inseriti dal sito e rimane selezionata durante navigazione e ricaricamento.

Prove aggiuntive a 390 e 1440 pixel: passaggio fra tutte le cinque lingue senza sostituire il documento; stesso lettore audio collegato e attivo durante la navigazione. HTTP 503 e richiesta del catalogo lasciata pendente: errore visibile entro il timeout, lingua precedente conservata, selettore chiudibile e tentativo successivo riuscito. Ricerca in inglese, prenotazione e testo WhatsApp tradotti; valori digitati preservati. Ritorno completo all’italiano. Nessun blocco permanente della pagina.

## Contenuti conservati

Galleria nella home con 23 foto dell’utente e anteprima di sei, menu pubblico senza fotografie, marchio rotante e intro automatica di circa 4,1 secondi anche con movimento ridotto di sistema, selezionati dal proprietario. Stesso lettore nelle transizioni interne; nessuna modifica a prezzi o dati amministrativi.

## Limiti e pubblicazione

Non è una traduzione automatica di qualsiasi testo o lingua: nuovi contenuti del menu restano nell’originale finché i cataloghi non vengono aggiornati. L’area amministrativa e il testo libero dell’ospite non vengono tradotti. Non sono stati forniti lingua/browser specifici in cui il vecchio proxy si bloccava; il controllo riguarda la nuova soluzione locale.

Nessun deploy Netlify eseguito. I download GitHub devono essere pubblicati sull’hosting, con tutti i file della build 7.13, per aggiornare il sito online. L’autoplay sonoro resta soggetto al browser e il volume fisico al dispositivo.

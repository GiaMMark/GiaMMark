import { LANGUAGE_CATALOG } from './languages-data.js';

const CONTROLLER = Symbol.for('oronero.languages.controller');
const PUBLIC_PAGES = new Set(['', 'menu', 'galleria', 'allergeni', 'recensioni', 'privacy', 'qr']);
const CODES = new Set(LANGUAGE_CATALOG.map((entry) => entry.code));
const PREFERRED = ['it', 'en', 'de', 'fr', 'es', 'zh-CN', 'ar', 'ja'];
const NAMES = {
  it: ['Italiano', 'Italiano'], en: ['Inglese', 'English'], de: ['Tedesco', 'Deutsch'],
  fr: ['Francese', 'Français'], es: ['Spagnolo', 'Español'], ar: ['Arabo', 'العربية'],
  ja: ['Giapponese', '日本語'], ko: ['Coreano', '한국어'], ru: ['Russo', 'Русский'],
  uk: ['Ucraino', 'Українська'], hi: ['Hindi', 'हिन्दी'], tr: ['Turco', 'Türkçe'],
  'zh-CN': ['Cinese semplificato', '中文（简体）'], 'zh-TW': ['Cinese tradizionale', '中文（繁體）'],
  pt: ['Portoghese (Brasile)', 'Português (Brasil)'], 'pt-PT': ['Portoghese (Portogallo)', 'Português (Portugal)'],
  'fr-CA': ['Francese (Canada)', 'Français (Canada)'],
};

function privateHost(hostname) {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (!host.includes('.') || /(?:^|\.)(?:localhost|local|test|invalid|example|internal|lan|home|corp|onion)$/.test(host)) return true;
  if (host.includes(':')) return true;
  // This website translates named public sites, not literal service addresses.
  return /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.test(host);
}

function publicUrl(value) {
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.port || privateHost(url.hostname)) return null;
    return url;
  } catch { return null; }
}

/** Only public restaurant pages are shared; query strings and fragments stay private. */
export function publicTranslationPage(locationHref, { publicBase } = {}) {
  let source;
  try { source = new URL(locationHref); } catch { return null; }
  if (!['http:', 'https:'].includes(source.protocol) || source.username || source.password) return null;
  const route = source.pathname.replace(/^\/+/, '').replace(/index\.html$/, '').replace(/\/+$/, '');
  if (!PUBLIC_PAGES.has(route)) return null;
  if (privateHost(source.hostname)) {
    const base = publicUrl(publicBase);
    if (!base) return null;
    source = new URL(source.pathname, base.origin);
  } else if (!publicUrl(source.href)) return null;
  source.search = '';
  source.hash = '';
  return source.href;
}

/** Google Translate's public website tool; no undocumented translation API. */
export function translationUrl(locationHref, languageCode, options = {}) {
  if (!CODES.has(languageCode)) return null;
  const source = publicTranslationPage(locationHref, options);
  if (!source) return null;
  if (languageCode === 'it') return source;
  const target = new URL('https://translate.google.com/translate');
  target.searchParams.set('sl', 'it');
  target.searchParams.set('tl', languageCode);
  target.searchParams.set('hl', languageCode);
  target.searchParams.set('u', source);
  return target.href;
}

function normalize(value) {
  return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function languageNames(entry, win) {
  if (NAMES[entry.code]) return NAMES[entry.code];
  let label = entry.name;
  let native = entry.name;
  try {
    const tag = new win.Intl.Locale(entry.code).toString();
    const translated = new win.Intl.DisplayNames(['it'], { type: 'language' }).of(tag);
    if (translated && translated !== tag) label = translated.charAt(0).toUpperCase() + translated.slice(1);
    if (win.Intl.DisplayNames.supportedLocalesOf([tag]).length) {
      native = new win.Intl.DisplayNames([tag], { type: 'language' }).of(tag) || entry.name;
    }
  } catch { /* The catalog also contains languages unavailable in browser Intl data. */ }
  return [label, native];
}

export function setupLanguages(doc = document, win = window, options = {}) {
  const existing = doc.querySelector('#language-dialog');
  if (existing?.[CONTROLLER]) return existing[CONTROLLER];
  const dialog = doc.createElement('dialog');
  dialog.id = 'language-dialog';
  dialog.className = 'language-dialog';
  dialog.setAttribute('aria-labelledby', 'language-title');
  dialog.setAttribute('aria-describedby', 'language-note');
  dialog.innerHTML = [
    '<div class="language-panel">',
    '<header class="language-head"><div><p>Lingua / Language</p><h2 id="language-title">Scegli la tua lingua.</h2></div><button type="button" class="language-close" data-language-close aria-label="Chiudi il selettore delle lingue">×</button></header>',
    '<p class="language-note" id="language-note">La versione tradotta si apre in una nuova scheda tramite Google Translate. La traduzione è automatica e dipende dalle lingue disponibili nel servizio.</p>',
    '<p class="language-unavailable" data-language-unavailable hidden></p>',
    '<label class="language-search"><span>Cerca una lingua / Find a language</span><input type="search" data-language-search autocomplete="off" spellcheck="false" placeholder="Italiano, English, Deutsch…" aria-controls="language-results"></label>',
    '<p class="language-count" data-language-count role="status" aria-live="polite"></p>',
    '<ul class="language-list" id="language-results" data-language-results></ul>',
    '<p class="language-empty" data-language-empty hidden>Nessuna lingua trovata. Prova con il nome in inglese o il codice della lingua.</p>',
    '<footer class="language-foot">La pagina originale resta in italiano.</footer>',
    '</div>',
  ].join('');
  doc.body.append(dialog);
  const input = dialog.querySelector('[data-language-search]');
  const results = dialog.querySelector('[data-language-results]');
  const count = dialog.querySelector('[data-language-count]');
  const empty = dialog.querySelector('[data-language-empty]');
  const notice = dialog.querySelector('[data-language-unavailable]');
  const entries = LANGUAGE_CATALOG.map((entry) => {
    const [label, native] = languageNames(entry, win);
    return { ...entry, label, native, search: normalize([entry.code, entry.name, label, native].join(' ')) };
  }).sort((a, b) => {
    const first = PREFERRED.indexOf(a.code), second = PREFERRED.indexOf(b.code);
    if (first >= 0 || second >= 0) return (first < 0 ? 100 : first) - (second < 0 ? 100 : second);
    return a.label.localeCompare(b.label, 'it');
  });
  let opener;
  let alive = true;
  let returnFocus = true;

  const controls = () => doc.querySelectorAll('[data-language-open]');
  const syncControls = (open) => controls().forEach((button) => {
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', dialog.id);
    button.setAttribute('aria-expanded', String(open));
  });
  const render = () => {
    const query = normalize(input.value);
    const shown = entries.filter((entry) => !query || entry.search.includes(query));
    const source = publicTranslationPage(win.location.href, options);
    notice.hidden = Boolean(source);
    if (!source) {
      notice.textContent = /\/(?:admin|api|\.netlify)(?:\/|$)/.test(win.location.pathname)
        ? 'La traduzione è disponibile per le pagine pubbliche. L’area amministrativa resta nella lingua originale.'
        : 'La traduzione sarà disponibile dal dominio pubblico del sito. Questa anteprima locale non viene inviata a Google.';
    }
    results.replaceChildren();
    for (const entry of shown) {
      const item = doc.createElement('li');
      const link = doc.createElement(source ? 'a' : 'span');
      link.className = 'language-choice';
      link.setAttribute('data-translation-code', entry.code);
      if (source) {
        link.href = translationUrl(win.location.href, entry.code, options);
        link.setAttribute('data-native-navigation', '');
        if (entry.code !== 'it') { link.target = '_blank'; link.rel = 'noopener noreferrer'; }
      } else link.setAttribute('aria-disabled', 'true');
      const name = doc.createElement('strong');
      name.textContent = entry.native;
      name.dir = 'auto';
      const label = doc.createElement('span');
      label.textContent = entry.label;
      const code = doc.createElement('small');
      code.textContent = entry.code.toUpperCase();
      link.append(name, label, code);
      if (entry.code === 'it') link.setAttribute('aria-current', 'true');
      item.append(link);
      results.append(item);
    }
    count.textContent = shown.length + (shown.length === 1 ? ' lingua trovata' : ' lingue disponibili');
    empty.hidden = shown.length !== 0;
  };
  const focusBack = () => {
    if (!alive) return;
    doc.body.classList.remove('language-open');
    syncControls(false);
    if (returnFocus) (opener?.isConnected ? opener : doc.querySelector('[data-language-open]'))?.focus({ preventScroll: true });
  };
  const close = (focus = true) => {
    returnFocus = focus;
    if (dialog.open && typeof dialog.close === 'function') {
      try { dialog.close(); } catch { dialog.removeAttribute('open'); focusBack(); }
    } else { dialog.removeAttribute('open'); focusBack(); }
  };
  const open = (trigger) => {
    if (!alive) return;
    // Release the mobile navigation's own focus trap before opening a modal.
    doc.querySelector('.nav-toggle[aria-expanded="true"]')?.click();
    opener = trigger || doc.activeElement;
    returnFocus = true;
    input.value = '';
    render();
    if (!dialog.open) {
      try { dialog.showModal(); } catch { dialog.setAttribute('open', ''); }
    }
    doc.body.classList.add('language-open');
    syncControls(true);
    input.focus({ preventScroll: true });
  };
  const onDocumentClick = (event) => {
    const trigger = event.target.closest?.('[data-language-open]');
    if (trigger) { event.preventDefault(); open(trigger); }
  };
  const onDialogClick = (event) => {
    if (event.target === dialog || event.target.closest?.('[data-language-close]')) { close(); return; }
    const choice = event.target.closest?.('[data-translation-code]');
    if (!choice) return;
    if (choice.getAttribute('aria-disabled') === 'true' || choice.dataset.translationCode === 'it') event.preventDefault();
    if (choice.getAttribute('aria-disabled') !== 'true') close();
  };
  const onCancel = (event) => { event.preventDefault(); close(); };
  doc.addEventListener('click', onDocumentClick);
  input.addEventListener('input', render);
  dialog.addEventListener('click', onDialogClick);
  dialog.addEventListener('cancel', onCancel);
  dialog.addEventListener('close', focusBack);
  syncControls(false);

  const controller = { dialog, open, close, destroy() {
    alive = false;
    close(false);
    doc.body.classList.remove('language-open');
    syncControls(false);
    doc.removeEventListener('click', onDocumentClick);
    input.removeEventListener('input', render);
    dialog.removeEventListener('click', onDialogClick);
    dialog.removeEventListener('cancel', onCancel);
    dialog.removeEventListener('close', focusBack);
    delete dialog[CONTROLLER];
    dialog.remove();
  } };
  dialog[CONTROLLER] = controller;
  return controller;
}

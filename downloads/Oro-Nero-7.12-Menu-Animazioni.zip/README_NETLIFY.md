# Oro Nero 7.12.0 · Menu e animazioni · Guida Netlify

Questa versione conserva menu, vini, degustazioni, eventi, allergeni, QR e pannello amministrativo. Mostra un intro con solo logo, rotazione e lucciola; il menu pubblico è testuale e senza foto o segnaposti. La musica è disponibile su tutte le pagine. La direzione Laguna Nocturne mantiene nero laguna, avorio e oro, slider fotografico manuale, galleria da tastiera e navigazione per smartphone.

I font Cormorant Garamond e Manrope sono locali; le licenze SIL Open Font License si trovano in `site/assets/fonts/`. I doppioni obsoleti `menu.mts` e `admin-session.mts` sono stati rimossi: gli endpoint attivi sono i file `.mjs`.

La home include il racconto del ristorante e una sezione con Chef, Aiuto chef, Sala e Accoglienza. Nomi e dettagli storici reali si personalizzano in `site/index.html`.

Il selettore globale cerca fra 249 lingue e varianti e apre la pagina pubblica corrente tramite Google Translate in una nuova scheda. Non richiede variabili o chiavi. La pagina originale resta in italiano; copertura e qualità dipendono dal servizio esterno. L’anteprima locale e l’area amministrativa non vengono inviate a Google. L’effettiva traduzione remota e i contenuti dinamici non sono stati verificati da questo ambiente; consultare `README.md` e `VALIDAZIONE.md` per i limiti.

La galleria ora è nella home e include tutte le 23 foto uniche importate dai 13 ZIP. Le foto iniziali sono state sostituite negli spazi pubblici. Pubblicare l’intera build 7.12, inclusi `index.html`, `assets/images/collection-2026/`, `assets/gallery-page.css` e gli script aggiornati. Intro, lucciola e logo della testata rimangono animati anche con movimento ridotto di sistema, su richiesta del proprietario. Il menu conserva la grafica al primo accesso dalla home, senza ricaricare. La galleria si aggiorna nei sorgenti, come descritto in `README.md`.

## 1. Installazione e verifica

Con Node.js 22, esegui dalla cartella contenente `package.json`:

```bash
npm ci
npm run build
npm run check
npm test
```

- `npm ci` usa il lockfile senza aggiornare le dipendenze.
- `build` genera `dist/`, il menu statico e il QR.
- `check` verifica file esportati, sezioni e dati del menu.
- `test` verifica pagine, interazioni e funzioni amministrative.

Per l’anteprima statica puoi servire la cartella generata:

```bash
python3 -m http.server 8080 --directory dist
```

Questa anteprima non esegue le Functions: usa il menu JSON di riserva e non permette salvataggi amministrativi. Per provare l’intero flusso con Netlify CLI, usa `netlify dev` e configura le variabili segrete tramite gli strumenti sicuri di Netlify o dell’ambiente locale.

## 2. Pubblicazione completa da Git

1. Estrai lo ZIP sorgente e carica tutti i sorgenti in un repository GitHub.
2. In Netlify scegli **Add new project → Import an existing project** e seleziona il repository.
3. Controlla le impostazioni lette da `netlify.toml`:
   - Build command: `npm run build`;
   - Publish directory: `dist`;
   - Functions directory: `netlify/functions`;
   - Node.js: `22`.
4. Configura le variabili indicate sotto ed esegui il deploy.

Il collegamento Git consente di distribuire sia le pagine sia le Functions che gestiscono autenticazione e salvataggio in Netlify Blobs. Non occorrono chiavi di servizi AI: il Sommelier usa regole locali e le etichette visibili della carta vini.

## 3. Variabili dell’area amministrativa

In **Project configuration → Environment variables**, imposta per **Production** e ambito **Functions**:

| Variabile | Requisito |
| --- | --- |
| `ORONERO_ADMIN_PASSWORD` | Password privata di almeno 10 caratteri. |
| `ORONERO_SESSION_SECRET` | Segreto casuale distinto di almeno 32 caratteri. |

Non inserire i valori nei file o su GitHub. Dopo averli impostati o cambiati, esegui un nuovo deploy. Senza queste variabili il pannello spiega che la configurazione è incompleta; il menu pubblico resta consultabile.

La sessione dura **8 ore** e usa un cookie Secure, HttpOnly e SameSite=Strict. Le credenziali sono controllate dalle Functions.

## 4. Aggiornare il menu

1. Apri `/admin/` sul dominio pubblicato e accedi.
2. Modifica piatti, prezzi, disponibilità, fotografie, vini, degustazioni o eventi.
3. Salva le modifiche e verifica il risultato in `/menu/`.

Le modifiche vengono memorizzate in Netlify Blobs e condivise con chi apre il menu, anche dal QR. La breve cache del menu pubblico può ritardare la visualizzazione di un aggiornamento: ricarica dopo il salvataggio. Il QR punta alla pagina del menu, quindi non va ristampato per ogni modifica dei piatti.

L’editor di ogni piatto conserva i campi per la fotografia e il relativo testo alternativo, ma nella versione 7.12 il menu pubblico non mostra immagini. Puoi scegliere una foto dal dispositivo, controllarne l’anteprima e poi premere **Salva e pubblica**. L’upload autenticato conserva le immagini in Netlify Blobs separatamente dal JSON del menu; non servono ulteriori variabili segrete. In alternativa puoi associare un URL HTTPS o un’immagine inclusa in `site/assets/images/`. Per la procedura e il catalogo completo delle immagini da preparare, consulta `FOTO_PIATTI.md` e `foto-piatti.csv`. I dati fotografici preesistenti rimangono archiviati; fotografie e segnaposti non vengono visualizzati nel menu pubblico.

I dati iniziali restano quelli forniti nel progetto. Verifica con il ristorante prezzi, disponibilità e allergeni prima di rendere operativo il sito.

## 5. QR e dominio definitivo

La build legge la variabile `URL` fornita da Netlify e genera il QR verso il percorso `/menu/` di quel dominio. Se costruisci altrove, imposta `URL` al dominio definitivo prima di eseguire `npm run build`; in sua assenza viene usato `https://oronero.netlify.app`.

Apri `/qr/`, controlla la destinazione con il telefono e poi stampa il cartello oppure scarica il file SVG. Una build locale con il dominio di riserva non produce automaticamente un QR per il tuo nuovo progetto.

## 6. Upload statico di `dist/`

Per una semplice anteprima puoi caricare **solo il contenuto generato in `dist/`** su un hosting statico. Non trascinare lo ZIP sorgente come deploy statico.

In questa modalità funzionano pagine, ingresso animato, foto già incluse nella build, menu di riserva, filtri, galleria e richiesta WhatsApp. L’admin non dispone delle Functions né del salvataggio persistente; per queste capacità usa il deploy Git Netlify descritto sopra.

Questa consegna non ha pubblicato né aggiornato un sito Netlify. La pubblicazione richiede il deploy del progetto sul tuo account Netlify.

## Musica continua su tutte le pagine

La build include il nuovo estratto MP3 fornito, attenuato di 12 dB rispetto alla versione 7.4 e riprodotto al 70% del volume del lettore. Il sito tenta l’avvio automatico sonoro: se il browser lo blocca, la prima interazione con il sito lo sblocca, senza passare da un comando dedicato. Il pulsante musicale permette sempre la pausa, che viene rispettata.

La navigazione interna conserva lo stesso lettore audio e carica i contenuti senza ricaricare il documento; il brano continua anche tra menu, recensioni, privacy, QR e area admin. I link esterni, i download e le nuove schede rimangono nativi. Il browser mantiene il controllo sull’autoplay e sul volume del dispositivo.

Per verificare il ripristino della posizione dopo una ricarica completa usa un server con supporto HTTP Range. La navigazione interna continua non richiede di riavviare la traccia. Non occorrono chiavi API musicali.

## Intro automatica

La sequenza visiva parte automaticamente senza clic e senza aspettare eventi audio: 3 secondi di rotazione e ingrandimento del logo, poi 1,1 secondi di apertura con la lucciola. La freccia salta sempre l’intro. × ed Escape mettono in pausa il brano e consentono l’ingresso silenzioso.

Il modulo musicale nella testata tenta l’autoplay in modo indipendente. Se il browser richiede un gesto per riprodurre audio udibile, l’intro prosegue comunque; un’interazione ordinaria può avviare la musica. Errori della traccia o una pausa già salvata non bloccano l’animazione o l’accesso alle pagine.

Ogni apertura completa o ricaricamento della homepage riproduce automaticamente l’intro: i vecchi indicatori di visita in sessione non la sopprimono. Tornando alla home con un collegamento interno nello stesso documento, la sequenza non riparte; il replay resta disponibile su richiesta. Collegamenti diretti con frammento e accesso al menu tramite QR mantengono il percorso senza intro. Le animazioni del marchio restano attive anche con movimento ridotto di sistema.

## Primo ingresso e sottofondo

Pubblica anche index.html aggiornato, startup.js, music-start.js e il nuovo MP3, oltre agli altri file generati: la correzione della prima schermata non consiste nel solo CSS. Una copertura inline evita il lampo della homepage; un controllo anticipato permette skip/Escape e ripristina il sito in caso di mancato caricamento degli script. Il sottofondo è attenuato direttamente nel file di 12 dB rispetto alla 7.4 e il lettore è impostato al 70%.

Non è possibile forzare audio udibile quando il browser nega l’autoplay. In quel caso la normale interazione con il sito, anche prima del caricamento completo, avvia la musica senza un pulsante dedicato.

## Pubblicare tutti gli asset aggiornati

Includere anche refinements.css e le versioni aggiornate di index.html, site.js, arrival.js, arrival.css, startup.js e music.js. La testata contiene solo l’emblema rotante e i titoli sono senza a capo forzati. Copiare l’intera build dist evita di mescolare script di versioni diverse.

## Asset del nuovo marchio

Pubblicare l’intera build aggiornata, compreso `assets/images/oronero-emblem.png`. Non riutilizzare il piccolo logo precedente al posto del nuovo emblema: intro, header, footer e QR usano ora un’immagine quadrata senza ritagli. I nomi sono composti in HTML dove previsti. Il PNG è ad alta risoluzione e trasparente.

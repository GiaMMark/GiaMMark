# Oro Nero 7.12.0 · Menu al primo accesso e animazioni

## Contenuti e media

Tutti i 13 ZIP più recenti sono stati letti: 26 JPEG, 23 unici tramite SHA-256 e tre duplicati esatti. Versioni ottimizzate: 23 WebP con lato massimo 2000 pixel e 23 anteprime da 720 pixel, 6.377.524 byte complessivi. Verificati integrità, dimensioni, orientamento, conversione colore e assenza di EXIF/GPS nei file pubblici. Originali conservati solo nello staging dell’ambiente.

La galleria è in home con sei anteprime e comando per tutte le 23 foto. Le immagini iniziali degli spazi pubblici sono sostituite; apertura, cucina, proposte, cantina, atmosfera e social card usano i nuovi file. Ogni didascalia descrive ciò che è visibile, senza inventare ricette, nomi dello staff o ambienti assenti dalle foto.

## Build e test

Node.js 22.23.4: `npm run build`, `npm run check` e `npm test` riusciti. **89 test superati**, nessun fallimento o test saltato. Il controllo della build verifica tutte le 23 foto e i relativi asset. Il menu conserva 13 categorie e 80 voci.

Il nuovo test della raccolta verifica anteprima/espansione, unicità, scorrimento limitato al proprio gruppo, foto grande, contatore e didascalie senza indici decorativi. Inclusi 20 test dell’intro, 10 del primo avvio e 7 della navigazione, con regressioni per movimento ridotto, vecchi indicatori di sessione, skip e ritorno interno alla homepage.

## Primo accesso al menu

Riprodotto il difetto prima della correzione: nel passaggio home → menu restava soltanto `menu-text.css`; i quattro CSS comuni venivano rimossi perché i collegamenti relativi erano rivalutati dopo il cambio indirizzo. Il menu perdeva formattazione e il caricamento diretto la ripristinava.

I CSS iniziali relativi vengono ora sostituiti con copie assolute già caricate ma inattive fino al cambio pagina. I CSS comuni assoluti delle navigazioni successive non vengono riscritti o spostati, evitando anche il fotogramma senza grafica provocato dal riavvio di un foglio attivo. La sequenza finale corrisponde a quella dell’apertura diretta.

Due verifiche Chromium indipendenti a 390 e 1440 pixel: primo accesso senza refresh identico al caricamento diretto per i cinque fogli CSS e per proprietà calcolate di corpo pagina, testata, titolo, categorie, lista, piatti e prezzi. 13 categorie e 80 voci. Con CSS ritardato di 1,5–2 secondi la home rimane formattata finché il menu è pronto. Campionamenti rAF: 28 fotogrammi consecutivi corretti in una prova e 13/14 nelle verifiche indipendenti, senza passaggi agli stili predefiniti del browser. Ricerca, secondo accesso, Indietro/Avanti e lettore audio continuo funzionanti; nessun errore JavaScript.

La prova separata con API ritardata di 11 secondi conferma che l’interfaccia resta visibile e il JSON di riserva completa il menu dopo il timeout già previsto, senza bisogno di ricaricare. Non sono stati modificati i prezzi o il comportamento amministrativo.

## Browser e contenuti conservati

Chromium: home e raccolta verificati a 320×568, 390×844, 768×900, 900×900, 1280×900, 1440×900 e 1920×1080. Le 23 immagini caricano correttamente, mantengono le proporzioni e si aprono nella versione grande. Nessun overflow orizzontale. Verificati tastiera, Escape, ritorno del focus, espansione/riduzione della raccolta, contatori e gruppi separati (23 foto e 2 foto dell’atmosfera). Nessuna richiesta per le vecchie fotografie e nessun errore JavaScript.

Percorso home → menu → galleria nella home, Indietro/Avanti: stesso documento e stesso lettore audio in riproduzione, un solo visualizzatore. Anche `/galleria/` contiene le 23 nuove immagini. Menu pubblico senza fotografie. Il selettore di traduzione segue la home senza inviare frammenti.

Desktop 1440, senza user activation: intro animata autonoma di circa 4,1 secondi sia con movimento normale sia con movimento ridotto di sistema. Controllati nome/durata CSS e differenze reali tra fotogrammi del logo e della lucciola. Il logo della testata ruota con ciclo di 26 secondi prima e dopo la conclusione dell’intro. L’audio bloccato dal browser non impedisce la sequenza. Il primo fotogramma rimane coperto fino all’intro; salti e accessi diretti restano previsti. Registrata un’anteprima video su PC con preferenza di sistema ridotta e nessuna interazione. Senza la scelta esplicita `data-brand-motion="full"`, la variante di ripiego ridotta conserva il breve ingresso statico.

Lo sfondo desktop è a tutta larghezza con una composizione orizzontale nel primo fotogramma, sfumatura per il testo e spazio tra suggerimento iniziale e controllo musicale. Impostazioni e layout mobile approvati conservati.

## Limiti e pubblicazione

Nessun deploy Netlify eseguito. Gli archivi GitHub vanno pubblicati sull’hosting per modificare il sito online; le prove riguardano la build locale, non il browser effettivo dell’utente. Il difetto del menu è stato riprodotto e corretto nella build; non è stato ispezionato il browser personale dell’utente.

L’autoplay sonoro resta sotto il controllo del browser e il volume fisico del dispositivo sotto quello dell’ospite. La traduzione apre Google Translate in una nuova scheda; la resa remota, soprattutto dei contenuti dinamici, non è verificata da questo ambiente. Usare l’intera build aggiornata, senza mescolare asset di versioni diverse.

# Fotografie · Oro Nero 7.8

Il menu pubblico è senza fotografie, senza riquadri “Foto in arrivo” e senza ingrandimenti, come richiesto dall’utente. Anche la testata del menu non usa una foto. Nomi, descrizioni, prezzi, allergeni e abbinamenti restano disponibili.

Le fotografie già presenti rimangono nella homepage e nella galleria. Le nuove fotografie caricate dall’utente non sono ancora state importate: gli ZIP ricevuti superano il limite di trasferimento di 32 MiB. Servono foto singole o archivi sotto i 32 MB per poterle aggiungere progressivamente al sito.

## Dati fotografici nell’admin

I dati e i controlli fotografici preesistenti dell’admin sono conservati, ma la loro modifica non fa apparire foto nel menu pubblico. Questo evita di cancellare dati archiviati che potrebbero servire in futuro.

L’admin richiede il deploy completo Netlify con autenticazione, descritto in README_NETLIFY.md. Le immagini possono essere caricate dal dispositivo o associate tramite URL HTTPS; per rimuovere un’associazione si svuota il campo e si salva. Queste operazioni riguardano soltanto l’archivio, nella versione attuale.

`foto-piatti.csv` conserva il catalogo delle 80 voci e i nomi suggeriti per un’eventuale futura gestione fotografica. Non cambia l’aspetto testuale del menu.

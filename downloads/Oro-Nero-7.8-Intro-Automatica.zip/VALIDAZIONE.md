# Oro Nero 7.8.0 · Intro automatica

## Grafica conservata dalla versione 7.7

- Nuovo emblema trasparente PNG 1254 × 1254 pixel, ripulito dal riferimento originale con generazione d’immagine. Identità floreale intrecciata, cerchio e rombi conservati; il file è un’immagine raster ad alta risoluzione, non un SVG.
- Emblema coordinato in intro, testata, footer, icone e QR. Nessun ingrandimento del vecchio asset da circa 104 pixel e nessun ritaglio del nuovo marchio.
- Testata con solo emblema in lenta rotazione; nel footer e sul QR il nome è testo HTML nitido con i font del sito.
- Intro con simbolo iniziale più leggibile (circa 114 pixel mobile), rotazione di 48 gradi, ingrandimento progressivo, alone lieve e anello sottile. Singolo punto di luce con scia discreta; apertura a bordo morbido, senza le precedenti ali o il lampo ampio.
- Footer con gerarchia più ordinata, descrizione a 13 pixel, marchio proporzionato, separatori e griglia responsive. Spazio finale per i controlli fissi e pulsanti più rifiniti.

## Comportamento della versione 7.8

La sequenza visiva parte automaticamente, senza clic e senza attendere eventi del lettore audio: 3 secondi di rotazione e ingrandimento, seguiti da un’apertura di 1,1 secondi. La freccia salta sempre l’intro; × ed Escape mettono in pausa la musica e consentono l’ingresso silenzioso. Movimento ridotto, replay e protezione contro il lampo iniziale della homepage restano previsti.

L’intro e la copertura del primo fotogramma si attivano a ogni apertura completa o ricaricamento della homepage, ignorando gli indicatori di visita salvati dalle versioni precedenti. Il ritorno alla home tramite navigazione interna nello stesso documento non ripete automaticamente la sequenza; il replay rimane facoltativo. Movimento ridotto, link diretti con frammento e menu aperto dal QR mantengono il percorso senza intro.

Il tentativo di autoplay musicale avviene separatamente nella testata. Il browser può richiedere un’interazione per l’audio udibile; quel blocco non arresta l’intro. Traccia attenuata, volume del lettore al 70%, stesso elemento audio tra le pagine, titoli compatti e menu senza foto rimangono invariati. Nessuna modifica a nomi, prezzi, allergeni o dati del menu.

## Verifiche della versione 7.8

Node.js 22.23.4: build e controllo dei contenuti riusciti, 13 categorie e 80 voci. **73 test superati**, nessun fallimento o test saltato. Inclusi 18 test dell’intro e 8 del primo avvio, con regressioni per vecchi flag di sessione e ritorno interno alla homepage.

Chromium, senza clic, tocchi o tasti: osservazioni CDP con userGesture:false e navigator.userActivation.hasBeenActive=false. Intro attiva entro circa 0,3 secondi e completata entro circa 4,4 secondi sia con autoplay consentito sia con audio bloccato. Con MP3 ritardato di cinque secondi l’intro si avvia e si conclude autonomamente anche mentre il lettore è ancora in caricamento. Il permesso audio non controlla più la sequenza visiva.

Verificata una sessione con entrambi i vecchi flag di visita salvati: l’intro parte comunque senza interazione; dopo la conclusione, una ricarica completa la fa ripartire da sola. Tornando invece alla home dalla navigazione interna, il documento conserva il segnale di intro già mostrata e non ripete l’animazione.

I test coprono freccia sempre disponibile per saltare, ingresso silenzioso con × ed Escape, avvio precoce e passaggio della copertura senza lampo della homepage, movimento ridotto e replay. Riconfermata navigazione musicale continua su tutte le pagine, Indietro/Avanti, ricerca, Sommelier, prenotazione e stampa QR. Nessun errore JavaScript nelle prove funzionali.

Grafica di marchio e footer della versione 7.7 conservata: PNG trasparente da 1254 pixel, impaginazione verificata a 320, 390, 768 e 1440 pixel, descrizione footer a 13 pixel. Nessuna modifica al file audio attenuato o al volume del lettore.

## Pubblicazione

Nessun deploy Netlify eseguito. Gli archivi e le anteprime su GitHub devono essere pubblicati sull’hosting per aggiornare il sito online. Il browser mantiene il controllo sul permesso autoplay e l’ospite sul volume fisico del dispositivo. Usare l’intera build aggiornata, senza mescolare asset di versioni diverse.

-- SPDX-License-Identifier: GPL-3.0-only
-- Copyright (C) 2022-2026 ESX Framework

Config = {}

local txAdminLocale = GetConvar("txAdmin-locale", "en")
local esxLocale = GetConvar("esx:locale", "invalid")
Config.Locale = (esxLocale ~= "invalid") and esxLocale or (txAdminLocale ~= "custom" and txAdminLocale) or "en"

-- When a key is missing from the active locale, fall back to the English string
-- instead of returning a placeholder. Set convar "esx:localeFallback" to "false"
-- to keep the placeholder (useful when authoring a new translation).
Config.LocaleFallback = GetConvar("esx:localeFallback", "true") ~= "false"

-- For ox inventory, this will automatically be adjusted, do not change! For other inventories, leave as false unless specifically instructed to change.
Config.CustomInventory = false

-- Void is the survival currency. Keep the canonical ESX account name "money"
-- so existing getMoney/addMoney/removeMoney integrations continue to work.
Config.VoidCurrency = { Label = "Void" }

Config.Accounts = {
    bank = {
        label = TranslateCap("account_bank"),
        round = true,
        transferable = false,
    },
    money = {
        label = Config.VoidCurrency.Label,
        round = true,
    },
}

Config.StartingAccountMoney = { bank = 50000 }

Config.StartingInventoryItems = false -- table/false

-- Maximum absolute X, Y and Z for player positions. Increase this for custom maps outside the default world.
Config.PlayerCoordinateLimit = 10000.0

Config.DefaultSpawns = { -- If you want to have more spawn positions and select them randomly uncomment commented code or add more locations
    { x = 222.2027, y = -864.0162, z = 30.2922, heading = 1.0 },
    --{x = 224.9865, y = -865.0871, z = 30.2922, heading = 1.0},
    --{x = 227.8436, y = -866.0400, z = 30.2922, heading = 1.0},
    --{x = 230.6051, y = -867.1450, z = 30.2922, heading = 1.0},
    --{x = 233.5459, y = -868.2626, z = 30.2922, heading = 1.0}
}

---@deprecated Use `Config.CommandPermissions` as the single source of truth for command ACLs.
--- Kept temporarily for backwards compatibility with external resources that still read `Config.AdminGroups`.
--- Will be removed in ESX 1.15.
Config.AdminGroups = {
    ["owner"] = true,
    ["admin"] = true,
}

Config.CommandPermissions = {
    ["setcoords"]           = { "owner", "admin" }, -- /setcoords, /tp
    ["setjob"]              = { "owner", "admin" },
    ["car"]                 = { "owner", "admin" },
    ["cardel"]              = { "owner", "admin" }, -- /cardel, /dv
    ["fix"]                 = { "owner", "admin" }, -- /fix, /repair
    ["setaccountmoney"]     = { "owner", "admin" },
    ["giveaccountmoney"]    = { "owner", "admin" },
    ["removeaccountmoney"]  = { "owner", "admin" },
    ["giveitem"]            = { "owner", "admin" },
    ["giveweapon"]          = { "owner", "admin" },
    ["giveammo"]            = { "owner", "admin" },
    ["giveweaponcomponent"] = { "owner", "admin" },
    ["clearall"]            = { "owner", "admin" }, -- /clearall, /clsall
    ["refreshjobs"]         = { "owner", "admin" },
    ["refreshitems"]        = { "owner", "admin" },
    ["clearinventory"]      = { "owner", "admin" },
    ["clearloadout"]        = { "owner", "admin" },
    ["setgroup"]            = { "owner", "admin" },
    ["save"]                = { "owner", "admin" },
    ["saveall"]             = { "owner", "admin" },
    ["goto"]                = { "owner", "admin" },
    ["bring"]               = { "owner", "admin" },
    ["kill"]                = { "owner", "admin" },
    ["freeze"]              = { "owner", "admin" },
    ["unfreeze"]            = { "owner", "admin" },
    ["setdim"]              = { "owner", "admin" }, -- /setdim, /setbucket
    ["players"]             = { "owner", "admin" },
    ["noclip"]              = { "owner", "admin" },
    ["tpm"]                 = { "owner", "admin" },
    ["coords"]              = { "owner", "admin" },
    ["clear"]               = { "user", "admin", "owner" }, -- /clear, /cls
    ["group"]               = { "user", "admin", "owner" },
    ["job"]                 = { "user", "admin", "owner" },
    ["info"]                = { "user", "admin", "owner" },
    ["playtime"]            = { "user", "admin", "owner" },
}

Config.ValidCharacterSets = { -- Only enable additional charsets if your server is multilingual. By default everything is false.
    ['el'] = false, -- Greek
    ['sr'] = false, -- Cyrillic
    ['he'] = false, -- Hebrew
    ['ar'] = false, -- Arabic
    ['zh-cn'] = false -- Chinese, Japanese, Korean
}

Config.EnablePaycheck = true -- enable paycheck
Config.LogPaycheck = false -- Logs paychecks to a nominated Discord channel via webhook (default is false)
Config.EnableSocietyPayouts = false -- pay from the society account that the player is employed at? Requirement: esx_society
Config.MaxWeight = 24 -- the max inventory weight without a backpack
Config.PaycheckInterval = 7 * 60000 -- how often to receive paychecks in milliseconds
Config.PaycheckBatchSize = 100 -- how many players to pay before yielding the server thread
Config.PaycheckBatchDelay = 250 -- milliseconds to wait between paycheck batches
Config.PaycheckJitter = 30 * 1000 -- random delay added to each paycheck run to avoid synchronized bursts
Config.SaveDeathStatus = true -- Save the death status of a player
Config.EnableDebug = false -- Use Debug options?

Config.DefaultJobDuty = true -- A players default duty status when changing jobs
Config.OffDutyPaycheckMultiplier = 0.5 -- The multiplier for off duty paychecks. 0.5 = 50% of the on duty paycheck

Config.Multichar =true
Config.Identity = true -- Select a character identity data before they have loaded in (this happens by default with multichar)
Config.DistanceGive = 4.0 -- Max distance when giving items, weapons etc.

Config.AdminLogging = false -- Logs the usage of certain commands by those with group.admin ace permissions (default is false)

-------------------------------------
-- DO NOT CHANGE BELOW THIS LINE !!!
-------------------------------------
if GetResourceState("ox_inventory") ~= "missing" then
    Config.CustomInventory = "ox"
end

Config.EnableDefaultInventory = Config.CustomInventory == false -- Display the default Inventory ( F2 )
Config.Identifier = GetConvar("esx:identifier", "license")

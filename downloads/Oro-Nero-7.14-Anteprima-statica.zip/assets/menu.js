import { getTranslator } from './translation.js?v=7.14.0';

const translator = getTranslator(document, document.defaultView);
const state = { menu: null, category: "all", query: "", vegetarian: false };
let disposed = false;
const requests = new Set();
const timers = new Set();
let footerObserver;

function later(callback, delay) {
  const timer = setTimeout(() => {
    timers.delete(timer);
    if (!disposed) callback();
  }, delay);
  timers.add(timer);
  return timer;
}

export function cleanup() {
  disposed = true;
  document.removeEventListener('oronero:languagechange', onLanguageChange);
  requests.forEach((controller) => controller.abort());
  requests.clear();
  timers.forEach((timer) => clearTimeout(timer));
  timers.clear();
  footerObserver?.disconnect();
}

const euro = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" });
const shell = document.querySelector("#menu-sections");
const chips = document.querySelector("#category-chips");
const search = document.querySelector("#menu-search");
const veggie = document.querySelector("#vegetarian-filter");
const updated = document.querySelector("#menu-updated");
const wineShell = document.querySelector("#wine-list");
const tastingShell = document.querySelector("#degustation-list");
const eventShell = document.querySelector("#event-list");
const allergenUrl = new URL("../allergeni/", import.meta.url).href;
const fallbackMenuUrl = new URL("default-menu.json", import.meta.url).href;

async function fetchMenu(url) {
  if (disposed) throw new DOMException("Page closed", "AbortError");
  const controller = new AbortController();
  requests.add(controller);
  const timeout = later(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, { headers: { accept: "application/json" }, signal: controller.signal });
    if (!response.ok) throw new Error("Menu non disponibile");
    const menu = await response.json();
    if (disposed) throw new DOMException("Page closed", "AbortError");
    if (!menu || !Array.isArray(menu.categories)) throw new Error("Formato menu non valido");
    return menu;
  } finally {
    clearTimeout(timeout);
    timers.delete(timeout);
    requests.delete(controller);
  }
}

async function getMenu() {
  try {
    return await fetchMenu("/api/menu");
  } catch {
    if (disposed) throw new DOMException("Page closed", "AbortError");
    return fetchMenu(fallbackMenuUrl);
  }
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[character]);
}

function normalized(value = "") {
  return String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function formatPrice(value, emptyLabel = "Su richiesta") {
  if (value === null || value === undefined || value === "") return emptyLabel;
  return euro.format(Number(value));
}

function menuPrice(item) {
  if (item.price === null || item.price === undefined || item.price === "") return "—";
  const amount = euro.format(Number(item.price));
  if (item.priceSuffix === " da") return `da ${amount}`;
  return `${amount}${item.priceSuffix || ""}`;
}

function matches(item) {
  if (!item.visible) return false;
  if (state.vegetarian && !item.vegetarian) return false;
  if (!state.query) return true;
  return normalized(`${item.name} ${item.description || ""} ${translator.t(item.name)} ${translator.t(item.description || '')}`).includes(normalized(state.query));
}

function renderChips() {
  chips.innerHTML = [
    `<button class="chip active" data-category="all" type="button">Tutto</button>`,
    ...state.menu.categories.map((category) => `<button class="chip" data-category="${escapeHtml(category.id)}" type="button">${escapeHtml(category.title)}</button>`),
    `<a class="chip chip-link" href="#degustazioni">Degustazioni</a>`,
    `<a class="chip chip-link" href="#carta-vini">Carta vini</a>`,
  ].join("");
  chips.addEventListener("click", (event) => {
    const button = event.target.closest("[data-category]");
    if (!button) return;
    state.category = button.dataset.category;
    chips.querySelectorAll(".chip").forEach((chip) => chip.classList.toggle("active", chip === button));
    renderMenu();
  });
}

function renderMenu() {
  if (!state.menu) return;
  const categories = state.menu.categories.filter((category) => state.category === "all" || state.category === category.id);
  const html = categories.map((category) => {
    const items = category.items.filter(matches);
    if (!items.length) return "";
    return `
      <section class="menu-category" id="${escapeHtml(category.id)}">
        <header class="menu-category-heading">
          <p>${escapeHtml(category.eyebrow || "Oro Nero")}</p>
          <h2>${escapeHtml(category.title)}</h2>
          <span>${items.length} proposte</span>
        </header>
        <div class="menu-items menu-text-list">
          ${items.map((item) => `
            <article class="menu-item dish-card${item.featured ? " featured" : ""}">
              <div class="dish-card-body">
                <div class="dish-card-heading"><h3>${escapeHtml(item.name)}${item.vegetarian ? " <small>Vegetariano</small>" : ""}</h3><strong class="dish-price">${menuPrice(item)}</strong></div>
                ${item.description ? `<p class="dish-description">${escapeHtml(item.description)}</p>` : ""}
                <div class="dish-card-footer">${item.allergens?.length ? `<a class="allergen-link" href="${allergenUrl}" aria-label="Consulta gli allergeni di ${escapeHtml(item.name)}">Allergeni: ${item.allergens.join(", ")}</a>` : "<span></span>"}
                <button class="pairing-button" type="button" data-pairing="${escapeHtml(item.name)}">Abbina un vino</button></div>
              </div>
            </article>`).join("")}
        </div>
      </section>`;
  }).join("");
  shell.innerHTML = html || `<div class="empty-state"><h2>Nessun piatto trovato</h2><p>Prova a cambiare ricerca o filtro.</p></div>`;
  document.querySelectorAll("[data-pairing]").forEach((button) => button.addEventListener("click", () => openSommelier(`Cosa abbino a ${button.dataset.pairing}?`, true)));
}

function renderWines() {
  const wines = (state.menu.wines || []).filter((wine) => wine.visible);
  wineShell.innerHTML = wines.length ? wines.map((wine) => `
    <article class="wine-card">
      <div class="wine-card-top"><span>${escapeHtml(wine.type || "Vino")}</span>${wine.vintage ? `<strong>${escapeHtml(wine.vintage)}</strong>` : ""}</div>
      <h3>${escapeHtml(wine.name)}</h3>
      <p class="wine-producer">${escapeHtml([wine.producer, wine.region].filter(Boolean).join(" · "))}</p>
      ${wine.description ? `<p>${escapeHtml(wine.description)}</p>` : ""}
      <div class="wine-prices">
        ${wine.glassPrice !== null && wine.glassPrice !== undefined ? `<span>Calice <strong>${formatPrice(wine.glassPrice)}</strong></span>` : ""}
        ${wine.bottlePrice !== null && wine.bottlePrice !== undefined ? `<span>Bottiglia <strong>${formatPrice(wine.bottlePrice)}</strong></span>` : ""}
      </div>
      <button class="pairing-button" type="button" data-wine-question="${escapeHtml(wine.name)}">Con cosa lo abbino?</button>
    </article>`).join("") : `<p class="empty-state">La carta vini è in aggiornamento. Chiedi la selezione disponibile al personale.</p>`;
  document.querySelectorAll("[data-wine-question]").forEach((button) => button.addEventListener("click", () => openSommelier(`Con cosa posso abbinare ${button.dataset.wineQuestion}?`, true)));
}

function renderDegustations() {
  const degustations = (state.menu.degustations || []).filter((item) => item.visible);
  tastingShell.innerHTML = degustations.map((item) => `
    <article class="experience-card">
      <p>${escapeHtml(item.subtitle || "Esperienza Oro Nero")}</p>
      <h3>${escapeHtml(item.title)}</h3>
      <div>${escapeHtml(item.description || "")}</div>
      <strong>${formatPrice(item.price, "Prezzo su richiesta")}</strong>
      <button type="button" class="button button-gold" data-booking data-booking-note="${escapeHtml(item.title)}">Richiedi il percorso</button>
    </article>`).join("");
}

function renderEvents() {
  const events = (state.menu.events || []).filter((item) => item.visible);
  eventShell.innerHTML = events.map((item) => `
    <article class="event-card">
      <p>${escapeHtml(item.dateText || "In aggiornamento")}</p>
      <h3>${escapeHtml(item.title)}</h3>
      <div>${escapeHtml(item.description || "")}</div>
      <button type="button" class="text-link" data-booking data-booking-note="${escapeHtml(item.title)}">Chiedi informazioni →</button>
    </article>`).join("");
}

search.addEventListener("input", () => { state.query = search.value; renderMenu(); });
veggie.addEventListener("change", () => { state.vegetarian = veggie.checked; renderMenu(); });
function onLanguageChange() {
  if (!disposed && state.menu) {
    renderMenu();
    translator.refresh();
  }
}
document.addEventListener('oronero:languagechange', onLanguageChange);

const dialog = document.querySelector("#sommelier-dialog");
const launcher = document.querySelector(".sommelier-launcher");
const closeButton = document.querySelector("#sommelier-close");
const form = document.querySelector("#sommelier-form");
const input = document.querySelector("#sommelier-input");
const messages = document.querySelector("#sommelier-messages");

function winePrice(wine) {
  const prices = [];
  if (wine.glassPrice !== null && wine.glassPrice !== undefined) prices.push(`calice ${formatPrice(wine.glassPrice)}`);
  if (wine.bottlePrice !== null && wine.bottlePrice !== undefined) prices.push(`bottiglia ${formatPrice(wine.bottlePrice)}`);
  return prices.length ? ` (${prices.join(", ")})` : "";
}

function requestedBudget(text) {
  const query = normalized(text);
  const budgetMatch = query.match(/(?:entro|budget|massimo|fino a)?\s*(\d{1,3})\s*(?:€|euro)/);
  return budgetMatch ? Number(budgetMatch[1]) : null;
}

function wineRecommendations(text) {
  const query = normalized(text);
  const budget = requestedBudget(text);
  const intent = [];
  if (/crudo|tartare|cappesant|vongol|raw|scallop|clam|roh|jakobsmuschel|palourde|coquille|crudo|almeja/.test(query)) intent.push("crudi", "pesce");
  if (/fritt|calamar|gamber|fried|shrimp|prawn|frittiert|garnele|friture|crevette|frito|gamba/.test(query)) intent.push("frittura", "pesce");
  if (/pesce|mare|scamp|orata|tonno|merluzzo|triglia|fish|seafood|fisch|meeres|poisson|pescado|marisco/.test(query)) intent.push("pesce");
  if (/manzo|filetto|roast|carne|fiorentina|maiale|faraona|beef|meat|pork|rind|fleisch|schwein|viande|boeuf|porc|ternera|cerdo/.test(query)) intent.push("carne", "manzo");
  if (/veget|tofu|ceci|pesto|verdure|chickpea|gemuse|kichererbse|legume|pois chiche|verdura|garbanzo/.test(query)) intent.push("vegetariano");
  if (/dolce|dessert|tiramisu|profiterol|torta|sweet|cake|kuchen|nachtisch|gateau|postre|dulce/.test(query)) intent.push("dessert");
  if (/aperitivo|spritz|aperitif/.test(query)) intent.push("aperitivo");

  const allVisible = (state.menu?.wines || []).filter((wine) => wine.visible);
  const withinBudget = budget === null ? allVisible : allVisible.filter((wine) => {
    const relevantPrice = /calice|glass|glas|verre|copa/.test(query) ? wine.glassPrice : wine.bottlePrice ?? wine.glassPrice;
    return relevantPrice !== null && relevantPrice !== undefined && Number(relevantPrice) <= budget;
  });
  const visible = withinBudget;
  const scored = visible.map((wine) => {
    const haystack = normalized(`${wine.name} ${wine.producer || ""} ${wine.type || ""} ${(wine.pairings || []).join(" ")}`);
    const score = intent.reduce((total, tag) => total + (haystack.includes(normalized(tag)) ? 2 : 0), 0) + (query.includes(normalized(wine.name)) ? 5 : 0);
    return { wine, score };
  }).sort((a, b) => b.score - a.score);
  const selected = (scored.some((entry) => entry.score > 0) ? scored.filter((entry) => entry.score > 0) : scored).slice(0, 2).map((entry) => entry.wine);
  return selected;
}

function reply(text) {
  const query = normalized(text);
  const namedWine = (state.menu?.wines || []).find((wine) => wine.visible && (query.includes(normalized(wine.name)) || query.includes(normalized(translator.t(wine.name)))));
  if (namedWine) {
    const pairings = (namedWine.pairings || []).slice(0, 4).join(", ");
    return `${namedWine.name}${winePrice(namedWine)} è indicato con ${pairings || "i piatti consigliati dalla sala"}. Chiedi al personale quale portata del giorno lo valorizza meglio.`;
  }
  const selected = wineRecommendations(text);
  if (!selected.length && requestedBudget(text) !== null && (state.menu?.wines || []).some((wine) => wine.visible)) {
    return `Non ho trovato etichette disponibili entro il budget di ${formatPrice(requestedBudget(text))}. Chiedi alla sala un’alternativa oppure indica un altro budget.`;
  }
  if (!selected.length) return "La carta vini è in aggiornamento. Comunica il piatto e il budget alla sala per ricevere la proposta del giorno.";
  const suggestions = selected.map((wine) => `${wine.name}${winePrice(wine)}`).join(" oppure ");
  return `Dalla carta Oro Nero ti consiglio ${suggestions}. La disponibilità dell’etichetta viene confermata dalla sala.`;
}

function bubble(role, text) {
  const element = document.createElement("p");
  element.className = `sommelier-message ${role}`;
  if (role === 'user') element.setAttribute('translate', 'no');
  element.textContent = text;
  messages.append(element);
  messages.scrollTop = messages.scrollHeight;
}

function openSommelier(prompt = "", generatedPrompt = false) {
  if (disposed) return;
  if (!dialog.open) {
    try {
      dialog.showModal();
    } catch {
      dialog.setAttribute("open", "");
    }
  }
  document.body.classList.add("dialog-open");
  if (prompt) {
    bubble("user", generatedPrompt ? translator.t(prompt) : prompt);
    later(() => bubble("assistant", reply(prompt)), 280);
  }
  later(() => input.focus(), 50);
}

launcher.addEventListener("click", () => openSommelier());
closeButton.addEventListener("click", () => dialog.close());
dialog.addEventListener("close", () => document.body.classList.remove("dialog-open"));
dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); });
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  bubble("user", text);
  input.value = "";
  later(() => bubble("assistant", reply(text)), 320);
});

const footer = document.querySelector("#site-footer");
if (footer) {
  footerObserver = new IntersectionObserver(
    ([entry]) => launcher.classList.toggle("footer-near", entry.isIntersecting),
    { rootMargin: "0px 0px 80px 0px", threshold: 0.01 },
  );
  footerObserver.observe(footer);
}

getMenu()
  .then((menu) => {
    if (disposed) return;
    if (!menu || !Array.isArray(menu.categories)) throw new Error("Formato menu non valido");
    state.menu = menu;
    renderChips();
    renderMenu();
    renderWines();
    renderDegustations();
    renderEvents();
    document.dispatchEvent(new CustomEvent("oronero:dynamic-content"));
    const date = menu.updatedAt ? new Date(menu.updatedAt) : null;
    updated.textContent = date && !Number.isNaN(date.valueOf()) ? `Aggiornato il ${date.toLocaleDateString("it-IT")}` : "Prezzi aggiornati";
  })
  .catch(() => {
    if (disposed) return;
    shell.innerHTML = `<div class="empty-state"><h2>Menu momentaneamente non disponibile</h2><p>Riprova tra qualche istante oppure contatta Oro Nero.</p></div>`;
    updated.textContent = "Caricamento non riuscito";
  });

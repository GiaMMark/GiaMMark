import { getTranslator } from './translation.js?v=7.14.0';

const CONTROLLER = Symbol.for('oronero.languages.controller');
const LANGUAGES = [
  { code: 'it', name: 'Italiano', label: 'Italiano' },
  { code: 'en', name: 'English', label: 'Inglese' },
  { code: 'de', name: 'Deutsch', label: 'Tedesco' },
  { code: 'fr', name: 'Français', label: 'Francese' },
  { code: 'es', name: 'Español', label: 'Spagnolo' },
];
const COPY = {
  it: { title: 'Scegli la tua lingua.', note: 'La lingua cambia direttamente sul sito. Sono disponibili italiano, inglese, tedesco, francese e spagnolo.', search: 'Cerca una lingua / Find a language', close: 'Chiudi il selettore delle lingue', loading: 'Caricamento della lingua…', error: 'Impossibile caricare la lingua. Riprova oppure continua nella lingua attuale.', empty: 'Nessuna lingua trovata.', foot: 'I contenuti non ancora tradotti restano in italiano.', private: 'La traduzione è disponibile nelle pagine pubbliche. L’area amministrativa resta in italiano.' },
  en: { title: 'Choose your language.', note: 'The language changes here on the site. Italian, English, German, French and Spanish are available.', search: 'Find a language / Cerca una lingua', close: 'Close language selection', loading: 'Loading language…', error: 'The language could not be loaded. Try again or continue in the current language.', empty: 'No language found.', foot: 'Content without a translation remains in Italian.', private: 'Translation is available on public pages. The administration area stays in Italian.' },
  de: { title: 'Wählen Sie Ihre Sprache.', note: 'Die Sprache ändert sich direkt auf der Website. Italienisch, Englisch, Deutsch, Französisch und Spanisch sind verfügbar.', search: 'Sprache suchen / Find a language', close: 'Sprachauswahl schließen', loading: 'Sprache wird geladen…', error: 'Die Sprache konnte nicht geladen werden. Versuchen Sie es erneut oder nutzen Sie die aktuelle Sprache.', empty: 'Keine Sprache gefunden.', foot: 'Noch nicht übersetzte Inhalte bleiben auf Italienisch.', private: 'Übersetzungen sind auf öffentlichen Seiten verfügbar. Der Verwaltungsbereich bleibt auf Italienisch.' },
  fr: { title: 'Choisissez votre langue.', note: 'La langue change directement sur le site. L’italien, l’anglais, l’allemand, le français et l’espagnol sont disponibles.', search: 'Rechercher une langue / Find a language', close: 'Fermer le choix de langue', loading: 'Chargement de la langue…', error: 'Impossible de charger la langue. Réessayez ou continuez dans la langue actuelle.', empty: 'Aucune langue trouvée.', foot: 'Les contenus non encore traduits restent en italien.', private: 'La traduction est disponible sur les pages publiques. L’administration reste en italien.' },
  es: { title: 'Elige tu idioma.', note: 'El idioma cambia directamente en el sitio. Están disponibles italiano, inglés, alemán, francés y español.', search: 'Buscar un idioma / Find a language', close: 'Cerrar la selección de idioma', loading: 'Cargando el idioma…', error: 'No se pudo cargar el idioma. Vuelve a intentarlo o continúa en el idioma actual.', empty: 'No se ha encontrado ningún idioma.', foot: 'Los contenidos aún no traducidos permanecen en italiano.', private: 'La traducción está disponible en las páginas públicas. La administración permanece en italiano.' },
};
const normalize = (text) => String(text).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

export function setupLanguages(doc = document, win = window, options = {}) {
  const existing = doc.querySelector('#language-dialog');
  if (existing?.[CONTROLLER]) return existing[CONTROLLER];
  const translator = getTranslator(doc, win, options);
  const dialog = doc.createElement('dialog');
  dialog.id = 'language-dialog';
  dialog.className = 'language-dialog';
  dialog.setAttribute('translate', 'no');
  dialog.setAttribute('aria-labelledby', 'language-title');
  dialog.setAttribute('aria-describedby', 'language-note');
  dialog.innerHTML = [
    '<div class="language-panel">',
    '<header class="language-head"><div><p>Lingua / Language</p><h2 id="language-title"></h2></div><button type="button" class="language-close" data-language-close>×</button></header>',
    '<p class="language-note" id="language-note"></p>',
    '<p class="language-unavailable" data-language-unavailable hidden></p>',
    '<label class="language-search"><span data-language-search-label></span><input type="search" data-language-search autocomplete="off" spellcheck="false" placeholder="Italiano, English, Deutsch…" aria-controls="language-results"></label>',
    '<p class="language-count" data-language-status role="status" aria-live="polite"></p>',
    '<ul class="language-list" id="language-results" data-language-results></ul>',
    '<p class="language-empty" data-language-empty hidden></p>',
    '<footer class="language-foot"></footer>',
    '</div>',
  ].join('');
  doc.body.append(dialog);
  const input = dialog.querySelector('[data-language-search]');
  const results = dialog.querySelector('[data-language-results]');
  const status = dialog.querySelector('[data-language-status]');
  const empty = dialog.querySelector('[data-language-empty]');
  const notice = dialog.querySelector('[data-language-unavailable]');
  let opener;
  let alive = true;
  let returnFocus = true;
  let busy = false;
  let failed = false;
  let selection = 0;
  const controls = () => doc.querySelectorAll('[data-language-open]');
  const syncControls = (open) => controls().forEach((button) => {
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', dialog.id);
    button.setAttribute('aria-expanded', String(open));
  });
  const render = () => {
    if (!alive) return;
    const copy = COPY[translator.locale] || COPY.it;
    const available = translator.available;
    dialog.lang = available ? translator.locale : 'it';
    dialog.querySelector('#language-title').textContent = copy.title;
    dialog.querySelector('#language-note').textContent = copy.note;
    dialog.querySelector('[data-language-close]').setAttribute('aria-label', copy.close);
    dialog.querySelector('[data-language-search-label]').textContent = copy.search;
    dialog.querySelector('.language-foot').textContent = copy.foot;
    empty.textContent = copy.empty;
    notice.hidden = available;
    notice.textContent = available ? '' : copy.private;
    status.textContent = busy ? copy.loading : failed ? copy.error : '';
    status.classList.toggle('language-error', failed);
    dialog.setAttribute('aria-busy', String(busy));
    const query = normalize(input.value);
    const shown = LANGUAGES.filter((entry) => !query || normalize([entry.code, entry.name, entry.label].join(' ')).includes(query));
    results.replaceChildren();
    for (const entry of shown) {
      const item = doc.createElement('li');
      const button = doc.createElement('button');
      button.type = 'button';
      button.className = 'language-choice';
      button.dataset.translationCode = entry.code;
      button.disabled = busy || !available;
      button.setAttribute('aria-pressed', String(entry.code === translator.locale));
      const name = doc.createElement('strong'); name.textContent = entry.name; name.lang = entry.code;
      const label = doc.createElement('span'); label.textContent = entry.label; label.lang = 'it';
      const code = doc.createElement('small'); code.textContent = entry.code.toUpperCase();
      button.append(name, label, code);
      item.append(button); results.append(item);
    }
    empty.hidden = shown.length !== 0;
  };
  const focusBack = () => {
    if (!alive) return;
    doc.body.classList.remove('language-open');
    syncControls(false);
    if (returnFocus) (opener?.isConnected ? opener : doc.querySelector('[data-language-open]'))?.focus({ preventScroll: true });
  };
  const close = (focus = true) => {
    returnFocus = focus;
    if (dialog.open && typeof dialog.close === 'function') {
      try { dialog.close(); } catch { dialog.removeAttribute('open'); focusBack(); }
    } else { dialog.removeAttribute('open'); focusBack(); }
  };
  const open = (trigger) => {
    if (!alive) return;
    doc.querySelector('.nav-toggle[aria-expanded="true"]')?.click();
    opener = trigger || doc.activeElement;
    returnFocus = true;
    input.value = '';
    failed = false;
    translator.refresh(); render();
    if (!dialog.open) {
      try { dialog.showModal(); } catch { dialog.setAttribute('open', ''); }
    }
    doc.body.classList.add('language-open'); syncControls(true);
    input.focus({ preventScroll: true });
  };
  const choose = async (code) => {
    if (busy || !translator.available) return;
    const token = ++selection;
    busy = true; failed = false; render();
    try {
      await translator.setLanguage(code);
      if (!alive || token !== selection) return;
      busy = false; render(); close();
    } catch (error) {
      if (!alive || token !== selection) return;
      busy = false;
      failed = error.name !== 'AbortError';
      render();
      dialog.querySelector(`[data-translation-code="${code}"]`)?.focus({ preventScroll: true });
    }
  };
  const onDocumentClick = (event) => {
    const trigger = event.target.closest?.('[data-language-open]');
    if (trigger) { event.preventDefault(); open(trigger); }
  };
  const onDialogClick = (event) => {
    if (event.target === dialog || event.target.closest?.('[data-language-close]')) { close(); return; }
    const choice = event.target.closest?.('[data-translation-code]');
    if (choice && !choice.disabled) { event.preventDefault(); void choose(choice.dataset.translationCode); }
  };
  const onCancel = (event) => { event.preventDefault(); close(); };
  const onChange = () => { render(); };
  doc.addEventListener('click', onDocumentClick);
  doc.addEventListener('oronero:languagechange', onChange);
  input.addEventListener('input', render);
  dialog.addEventListener('click', onDialogClick);
  dialog.addEventListener('cancel', onCancel);
  dialog.addEventListener('close', focusBack);
  syncControls(false); render();
  translator.ready.then(() => { if (alive) render(); });

  const controller = { dialog, translator, open, close, destroy() {
    alive = false; selection++;
    close(false);
    doc.body.classList.remove('language-open'); syncControls(false);
    doc.removeEventListener('click', onDocumentClick);
    doc.removeEventListener('oronero:languagechange', onChange);
    input.removeEventListener('input', render);
    dialog.removeEventListener('click', onDialogClick);
    dialog.removeEventListener('cancel', onCancel);
    dialog.removeEventListener('close', focusBack);
    delete dialog[CONTROLLER]; dialog.remove();
    // The document's translator and the persistent music player survive SPA swaps.
  } };
  dialog[CONTROLLER] = controller;
  return controller;
}

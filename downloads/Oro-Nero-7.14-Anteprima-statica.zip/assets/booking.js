/** Native HTTPS submission keeps the provider's spam verification enabled. */
export function setupBookingForm(form, { translate = (text) => text, now = () => new Date() } = {}) {
  const date = form.elements.namedItem('date');
  const status = form.querySelector('#booking-status');
  const fallback = form.querySelector('[data-booking-email]');
  const updateDate = () => {
    const today = now();
    date.min = new Date(today.getTime() - today.getTimezoneOffset() * 60_000).toISOString().slice(0, 10);
  };
  updateDate();

  form.addEventListener('submit', (event) => {
    updateDate();
    if (!form.reportValidity() || form.elements.namedItem('_honey').value.trim()) {
      event.preventDefault();
      return;
    }
    // Let the browser POST to FormSubmit. Do not announce delivery on a local event.
    status.textContent = translate('Completa la verifica nella pagina appena aperta. Attendi la nostra risposta per la conferma del tavolo.');
    status.hidden = false;
  });

  fallback.addEventListener('click', () => {
    const value = (name) => form.elements.namedItem(name)?.value.trim() || '';
    const body = [
      'Ciao Oro Nero, vorrei richiedere una prenotazione:',
      `Nome: ${value('name')}`,
      `Email: ${value('email')}`,
      `Telefono: ${value('phone')}`,
      `Persone: ${value('guests')}`,
      `Data: ${value('date')}`,
      `Ora: ${value('time')}`,
      `Note: ${value('notes')}`,
    ].join('\n');
    fallback.href = `mailto:alphascript24@gmail.com?subject=${encodeURIComponent('Richiesta dal sito · Oro Nero')}&body=${encodeURIComponent(body)}`;
  });
}

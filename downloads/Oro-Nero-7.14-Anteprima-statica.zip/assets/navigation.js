/** Swap local pages while the same, connected audio element keeps playing. */
const PAGE_NAMES = new Set(['', 'menu', 'galleria', 'allergeni', 'recensioni', 'privacy', 'qr', 'admin']);
const PAGE_MODULES = new Set(['menu.js', 'admin.js', 'qr.js']);

export function isSitePage(url, root) {
  if (url.origin !== root.origin || !url.pathname.startsWith(root.pathname)) return false;
  const path = url.pathname.slice(root.pathname.length).replace(/index\.html$/, '').replace(/\/$/, '');
  return PAGE_NAMES.has(path);
}

export function setupNavigation({ initialize, cleanup, root = new URL('../', import.meta.url), doc = document, win = window, loadModule = (url) => import(url) } = {}) {
  if (root.origin !== win.location.origin || win.__oroneroNavigation) return null;
  const fetchPage = win.fetch?.bind(win) || globalThis.fetch;
  const parser = new win.DOMParser();
  let currentUrl = new URL(win.location.href);
  let currentKey = win.history.state?.oroneroKey || `page-${Date.now()}`;
  let sequence = 0;
  let request;
  let disposed = false;
  let hashCleanup = () => {};
  let routeModules = pageModuleUrls(doc, currentUrl).map((url) => ({ url, namespace: null }));
  const positions = new Map();
  const previousRestoration = win.history.scrollRestoration;
  win.history.scrollRestoration = 'manual';
  win.history.replaceState({ ...win.history.state, oroneroKey: currentKey }, '', currentUrl);

  function pageModuleUrls(page, base) {
    return [...page.querySelectorAll('script[type="module"][src]')].map((script) => new URL(script.getAttribute('src'), base)).filter((url) => url.origin === root.origin && url.pathname.startsWith(root.pathname + 'assets/') && PAGE_MODULES.has(url.pathname.split('/').at(-1))).map((url) => url.href);
  }
  function rememberScroll() { positions.set(currentKey, [win.scrollX, win.scrollY]); }
  function scrollToPage(url, position, focus = true) {
    hashCleanup();
    const scroll = () => {
      let target;
      try { target = url.hash ? doc.getElementById(decodeURIComponent(url.hash.slice(1))) : null; } catch { /* Invalid fragments are harmless. */ }
      if (focus) {
        const focusTarget = target || doc.querySelector('main');
        if (focusTarget) {
          const hadTabindex = focusTarget.hasAttribute('tabindex');
          if (!hadTabindex) focusTarget.setAttribute('tabindex', '-1');
          focusTarget.focus({ preventScroll: true });
          if (!hadTabindex) focusTarget.removeAttribute('tabindex');
        }
      }
      if (position) win.scrollTo(...position);
      else if (target) target.scrollIntoView();
      else win.scrollTo(0, 0);
      return Boolean(target);
    };
    if (scroll() || !url.hash || position) return;
    // A category can arrive after the menu's JSON request.
    const onContent = () => { if (scroll()) hashCleanup(); };
    doc.addEventListener('oronero:dynamic-content', onContent);
    const timer = win.setTimeout(() => hashCleanup(), 10000);
    hashCleanup = () => { doc.removeEventListener('oronero:dynamic-content', onContent); win.clearTimeout(timer); hashCleanup = () => {}; };
  }
  function updateHistory(url, pop) {
    if (!pop) {
      currentKey = `page-${Date.now()}-${sequence}`;
      win.history.pushState({ oroneroKey: currentKey }, '', url);
    } else currentKey = win.history.state?.oroneroKey || `page-${Date.now()}-${sequence}`;
    currentUrl = new URL(url);
  }
  function makeAbsolute(page, base) {
    for (const element of page.body.querySelectorAll('[href], [src], [action], [poster]')) {
      for (const attr of ['href', 'src', 'action', 'poster']) {
        if (element.hasAttribute(attr)) element.setAttribute(attr, new URL(element.getAttribute(attr), base).href);
      }
    }
    for (const element of page.body.querySelectorAll('[srcset]')) {
      element.setAttribute('srcset', element.getAttribute('srcset').split(',').map((part) => {
        const [src, ...descriptor] = part.trim().split(/\s+/);
        return [new URL(src, base).href, ...descriptor].join(' ');
      }).join(', '));
    }
  }
  async function prepareStyles(page, base, signal) {
    if (signal.aborted) throw new Error('Navigation superseded');
    const desired = [...page.head.querySelectorAll('link[rel="stylesheet"]')].map((link) => ({ source: link, href: new URL(link.getAttribute('href'), base).href }));
    // Snapshot URLs before history changes. Rewriting or moving an active link
    // can unload its CSS for a frame, even when the final absolute URL is equal.
    const existing = [...doc.head.querySelectorAll('link[rel="stylesheet"]')].filter((link) => !link.hasAttribute('data-navigation-style-pending')).map((link) => ({ link, href: link.href }));
    const retained = new Set();
    let previousIndex = -1;
    const prepared = desired.map(({source, href}) => {
      const media = source.getAttribute('media');
      const index = existing.findIndex((entry, index) => index > previousIndex && !retained.has(entry.link) && entry.href === href && entry.link.getAttribute('href') === href && entry.link.getAttribute('media') === media);
      if (index !== -1) {
        previousIndex = index;
        const link = existing[index].link;
        retained.add(link);
        return { link, media, added: false };
      }
      // Relative initial links need ready absolute copies before pushState can
      // rebase their URLs. Keep the originals active while those copies load.
      const link = doc.importNode(source, true);
      link.href = href;
      link.media = 'not all';
      link.setAttribute('data-navigation-style-pending', '');
      return { link, media, added: true };
    });
    const added = prepared.filter((entry) => entry.added);
    const cancellations = [];
    try {
      await Promise.all(added.map(({link}) => new Promise((resolve, reject) => {
        let timer;
        let settled = false;
        const done = (error) => {
          if (settled) return;
          settled = true;
          win.clearTimeout(timer);
          signal.removeEventListener('abort', abort);
          link.onload = link.onerror = null;
          error ? reject(error) : resolve();
        };
        const abort = () => done(new Error('Navigation superseded'));
        cancellations.push(abort);
        signal.addEventListener('abort', abort, { once: true });
        link.onload = () => done();
        link.onerror = () => done(new Error('Page stylesheet unavailable'));
        timer = win.setTimeout(() => done(new Error('Page stylesheet timed out')), 10000);
        // Stage at the final cascade position while inactive; loaded links must
        // never be removed/reinserted when the destination becomes visible.
        const index = prepared.findIndex((entry) => entry.link === link);
        const nextRetained = prepared.slice(index + 1).find((entry) => !entry.added);
        doc.head.insertBefore(link, nextRetained?.link || null);
      })));
    } catch (error) {
      cancellations.forEach((cancel) => cancel());
      added.forEach(({link}) => link.remove());
      throw error;
    }
    return { commit: () => {
      for (const {link, media} of added) {
        if (media === null) link.removeAttribute('media');
        else link.media = media;
        link.removeAttribute('data-navigation-style-pending');
      }
      existing.filter(({link}) => !retained.has(link)).forEach(({link}) => link.remove());
    }, rollback: () => added.forEach(({link}) => link.remove()) };
  }
  function updateHead(page, base) {
    doc.title = page.title;
    const selector = 'meta[name], meta[property], link[rel="canonical"], script[type="application/ld+json"]';
    doc.head.querySelectorAll(selector).forEach((node) => node.remove());
    page.head.querySelectorAll(selector).forEach((source) => {
      const node = doc.importNode(source, true);
      if (node.hasAttribute('href')) node.setAttribute('href', new URL(node.getAttribute('href'), base).href);
      doc.head.append(node);
    });
    doc.documentElement.lang = page.documentElement.lang || 'it';
  }
  async function releaseRoute() {
    const old = routeModules;
    routeModules = [];
    for (const entry of old) {
      const namespace = entry.namespace || await loadModule(entry.url);
      namespace.cleanup?.();
    }
  }
  async function navigate(target, { pop = false } = {}) {
    const url = new URL(target, win.location.href);
    if (!isSitePage(url, root)) return false;
    const token = ++sequence;
    request?.abort();
    request = new win.AbortController();
    const controller = request;
    const signal = controller.signal;
    rememberScroll();
    if (url.pathname === currentUrl.pathname && url.search === currentUrl.search) {
      updateHistory(url, pop);
      scrollToPage(url, pop ? positions.get(currentKey) : null);
      doc.documentElement.removeAttribute('aria-busy');
      return true;
    }
    const timeout = win.setTimeout(() => controller.abort(), 15000);
    doc.documentElement.setAttribute('aria-busy', 'true');
    try {
      const response = await fetchPage(url.href, { signal, headers: { accept: 'text/html' }, credentials: 'same-origin' });
      if (!response.ok || !response.headers.get('content-type')?.includes('text/html')) throw new Error('Page unavailable');
      const page = parser.parseFromString(await response.text(), 'text/html');
      if (!page.querySelector('main') || !page.querySelector('site-header')) throw new Error('Not a site page');
      const finalUrl = new URL(response.url || url.href);
      if (!isSitePage(finalUrl, root)) throw new Error('Unexpected redirect');
      finalUrl.hash = url.hash;
      const scripts = pageModuleUrls(page, finalUrl);
      makeAbsolute(page, finalUrl);
      page.body.querySelectorAll('script').forEach((script) => script.remove());
      const finishStyles = await prepareStyles(page, finalUrl, signal);
      if (disposed || token !== sequence || signal.aborted) { finishStyles.rollback(); return false; }
      await releaseRoute();
      if (disposed || token !== sequence || signal.aborted) { finishStyles.rollback(); return false; }
      cleanup?.();
      // Install ready CSS before changing the URL: relative outgoing links must
      // be retired before pushState can resolve them against a new directory.
      finishStyles.commit();
      // Preserve the live audio node in-place: even removing and re-appending it
      // can interrupt decoding in a browser. Keep the body itself, too.
      for (const node of [...doc.body.childNodes]) {
        if (node.nodeType === 1 && node.matches('[data-persistent-audio], [data-music-control]')) continue;
        node.remove();
      }
      updateHistory(finalUrl, pop);
      doc.body.className = page.body.className;
      updateHead(page, finalUrl);
      const fragment = doc.createDocumentFragment();
      for (const node of [...page.body.childNodes]) fragment.append(doc.importNode(node, true));
      doc.body.insertBefore(fragment, doc.body.firstChild);
      initialize?.();
      for (const source of scripts) {
        const moduleUrl = new URL(source);
        moduleUrl.searchParams.set('navigation', String(token));
        const entry = { url: moduleUrl.href, namespace: null };
        routeModules.push(entry);
        entry.namespace = await loadModule(entry.url);
        if (disposed || token !== sequence) { entry.namespace.cleanup?.(); return false; }
      }
      scrollToPage(finalUrl, pop ? positions.get(currentKey) : null);
      doc.dispatchEvent(new win.CustomEvent('oronero:navigation', { detail: { url: finalUrl.href } }));
      return true;
    } catch (error) {
      if (!disposed && token === sequence) win.location.assign(url.href);
      return false;
    } finally {
      win.clearTimeout(timeout);
      if (token === sequence) doc.documentElement.removeAttribute('aria-busy');
    }
  }
  const onClick = (event) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const anchor = event.target.closest?.('a[href]');
    if (!anchor || anchor.hasAttribute('download') || anchor.hasAttribute('data-native-navigation') || (anchor.target && anchor.target !== '_self')) return;
    const url = new URL(anchor.href, win.location.href);
    if (!isSitePage(url, root)) return;
    event.preventDefault();
    void navigate(url);
  };
  const onPop = () => { void navigate(win.location.href, { pop: true }); };
  doc.addEventListener('click', onClick);
  win.addEventListener('popstate', onPop);
  const controller = { navigate, destroy() {
    disposed = true;
    request?.abort();
    hashCleanup();
    doc.removeEventListener('click', onClick);
    win.removeEventListener('popstate', onPop);
    win.history.scrollRestoration = previousRestoration;
    delete win.__oroneroNavigation;
  } };
  win.__oroneroNavigation = controller;
  return controller;
}

import { setupArrival } from "./arrival.js?v=7.14.0";
import { setupMusic } from "./music.js?v=7.14.0";
import { setupNavigation } from "./navigation.js?v=7.14.0";
import { setupLanguages } from "./languages.js?v=7.14.0";
import { getTranslator } from "./translation.js?v=7.14.0";
import { setupBookingForm } from "./booking.js?v=7.14.0";

const siteRoot = new URL("../", import.meta.url);
const siteUrl = (path = "") => new URL(path, siteRoot).href;

const instagram = "https://www.instagram.com/oronero_bistrot_chioggia/";
const facebook = "https://www.facebook.com/chefmanueldepasquale/";
const tripadvisor = "https://www.tripadvisor.it/Restaurant_Review-g194738-d28053942-Reviews-OroNero-Chioggia_Veneto.html";
const maps = "https://maps.google.com/?q=Calle+Vianelli+1011+Chioggia";
const whatsappNumber = "393442865877";
const whatsapp = `https://wa.me/${whatsappNumber}`;

const socialProfiles = [
  { id: "instagram", name: "Instagram", handle: "@oronero_bistrot_chioggia", action: "Guarda le foto", href: instagram },
  { id: "facebook", name: "Facebook", handle: "Oro Nero · Chioggia", action: "Segui gli aggiornamenti", href: facebook },
  { id: "tripadvisor", name: "Tripadvisor", handle: "Le recensioni degli ospiti", action: "Leggi le recensioni", href: tripadvisor },
  { id: "whatsapp", name: "WhatsApp", handle: "+39 344 286 5877", action: "Scrivici ora", href: whatsapp },
];

function brandIcon(name) {
  const icons = {
    instagram: `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4.25"/><circle class="icon-fill" cx="17.35" cy="6.75" r="1.15"/></svg>`,
    facebook: `<svg viewBox="0 0 24 24" aria-hidden="true"><path class="icon-fill" d="M13.8 22v-8h2.75l.42-3.16H13.8V8.82c0-.92.26-1.54 1.59-1.54h1.69V4.45a22.6 22.6 0 0 0-2.47-.13c-2.44 0-4.11 1.49-4.11 4.22v2.3H7.74V14h2.76v8h3.3Z"/></svg>`,
    tripadvisor: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.1 8.05C7 6.85 9.35 6.2 12 6.2s5 .65 6.9 1.85"/><circle cx="7.45" cy="13.05" r="4.05"/><circle cx="16.55" cy="13.05" r="4.05"/><circle class="icon-fill" cx="7.45" cy="13.05" r="1.55"/><circle class="icon-fill" cx="16.55" cy="13.05" r="1.55"/><path d="m10.35 16.15 1.65 2.1 1.65-2.1M2.8 9.15 1.5 7.8h3.35M21.2 9.15l1.3-1.35h-3.35"/></svg>`,
    whatsapp: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.15 11.65a8.15 8.15 0 0 1-11.98 7.2L3.8 20.2l1.42-4.22a8.16 8.16 0 1 1 14.93-4.33Z"/><path d="M8.35 7.8c.18-.42.36-.43.67-.44h.57c.18 0 .4.06.5.36l.78 1.9c.09.25.03.47-.12.65l-.58.7c-.17.18-.15.38-.04.58.63 1.08 1.48 1.93 2.57 2.55.2.11.39.13.57-.04l.83-.95c.18-.2.4-.22.64-.12l1.8.86c.27.13.4.22.4.4-.02.34-.16 1.54-1.05 2.15-.63.44-1.46.65-2.35.42-1.21-.31-2.7-.98-4.32-2.4-1.28-1.13-2.13-2.49-2.38-3.42-.25-.94-.04-1.96.35-2.51.3-.43.66-.66 1.15-.69Z"/></svg>`,
  };
  return icons[name] || "";
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[character]);
}

class SiteHeader extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <header class="site-header">
        <a class="brand" href="${siteUrl("index.html")}" aria-label="Oro Nero, torna alla home">
          <span class="brand-emblem" aria-hidden="true"><img src="${siteUrl("assets/images/oronero-emblem.png")}" alt="" width="256" height="256" decoding="async"></span>
          <span class="brand-wordmark"><strong>ORO NERO</strong><small>Experience Bistrot · Chioggia</small></span>
        </a>
        <button class="language-trigger" type="button" data-language-open aria-label="Lingua / Language" aria-haspopup="dialog"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z"/></svg><span class="language-trigger-label">Lingua</span></button>
        <button class="nav-toggle" type="button" aria-label="Apri il menu" aria-expanded="false" aria-controls="main-navigation"><span></span><span></span></button>
        <nav class="site-nav" id="main-navigation" aria-label="Navigazione principale">
          <a href="${siteUrl("index.html")}">Home</a>
          <a href="${siteUrl("index.html#ristorante")}">Il ristorante</a>
          <a href="${siteUrl("menu/")}">Menu</a>
          <a href="${siteUrl("menu/#carta-vini")}">Carta vini</a>
          <a href="${siteUrl("index.html#galleria")}">Galleria</a>
          <a href="${siteUrl("recensioni/")}">Recensioni</a>
          <a href="${siteUrl("index.html#contatti")}">Contatti</a>
          <a class="nav-book" href="#prenota" data-booking>Prenota <span>→</span></a>
        </nav>
      </header>`;

    const button = this.querySelector(".nav-toggle");
    const nav = this.querySelector(".site-nav");
    const mobile = window.matchMedia?.("(max-width: 880px)");
    const setOpen = (open, returnFocus = false) => {
      button.setAttribute("aria-expanded", String(open));
      button.setAttribute("aria-label", open ? "Chiudi il menu" : "Apri il menu");
      nav.classList.toggle("open", open);
      document.body.classList.toggle("nav-open", open);
      nav.inert = Boolean(mobile?.matches && !open);
      if (returnFocus) button.focus();
    };
    setOpen(false);
    button.addEventListener("click", () => {
      const open = button.getAttribute("aria-expanded") !== "true";
      setOpen(open);
      if (open) nav.querySelector("a")?.focus();
    });
    nav.querySelectorAll("a").forEach((link) => {
      const target = new URL(link.href);
      if (!target.hash && target.pathname.replace(/index\.html$/, "") === location.pathname.replace(/index\.html$/, "")) link.setAttribute("aria-current", "page");
      link.addEventListener("click", () => setOpen(false));
    });
    this.addEventListener("keydown", (event) => {
      if (button.getAttribute("aria-expanded") !== "true") return;
      if (event.key === "Escape") { event.preventDefault(); setOpen(false, true); }
      if (event.key === "Tab" && mobile?.matches) {
        const links = [...nav.querySelectorAll("a")];
        if (event.shiftKey && document.activeElement === button) { event.preventDefault(); links.at(-1).focus(); }
        else if (!event.shiftKey && document.activeElement === links.at(-1)) { event.preventDefault(); button.focus(); }
      }
    });
    const onMobile = () => setOpen(false);
    mobile?.addEventListener("change", onMobile);
    this.releaseMedia = () => mobile?.removeEventListener("change", onMobile);
  }
  disconnectedCallback() { this.releaseMedia?.(); }
}

class SiteFooter extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <footer class="site-footer" id="site-footer">
        <div class="footer-grid">
          <div class="footer-intro">
            <a class="footer-brand" href="${siteUrl("index.html")}" aria-label="Oro Nero, torna alla home">
              <img class="footer-logo" src="${siteUrl("assets/images/oronero-emblem.png")}" alt="" width="256" height="256" loading="lazy" decoding="async">
              <span class="footer-wordmark"><strong>ORO NERO</strong><small>Experience Bistrot</small></span>
            </a>
            <p class="footer-description">Piatti di mare e di terra. Ci trovi in Calle Vianelli, a Riva Vena, nel centro di Chioggia.</p>
          </div>
          <div>
            <h2>Contatti</h2>
            <a href="${maps}" target="_blank" rel="noreferrer">Calle Vianelli, 1011 · Chioggia</a>
            <a href="tel:+393442865877">+39 344 286 5877</a>
            <a href="mailto:ma.tizzisrls@gmail.com">ma.tizzisrls@gmail.com</a>
          </div>
          <div>
            <h2>Informazioni</h2>
            <a href="${siteUrl("menu/")}">Menu e prezzi</a>
            <a href="${siteUrl("menu/#carta-vini")}">Carta dei vini</a>
            <a href="${siteUrl("index.html#galleria")}">Galleria fotografica</a>
            <a href="${siteUrl("allergeni/")}">Allergeni</a>
            <a href="${siteUrl("privacy/")}">Privacy</a>
            <a href="${siteUrl("index.html#la-squadra")}">La squadra</a>
            <a href="${siteUrl("qr/")}">QR da stampare</a>
            <a href="${siteUrl("admin/")}">Area amministrativa</a>
            <button class="footer-language" type="button" data-language-open aria-haspopup="dialog">Lingua / Language</button>
          </div>
          <div>
            <h2>Seguici</h2>
            <div class="social-links">
              ${socialProfiles.map((profile) => `<a class="social-mark social-mark-${profile.id}" href="${profile.href}" target="_blank" rel="noopener noreferrer" aria-label="Apri ${profile.name}"><span class="social-mark-icon">${brandIcon(profile.id)}</span><span class="social-mark-label">${profile.name}</span></a>`).join("")}
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <span>P.IVA 04860790270</span>
          <a class="developer-credit" href="https://giammarkdev.netlify.app/" target="_blank" rel="noreferrer">Developed by <strong>GiaMMarK</strong></a>
        </div>
      </footer>`;
  }
}

class SocialStage extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <section class="social-stage" aria-labelledby="social-stage-title">
        <div class="social-stage-heading">
          <p class="eyebrow">Ci trovi anche qui</p>
          <h2 id="social-stage-title">Restiamo <em>in contatto.</em></h2>
          <p>Per vedere cosa cuciniamo, leggere le recensioni o scriverci: ci trovi anche qui.</p>
        </div>
        <div class="social-constellation">
          ${socialProfiles.map((profile, index) => `
            <a class="social-card social-card-${profile.id}" href="${profile.href}" target="_blank" rel="noopener noreferrer" aria-label="${profile.action} su ${profile.name}">
              <span class="social-card-number">0${index + 1}</span>
              <span class="social-card-icon">${brandIcon(profile.id)}</span>
              <span class="social-card-copy"><strong>${profile.name}</strong><small>${profile.handle}</small></span>
              <span class="social-card-action">${profile.action}<i><svg class="direction-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></i></span>
            </a>`).join("")}
        </div>
        <div class="social-stage-ticker" aria-hidden="true"><span>ORO NERO · CHIOGGIA · RIVA VENA · EXPERIENCE BISTROT · </span></div>
      </section>`;

    this.querySelectorAll(".social-card").forEach((card) => {
      card.addEventListener("pointermove", (event) => {
        const bounds = card.getBoundingClientRect();
        card.style.setProperty("--pointer-x", `${event.clientX - bounds.left}px`);
        card.style.setProperty("--pointer-y", `${event.clientY - bounds.top}px`);
      });
      card.addEventListener("pointerleave", () => {
        card.style.removeProperty("--pointer-x");
        card.style.removeProperty("--pointer-y");
      });
    });
  }
}

if (!customElements.get("site-header")) customElements.define("site-header", SiteHeader);
if (!customElements.get("site-footer")) customElements.define("site-footer", SiteFooter);
if (!customElements.get("social-stage")) customElements.define("social-stage", SocialStage);

let currentPage = null;
function pageTimeout(callback, delay) {
  const scope = currentPage;
  const timer = setTimeout(() => { scope?.timers.delete(timer); if (!scope?.closed) callback(); }, delay);
  scope?.timers.add(timer);
  return timer;
}

function bookingTimes(start, end) {
  return Array.from({ length: (end - start) / 15 + 1 }, (_, index) => {
    const minutes = start + index * 15;
    const time = `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
    return `<option value="${time}" ${time === "19:30" ? "selected" : ""}>${time}</option>`;
  }).join("");
}

function injectBookingDialog() {
  if (document.querySelector("#booking-dialog")) return;
  document.body.insertAdjacentHTML("beforeend", `
    <dialog class="booking-dialog" id="booking-dialog" aria-labelledby="booking-title">
      <form class="booking-card" id="booking-form" action="https://formsubmit.co/alphascript24@gmail.com" method="post" target="_blank" rel="noopener" aria-describedby="booking-note">
        <input type="hidden" name="_subject" value="Richiesta dal sito · Oro Nero">
        <input type="hidden" name="_template" value="table">
        <div hidden aria-hidden="true"><label>Lascia vuoto questo campo<input name="_honey" type="text" tabindex="-1" autocomplete="off"></label></div>
        <header><div><p>Prenotazioni Oro Nero</p><h2 id="booking-title">Richiedi un tavolo.</h2></div><button type="button" id="booking-close" aria-label="Chiudi">×</button></header>
        <div class="booking-fields">
          <label>Nome e cognome<input name="name" autocomplete="name" maxlength="120" required></label>
          <label>Persone<select name="guests" required>${Array.from({ length: 12 }, (_, index) => `<option value="${index + 1}" ${index === 1 ? "selected" : ""}>${index + 1}</option>`).join("")}</select></label>
          <label>Email<input name="email" type="email" autocomplete="email" maxlength="254" required></label>
          <label><span>Telefono <small>(facoltativo)</small></span><input name="phone" type="tel" autocomplete="tel" maxlength="40"></label>
          <label>Data<input name="date" type="date" required></label>
          <label>Ora<select name="time" required><optgroup label="Pranzo">${bookingTimes(11 * 60 + 30, 14 * 60 + 30)}</optgroup><optgroup label="Cena">${bookingTimes(18 * 60, 23 * 60 + 30)}</optgroup></select></label>
          <label class="booking-wide">Richieste o occasione<textarea name="notes" rows="3" maxlength="2000" placeholder="Un’occasione speciale o una richiesta per il tavolo…"></textarea></label>
        </div>
        <p class="booking-note" id="booking-note">La richiesta verrà inviata via email. Il tavolo è confermato solo dopo la nostra risposta.</p>
        <p class="booking-note">Si aprirà la pagina di FormSubmit: completa la verifica per inviare il modulo. I dati vengono trasmessi tramite questo servizio. Per i dettagli: <a href="${siteUrl("privacy/")}" target="_blank" rel="noopener">informativa privacy</a>.</p>
        <button class="button button-gold" type="submit">Invia richiesta via email <svg class="direction-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></button><p id="booking-status" class="booking-status" role="status" hidden></p>
        <p class="booking-note">Preferisci usare il tuo programma email? <a data-booking-email href="mailto:alphascript24@gmail.com">Scrivici direttamente</a>.</p>
      </form>
    </dialog>`);

  const dialog = document.querySelector("#booking-dialog");
  const form = document.querySelector("#booking-form");
  document.querySelector("#booking-close").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener("close", () => document.body.classList.remove("dialog-open"));
  setupBookingForm(form, { translate: (text) => getTranslator(document, window).t(text) });
}

function bindBookingButtons() {
  document.querySelectorAll("[data-booking]").forEach((button) => {
    if (button.dataset.bookingBound) return;
    button.dataset.bookingBound = "true";
    button.addEventListener("click", (event) => {
      event.preventDefault();
      const dialog = document.querySelector("#booking-dialog");
      document.querySelector("#booking-status").hidden = true;
      const notes = dialog.querySelector("[name=notes]");
      if (button.dataset.bookingNote) notes.value = getTranslator(document, window).t(`Vorrei informazioni su: ${button.dataset.bookingNote}`);
      if (!dialog.open) {
        try {
          dialog.showModal();
        } catch {
          dialog.setAttribute("open", "");
        }
      }
      document.body.classList.add("dialog-open");
      pageTimeout(() => dialog.querySelector("[name=name]").focus(), 50);
    });
  });
}

function injectMobileDock() {
  if (/\/admin\/?(?:index\.html)?$/.test(location.pathname)) return;
  document.body.classList.add("has-mobile-dock");
  document.body.insertAdjacentHTML("beforeend", `
    <nav class="mobile-dock" aria-label="Azioni rapide">
      <a href="${siteUrl("index.html")}"><span>⌂</span>Home</a>
      <a href="${siteUrl("menu/")}"><span>≡</span>Menu</a>
      <a href="#prenota" data-booking><span>◇</span>Prenota</a>
      <a href="${maps}" target="_blank" rel="noreferrer"><span>⌖</span>Mappa</a>
    </nav>`);
  document.querySelectorAll(".mobile-dock a").forEach((link) => {
    if (new URL(link.href).pathname.replace(/index\.html$/, "") === location.pathname.replace(/index\.html$/, "") && !new URL(link.href).hash) link.setAttribute("aria-current", "page");
  });
}

function setupGallery() {
  const images = [...document.querySelectorAll(".gallery-card img")];
  if (!images.length) return;
  document.querySelectorAll('[data-gallery-more]').forEach((button) => {
    const collection = button.closest('[data-gallery-group]');
    const extras = [...collection.querySelectorAll('[data-gallery-extra]')];
    const total = collection.querySelectorAll('.gallery-card').length;
    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') !== 'true';
      button.setAttribute('aria-expanded', String(expanded));
      extras.forEach((card) => { card.hidden = !expanded; });
      button.textContent = expanded ? 'Mostra meno foto ↑' : `Mostra tutte le ${total} foto ↓`;
    });
  });
  document.body.insertAdjacentHTML("beforeend", `
    <dialog class="gallery-dialog" id="gallery-dialog" aria-label="Galleria fotografica Oro Nero">
      <button class="gallery-close" type="button" aria-label="Chiudi">×</button>
      <button class="gallery-nav gallery-prev" type="button" aria-label="Foto precedente">‹</button>
      <span class="gallery-position" role="status" aria-live="polite"></span>
      <figure><img alt=""><figcaption></figcaption></figure>
      <button class="gallery-nav gallery-next" type="button" aria-label="Foto successiva">›</button>
    </dialog>`);
  const dialog = document.querySelector("#gallery-dialog");
  const dialogImage = dialog.querySelector("img");
  const caption = dialog.querySelector("figcaption");
  const position = dialog.querySelector(".gallery-position");
  let activeImages = images;
  let current = 0;
  const show = (index) => {
    current = (index + activeImages.length) % activeImages.length;
    const photo = activeImages[current];
    dialogImage.src = photo.dataset.fullSrc || photo.src;
    dialogImage.alt = photo.alt;
    const label = photo.closest("figure")?.querySelector("figcaption")?.cloneNode(true);
    label?.querySelectorAll('[aria-hidden="true"]').forEach((node) => node.remove());
    caption.textContent = label?.textContent || photo.alt;
    position.textContent = `Foto ${current + 1} di ${activeImages.length}`;
  };
  images.forEach((image) => {
    image.closest("figure").tabIndex = 0;
    image.closest("figure").setAttribute("role", "button");
    image.closest("figure").setAttribute("aria-label", `Apri foto: ${image.alt}`);
    const open = () => {
      const group = image.closest('[data-gallery-group]');
      activeImages = group ? [...group.querySelectorAll('.gallery-card img')] : images;
      show(activeImages.indexOf(image));
      if (!dialog.open) {
        try {
          dialog.showModal();
        } catch {
          dialog.setAttribute("open", "");
        }
      }
      document.body.classList.add("dialog-open");
    };
    image.closest("figure").addEventListener("click", open);
    image.closest("figure").addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        open();
      }
    });
  });
  dialog.querySelector(".gallery-close").addEventListener("click", () => dialog.close());
  dialog.querySelector(".gallery-prev").addEventListener("click", () => show(current - 1));
  dialog.querySelector(".gallery-next").addEventListener("click", () => show(current + 1));
  dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener("close", () => document.body.classList.remove("dialog-open"));
  dialog.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") show(current - 1);
    if (event.key === "ArrowRight") show(current + 1);
  });
}

async function loadHomepageHighlights(signal) {
  const tastingTarget = document.querySelector("#home-degustation-list");
  const eventTarget = document.querySelector("#home-event-list");
  if (!tastingTarget && !eventTarget) return;
  let data;
  try {
    const response = await fetch("/api/menu", { headers: { accept: "application/json" }, signal });
    if (!response.ok) throw new Error();
    data = await response.json();
  } catch {
    if (signal.aborted) return;
    const response = await fetch(siteUrl("assets/default-menu.json"), { headers: { accept: "application/json" }, signal });
    if (!response.ok) throw new Error("Menu non disponibile");
    data = await response.json();
  }
  if (signal.aborted) return;
  if (tastingTarget) {
    tastingTarget.innerHTML = (data.degustations || []).filter((item) => item.visible).slice(0, 2).map((item) => `
      <article class="experience-card"><p>${escapeHtml(item.subtitle || "Esperienza Oro Nero")}</p><h3>${escapeHtml(item.title)}</h3><div>${escapeHtml(item.description || "")}</div><button class="text-link light-link" type="button" data-booking data-booking-note="${escapeHtml(item.title)}">Richiedi informazioni →</button></article>`).join("");
  }
  if (eventTarget) {
    eventTarget.innerHTML = (data.events || []).filter((item) => item.visible).slice(0, 3).map((item) => `
      <article class="event-card"><p>${escapeHtml(item.dateText || "In aggiornamento")}</p><h3>${escapeHtml(item.title)}</h3><div>${escapeHtml(item.description || "")}</div><button class="text-link" type="button" data-booking data-booking-note="${escapeHtml(item.title)}">Chiedi informazioni →</button></article>`).join("");
  }
  bindBookingButtons();
  document.dispatchEvent(new CustomEvent("oronero:dynamic-content"));
}

export function setupSite() {
  cleanupSite();
  const scope = { closed: false, timers: new Set(), abort: new window.AbortController(), reveal: null, arrival: null };
  currentPage = scope;

  injectBookingDialog();
  injectMobileDock();
  bindBookingButtons();
  setupGallery();
  loadHomepageHighlights(scope.abort.signal).catch(() => {
    if (scope.closed) return;
    const tastingTarget = document.querySelector("#home-degustation-list");
    const eventTarget = document.querySelector("#home-event-list");
    if (tastingTarget) tastingTarget.innerHTML = "<p>Le degustazioni saranno disponibili a breve.</p>";
    if (eventTarget) eventTarget.innerHTML = "<p>Gli eventi saranno disponibili a breve.</p>";
  });
  document.addEventListener("oronero:dynamic-content", bindBookingButtons);

  // The photographic story advances only on request: no distracting autoplay.
  const showcase = document.querySelector("[data-hero-showcase]");
  if (showcase) {
    const slides = [...showcase.querySelectorAll("[data-hero-slide]")];
    const counter = showcase.querySelector("[data-hero-current]");
    const caption = showcase.querySelector("[data-hero-caption]");
    let activeSlide = 0;
    if (caption) caption.setAttribute("aria-live", "polite");
    const showSlide = (index) => {
      activeSlide = (index + slides.length) % slides.length;
      slides.forEach((slide, slideIndex) => slide.classList.toggle("is-active", slideIndex === activeSlide));
      if (counter) counter.textContent = String(activeSlide + 1).padStart(2, "0");
      if (caption) caption.textContent = slides[activeSlide].dataset.caption || "";
    };
    showcase.querySelector("[data-hero-prev]")?.addEventListener("click", () => showSlide(activeSlide - 1));
    showcase.querySelector("[data-hero-next]")?.addEventListener("click", () => showSlide(activeSlide + 1));
  }

  const hero = document.querySelector(".hero");
  if (hero && typeof matchMedia === "function" && matchMedia("(pointer: fine)").matches) {
    hero.addEventListener("pointermove", (event) => {
      const bounds = hero.getBoundingClientRect();
      hero.style.setProperty("--hero-x", `${((event.clientX - bounds.left) / bounds.width - 0.5) * 16}px`);
      hero.style.setProperty("--hero-y", `${((event.clientY - bounds.top) / bounds.height - 0.5) * 12}px`);
    });
  }

  if (typeof IntersectionObserver === "function") {
    const reveal = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("revealed");
        reveal.unobserve?.(entry.target);
      }
    }), { threshold: 0.08 });
    scope.reveal = reveal;
    document.documentElement.classList.add("reveal-ready");
    document.querySelectorAll("[data-reveal]").forEach((element) => reveal.observe(element));
  }

  scope.languages = setupLanguages();
  scope.arrival = setupArrival();
  return () => { if (currentPage === scope) cleanupSite(); };
}
export function cleanupSite() {
  if (!currentPage) return;
  const scope = currentPage;
  scope.closed = true;
  scope.abort.abort();
  scope.timers.forEach(clearTimeout);
  scope.reveal?.disconnect();
  scope.arrival?.destroy();
  scope.languages?.destroy();
  document.removeEventListener("oronero:dynamic-content", bindBookingButtons);
  currentPage = null;
}

setupMusic();
setupSite();
setupNavigation({ initialize: setupSite, cleanup: cleanupSite, root: siteRoot });

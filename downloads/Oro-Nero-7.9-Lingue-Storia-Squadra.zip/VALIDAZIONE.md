# Oro Nero 7.9.0 · Lingue, storia e squadra

## Modifiche della versione 7.9

Selettore globale nella testata e nel footer, dialog accessibile con ricerca fra 249 lingue e varianti, nomi nativi dove disponibili, focus restituito al comando di apertura e chiusura con Escape. I collegamenti aprono Google Translate in una nuova scheda e seguono la pagina pubblica corrente. Query, frammenti, area amministrativa e indirizzi locali non vengono condivisi. L’italiano chiude il selettore senza ricaricare il sito.

La homepage presenta il racconto del ristorante e quattro schede dei ruoli: Chef, Aiuto chef, Sala, Accoglienza. Testi basati sull’identità già presente; nessun anno di apertura, nome personale, ritratto o biografia inventato. Le informazioni reali non sono state ancora fornite.

Build e controllo dei contenuti riusciti: 13 categorie e 80 voci. **81 test superati**, nessun fallimento o test saltato. Gli 8 nuovi test coprono catalogo, generazione dei collegamenti, pagine consentite, ricerca, accessibilità e ciclo di apertura/chiusura durante la navigazione.

La destinazione esterna è simulata nelle prove browser: il test conferma l’apertura della nuova scheda e il collegamento corretto, non la traduzione eseguita da Google. La resa del servizio remoto e dei contenuti dinamici richiede verifica sul dominio pubblicato. La copertura non equivale a tutte le lingue esistenti.

Chromium: layout verificati a 320, 390, 768, 900, 1024 e 1440 pixel senza overflow orizzontale. Quattro schede staff presenti e leggibili; dialog cercabile, nuova scheda, ripristino del focus ed Escape verificati. Il comando delle lingue funziona anche con la navigazione mobile aperta. Controllati i collegamenti su home, menu, allergeni, recensioni, privacy e QR; l’admin rimane escluso. Il lettore audio resta lo stesso durante questi passaggi e non si duplicano i dialoghi. Nessun errore JavaScript.

Regressione dell’intro sulla build 7.9: avvio visivo senza user activation con audio consentito, bloccato e ritardato di cinque secondi; conclusione autonoma dopo circa 4,1 secondi. Ricaricamento e vecchi indicatori di visita non impediscono l’intro. Il ritorno interno alla home non la ripete e conserva il lettore attivo.

## Grafica conservata dalla versione 7.7

- Nuovo emblema trasparente PNG 1254 × 1254 pixel, ripulito dal riferimento originale con generazione d’immagine. Identità floreale intrecciata, cerchio e rombi conservati; il file è un’immagine raster ad alta risoluzione, non un SVG.
- Emblema coordinato in intro, testata, footer, icone e QR. Nessun ingrandimento del vecchio asset da circa 104 pixel e nessun ritaglio del nuovo marchio.
- Testata con solo emblema in lenta rotazione; nel footer e sul QR il nome è testo HTML nitido con i font del sito.
- Intro con simbolo iniziale più leggibile (circa 114 pixel mobile), rotazione di 48 gradi, ingrandimento progressivo, alone lieve e anello sottile. Singolo punto di luce con scia discreta; apertura a bordo morbido, senza le precedenti ali o il lampo ampio.
- Footer con gerarchia più ordinata, descrizione a 13 pixel, marchio proporzionato, separatori e griglia responsive. Spazio finale per i controlli fissi e pulsanti più rifiniti.

## Comportamento della versione 7.8

La sequenza visiva parte automaticamente, senza clic e senza attendere eventi del lettore audio: 3 secondi di rotazione e ingrandimento, seguiti da un’apertura di 1,1 secondi. La freccia salta sempre l’intro; × ed Escape mettono in pausa la musica e consentono l’ingresso silenzioso. Movimento ridotto, replay e protezione contro il lampo iniziale della homepage restano previsti.

L’intro e la copertura del primo fotogramma si attivano a ogni apertura completa o ricaricamento della homepage, ignorando gli indicatori di visita salvati dalle versioni precedenti. Il ritorno alla home tramite navigazione interna nello stesso documento non ripete automaticamente la sequenza; il replay rimane facoltativo. Movimento ridotto, link diretti con frammento e menu aperto dal QR mantengono il percorso senza intro.

Il tentativo di autoplay musicale avviene separatamente nella testata. Il browser può richiedere un’interazione per l’audio udibile; quel blocco non arresta l’intro. Traccia attenuata, volume del lettore al 70%, stesso elemento audio tra le pagine, titoli compatti e menu senza foto rimangono invariati. Nessuna modifica a nomi, prezzi, allergeni o dati del menu.

## Verifiche della versione 7.8

Node.js 22.23.4: build e controllo dei contenuti riusciti, 13 categorie e 80 voci. **73 test superati**, nessun fallimento o test saltato. Inclusi 18 test dell’intro e 8 del primo avvio, con regressioni per vecchi flag di sessione e ritorno interno alla homepage.

Chromium, senza clic, tocchi o tasti: osservazioni CDP con userGesture:false e navigator.userActivation.hasBeenActive=false. Intro attiva entro circa 0,3 secondi e completata entro circa 4,4 secondi sia con autoplay consentito sia con audio bloccato. Con MP3 ritardato di cinque secondi l’intro si avvia e si conclude autonomamente anche mentre il lettore è ancora in caricamento. Il permesso audio non controlla più la sequenza visiva.

Verificata una sessione con entrambi i vecchi flag di visita salvati: l’intro parte comunque senza interazione; dopo la conclusione, una ricarica completa la fa ripartire da sola. Tornando invece alla home dalla navigazione interna, il documento conserva il segnale di intro già mostrata e non ripete l’animazione.

I test coprono freccia sempre disponibile per saltare, ingresso silenzioso con × ed Escape, avvio precoce e passaggio della copertura senza lampo della homepage, movimento ridotto e replay. Riconfermata navigazione musicale continua su tutte le pagine, Indietro/Avanti, ricerca, Sommelier, prenotazione e stampa QR. Nessun errore JavaScript nelle prove funzionali.

Grafica di marchio e footer della versione 7.7 conservata: PNG trasparente da 1254 pixel, impaginazione verificata a 320, 390, 768 e 1440 pixel, descrizione footer a 13 pixel. Nessuna modifica al file audio attenuato o al volume del lettore.

## Pubblicazione

Nessun deploy Netlify eseguito. Gli archivi e le anteprime su GitHub devono essere pubblicati sull’hosting per aggiornare il sito online. Il browser mantiene il controllo sul permesso autoplay e l’ospite sul volume fisico del dispositivo. Usare l’intera build aggiornata, senza mescolare asset di versioni diverse.

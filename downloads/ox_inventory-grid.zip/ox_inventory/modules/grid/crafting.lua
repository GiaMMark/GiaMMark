-- Preflight crafting against its final physical inventory, without changing items.
-- Positive ingredients free their slots before durability stacks are split.
local Grid = require 'modules.grid.server'
local G = Grid.geometry
local C = {}

local function copy(value)
    if type(value) ~= 'table' then return value end
    local result = {}
    for k,v in pairs(value) do result[k] = copy(v) end
    return result
end

local function slotsInOrder(items)
    local slots = {}
    for slot in pairs(items) do slots[#slots+1] = slot end
    table.sort(slots)
    return slots
end

local function equalMetadata(a,b)
    return table.matches(a or {},b or {})
end

function C.plan(inv, craftedItem, craftCount, metadata, requestedSlot, consumption, ingredients, getItem, slotWeight, availableSlots)
    if not Grid.enabled then return { disabled = true } end
    if not craftedItem or not G.integer(craftCount) or craftCount < 1 then return end
    local shadow = {}
    for k,v in pairs(inv) do shadow[k] = v end
    shadow.items = copy(inv.items)
    shadow._grid = G.copy(Grid.reconcile(inv))
    local plan = { removals = {}, tools = {}, splits = {} }
    local used = {}
    local maxSlot = inv.slots
    if Grid.isPlayer(inv) then
        -- Never auto-place ordinary crafting output in pinkFrog clothing slots.
        local config = lib.load('data.grid')
        maxSlot = math.max(0,inv.slots-config.clothingSlots)
    end
    if type(availableSlots)=='number' and availableSlots > 0 then
        maxSlot = math.min(maxSlot,math.floor(availableSlots))
    end
    local function firstFree(item)
        for slot=1,maxSlot do
            if not shadow.items[slot] and Grid.allowed(shadow,slot,item) then return slot end
        end
    end
    local function place(slot,item)
        if not slot or not Grid.preflightAdd(shadow,{{slot=slot,item=item}}) then return false end
        item.slot=slot
        shadow.items[slot]=item
        Grid.reconcile(shadow)
        return true
    end

    -- Validate the pre-animation slot plan against current names, counts and tools.
    -- A different item in the same logical slot must never satisfy a stale recipe.
    for _,slot in ipairs(slotsInOrder(consumption)) do
        local amount=consumption[slot]
        local current=shadow.items[slot]
        if not current or not ingredients[current.name] or type(amount)~='number' or amount<=0 then return end
        local needs=ingredients[current.name]
        if (amount<1) ~= (needs<1) or amount>needs then return end
        used[current.name]=(used[current.name] or 0)+amount
        if amount>=1 then
            if not G.integer(amount) or current.count<amount then return end
            plan.removals[#plan.removals+1]={slot=slot,name=current.name,count=amount}
            current.count=current.count-amount
            if current.count==0 then shadow.items[slot]=nil end
        else
            local definition=getItem(current.name)
            local durability=current.metadata and current.metadata.durability
            if not definition or type(durability)~='number' or durability<amount*100 then return end
            if durability>100 then
                local degrade=(current.metadata.degrade or definition.degrade)
                if type(degrade)~='number' or degrade<=0 then return end
                if ((durability-os.time())*100)/(degrade*60)<amount*100 then return end
                durability=durability-degrade*60*amount
            else
                durability=durability-amount*100
            end
            plan.tools[#plan.tools+1]={slot=slot,name=current.name,amount=amount,durability=math.max(0,durability)}
        end
    end
    for name,needs in pairs(ingredients) do
        if needs>0 and math.abs((used[name] or 0)-needs)>0.000001 then return end
        if needs==0 then
            local found=false
            for _,item in pairs(shadow.items) do
                if item.name==name and (not item.metadata.durability or item.metadata.durability>0) then found=true;break end
            end
            if not found then return end
        end
    end
    Grid.reconcile(shadow)
    -- Splitting a tool stack produces an additional footprint, even though total
    -- quantity and weight of that tool do not change.
    for _,tool in ipairs(plan.tools) do
        local current=shadow.items[tool.slot]
        if current.count>1 then
            local newItem=copy(current)
            newItem.count=1
            newItem.metadata.durability=tool.durability
            local destination=firstFree(newItem)
            if not place(destination,newItem) then return end
            current.count=current.count-1
            plan.splits[tool.slot]=destination
        else
            current.metadata.durability=tool.durability
        end
    end
    local output={name=craftedItem.name,label=craftedItem.label,count=craftCount,
        weight=craftedItem.weight,metadata=copy(metadata or {}),stack=craftedItem.stack}
    if craftedItem.stack then
        local destination
        if G.integer(requestedSlot) and requestedSlot>=1 and requestedSlot<=maxSlot
            and Grid.allowed(shadow,requestedSlot,output) then
            local old=shadow.items[requestedSlot]
            if not old or old.name==output.name and equalMetadata(old.metadata,output.metadata) then destination=requestedSlot end
        end
        if not destination then
            for slot=1,maxSlot do
                local old=shadow.items[slot]
                if old and old.name==output.name and equalMetadata(old.metadata,output.metadata) then destination=slot;break end
            end
        end
        destination=destination or firstFree(output)
        if not destination then return end
        local old=shadow.items[destination]
        if old then old.count=old.count+craftCount
        elseif not place(destination,output) then return end
        plan.outputSlot=destination
    else
        for _=1,craftCount do
            local one=copy(output);one.count=1
            if not place(firstFree(one),one) then return end
        end
    end
    local _,overflow=Grid.reconcile(shadow)
    if #overflow>0 then return end
    -- Recalculate final weight; durability fractions do not remove tool weight.
    if slotWeight then
        local finalWeight=0
        for _,item in pairs(shadow.items) do
            local definition=getItem(item.name)
            if not definition then return end
            finalWeight=finalWeight+slotWeight(definition,item)
        end
        if finalWeight>inv.maxWeight then return end
    end
    return plan
end

return C

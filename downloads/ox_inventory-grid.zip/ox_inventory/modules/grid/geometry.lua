-- Pure Lua 5.4: shared algorithm used by server validation and unit tests.
local G = {}
function G.integer(n)
    return type(n) == 'number' and n == n and n % 1 == 0 and math.abs(n) < 1000000
end
function G.copy(placements)
    local result = {}
    for slot, p in pairs(placements or {}) do
        result[slot] = { x=p.x, y=p.y, w=p.w, h=p.h, rotated=p.rotated == true, name=p.name }
    end
    return result
end
function G.fits(placements, p, columns, rows, ignore)
    if type(p) ~= 'table' or not G.integer(p.x) or not G.integer(p.y)
        or not G.integer(p.w) or not G.integer(p.h) or p.w < 1 or p.h < 1
        or p.x < 0 or p.y < 0 or p.x+p.w > columns or p.y+p.h > rows then return false end
    for slot, q in pairs(placements) do
        if slot ~= ignore and p.x < q.x+q.w and q.x < p.x+p.w
            and p.y < q.y+q.h and q.y < p.y+p.h then return false end
    end
    return true
end
function G.firstFit(placements, w, h, columns, rows, rotated)
    for y=0,rows-h do
        for x=0,columns-w do
            local p = {x=x,y=y,w=w,h=h,rotated=rotated == true}
            if G.fits(placements,p,columns,rows) then return p end
        end
    end
end
return G

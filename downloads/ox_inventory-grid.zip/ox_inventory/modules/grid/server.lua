local Config = lib.load('data.grid')
local G = require 'modules.grid.geometry'
local Grid = { enabled = Config.enabled, geometry = G }
local Inventory, Items
local locks = {}
function Grid.hasLock(inv) return locks[inv] ~= nil end
function Grid.isLocked(inv)
    local lock=locks[inv]
    return lock==true or type(lock)=='table' and lock.owner~=coroutine.running()
end
function Grid.beginTransaction(inv)
    if not Grid.enabled then return setmetatable({commit=false},{__close=function() end}) end
    if locks[inv] then return end
    local function clone(value)
        if type(value)~='table' then return value end
        local result={}; for k,v in pairs(value) do result[k]=clone(v) end; return result
    end
    local original=clone(inv.items)
    local oldWeight,oldGrid=inv.weight,inv._grid and G.copy(inv._grid) or nil
    local tx={commit=false}
    locks[inv]={owner=coroutine.running()}
    return setmetatable(tx,{__close=function()
        locks[inv]=nil
        if tx.commit then
            Grid.save(inv,Grid.reconcile(inv)); Grid.push(inv)
        else
            local updates,seen={},{}
            for slot in pairs(inv.items) do seen[slot]=true end
            for slot in pairs(original) do seen[slot]=true end
            inv.items=original; inv.weight=oldWeight; inv._grid=oldGrid; inv.changed=true
            for slot in pairs(seen) do updates[#updates+1]={item=original[slot] or {slot=slot},inventory=inv.id} end
            inv:syncSlotsWithClients(updates,true)
            if inv.player and server and server.syncInventory then server.syncInventory(inv) end
            Grid.push(inv)
        end
    end})
end

function Grid.isPlayer(inv) return inv.type == 'player' or inv.type == 'otherplayer' end
function Grid.isBagSlot(inv, slot)
    return not Grid.isPlayer(inv) or (slot > Config.quickSlots and slot <= inv.slots-Config.clothingSlots)
end
function Grid.availableSlots(inv)
    if not Grid.isPlayer(inv) then return inv.slots end
    local ok,n=pcall(function() return exports['pinkFrog_inventoryAddon']:getAvailableSlots(inv.id) end)
    return ok and G.integer(n) and n>0 and math.min(n,inv.slots) or inv.slots
end
function Grid.allowed(inv, slot, item)
    if not G.integer(slot) or slot < 1 or slot > inv.slots then return false end
    if Grid.isPlayer(inv) and slot<=inv.slots-Config.clothingSlots and slot>Grid.availableSlots(inv) then return false end
    if Grid.isPlayer(inv) and slot>inv.slots-Config.clothingSlots then
        local category=Config.clothingByOffset[slot-(inv.slots-Config.clothingSlots)]
        if category and item.name~=category then return false end
    end
    if Grid.isPlayer(inv) and Config.weaponQuickSlots[slot] then
        return item.name:upper():sub(1,7) == 'WEAPON_'
    end
    return true
end
function Grid.autoSlotAllowed(inv,slot,item)
    if Grid.isPlayer(inv) and slot>inv.slots-Config.clothingSlots then return false end
    return Grid.allowed(inv,slot,item)
end
function Grid.dimensions(item, rotated)
    local size = Config.items[item.name] or (item.name:upper():sub(1,7) == 'WEAPON_' and Config.weaponDefault) or Config.defaultSize
    local w,h = size[1],size[2]
    if rotated then w,h=h,w end
    return w,h
end
function Grid.bounds(inv)
    return Config.columns, Config.rows[Grid.isPlayer(inv) and 'player' or inv.type] or Config.rows.default
end
local function key(inv)
    -- Player source IDs are transient; owner is the persistent framework identifier.
    -- Stashes use their database identity and owner. Ephemeral drops are not persisted.
    if inv.type == 'drop' or inv.type == 'newdrop' or inv.type == 'temp' then return end
    if Grid.isPlayer(inv) and not inv.owner then return end
    if Grid.isPlayer(inv) then return 'ox_grid:v1:player:'..tostring(inv.owner) end
    return 'ox_grid:v1:'..inv.type..':'..tostring(inv.dbId or inv.id)..':'..tostring(inv.owner or '')
end
local function load(inv)
    if inv._grid then return inv._grid end
    local k=key(inv)
    local raw=k and GetResourceKvpString(k)
    local ok,decoded=pcall(json.decode, raw or '{}')
    inv._grid={}
    if ok and type(decoded)=='table' then
        for slot,p in pairs(decoded) do
            local n=tonumber(slot)
            if G.integer(n) and type(p)=='table' then inv._grid[n]=p end
        end
    end
    return inv._grid
end
function Grid.save(inv, placements)
    inv._grid=placements
    inv._gridDirty=false
    local k=key(inv)
    if k then SetResourceKvp(k,json.encode(placements)) end
end
function Grid.reconcile(inv)
    local previous=load(inv)
    local placements={}
    local columns,rows=Grid.bounds(inv)
    local slots={}
    for slot,item in pairs(inv.items) do
        if item.name and Grid.isBagSlot(inv,slot) then slots[#slots+1]=slot end
    end
    table.sort(slots)
    -- First retain all still-valid positions, then place new/unmapped objects.
    for _,slot in ipairs(slots) do
        local old=previous[slot]
        if old and old.name==inv.items[slot].name then
            local w,h=Grid.dimensions(inv.items[slot],old.rotated == true)
            local p={x=old.x,y=old.y,w=w,h=h,rotated=old.rotated == true,name=old.name}
            if G.fits(placements,p,columns,rows) then placements[slot]=p end
        end
    end
    local overflow={}
    for _,slot in ipairs(slots) do
        if not placements[slot] then
            local item=inv.items[slot]
            local w,h=Grid.dimensions(item,false)
            local p=G.firstFit(placements,w,h,columns,rows,false)
            if not p then p=G.firstFit(placements,h,w,columns,rows,true) end
            if p then p.name=item.name; placements[slot]=p else overflow[#overflow+1]=slot end
        end
    end
    local changed=false
    for slot,p in pairs(placements) do
        local old=previous[slot]
        if not old or old.name~=p.name or old.x~=p.x or old.y~=p.y or old.w~=p.w or old.h~=p.h or old.rotated~=p.rotated then changed=true; break end
    end
    if not changed then for slot in pairs(previous) do if not placements[slot] then changed=true; break end end end
    inv._grid=placements
    inv._gridDirty=inv._gridDirty or changed
    return placements,overflow
end
function Grid.preflightAdd(inv, additions)
    if not Grid.enabled then return true end
    local current,overflow=Grid.reconcile(inv)
    local placements=G.copy(current)
    local columns,rows=Grid.bounds(inv)
    for _,entry in ipairs(additions) do
        local item=entry.item
        local slot=entry.slot
        if not Grid.allowed(inv,slot,item) then return false end
        if Grid.isBagSlot(inv,slot) and not inv.items[slot] then
            if #overflow>0 then return false end
            local w,h=Grid.dimensions(item,false)
            local p=G.firstFit(placements,w,h,columns,rows,false) or G.firstFit(placements,h,w,columns,rows,true)
            if not p then return false end
            p.name=item.name; placements[slot]=p
        end
    end
    return true
end
function Grid.canCarry(inv,item,count,metadata)
    if not Grid.enabled then return true end
    local additions={}
    local remaining=item.stack and 1 or math.max(1,count or 1)
    local maxSlot=Grid.isPlayer(inv) and inv.slots-Config.clothingSlots or inv.slots
    for slot=1,maxSlot do
        local old=inv.items[slot]
        if old and item.stack and old.name==item.name and table.matches(old.metadata or {},metadata or {}) then return true end
        if not old and Grid.allowed(inv,slot,item) then
            additions[#additions+1]={slot=slot,item=item}
            remaining=remaining-1
            if remaining<=0 then return Grid.preflightAdd(inv,additions) end
        end
    end
    return false
end
function Grid.snapshot(inv)
    local placements,overflow=Grid.reconcile(inv)
    if inv._gridDirty and not locks[inv] then Grid.save(inv,placements) end
    local columns,rows=Grid.bounds(inv)
    local items={}
    for slot,item in pairs(inv.items) do items[tostring(slot)]=item end
    return {id=inv.id,type=inv.type,slots=inv.slots,columns=columns,rows=rows,placements=placements,
        overflow=overflow,items=items,availableSlots=Grid.availableSlots(inv),quickSlots=Config.quickSlots,clothingSlots=Config.clothingSlots}
end
local function snapshots(player)
    local right=player.open and Inventory(player.open)
    return {enabled=Grid.enabled,left=Grid.snapshot(player),right=right and Grid.snapshot(right) or false}
end
function Grid.push(inv)
    local recipients={}
    if inv.player then recipients[inv.id]=true end
    for id in pairs(inv.openedBy or {}) do recipients[id]=true end
    for id in pairs(recipients) do
        local player=Inventory(id)
        if player then TriggerClientEvent('ox_inventory:gridState',id,snapshots(player)) end
    end
end
function Grid.prepare(from,to,data)
    local fp,fo=Grid.reconcile(from)
    local tp,tover
    if from==to then tp=fp; tover=fo else tp,tover=Grid.reconcile(to) end
    local plans={[from]=G.copy(fp)}
    if from~=to then plans[to]=G.copy(tp) end
    local item=from.items[data.fromSlot]
    local target=to.items[data.toSlot]
    if not item or not Grid.allowed(to,data.toSlot,item) then return end
    if target and not Grid.allowed(from,data.fromSlot,target) then return end
    local sameSlot=from==to and data.fromSlot==data.toSlot
    local stack=not sameSlot and target and target.name==item.name and target.stack and table.matches(target.metadata or {},item.metadata or {})
    if stack then
        if data.count>=item.count then plans[from][data.fromSlot]=nil end
        return plans
    end
    local swapping=target and not sameSlot
    if swapping or sameSlot or data.count>=item.count then plans[from][data.fromSlot]=nil end
    plans[to][data.toSlot]=nil
    local function place(inv,slot,what,requested,fallback)
        if not Grid.isBagSlot(inv,slot) then return true end
        local placements=plans[inv]
        local columns,rows=Grid.bounds(inv)
        local rotated=requested and requested.rotated==true or false
        local w,h=Grid.dimensions(what,rotated)
        local p
        if requested then
            if type(requested)~='table' or type(requested.rotated)~='boolean' then return false end
            p={x=requested.x,y=requested.y,w=w,h=h,rotated=rotated}
            if not G.fits(placements,p,columns,rows) then return false end
        else
            if fallback then
                local fw,fh=Grid.dimensions(what,fallback.rotated)
                p={x=fallback.x,y=fallback.y,w=fw,h=fh,rotated=fallback.rotated}
                if not G.fits(placements,p,columns,rows) then p=nil end
            end
            p=p or G.firstFit(placements,w,h,columns,rows,false) or G.firstFit(placements,h,w,columns,rows,true)
            if not p then return false end
        end
        p.name=what.name; placements[slot]=p
        return true
    end
    if not place(to,data.toSlot,item,data.grid,fp[data.fromSlot]) then return end
    if swapping and not place(from,data.fromSlot,target,nil,fp[data.fromSlot]) then return end
    return plans
end
function Grid.wrapSwap(nativeSwap)
    return function(source,data)
        if not Grid.enabled then return nativeSwap(source,data) end
        if type(data)~='table' or not G.integer(data.fromSlot) or not G.integer(data.toSlot)
            or not G.integer(data.count) or data.count<1 or (data.grid~=nil and type(data.grid)~='table') then return false end
        local player=Inventory(source)
        if not player then return false end
        local secondary=player.open and Inventory(player.open) or nil
        local from=data.fromType=='player' and player or secondary
        local to=data.toType=='player' and player or secondary
        if data.toType=='newdrop' then
            if data.fromType~='player' then return false end
            to=player
        end
        if not from or not to or type(from.items)~='table' or type(to.items)~='table'
            or not G.integer(from.slots) or not G.integer(to.slots)
            or data.fromType=='inspect' or data.toType=='inspect' then return false end
        local function matches(inv,kind)
            return kind==inv.type or (kind=='otherplayer' and Grid.isPlayer(inv))
        end
        if data.fromType~='player' and not matches(from,data.fromType) then return false end
        if data.toType~='player' and data.toType~='newdrop' and not matches(to,data.toType) then return false end
        if not Grid.allowed(from,data.fromSlot,from.items[data.fromSlot] or {name=''}) and not from.items[data.fromSlot] then return false end
        if data.fromSlot<1 or data.fromSlot>from.slots or data.toSlot<1 or data.toSlot>to.slots then return false end
        if locks[from] or locks[to] then return false end
        locks[from]=true; locks[to]=true
        local release <close> = setmetatable({}, {__close=function() locks[from]=nil; locks[to]=nil end})
        if data.toType=='newdrop' then
            local result=table.pack(nativeSwap(source,data))
            if result[1] then Grid.save(from,Grid.reconcile(from)); Grid.push(from) end
            return table.unpack(result,1,result.n)
        end
        local plans=Grid.prepare(from,to,data)
        if not plans then return false end
        if from==to and data.fromSlot==data.toSlot then
            if not data.grid then return false end
            Grid.save(from,plans[from]); Grid.push(from)
            return true
        end
        local result=table.pack(nativeSwap(source,data))
        if result[1] then
            for inv,placements in pairs(plans) do Grid.save(inv,placements) end
            Grid.push(from)
            if from~=to then Grid.push(to) end
        end
        return table.unpack(result,1,result.n)
    end
end
function Grid.init(inventory,items)
    Inventory=inventory; Items=items
    lib.callback.register('ox_inventory:gridState',function(source)
        local player=Inventory(source)
        if not player then return {enabled=false} end
        return snapshots(player)
    end)
end
return Grid

-- Read-only snapshots; native ox_inventory swapItems remains the only move route.
RegisterNUICallback('gridState', function(_, cb)
    local ok, state = pcall(lib.callback.await, 'ox_inventory:gridState', false)
    cb(ok and state or { enabled = false, error = 'Griglia non disponibile' })
end)
RegisterNetEvent('ox_inventory:gridState', function(state)
    SendNUIMessage({ action = 'gridState', data = state })
end)

-- Local NUI diagnostics: no inventory contents or credentials are included.
local gridBrowserBuild
RegisterNUICallback('gridUiReady', function(data, cb)
    local build = type(data) == 'table' and type(data.build) == 'string' and data.build:sub(1,100) or 'unknown'
    if gridBrowserBuild ~= build then
        gridBrowserBuild = build
        print(('[ox-grid-r4] browser pronto: %s'):format(build))
    end
    cb({ok=true})
end)

RegisterNUICallback('gridUiError', function(data, cb)
    if type(data) ~= 'table' then cb(false); return end
    local function safe(value, maximum)
        return type(value) == 'string' and value:sub(1,maximum) or ''
    end
    print(('[ox-grid-r4] UI ERROR build=%s\n%s\n%s\nReact components:%s'):format(
        safe(data.build,100),safe(data.message,2000),safe(data.stack,8000),safe(data.componentStack,8000)))
    cb({ok=true})
end)

RegisterCommand('oxgridversion', function()
    local html = LoadResourceFile(GetCurrentResourceName(), 'web/build/index.html') or ''
    local indexBuild = html:find('ox-grid-r4.js',1,true) and 'r4' or 'diverso da r4'
    print(('[ox-grid-r4] risorsa=%s; client=r4; browser=%s; index=%s'):format(
        GetCurrentResourceName(),gridBrowserBuild or 'nessuna conferma',indexBuild))
end, false)

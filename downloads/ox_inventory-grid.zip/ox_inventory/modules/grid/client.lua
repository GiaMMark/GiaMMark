-- Read-only snapshots; native ox_inventory swapItems remains the only move route.
RegisterNUICallback('gridState', function(_, cb)
    local ok, state = pcall(lib.callback.await, 'ox_inventory:gridState', false)
    cb(ok and state or { enabled = false, error = 'Griglia non disponibile' })
end)
RegisterNetEvent('ox_inventory:gridState', function(state)
    SendNUIMessage({ action = 'gridState', data = state })
end)

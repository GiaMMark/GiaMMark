return {
	
	Weapons = {
['WEAPON_HOSE'] = {
    label = 'Manichetta',
    weight = 1000,
    durability = 0.01,
},
		    
['WEAPON_FIREEXTINGUISHER'] = {
    label = 'Estintore VVF',
    weight = 5000,
    durability = 0.01,
},
  -- Pistole
    ['WEAPON_1911'] = {
        label = 'Colt 1911',
        weight = 1100,
        durability = 0.2,
        ammoname = 'ammo-45'
    },

    ['WEAPON_92FS'] = {
        label = 'Beretta 92FS',
        weight = 950,
        durability = 0.2,
        ammoname = 'ammo-9'
    },

    ['WEAPON_G17'] = {
        label = 'Glock 17',
        weight = 900,
        durability = 0.2,
        ammoname = 'ammo-9'
    },

    ['WEAPON_G18'] = {
        label = 'Glock 18',
        weight = 1000,
        durability = 0.05,
        ammoname = 'ammo-9'
    },

    ['WEAPON_G19'] = {
        label = 'Glock 19',
        weight = 850,
        durability = 0.2,
        ammoname = 'ammo-9'
    },

    ['WEAPON_M9'] = {
        label = 'Beretta M9',
        weight = 970,
        durability = 0.2,
        ammoname = 'ammo-9'
    },

    ['WEAPON_P226'] = {
        label = 'SIG Sauer P226',
        weight = 960,
        durability = 0.2,
        ammoname = 'ammo-9'
    },

    ['WEAPON_P88'] = {
        label = 'Walther P88',
        weight = 900,
        durability = 0.2,
        ammoname = 'ammo-9'
    },

    -- Pistole mitragliatrici e mitra
    ['WEAPON_MINIUZI'] = {
        label = 'Mini Uzi',
        weight = 2200,
        durability = 0.05,
        ammoname = 'ammo-9'
    },

    ['WEAPON_MP5'] = {
        label = 'Heckler & Koch MP5',
        weight = 2900,
        durability = 0.05,
        ammoname = 'ammo-9'
    },

    ['WEAPON_MP52'] = {
        label = 'Heckler & Koch MP5 - Variante 2',
        weight = 2700,
        durability = 0.05,
        ammoname = 'ammo-9'
    },

    ['WEAPON_MP9'] = {
        label = 'Brugger & Thomet MP9',
        weight = 1500,
        durability = 0.05,
        ammoname = 'ammo-9'
    },


    ['WEAPON_PMXFM'] = {
        label = 'Beretta PMX',
        weight = 2400,
        durability = 0.05,
        ammoname = 'ammo-9'
    },

    ['WEAPON_SCORPION'] = {
        label = 'CZ Scorpion',
        weight = 2800,
        durability = 0.05,
        ammoname = 'ammo-9'
    },

    -- Fucili d'assalto
    ['WEAPON_AK17'] = {
        label = 'AK-47',
        weight = 4300,
        durability = 0.03,
        ammoname = 'ammo-rifle2'
    },

    ['WEAPON_AK74'] = {
        label = 'AK-74',
        weight = 3700,
        durability = 0.03,
        ammoname = 'ammo-rifle'
    },

    ['WEAPON_ARX160'] = {
        label = 'Beretta ARX160',
        weight = 3000,
        durability = 0.03,
        ammoname = 'ammo-rifle'
    },

    ['WEAPON_G36'] = {
        label = 'Heckler & Koch G36',
        weight = 3600,
        durability = 0.03,
        ammoname = 'ammo-rifle'
    },

    ['WEAPON_MM4'] = {
        label = 'M4 Carbine',
        weight = 3100,
        durability = 0.03,
        ammoname = 'ammo-rifle'
    },

    -- Fucile di precisione
    ['WEAPON_M700'] = {
        label = 'Remington M700',
        weight = 4200,
        durability = 0.5,
        ammoname = 'ammo-sniper'
    },

    -- Armi da servizio non letali
    ['WEAPON_COLBATON'] = {
        label = 'Manganello telescopico',
        weight = 600,
        durability = 0.1
    },

    ['WEAPON_PALETTACC'] = {
        label = 'Paletta Carabinieri',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTACOSTIERA'] = {
        label = 'Paletta Guardia Costiera',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAECOZOOFILE'] = {
        label = 'Paletta Guardia Ecozoofila',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAESERCITO'] = {
        label = 'Paletta Esercito Italiano',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAFINANZA'] = {
        label = 'Paletta Guardia di Finanza',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAGGIURATA'] = {
        label = 'Paletta Guardia Giurata',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTALOCALE'] = {
        label = 'Paletta Polizia Locale',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAMARINA'] = {
        label = 'Paletta Marina Militare',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAMUNICIPALE'] = {
        label = 'Paletta Polizia Municipale',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAPENITENZIARIA'] = {
        label = 'Paletta Polizia Penitenziaria',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTASTRADALE'] = {
        label = 'Paletta Polizia Stradale',
        weight = 250,
        durability = 0.1
    },

    ['WEAPON_PALETTAVVF'] = {
        label = 'Paletta Vigili del Fuoco',
        weight = 250,
        durability = 0.1
    },
		['WEAPON_HACKINGDEVICE'] = {
    label = 'Scanner per piante',
    weight = 200,
},
		-- Accessori Armi
['suppressor'] = { label = 'Silenziatore', weight = 100, stack = true, close = true },
['scope'] = { label = 'Mirino Olografico', weight = 150, stack = true, close = true },
['scope2'] = { label = 'Mirino Avanzato', weight = 150, stack = true, close = true },
['scope3'] = { label = 'Mirino Zoom', weight = 150, stack = true, close = true },
['defaultclip'] = { label = 'Caricatore Standard', weight = 200, stack = true, close = true },
['grip'] = { label = 'Impugnatura', weight = 150, stack = true, close = true },
['flashlight'] = { label = 'Torcia', weight = 100, stack = true, close = true },
['extendedclip'] = { label = 'Caricatore Esteso', weight = 250, stack = true, close = true },
['barrel'] = { label = 'Canna Standard', weight = 300, stack = true, close = true },
['barrel2'] = { label = 'Canna Pesante', weight = 400, stack = true, close = true },
['suppressor2'] = { label = 'Freno di Bocca Piatto', weight = 100, stack = true, close = true },
['suppressor3'] = { label = 'Freno di Bocca Tattico', weight = 100, stack = true, close = true },
['suppressor4'] = { label = 'Freno di Bocca Largo', weight = 100, stack = true, close = true },
['suppressor5'] = { label = 'Freno di Bocca di Precisione', weight = 100, stack = true, close = true },
['suppressor6'] = { label = 'Freno di Bocca Rinforzato', weight = 100, stack = true, close = true },
['suppressor7'] = { label = 'Freno di Bocca Inclinato', weight = 100, stack = true, close = true },
['suppressor8'] = { label = 'Freno di Bocca Diviso', weight = 100, stack = true, close = true },
['drummag'] = { label = 'Caricatore a Tamburo', weight = 400, stack = true, close = true },
		['WEAPON_DHR31'] = {
    label = 'Fucile da Caccia',
    weight = 250.0,
    durability = 0.01,
    ammoname = 'ammo-heavysniper'
},
['WEAPON_DRILL'] = {
    label = 'Trapano Portatile',
    weight = 375.0,
    durability = 0.08,
},

		['WEAPON_HACKINGDEVICE'] = {
	label = 'Dispositivo Hacking',
	weight = 50.0,
	durability = 0,
},
		['WEAPON_BATTLERIFLE'] = {
			label = 'Battle Rifle',
			weight = 1650.0,
			durability =0.012,
			ammoname = 'ammo-rifle2',
		},

		
		['WEAPON_KATANA_2'] = {
			label = 'Katana',
			weight = 60.0,
			durability = 0.06
		},
	
	
	-- previous weapons
	['WEAPON_ACIDPACKAGE'] = {
		label = 'Giornale',
		weight = 1250.0,
		durability = 0.015,
		ammoname = 'ammo-acid'
	},

		
		['WEAPON_SNOWLAUNCHER'] = {
			label = 'Snowball Launcher',
			weight = 500.0,
			durability =0.015,
			ammoname = 'WEAPON_SNOWBALL',
		},

		['WEAPON_TECPISTOL'] = {
			label = 'Tactical SMG',
			weight = 750.0,
			durability = 0.017,
			ammoname = 'ammo-9',
		},

		['WEAPON_ADVANCEDRIFLE'] = {
			label = 'Advanced Rifle',
			weight = 1550.0,
			durability =0.012,
			ammoname = 'ammo-rifle',
		},

		['WEAPON_APPISTOL'] = {
			label = 'AP Pistol',
			weight = 700.0,
			durability = 0.018,
			ammoname = 'ammo-9',
		},

		['WEAPON_ASSAULTRIFLE'] = {
			label = 'Assault Rifle',
			weight = 2250.0,
			durability =0.012,
			ammoname = 'ammo-rifle2',
		},

		['WEAPON_ASSAULTRIFLE_MK2'] = {
			label = 'Assault Rifle MK2',
			weight = 1475.0,
			durability =0.012,
			ammoname = 'ammo-rifle2',
		},

		['WEAPON_ASSAULTSHOTGUN'] = {
			label = 'Assault Shotgun',
			weight = 2600.0,
			durability = 0.02,
			ammoname = 'ammo-shotgun'
		},
		['WEAPON_PAINTBALL'] = {
			label = 'Fucile PaintBall',
			weight = 2600.0,
			durability = 0.015,
			ammoname = 'ammo-pistol'
		},
		


		['WEAPON_ASSAULTSMG'] = {
			label = 'Assault SMG',
			weight = 1450.0,
			durability = 0.017,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_BALL'] = {
			label = 'Ball',
			weight = 74.5,
			throwable = true,
		},

		['WEAPON_BAT'] = {
			label = 'Bat',
			weight = 125.0,
			durability = 0.06,
		},

		['WEAPON_BATTLEAXE'] = {
			label = 'Ascia',
			weight = 50.0,
			durability = 0.06,
		},

		['WEAPON_BOTTLE'] = {
			label = 'Bottle',
			weight = 175.0,
			durability = 0.04,
		},

		['WEAPON_BULLPUPRIFLE'] = {
			label = 'Bullpup Rifle',
			weight = 1450.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_BULLPUPRIFLE_MK2'] = {
			label = 'Bullpup Rifle MK2',
			weight = 1450.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_BULLPUPSHOTGUN'] = {
			label = 'Bullpup Shotgun',
			weight = 1550.0,
			durability =0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_BZGAS'] = {
			label = 'BZ Gas',
			weight = 300.0,
			throwable = true,
		},

		['WEAPON_CARBINERIFLE'] = {
			label = 'Carbine Rifle',
			weight = 1550.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_CARBINERIFLE_MK2'] = {
			label = 'Carabina MK2',
			weight = 1500.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_CERAMICPISTOL'] = {
			label = 'Ceramic Pistol',
			weight = 400.0,
			durability =0.015,
			ammoname = 'ammo-9'
		},

		['WEAPON_PISTOLXM3'] = {
			label = 'WM 29 Pistol',
			weight = 484.5,
			durability =0.015,
			ammoname = 'ammo-9'
		},

		['WEAPON_COMBATMG'] = {
			label = 'Combat MG',
			weight = 3750.0,
			durability = 0.025,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_COMBATMG_MK2'] = {
			label = 'Combat MG MK2',
			weight = 4000.0,
			durability = 0.025,
			ammoname = 'ammo-rifle2'
		},

		['WEAPON_COMBATPDW'] = {
			label = 'Combat PDW',
			weight = 1150.0,
			durability = 0.017,
			ammoname = 'ammo-9'
		},

		['WEAPON_COMBATPISTOL'] = {
			label = 'Combat Pistol',
			weight = 392.5,
			durability =0.015,
			ammoname = 'ammo-9'
		},

		['WEAPON_COMBATSHOTGUN'] = {
			label = 'Combat Shotgun',
			weight = 2200.0,
			durability =0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_COMPACTLAUNCHER'] = {
			label = 'Compact Grenade Launcher',
			weight = 1250.0,
			durability = 0.03,
			ammoname = 'ammo-grenade'
		},

		['WEAPON_COMPACTRIFLE'] = {
			label = 'Compact Rifle',
			weight = 1800.0,
			durability = 0.012,
			ammoname = 'ammo-rifle2'
		},

	['WEAPON_DIGISCANNER'] = {    label = 'Digiscanner',    weight = 1000,    durability = 0.0,},
	['WEAPON_CROWBAR'] = {    label = 'Piede di porco',    weight = 2500,    durability = 0.1,},

		['WEAPON_DAGGER'] = {
			label = 'Pugnale',
			weight = 400.0,
			durability = 0.04,
		},

		['WEAPON_DBSHOTGUN'] = {
			label = 'Double Barrel Shotgun',
			weight = 1587.5,
			durability =0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_DOUBLEACTION'] = {
			label = 'Double Action Revolver',
			weight = 470.0,
			durability =0.018,
			ammoname = 'ammo-38'
		},

		['WEAPON_EMPLAUNCHER'] = {
			label = 'Compact EMP Launcher',
			weight = 1375.0,
			durability =0.03,
			ammoname = 'ammo-emp'
		},


		['WEAPON_FIREWORK'] = {
			label = 'Firework Launcher',
			weight = 500.0,
			durability = 0.03,
			ammoname = 'ammo-firework'
		},

		['WEAPON_FLARE'] = {
			label = 'Flare',
			weight = 125.0,
			throwable = true,
		},

		['WEAPON_FLAREGUN'] = {
			label = 'Flare Gun',
			weight = 500.0,
			durability = 0.025,
			ammoname = 'ammo-flare'
		},

		['WEAPON_FLASHLIGHT'] = {
			label = 'Torcia',
			weight = 62.5,
			durability = 0.03,
		},
	['WEAPON_FLASHBANG'] = {
			label = 'Granata Stordente',
			weight = 62.5,
			throwable = true,
		},
		['WEAPON_GOLFCLUB'] = {
			label = 'Golf Club',
			weight = 165.0,
			durability = 0.06,
		},

		['WEAPON_GRENADE'] = {
			label = 'Grenata',
			weight = 200.0,
			throwable = true,
		},

		['WEAPON_GRENADELAUNCHER'] = {
			label = 'Grenade Launcher',
			weight = 3250.0,
			durability = 0.03,
			ammoname = 'ammo-grenade'
		},

		['WEAPON_GUSENBERG'] = {
			label = 'Gusenberg',
			weight = 2450.0,
			durability = 0.025,
			ammoname = 'ammo-45'
		},

		['WEAPON_HAMMER'] = {
			label = 'Hammer',
			weight = 600.0,
			durability = 0.06,
		},

		['WEAPON_HATCHET'] = {
			label = 'Hatchet',
			weight = 500.0,
			durability = 0.06,
		},

		['WEAPON_HEAVYRIFLE'] = {
			label = 'Heavy Rifle',
			weight = 1650.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_HAZARDCAN'] = {
			label = 'Hazard Can',
			weight = 6000.0,
			durability = 0.04,
		},

		['WEAPON_METALDETECTOR'] = {
			label = 'Metal Detector',
			weight = 600.0,
			durability = 0.08,
		},

		['WEAPON_HOMINGLAUNCHER'] = {
			label = 'Homing Launcher',
			weight = 5000.0,
			durability = 0.03,
			ammoname = 'ammo-rocket'
		},

		['WEAPON_FERTILIZERCAN'] = {
			label = 'Fertilizer Can',
			weight = 6000.0,
			durability = 0.04,
		},

		['WEAPON_HEAVYPISTOL'] = {
			label = 'Heavy Pistol',
			weight = 550.0,
			durability =0.018,
			ammoname = 'ammo-45'
		},

		['WEAPON_HEAVYSHOTGUN'] = {
			label = 'Heavy Shotgun',
			weight = 1800.0,
			durability = 0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_HEAVYSNIPER'] = {
			label = 'Heavy Sniper',
			weight = 6350.0,
			durability = 0.01,
			ammoname = 'ammo-heavysniper'
		},

		['WEAPON_HEAVYSNIPER_MK2'] = {
			label = 'Heavy Sniper MK2',
			weight = 7000.0,
			durability = 0.01,
			ammoname = 'ammo-heavysniper'
		},

		['WEAPON_KNIFE'] = {
			label = 'Coltello',
			weight = 150.0,
			durability = 0.04,
		},

		['WEAPON_KNUCKLE'] = {
			label = 'Tirapugni',
			weight = 150.0,
			durability = 0.04,
		},

		['WEAPON_MACHETE'] = {
			label = 'Machete',
			weight = 500.0,
			durability = 0.06,
		},

		['WEAPON_MACHINEPISTOL'] = {
			label = 'Machine Pistol',
			weight = 700.0,
			durability = 0.017,
			ammoname = 'ammo-9'
		},

		['WEAPON_MARKSMANPISTOL'] = {
			label = 'Marksman Pistol',
			weight = 794.0,
			durability = 0.018,
			ammoname = 'ammo-22'
		},

		['WEAPON_MARKSMANRIFLE'] = {
			label = 'Marksman Rifle',
			weight = 3750.0,
			durability =0.01,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_MARKSMANRIFLE_MK2'] = {
			label = 'Marksman Rifle MK2',
			weight = 2000.0,
			durability =0.01,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_MG'] = {
			label = 'Machine Gun',
			weight = 4500.0,
			durability = 0.025,
			ammoname = 'ammo-rifle2'
		},

		['WEAPON_MINIGUN'] = {
			label = 'Minigun',
			weight = 19250.0,
			durability = 0.025,
			ammoname = 'ammo-rifle2'
		},

		['WEAPON_MICROSMG'] = {
			label = 'Micro SMG',
			weight = 1500.0,
			durability = 0.017,
			ammoname = 'ammo-45'
		},

		['WEAPON_MILITARYRIFLE'] = {
			label = 'Military Rifle',
			weight = 1800.0,
			durability =0.017,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_MINISMG'] = {
			label = 'Mini SMG',
			weight = 635.0,
			durability = 0.017,
			ammoname = 'ammo-9'
		},

		['WEAPON_MOLOTOV'] = {
			label = 'Molotov',
			weight = 900.0,
			throwable = true,
		},

		['WEAPON_MUSKET'] = {
			label = 'Musket',
			weight = 2250.0,
			durability = 0.015,
			ammoname = 'ammo-musket'
		},

		['WEAPON_NAVYREVOLVER'] = {
			label = 'Navy Revolver',
			weight = 2000.0,
			durability =0.018,
			ammoname = 'ammo-44'
		},

		['WEAPON_NIGHTSTICK'] = {
			label = 'Manganello',
			weight = 500.0,
			durability = 0.06,
		},

		['WEAPON_PETROLCAN'] = {
			label = 'Tanica',
			weight = 10.0,
			durability = 0.04,
		},

		['WEAPON_GADGETPISTOL'] = {
			label = 'Perico Pistol',
			weight = 875.0,
			durability = 0.015,
			ammoname = 'ammo-9'
		},

		['WEAPON_PIPEBOMB'] = {
			label = 'Pipe Bomb',
			weight = 900.0,
			throwable = true,
		},

		['WEAPON_PISTOL'] = {
			label = 'Glock 17',
			weight = 400.0,
			durability = 0.015,
			ammoname = 'ammo-9',
		},

		['WEAPON_PISTOL50'] = {
			label = 'Glock 22',
			weight = 450.0,
			durability = 0.018,
			ammoname = 'ammo-50'
		},

		['WEAPON_PISTOL_MK2'] = {
			label = 'Pistol MK2',
			weight = 500.0,
			durability = 0.015,
			ammoname = 'ammo-9'
		},

		['WEAPON_POOLCUE'] = {
			label = 'Piccone Normale',
			weight = 73.0,
			durability = 0.06,
		},

		['WEAPON_CANDYCANE'] = {
			label = 'Candy Cane',
			weight = 42.5,
			durability = 0.05,
		},

		['WEAPON_PROXMINE'] = {
			label = 'Proximity Mine',
			weight = 1250.0,
			throwable = true,
		},

		['WEAPON_PUMPSHOTGUN'] = {
			label = 'Fucile a pompa',
			weight = 1700.0,
			durability = 0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_PUMPSHOTGUN_MK2'] = {
			label = 'Pump Shotgun MK2',
			weight = 1600.0,
			durability = 0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_RAILGUN'] = {
			label = 'Railgun',
			weight = 1785.0,
			durability = 0.03,
			ammoname = 'ammo-railgun'
		},

		['WEAPON_RAILGUNXM3'] = {
			label = 'Railgun XM3',
			weight = 1785.0,
			durability = 0.03,
			ammoname = 'ammo-railgun'
		},

		['WEAPON_RAYCARBINE'] = {
			label = 'Unholy Hellbringer',
			weight = 1810.0,
			durability =0.03,
			ammoname = 'ammo-laser'
		},

		['WEAPON_RAYPISTOL'] = {
			label = 'Up-n-Atomizer',
			weight = 770.0,
			durability = 0.03
		},

		['WEAPON_REVOLVER'] = {
			label = 'Revolver',
			weight = 1130.0,
			durability = 0.018,
			ammoname = 'ammo-44'
		},

		['WEAPON_REVOLVER_MK2'] = {
			label = 'Revolver MK2',
			weight = 1300.0,
			durability = 0.018,
			ammoname = 'ammo-44'
		},
--[[
		['WEAPON_RPG'] = {
			label = 'RPG',
			weight = 2500.0,
			durability = 0.03,
			ammoname = 'ammo-rocket'
		},
]]
		['WEAPON_SAWNOFFSHOTGUN'] = {
			label = 'Sawn Off Shotgun',
			weight = 1190.0,
			durability = 0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_SMG'] = {
			label = 'SMG',
			weight = 1542.0,
			durability = 0.017,
			ammoname = 'ammo-9'
		},

		['WEAPON_SMG_MK2'] = {
			label = 'SMG Mk2',
			weight = 1350.0,
			durability = 0.017,
			ammoname = 'ammo-9'
		},

		['WEAPON_SMOKEGRENADE'] = {
			label = 'Smoke Grenade',
			weight = 300.0,
			throwable = true,
		},

		['WEAPON_SNIPERRIFLE'] = {
			label = 'Cecchino',
			weight = 2500.0,
			durability = 0.01,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_SNOWBALL'] = {
			label = 'Snow Ball',
			weight = 2.5,
			throwable = true,
		},
			['ammo-acid'] = {
				label = 'acid',
			weight = 2.5,
		},
		['WEAPON_SNSPISTOL'] = {
			label = 'SNS Pistol',
			weight = 232.5,
			durability = 0.015,
			ammoname = 'ammo-45'
		},

		['WEAPON_SNSPISTOL_MK2'] = {
			label = 'SNS Pistol MK2',
			weight = 232.5,
			durability = 0.015,
			ammoname = 'ammo-45'
		},

		['WEAPON_SPECIALCARBINE'] = {
			label = 'Special Carbine',
			weight = 1500.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_SPECIALCARBINE_MK2'] = {
			label = 'Special Carbine MK2',
			weight = 1685.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_STICKYBOMB'] = {
			label = 'Sticky Bomb',
			weight = 500.0,
			throwable = true,
		},

		['WEAPON_STONE_HATCHET'] = {
			label = 'Stone Hatchet',
			weight = 400.0,
			durability = 0.06,
		},

		['WEAPON_STUNGUN'] = {
			label = 'Teaser',
			weight = 113.5,
			durability = 0.018,
		},

		['WEAPON_AUTOSHOTGUN'] = {
			label = 'Sweeper Shotgun',
			weight = 2200.0,
			durability = 0.02,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_SWITCHBLADE'] = {
			label = 'Switchblade',
			weight = 150.0,
			durability = 0.04,
			anim = { 'anim@melee@switchblade@holster', 'unholster', 200, 'anim@melee@switchblade@holster', 'holster', 600 },
		},

		['WEAPON_VINTAGEPISTOL'] = {
			label = 'Vintage Pistol',
			weight = 350.0,
			durability = 0.015,
			ammoname = 'ammo-9'
		},

		['WEAPON_RAYMINIGUN'] = {
			label = 'Widowmaker',
			weight = 3500.0,
			durability = 0.03,
			ammoname = 'ammo-laser'
		},

		['WEAPON_WRENCH'] = {
			label = 'Wrench',
			weight = 1250.0,
			durability = 0.06,
		},

		['WEAPON_PRECISIONRIFLE'] = {
			label = 'Precision Rifle',
			weight = 2400.0,
			durability =0.01,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_TACTICALRIFLE'] = {
			label = 'Tactical Rifle',
			weight = 1700.0,
			durability =0.012,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_TEARGAS'] = {
			label = 'Tear Gas',
			weight = 300.0,
			throwable = true,
		},
	},

	Components = {
		['at_flashlight'] = {
			label = 'Tactical Flashlight',
			weight = 60.0,
			type = 'flashlight',
			client = {
				component = {
					`COMPONENT_AT_AR_FLSH`,
					`COMPONENT_AT_AR_FLSH_REH`,
					`COMPONENT_AT_PI_FLSH`,
					`COMPONENT_AT_PI_FLSH_02`,
					`COMPONENT_AT_PI_FLSH_03`,
				},
				usetime = 2500
			}
		},

		['at_suppressor_light'] = {
			label = 'Suppressor',
			weight = 140.0,
			type = 'muzzle',
			client = {
                image = 'at_suppressor.png',
				component = {
					`COMPONENT_AT_PI_SUPP`,
					`COMPONENT_AT_PI_SUPP_02`,
					`COMPONENT_CERAMICPISTOL_SUPP`,
					`COMPONENT_PISTOLXM3_SUPP`
				},
				usetime = 2500
			}
		},

		['at_suppressor_heavy'] = {
			label = 'Tactical Suppressor',
			weight = 140.0,
			type = 'muzzle',
			client = {
                image = 'at_suppressor.png',
				component = {
					`COMPONENT_AT_AR_SUPP`,
					`COMPONENT_AT_AR_SUPP_02`,
					`COMPONENT_AT_SR_SUPP`,
					`COMPONENT_AT_SR_SUPP_03`,
				},
				usetime = 2500
			}
		},

		['at_grip'] = {
			label = 'Grip',
			type = 'grip',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_AR_AFGRIP`,
					`COMPONENT_AT_AR_AFGRIP_02`
				},
				usetime = 2500
			}
		},

		['at_barrel'] = {
			label = 'Heavy Barrel',
			type = 'barrel',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_AR_BARREL_02`,
					`COMPONENT_AT_BP_BARREL_02`,
					`COMPONENT_AT_CR_BARREL_02`,
					`COMPONENT_AT_MG_BARREL_02`,
					`COMPONENT_AT_MRFL_BARREL_02`,
					`COMPONENT_AT_SB_BARREL_02`,
					`COMPONENT_AT_SC_BARREL_02`,
					`COMPONENT_AT_SR_BARREL_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_extended_pistol'] = {
			label = 'Extended Pistol Clip',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_extended.png',
				component = {
					`COMPONENT_APPISTOL_CLIP_02`,
					`COMPONENT_CERAMICPISTOL_CLIP_02`,
					`COMPONENT_COMBATPISTOL_CLIP_02`,
					`COMPONENT_HEAVYPISTOL_CLIP_02`,
					`COMPONENT_PISTOL_CLIP_02`,
					`COMPONENT_PISTOL_MK2_CLIP_02`,
					`COMPONENT_PISTOL50_CLIP_02`,
					`COMPONENT_SNSPISTOL_CLIP_02`,
					`COMPONENT_SNSPISTOL_MK2_CLIP_02`,
					`COMPONENT_VINTAGEPISTOL_CLIP_02`,
                    `COMPONENT_TECPISTOL_CLIP_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_extended_smg'] = {
			label = 'Extended SMG Clip',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_extended.png',
				component = {
					`COMPONENT_ASSAULTSMG_CLIP_02`,
					`COMPONENT_COMBATPDW_CLIP_02`,
					`COMPONENT_MACHINEPISTOL_CLIP_02`,
					`COMPONENT_MICROSMG_CLIP_02`,
					`COMPONENT_MINISMG_CLIP_02`,
					`COMPONENT_SMG_CLIP_02`,
					`COMPONENT_SMG_MK2_CLIP_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_extended_shotgun'] = {
			label = 'Extended Shotgun Clip',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_extended2.png',
				component = {
					`COMPONENT_ASSAULTSHOTGUN_CLIP_02`,
					`COMPONENT_HEAVYSHOTGUN_CLIP_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_extended_rifle'] = {
			label = 'Extended Rifle Clip',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_extended2.png',
				component = {
					`COMPONENT_ADVANCEDRIFLE_CLIP_02`,
					`COMPONENT_ASSAULTRIFLE_CLIP_02`,
					`COMPONENT_ASSAULTRIFLE_MK2_CLIP_02`,
					`COMPONENT_BULLPUPRIFLE_CLIP_02`,
					`COMPONENT_BULLPUPRIFLE_MK2_CLIP_02`,
					`COMPONENT_CARBINERIFLE_CLIP_02`,
					`COMPONENT_CARBINERIFLE_MK2_CLIP_02`,
					`COMPONENT_COMPACTRIFLE_CLIP_02`,
					`COMPONENT_HEAVYRIFLE_CLIP_02`,
					`COMPONENT_MILITARYRIFLE_CLIP_02`,
					`COMPONENT_SPECIALCARBINE_CLIP_02`,
					`COMPONENT_SPECIALCARBINE_MK2_CLIP_02`,
					`COMPONENT_TACTICALRIFLE_CLIP_02`,
					`COMPONENT_BATTLERIFLE_CLIP_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_extended_mg'] = {
			label = 'Extended MG Clip',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_drum.png',
				component = {
					`COMPONENT_GUSENBERG_CLIP_02`,
					`COMPONENT_MG_CLIP_02`,
					`COMPONENT_COMBATMG_CLIP_02`,
					`COMPONENT_COMBATMG_MK2_CLIP_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_extended_sniper'] = {
			label = 'Extended Sniper Clip',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_extended2.png',
				component = {
					`COMPONENT_HEAVYSNIPER_MK2_CLIP_02`,
					`COMPONENT_MARKSMANRIFLE_CLIP_02`,
					`COMPONENT_MARKSMANRIFLE_MK2_CLIP_02`,
				},
				usetime = 2500
			}
		},

		['at_clip_drum_smg'] = {
			label = 'SMG Drum',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_drum.png',
				component = {
					`COMPONENT_COMBATPDW_CLIP_03`,
					`COMPONENT_MACHINEPISTOL_CLIP_03`,
					`COMPONENT_SMG_CLIP_03`,
				},
				usetime = 2500
			}
		},

		['at_clip_drum_shotgun'] = {
			label = 'Shotgun Drum',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_drum.png',
				component = {
					`COMPONENT_HEAVYSHOTGUN_CLIP_03`
				},
				usetime = 2500
			}
		},

		['at_clip_drum_rifle'] = {
			label = 'Rifle Drum',
			type = 'magazine',
			weight = 140.0,
			client = {
                image = 'at_clip_drum.png',
				component = {
					`COMPONENT_ASSAULTRIFLE_CLIP_03`,
					`COMPONENT_COMPACTRIFLE_CLIP_03`,
					`COMPONENT_CARBINERIFLE_CLIP_03`,
					`COMPONENT_SPECIALCARBINE_CLIP_03`,
				},
				usetime = 2500
			}
		},

		['at_compensator'] = {
			label = 'Compensator',
			type = 'muzzle',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_PI_COMP`,
					`COMPONENT_AT_PI_COMP_02`,
					`COMPONENT_AT_PI_COMP_03`
				},
				usetime = 2500
			}
		},

		['at_scope_macro'] = {
			label = 'Macro Scope',
			type = 'sight',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_MACRO`,
					`COMPONENT_AT_SCOPE_MACRO_02`,
					`COMPONENT_AT_SCOPE_MACRO_MK2`,
					`COMPONENT_AT_SCOPE_MACRO_02_MK2`,
					`COMPONENT_AT_SCOPE_MACRO_02_SMG_MK2`
				},
				usetime = 2500
			}
		},

		['at_scope_small'] = {
			label = 'Small Scope',
			type = 'sight',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_SMALL`,
					`COMPONENT_AT_SCOPE_SMALL_02`,
					`COMPONENT_AT_SCOPE_SMALL_MK2`,
					`COMPONENT_AT_SCOPE_SMALL_SMG_MK2`
				},
				usetime = 2500
			}
		},

		['at_scope_medium'] = {
			label = 'Medium Scope',
			type = 'sight',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_MEDIUM`,
					`COMPONENT_AT_SCOPE_MEDIUM_MK2`
				},
				usetime = 2500
			}
		},

		['at_scope_large'] = {
			label = 'Large Scope',
			type = 'sight',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_LARGE_MK2`
				},
				usetime = 2500
			}
		},

		['at_scope_advanced'] = {
			label = 'Advanced Scope',
			type = 'sight',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_MAX`
				},
				usetime = 2500
			}
		},

		['at_scope_nv'] = {
			label = 'NV Scope',
			type = 'sight',
			weight = 210.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_NV`
				},
				usetime = 2500
			}
		},

		['at_scope_thermal'] = {
			label = 'Thermal Scope',
			type = 'sight',
			weight = 210.0,
			client = {
				component = {
					`COMPONENT_AT_SCOPE_THERMAL`
				},
				usetime = 2500
			}
		},

		['at_scope_holo'] = {
			label = 'Holographic Sight',
			type = 'sight',
			weight = 140.0,
			client = {
				component = {
					`COMPONENT_AT_PI_RAIL`,
					`COMPONENT_AT_PI_RAIL_02`,
					`COMPONENT_AT_SIGHTS`,
					`COMPONENT_AT_SIGHTS_SMG`
				},
				usetime = 2500
			}
		},

		['at_muzzle_flat'] = {
			label = 'Flat Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_01`
				},
				usetime = 2500
			}
		},

		['at_muzzle_tactical'] = {
			label = 'Tactical Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_02`
				},
				usetime = 2500
			}
		},

		['at_muzzle_fat'] = {
			label = 'Fat Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_03`
				},
				usetime = 2500
			}
		},

		['at_muzzle_precision'] = {
			label = 'Precision Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_04`
				},
				usetime = 2500
			}
		},

		['at_muzzle_heavy'] = {
			label = 'Heavy Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_05`
				},
				usetime = 2500
			}
		},

		['at_muzzle_slanted'] = {
			label = 'Slanted Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_06`
				},
				usetime = 2500
			}
		},

		['at_muzzle_split'] = {
			label = 'Split Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_07`
				},
				usetime = 2500
			}
		},

		['at_muzzle_squared'] = {
			label = 'Squared Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_08`
				},
				usetime = 2500
			}
		},

		['at_muzzle_bell'] = {
			label = 'Bell Muzzle',
			type = 'muzzle',
			weight = 40.0,
			client = {
				component = {
					`COMPONENT_AT_MUZZLE_09`
				},
				usetime = 2500
			}
		},

		['at_skin_luxe'] = {
			label = 'Luxury Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_VARMOD_LUXE`,
					`COMPONENT_ASSAULTSMG_VARMOD_LOWRIDER`,
					`COMPONENT_CARBINERIFLE_VARMOD_LUXE`,
					`COMPONENT_COMBATPISTOL_VARMOD_LOWRIDER`,
					`COMPONENT_MARKSMANRIFLE_VARMOD_LUXE`,
					`COMPONENT_MG_VARMOD_LOWRIDER`,
					`COMPONENT_MICROSMG_VARMOD_LUXE`,
					`COMPONENT_PISTOL_VARMOD_LUXE`,
					`COMPONENT_PUMPSHOTGUN_VARMOD_LOWRIDER`,
					`COMPONENT_SMG_VARMOD_LUXE`
				},
				usetime = 2500
			}
		},

		['at_skin_wood'] = {
			label = 'Wood Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_HEAVYPISTOL_VARMOD_LUXE`,
					`COMPONENT_SNIPERRIFLE_VARMOD_LUXE`,
					`COMPONENT_SNSPISTOL_VARMOD_LOWRIDER`
				},
				usetime = 2500
			}
		},

		['at_skin_metal'] = {
			label = 'Metal Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ADVANCEDRIFLE_VARMOD_LUXE`,
					`COMPONENT_APPISTOL_VARMOD_LUXE`,
					`COMPONENT_BULLPUPRIFLE_VARMOD_LOW`,
					`COMPONENT_SAWNOFFSHOTGUN_VARMOD_LUXE`,
					`COMPONENT_SPECIALCARBINE_VARMOD_LOWRIDER`
				},
				usetime = 2500
			}
		},

		['at_skin_pearl'] = {
			label = 'Pearl Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_PISTOL50_VARMOD_LUXE`
				},
				usetime = 2500
			}
		},

		['at_skin_ballas'] = {
			label = 'Ballas Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_BALLAS`
				},
				usetime = 2500
			}
		},

		['at_skin_diamond'] = {
			label = 'Diamond Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_DIAMOND`
				},
				usetime = 2500
			}
		},

		['at_skin_dollar'] = {
			label = 'Dollar Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_DOLLAR`
				},
				usetime = 2500
			}
		},

		['at_skin_hate'] = {
			label = 'Hate Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_HATE`
				},
				usetime = 2500
			}
		},

		['at_skin_king'] = {
			label = 'King Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_KING`
				},
				usetime = 2500
			}
		},

		['at_skin_love'] = {
			label = 'Love Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_LOVE`
				},
				usetime = 2500
			}
		},

		['at_skin_pimp'] = {
			label = 'Pimp Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_PIMP`
				},
				usetime = 2500
			}
		},

		['at_skin_player'] = {
			label = 'Player Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_PLAYER`
				},
				usetime = 2500
			}
		},

		['at_skin_vagos'] = {
			label = 'Vagos Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_KNUCKLE_VARMOD_VAGOS`
				},
				usetime = 2500
			}
		},

		['at_skin_blagueurs'] = {
			label = 'Blagueurs Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3`
				},
				usetime = 2500
			}
		},

		['at_skin_splatter'] = {
			label = 'Splatter Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_01`
				},
				usetime = 2500
			}
		},

		['at_skin_bulletholes'] = {
			label = 'Bullet Holes Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_02`
				},
				usetime = 2500
			}
		},

		['at_skin_burgershot'] = {
			label = 'Burger Shot Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_03`
				},
				usetime = 2500
			}
		},

		['at_skin_cluckinbell'] = {
			label = 'Cluckin Bell Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_04`
				},
				usetime = 2500
			}
		},

		['at_skin_fatalincursion'] = {
			label = 'Fatal Incursion Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_05`
				},
				usetime = 2500
			}
		},

		['at_skin_luchalibre'] = {
			label = 'Lucha Libre Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_06`
				},
				usetime = 2500
			}
		},

		['at_skin_trippy'] = {
			label = 'Trippy Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_07`
				},
				usetime = 2500
			}
		},

		['at_skin_tiedye'] = {
			label = 'Tie-Dye Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_08`
				},
				usetime = 2500
			}
		},

		['at_skin_wall'] = {
			label = 'Wall Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_BAT_VARMOD_XM3_09`
				},
				usetime = 2500
			}
		},

		['at_skin_vip'] = {
			label = 'VIP Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_REVOLVER_VARMOD_BOSS`,
					`COMPONENT_SWITCHBLADE_VARMOD_VAR1`
				},
				usetime = 2500
			}
		},

		['at_skin_bodyguard'] = {
			label = 'Bodyguard Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_REVOLVER_VARMOD_GOON`,
					`COMPONENT_SWITCHBLADE_VARMOD_VAR2`
				},
				usetime = 2500
			}
		},

		['at_skin_festive'] = {
			label = 'Festive Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_RAYPISTOL_VARMOD_XMAS18`
				},
				usetime = 2500
			}
		},

		['at_skin_security'] = {
			label = 'Security Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_APPISTOL_VARMOD_SECURITY`,
					`COMPONENT_MICROSMG_VARMOD_SECURITY`,
				},
				usetime = 2500
			}
		},

		['at_skin_camo'] = {
			label = 'Camo Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO`,
					`COMPONENT_COMBATMG_MK2_CAMO`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO`,
					`COMPONENT_PISTOL_MK2_CAMO`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO`,
					`COMPONENT_REVOLVER_MK2_CAMO`,
					`COMPONENT_SMG_MK2_CAMO`,
					`COMPONENT_SNSPISTOL_MK2_CAMO`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO`,
				},
				usetime = 2500
			}
		},

		['at_skin_brushstroke'] = {
			label = 'Brushstroke Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_02`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_02`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_02`,
					`COMPONENT_COMBATMG_MK2_CAMO_02`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_02`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_02`,
					`COMPONENT_PISTOL_MK2_CAMO_02`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_02`,
					`COMPONENT_REVOLVER_MK2_CAMO_02`,
					`COMPONENT_SMG_MK2_CAMO_02`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_02`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_02`,
				},
				usetime = 2500
			}
		},

		['at_skin_woodland'] = {
			label = 'Woodland Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_03`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_03`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_03`,
					`COMPONENT_COMBATMG_MK2_CAMO_03`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_03`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_03`,
					`COMPONENT_PISTOL_MK2_CAMO_03`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_03`,
					`COMPONENT_REVOLVER_MK2_CAMO_03`,
					`COMPONENT_SMG_MK2_CAMO_03`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_03`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_03`,
				},
				usetime = 2500
			}
		},

		['at_skin_skull'] = {
			label = 'Skull Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_04`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_04`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_04`,
					`COMPONENT_COMBATMG_MK2_CAMO_04`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_04`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_04`,
					`COMPONENT_PISTOL_MK2_CAMO_04`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_04`,
					`COMPONENT_REVOLVER_MK2_CAMO_04`,
					`COMPONENT_SMG_MK2_CAMO_04`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_04`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_04`,
				},
				usetime = 2500
			}
		},

		['at_skin_sessanta'] = {
			label = 'Sessanta Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_05`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_05`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_05`,
					`COMPONENT_COMBATMG_MK2_CAMO_05`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_05`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_05`,
					`COMPONENT_PISTOL_MK2_CAMO_05`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_05`,
					`COMPONENT_REVOLVER_MK2_CAMO_05`,
					`COMPONENT_SMG_MK2_CAMO_05`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_05`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_05`,
				},
				usetime = 2500
			}
		},

		['at_skin_perseus'] = {
			label = 'Perseus Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_06`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_06`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_06`,
					`COMPONENT_COMBATMG_MK2_CAMO_06`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_06`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_06`,
					`COMPONENT_PISTOL_MK2_CAMO_06`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_06`,
					`COMPONENT_REVOLVER_MK2_CAMO_06`,
					`COMPONENT_SMG_MK2_CAMO_06`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_06`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_06`,
				},
				usetime = 2500
			}
		},

		['at_skin_leopard'] = {
			label = 'Leopard Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_07`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_07`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_07`,
					`COMPONENT_COMBATMG_MK2_CAMO_07`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_07`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_07`,
					`COMPONENT_PISTOL_MK2_CAMO_07`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_07`,
					`COMPONENT_REVOLVER_MK2_CAMO_07`,
					`COMPONENT_SMG_MK2_CAMO_07`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_07`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_07`,
				},
				usetime = 2500
			}
		},

		['at_skin_zebra'] = {
			label = 'Zebra Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_08`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_08`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_08`,
					`COMPONENT_COMBATMG_MK2_CAMO_08`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_08`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_08`,
					`COMPONENT_PISTOL_MK2_CAMO_08`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_08`,
					`COMPONENT_REVOLVER_MK2_CAMO_08`,
					`COMPONENT_SMG_MK2_CAMO_08`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_08`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_08`,
				},
				usetime = 2500
			}
		},

		['at_skin_geometric'] = {
			label = 'Geometric Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_09`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_09`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_09`,
					`COMPONENT_COMBATMG_MK2_CAMO_09`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_09`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_09`,
					`COMPONENT_PISTOL_MK2_CAMO_09`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_09`,
					`COMPONENT_REVOLVER_MK2_CAMO_09`,
					`COMPONENT_SMG_MK2_CAMO_09`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_09`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_09`,
				},
				usetime = 2500
			}
		},

		['at_skin_boom'] = {
			label = 'Boom Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_10`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_10`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_10`,
					`COMPONENT_COMBATMG_MK2_CAMO_10`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_10`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_10`,
					`COMPONENT_PISTOL_MK2_CAMO_10`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_10`,
					`COMPONENT_REVOLVER_MK2_CAMO_10`,
					`COMPONENT_SMG_MK2_CAMO_10`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_10`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_10`,
				},
				usetime = 2500
			}
		},

		['at_skin_patriotic'] = {
			label = 'Patriotic Weapon Kit',
			type = 'skin',
			weight = 25.0,
			client = {
				component = {
					`COMPONENT_ASSAULTRIFLE_MK2_CAMO_IND_01`,
					`COMPONENT_BULLPUPRIFLE_MK2_CAMO_IND_01`,
					`COMPONENT_CARBINERIFLE_MK2_CAMO_IND_01`,
					`COMPONENT_COMBATMG_MK2_CAMO_IND_01`,
					`COMPONENT_HEAVYSNIPER_MK2_CAMO_IND_01`,
					`COMPONENT_MARKSMANRIFLE_MK2_CAMO_IND_01`,
					`COMPONENT_PISTOL_MK2_CAMO_IND_01`,
					`COMPONENT_PUMPSHOTGUN_MK2_CAMO_IND_01`,
					`COMPONENT_REVOLVER_MK2_CAMO_IND_01`,
					`COMPONENT_SMG_MK2_CAMO_IND_01`,
					`COMPONENT_SNSPISTOL_MK2_CAMO_IND_01`,
					`COMPONENT_SPECIALCARBINE_MK2_CAMO_IND_01`,
				},
				usetime = 2500
			}
		},
	},

	Ammo = {
		['ammo-benzina'] = {
			label = 'Bottiglia di benzina',
			weight = 1.5,
		},
		['ammo-22'] = {
			label = '.22 Long Rifle',
			weight = 1.5,
		},
		['ammo-pistol'] = {
			label = 'Proiettili Paintball',
			weight = 1.5,
		},
		['ammo-38'] = {
			label = '.38 LC',
			weight = 7.5,
		},

		['ammo-44'] = {
			label = '.44 Magnum',
			weight = 8.0,
		},

		['ammo-45'] = {
			label = '.45 ACP',
			weight = 7.5,
		},

		['ammo-50'] = {
			label = '.50 AE',
			weight = 5.0,
		},

		['ammo-9'] = {
			label = '9mm',
			weight = 3.5,
		},

		['ammo-firework'] = {
			label = 'Firework',
			weight = 100.0,
		},

		['ammo-flare'] = {
			label = 'Flare round',
			weight = 19.0,
		},

		['ammo-grenade'] = {
			label = '40mm Explosive',
			weight = 200.0,
		},

		['ammo-heavysniper'] = {
			label = '.50 BMG',
			weight = 25.5,
		},

		['ammo-laser'] = {
			label = 'Laser charge',
			weight = 0.5,
		},

		['ammo-musket'] = {
			label = '.50 Ball',
			weight = 19.0,
		},

		['ammo-railgun'] = {
			label = 'Railgun charge',
			weight = 75.0,
		},

		['ammo-rifle'] = {
			label = '5.56x45',
			weight = 2.0,
		},

		['ammo-rifle2'] = {
			label = '7.62x39',
			weight = 4.0,
		},

		['ammo-rocket'] = {
			label = 'Rocket',
			weight = 250.0,
		},

		['ammo-shotgun'] = {
			label = '12 Gauge',
			weight = 19.0,
		},

		['ammo-sniper'] = {
			label = '7.62x51',
			weight = 4.5,
		},

		['ammo-emp'] = {
			label = 'EMP round',
			weight = 200.0,
		},
	}
}

-- Server-authoritative dimensions. These are cell counts, not ox logical slots.
-- Keep the last 15 player slots reserved for this archive's pinkFrog clothing.
return {
    enabled = true,
    columns = 10,
    rows = { player = 12, stash = 20, trunk = 12, glovebox = 5, drop = 12, container = 10, default = 12 },
    quickSlots = 5,
    clothingSlots = 15,
    -- Relative to the last 15 slots in the supplied pinkFrog build.
    clothingByOffset = {'hat','ears','tshirt','torso','arms','legs','shoes','mask','glasses','chain','bproof','bags','watches','bra','panties'},
    weaponQuickSlots = { [1] = true, [2] = true },
    items = {
        water = {1, 2}, bandage = {1, 1}, phone = {1, 2}, radio = {1, 2},
        small_backpack = {3, 4}, medium_bag = {4, 4}, large_backpack = {4, 5},
        weapon_case = {5, 3}, storage_case = {4, 3},
        WEAPON_PISTOL = {2, 2}, WEAPON_COMBATPISTOL = {2, 2}, WEAPON_APPISTOL = {2, 2},
        WEAPON_SMG = {3, 2}, WEAPON_MICROSMG = {3, 2},
        WEAPON_CARBINERIFLE = {5, 2}, WEAPON_ASSAULTRIFLE = {5, 2},
        WEAPON_PUMPSHOTGUN = {5, 2}, WEAPON_SNIPERRIFLE = {6, 2},
        WEAPON_KNIFE = {1, 3}, WEAPON_BAT = {1, 5},
    },
    weaponDefault = {4, 2},
    defaultSize = {1, 1},
}

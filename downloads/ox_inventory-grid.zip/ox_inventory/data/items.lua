return {


	['backpack'] = {
		label = 'Zaino aggiuntivo',
		weight = 5000,
		stack = true,
		close = true,
		description = 'Aggiunge slot e capacità di carico',
		rarity = 'unique', -- can be unique, rare, epic, legendary, mythic
	},

	['extrabag'] = {
		label = 'Borsa aggiuntiva',
		weight = 7000,
		stack = true,
		close = true,
		description = 'Aggiunge slot e capacità di carico',
		rarity = 'epic', -- can be unique, rare, epic, legendary, mythic
		canThrow = true, -- if true, then you can throw this item (only if Config.throwingSettings.enable = true in pinkFrog_inventoryAddon/config.lua)
		-- if you enable canThrow without prop it's going to use default prop of bag 
		propThrow = 'prop_nigel_bag_pickup', -- prop to show when you throw item (only if canThrow = true) 
		client = {
		   image = 'bags.png',
		}
	},

	['bag_clothes'] = {
		label = 'Borsa per vestiti',
		weight = 1000,
		stack = false,
		close = true,
		consume = 0,
		description = 'Una borsa elegante per trasportare i tuoi vestiti',
		rarity = 'rare', -- can be unique, rare, epic, legendary, mythic
		canRename = true, -- if true, then you can rename this item (only if Config.canRenameAllItems = false in config.lua)
	    canChangeDescription = true, -- if true, then you can change description for this item (only if Config.canChangeDescription = false in config.lua)
		canThrow = true, -- if true, then you can throw this item (only if Config.throwingSettings.enable = true in pinkFrog_inventoryAddon/config.lua)
		canPlaceOnGround = true, -- if true, then you can place this item on the ground and takes prop from propThrow
		propThrow = 'prop_nigel_bag_pickup', -- prop to show when you throw item (only if canThrow = true)
		client = {
			export = 'pinkFrog_inventoryAddon.useBagClothes',
		},
	},

	-- it's exmample you can register as many items as you want below
  ['plate_armor'] = {
	label = 'Piastra balistica',
	weight = 100,
	stack = true,
	close = true,
	rarity = 'rare',
	consume = 0,
	description = 'Aggiunge 50 punti di protezione al giubbotto antiproiettile',
	client = {
		   export = 'pinkFrog_inventoryAddon.fasterUsePlate',
	},
  },

 
  ['plate_reinforced'] = {
	label = 'Piastra balistica rinforzata',
	weight = 100,
	stack = true,
	close = true,
	rarity = 'rare',
	consume = 0,
	description = 'Aggiunge 75 punti di protezione al giubbotto antiproiettile',
	client = {
		   image = 'plate_armor.png',
		   export = 'pinkFrog_inventoryAddon.fasterUsePlate',
	},
   },

    
  ['plate_military'] = {
	label = 'Piastra balistica militare',
	weight = 100,
	stack = true,
	close = true,
	rarity = 'rare',
	consume = 0,
	description = 'Aggiunge 100 punti di protezione al giubbotto antiproiettile',
	client = {
		   image = 'plate_armor.png',
		   export = 'pinkFrog_inventoryAddon.fasterUsePlate',
	},
},


	-- You need to add the following items to your ox_inventory/data/items.lua file
['hat'] = {
	label = 'Cappello',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
	buttons = {      
		
        {
            label = 'Nascondi capelli', -- additional button to hide hair
            action = function(slot) 
                TriggerEvent('pinkFrog:repairFivemBrokenModels', slot, 'hat', 'clear')
            end
        },
        {
            label = 'Mostra capelli',
            action = function(slot)
                TriggerEvent('pinkFrog:repairFivemBrokenModels', slot, 'hat', 'restore')
            end
        },
    },
},

['ears'] = {
		label = 'Orecchini',
		weight = 100,
		stack = true,
		close = true,
		description = nil,

},
	
['tshirt'] = {
	label = 'Maglietta',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
},



['torso'] = {
	label = 'Busto',
	weight = 0,
	stack = false,
	close = true,
	description = nil,
},


['arms'] = {
	label = 'Braccia',
	weight = 100,
	stack = true,
	close = true,
	description = nil,
},

['legs'] = {
	label = 'Pantaloni',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
},


['shoes'] = {
	label = 'Scarpe',
	weight = 100,
	stack = false,
	close = true,
	description = nil,	
},

['mask'] = {
    label = 'Maschera',              
    weight = 100,           
    stack = false,                 
    close = true,                   
    description = nil,             
    buttons = {           
        {
            label = 'Nascondi viso', -- additional button to hide face
            action = function(slot) 
                TriggerEvent('pinkFrog:repairFivemBrokenModels', slot, 'mask', 'clear')
            end
        },
        {
            label = 'Mostra viso',
            action = function(slot)
                TriggerEvent('pinkFrog:repairFivemBrokenModels', slot, 'mask', 'restore')
            end
        },
    },
},

['chain'] = {
	label = 'Collana',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
},


['glasses'] = {
	label = 'Occhiali',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
},


['bproof'] = {
	label = 'Giubbotto antiproiettile',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
	   buttons = {           
        {
            label = 'Aggiungi una piastra', -- additional button to add plate
            action = function(slot) 
                TriggerEvent('pinkFrog:addPlateToBproof', slot)
            end
        },
	},
},


['bags'] = {
	label = 'Borsa',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
},

['watches'] = {
	label = 'Orologi',
	weight = 100,
	stack = false,
	close = true,
	description = nil,
},

  ['radio'] = {
		label = 'Radio',
		weight = 1000,
		stack = false,
		consume = 0,
		close = true,
		durability = 0.1,
		canThrow = true, -- if true, then you can throw this item (only if Config.throwingSettings.enable = true in pinkFrog_inventoryAddon/config.lua)
		propThrow = 'prop_cs_hand_radio', -- prop to show when you throw item (only if canThrow = true)
		description = 'Serve per utilizzare la radio',
		client = {
			export = 'pinkFrog_radioList.useRadio',
		},
	},



    ["rappel"] = {
    label = "Corda da discesa",
    weight = 180,
},

["zipline"] = {
    label = "Teleferica",
    weight = 180,
},
    -- Bottiglie per devcore_needs
    ['bottiglia_rum'] = {
        label = 'Bottiglia di Rum', weight = 1000, stack = false, close = true, consume = 0,
        client = { export = 'devcore_needs.useConsumeItem' },
    },
    ['bottiglia_vodka'] = {
        label = 'Bottiglia di Vodka', weight = 1000, stack = false, close = true, consume = 0,
        client = { export = 'devcore_needs.useConsumeItem' },
    },
    ['bottiglia_tequila'] = {
        label = 'Bottiglia di Tequila', weight = 1000, stack = false, close = true, consume = 0,
        client = { export = 'devcore_needs.useConsumeItem' },
    },
    ['bottiglia_whisky'] = {
        label = 'Bottiglia di Whisky', weight = 1000, stack = false, close = true, consume = 0,
        client = { export = 'devcore_needs.useConsumeItem' },
    },
    ['bottiglia_cognac'] = {
        label = 'Bottiglia di Cognac', weight = 1000, stack = false, close = true, consume = 0,
        client = { export = 'devcore_needs.useConsumeItem' },
    },
    ['bottiglia_grappa'] = {
        label = 'Bottiglia di Grappa', weight = 1000, stack = false, close = true, consume = 0,
        client = { export = 'devcore_needs.useConsumeItem' },
    },

["hooked_rope"] = {
    label = "Corda con gancio",
    weight = 180,
},

["lasso"] = {
    label = "Lazo",
    weight = 180,
},

["grappel_gun_black"] = {
    label = "Pistola rampino (Nera)",
    weight = 180,
},

["grappel_gun_green"] = {
    label = "Pistola rampino (Verde)",
    weight = 180,
},

["grappel_gun_gold"] = {
    label = "Pistola rampino (Dorata)",
    weight = 180,
},

["grappel_gun_pink"] = {
    label = "Pistola rampino (Rosa)",
    weight = 180,
},

["grappel_gun_army"] = {
    label = "Pistola rampino (Militare)",
    weight = 180,
},

["grappel_gun_police"] = {
    label = "Pistola rampino (Polizia)",
    weight = 180,
},

["grappel_gun_orange"] = {
    label = "Pistola rampino (Arancione)",
    weight = 180,
},

["grappel_gun_red"] = {
    label = "Pistola rampino (Rossa)",
    weight = 180,
},

["grappel_gun_blue"] = {
    label = "Pistola rampino (Blu)",
    weight = 180,
},
['redwood_pack'] = {
	label = 'Pacchetto di sigarette Redwood',
	stack = false,
	weight = 50,
	close = true,
	client = {
		export = 'devcore_smoke.OpenCigPack'
	}
},

['foglie_verdi'] = {
    label = 'Foglie Verdi',
    weight = 1,
    stack = true,
    close = true,
    description = 'Foglie di tabacco appena raccolte, ancora fresche.',
 
},

['foglie_secche'] = {
    label = 'Foglie Secche',
    weight = 1,
    stack = true,
    close = true,
    description = 'Foglie di tabacco essiccate, pronte per essere lavorate.',
  
},
['frontiera_rossa_pack'] = {
    label = 'Pacchetto Frontiera Rossa',
    stack = true,
    weight = 50,
    close = true,
    client = {
        export = 'devcore_smoke.OpenCigPack'
    }
},

['cig_frontiera_rossa'] = {
    label = 'Sigaretta Frontiera Rossa',
    stack = true,
    weight = 20,
    close = true,
    client = {
        export = 'devcore_smoke.StartPlayerSmoking'
    }
},

['adriatica_nera_pack'] = {
    label = 'Pacchetto Adriatica Nera',
    stack = true,
    weight = 50,
    close = true,
    client = {
        export = 'devcore_smoke.OpenCigPack'
    }
},

['cig_adriatica_nera'] = {
    label = 'Sigaretta Adriatica Nera',
    stack = true,
    weight = 20,
    close = true,
    client = {
        export = 'devcore_smoke.StartPlayerSmoking'
    }
},

['marlboro_pack'] = {
	label = 'Pacchetto di sigarette Marlboro',
	stack = false,
	weight = 50,
	close = true,
	client = {
		export = 'devcore_smoke.OpenCigPack'
	}
},

['classic_lighter'] = {
	label = 'Accendino classico',
	stack = false,
	weight = 250,
	close = true,
	client = {
		export = 'devcore_smoke.UseLighter'
	}
},

['gold_lighter'] = {
	label = 'Accendino dorato',
	stack = false,
	weight = 600,
	close = true,
	client = {
		export = 'devcore_smoke.UseLighter'
	}
},

['cherry_liquid'] = {
	label = 'Liquido alla ciliegia',
	stack = false,
	weight = 250,
	close = false,
},

['blueberry_liquid'] = {
	label = 'Liquido al mirtillo',
	stack = false,
	weight = 250,
	close = false,
},

['cig_redwood'] = {
	label = 'Sigaretta Redwood',
	stack = true,
	weight = 20,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['cig_marlboro'] = {
	label = 'Sigaretta Marlboro',
	stack = true,
	weight = 20,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['og_kush_weed'] = {
	label = 'Erba OG Kush',
	stack = true,
	weight = 1,
	close = false,
},

['banana_kush_weed'] = {
	label = 'Erba Banana Kush',
	stack = true,
	weight = 1,
	close = false,
},

['purple_haze_weed'] = {
	label = 'Erba Purple Haze',
	stack = true,
	weight = 1,
	close = false,
},

['blue_dream_weed'] = {
	label = 'Erba Blue Dream',
	stack = true,
	weight = 1,
	close = false,
},

['og_kush_joint'] = {
	label = 'Canna OG Kush',
	stack = true,
	weight = 1,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['banana_kush_joint'] = {
	label = 'Canna Banana Kush',
	stack = true,
	weight = 1,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['purple_haze_joint'] = {
	label = 'Canna Purple Haze',
	stack = true,
	weight = 1,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['blue_dream_joint'] = {
	label = 'Canna Blue Dream',
	stack = true,
	weight = 1,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['ocb_paper'] = {
	label = 'Cartine OCB',
	stack = false,
	weight = 20,
	close = true,
	client = {
		export = 'devcore_smoke.UseRollingPaper'
	}
},

['raw_paper'] = {
	label = 'Cartine RAW',
	stack = false,
	weight = 20,
	close = true,
	client = {
		export = 'devcore_smoke.UseRollingPaper'
	}
},

['cigar_cuban'] = {
	label = 'Sigaro cubano',
	stack = true,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['cigar_redwood'] = {
	label = 'Sigaro Redwood',
	stack = true,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['bong'] = {
	label = 'Bong',
	stack = false,
	weight = 150,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['vape'] = {
	label = 'Sigaretta elettronica',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['puff_vape'] = {
	label = 'Puff',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['classic_hookah'] = {
	label = 'Narghilè',
	stack = false,
	weight = 1000,
	close = true,
	client = {
		export = 'devcore_smoke.UseHookah'
	}
},

['hookah_wooden_coals'] = {
	label = 'Carboni di legno',
	stack = true,
	weight = 50,
	close = false,
},

['hookah_coconut_coals'] = {
	label = 'Carboni al cocco',
	stack = true,
	weight = 50,
	close = false,
},

['hookah_bamboo_coals'] = {
	label = 'Carboni di bambù',
	stack = true,
	weight = 50,
	close = false,
},

['hookah_blueberry_tobacco'] = {
	label = 'Tabacco al mirtillo',
	stack = true,
	weight = 100,
	close = false,
},

['hookah_raspberry_tobacco'] = {
	label = 'Tabacco al lampone',
	stack = true,
	weight = 100,
	close = false,
},

['hookah_blackberry_tobacco'] = {
	label = 'Tabacco alla mora',
	stack = true,
	weight = 100,
	close = false,
},

['hookah_cherry_tobacco'] = {
	label = 'Tabacco alla ciliegia',
	stack = true,
	weight = 100,
	close = false,
},

['redwood_cherry_chew'] = {
	label = 'Tabacco da masticare alla ciliegia',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['redwood_mint_chew'] = {
	label = 'Tabacco da masticare alla menta',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['redwood_blueberry_chew'] = {
	label = 'Tabacco da masticare al mirtillo',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['redwood_vanilla_chew'] = {
	label = 'Tabacco da masticare alla vaniglia',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['redwood_strawberry_chew'] = {
	label = 'Tabacco da masticare alla fragola',
	stack = false,
	weight = 100,
	close = true,
	client = {
		export = 'devcore_smoke.StartPlayerSmoking'
	}
},

['gopro'] = {
    label = 'GoPro',
    weight = 350,
    stack = false,
    close = true,
    description = 'Action cam personale controllabile tramite tablet.',
    client = {
        event = 'spy-bodycam:goprostatus'
    }
},

    ['kit_pronto_soccorso'] = {
        label = 'Kit Pronto Soccorso',
        weight = 1200,
        stack = false,
        close = true,
        description = 'Valigetta professionale di primo soccorso.',
    },
['watertank'] = {
    label = 'Serbatoio portatile VVF',
    weight = 5000,
    stack = false,
    close = true,
    description = 'Serbatoio portatile per gli interventi antincendio.'
},

    ['maschera_antigas'] = {
        label = 'Maschera Antigas',
        weight = 900,
        stack = false,
        close = true,
        description = 'Maschera protettiva per fumo, gas e ambienti contaminati.',
    },

    ['torcia_vvf'] = {
        label = 'Torcia VVF',
        weight = 650,
        stack = false,
        close = true,
        description = 'Torcia professionale ad alta visibilità per interventi di soccorso.',
    },



    ['cesoie_idrauliche'] = {
        label = 'Cesoie Idrauliche',
        weight = 6500,
        stack = false,
        close = true,
        description = 'Attrezzo da soccorso per il taglio di parti metalliche.',
    },

    ['corda_soccorso'] = {
        label = 'Corda da Soccorso',
        weight = 2800,
        stack = false,
        close = true,
        description = 'Corda tecnica per operazioni di recupero e soccorso.',
    },

    ['defibrillatore'] = {
        label = 'Defibrillatore',
        weight = 3800,
        stack = false,
        close = true,
        description = 'Defibrillatore automatico esterno per emergenze sanitarie.',
    },

    ['estintore'] = {
        label = 'Estintore',
        weight = 5000,
        stack = false,
        close = true,
        description = 'Estintore portatile per piccoli incendi.',
    },
['illegal_toolkit'] = {
    label = 'Kit da officina',
    weight = 2500,
    stack = false,
    close = true,
    description = ''
},

['plate_blank'] = {
    label = 'Targa vergine',
    weight = 700,
    stack = true,
    close = true,
    description = 'Supporto metallico senza immatricolazione.'
},
['plate_blank'] = {
    label = 'Targa vergine',
    weight = 700,
    stack = true,
    close = true,
    description = 'Supporto metallico senza immatricolazione.'
},

['grattavinci'] = {
    label = 'Gratta e Vinci URBS',
    weight = 10,
    stack = true,
    close = true,
    description = 'Gratta il biglietto e scopri se hai vinto.',
  
},
['gps_detector'] = {
    label = 'Rilevatore GPS',
    weight = 650,
    stack = false,
    close = true,
    description = 'Scanner portatile per individuare localizzatori GPS installati sui veicoli.'
},

['gps_jammer'] = {
    label = 'GPS Jammer',
    weight = 900,
    stack = true,
    close = true,
    description = 'Disturbatore elettronico per sistemi di tracciamento.'
},

['hidden_compartment_kit'] = {
    label = 'Kit vano nascosto',
    weight = 3200,
    stack = true,
    close = true,
    description = 'Componenti per ricavare un compartimento occulto nel veicolo.'
},

['nitro_bottle'] = {
    label = 'Bombola nitro',
    weight = 4500,
    stack = true,
    close = true,
    description = 'Bombola pressurizzata per impianti da competizione clandestini.'
},

['key_cloner'] = {
    label = 'Clonatore chiavi',
    weight = 650,
    stack = false,
    close = true,
    description = 'Programmatore elettronico per chiavi veicolo.'
},

['electronic_chip'] = {
    label = 'Chip elettronico',
    weight = 80,
    stack = true,
    close = true,
    description = 'Chip riprogrammabile per sistemi automotive.'
},

['sabotage_kit'] = {
    label = 'Kit sabotaggio',
    weight = 1200,
    stack = true,
    close = true,
    description = 'Materiale per manomettere un veicolo.'
},

['angle_grinder'] = {
    label = 'Smerigliatrice',
    weight = 2600,
    stack = false,
    close = true,
    description = 'Utensile da taglio portatile.'
},

['cloned_car_key'] = {
    label = 'Chiave auto clonata',
    weight = 50,
    stack = false,
    close = true,
    consume = 0,
    description = 'Chiave elettronica clonata per un veicolo specifico.',
    client = {
        export = 'GiaMMarK_illegalmechanic.useClonedKey'
    }
},

['stolen_catalyst'] = { label = 'Catalizzatore rubato', weight = 4500, stack = true, close = true },
['stolen_ecu'] = { label = 'Centralina rubata', weight = 1200, stack = true, close = true },
['stolen_engine_parts'] = { label = 'Componenti motore rubati', weight = 3500, stack = true, close = true },
['stolen_rims'] = { label = 'Cerchi rubati', weight = 7000, stack = true, close = true },
['stolen_body_parts'] = { label = 'Parti carrozzeria rubate', weight = 3000, stack = true, close = true },
['vehicle_scrap'] = { label = 'Rottami veicolo', weight = 1000, stack = true, close = true },


['paletta_blocco'] = {
    label = 'Paletta - Posto di blocco',
    weight = 350,
    stack = false,
    close = true,
    consume = 0,
    description = 'Paletta per fermare il traffico durante un posto di blocco.',
    client = {
        export = 'cylex_animmenuv2.usePalettaBlocco'
    }
},

['paletta_controllo'] = {
    label = 'Paletta - Posto di controllo',
    weight = 350,
    stack = false,
    close = true,
    consume = 0,
    description = 'Paletta per gestire il traffico durante un posto di controllo.',
    client = {
        export = 'cylex_animmenuv2.usePalettaControllo'
    }
},

    	['adrenaline_syringe'] = {
		label = 'Siringa Adrenalina',
		weight = 5,  -- Prima era 100
		stack = true,
		close = true,
	},


--- # start 0r-illegalpack
['illegal_tablet'] = { label = 'Tablet illegale', weight = 1000, stack = false },
['lockpick'] = { label = 'Grimaldello', weight = 0, stack = true },
['powdered_milk'] = { label = 'Latte in polvere', weight = 100, stack = true },
['money_sheet'] = { label = 'Foglio di denaro', weight = 100, stack = true },
['anchor'] = { label = 'Ancora', weight = 100, stack = true },
['plant_spray'] = { label = 'Spruzzino per piante', weight = 100, stack = true },
['ammonia'] = { label = 'Ammoniaca', weight = 100, stack = true },
['sacid'] = { label = 'Acido', weight = 100, stack = true },
['atm_hack_device'] = { label = 'Dispositivo informatico', weight = 100, stack = true },
['blank_card'] = { label = 'Carta vuota', weight = 100, stack = true },
['moonshine_still'] = { label = 'Distillatore di Moonshine', weight = 1000, stack = true },
['moonshine_pack'] = { label = 'Confezione di Moonshine', weight = 100, stack = true },
['stolen_bag'] = { label = 'Borsa rubata', weight = 1000, stack = true },
['scrapmetal'] = { label = 'Rottame di metallo', weight = 100, stack = true },
['plastic'] = { label = 'Plastica', weight = 100, stack = true },
['glass'] = { label = 'Vetro', weight = 100, stack = true },
['copperwire'] = { label = 'Cavo di rame', weight = 100, stack = true },
['bandage'] = { label = 'Benda', weight = 100, stack = true },
['painkiller'] = { label = 'Antidolorifico', weight = 100, stack = true },
['medkit'] = { label = 'Kit medico', weight = 100, stack = true },
['adrenaline'] = { label = 'Adrenalina', weight = 100, stack = true },
['unpacked_coke'] = { label = 'Coca non confezionata', weight = 1000, stack = true },
['cutted_coke'] = { label = 'Coca tagliata', weight = 1000, stack = true },
['packed_coke'] = { label = 'Coca confezionata', weight = 1000, stack = true },
['uncutted_money'] = { label = 'Denaro non tagliato', weight = 100, stack = true },
['cutted_money'] = { label = 'Denaro tagliato', weight = 100, stack = true },
['fake_credit_card'] = { label = 'Carta di credito falsa', weight = 100, stack = true },
['cooked_meth'] = { label = 'Metanfetamina cotta', weight = 100, stack = true },
['breaked_meth'] = { label = 'Metanfetamina frantumata', weight = 100, stack = true },
['packed_meth'] = { label = 'Metanfetamina confezionata', weight = 100, stack = true },
['old_corn'] = { label = 'Mais vecchio', weight = 100, stack = true },
['old_fruit'] = { label = 'Frutta vecchia', weight = 100, stack = true },
['tap_water'] = { label = 'Acqua di rubinetto', weight = 100, stack = true },
['crushed_ingredients'] = { label = 'Ingredienti schiacciati', weight = 100, stack = true },
['blended_ingredients'] = { label = 'Ingredienti frullati', weight = 100, stack = true },
['moonshine'] = { label = 'Moonshine', weight = 100, stack = true },
['unpacked_weed'] = { label = 'Erba non confezionata', weight = 100, stack = true },
['packed_weed'] = { label = 'Erba confezionata', weight = 1000, stack = true },
['rolled_weed'] = { label = 'Erba rollata', weight = 100, stack = true },
--- # end 0r-illegalpack
    	['scudogdf'] = {
		label = 'Scudo Guardia di Finanza',
		weight = 500,
		stack = false,
		description = "Scudo Antisommossa Guardia di Finanza"
	},
 	['scudopds'] = {
		label = 'Scudo Polizia di Stato',
		weight = 500,
		stack = false,
		description = "Scudo Antisommossa Polizia di Stato"
	},
 	['scudocc'] = {
		label = 'Scudo Carabinieri',
		weight = 500,
		stack = false,
		description = "Scudo Antisommossa Carabinieri"
	},      
	['scudopolpen'] = {
	    label = 'Scudo Carabinieri',
		weight = 500,
		stack = false,
		description = "Scudo Antisommossa Carabinieri"
	},   
  ['coal_ore'] = {
        label = 'Minerale di Carbone',
        weight = 100,
        stack = true,
        description = 'Un pezzo di minerale di carbone.'
    },
    ['flint'] = {
        label = 'Selce',
        weight = 50,
        stack = true,
        description = 'Un pezzo di selce tagliente.'
    },
    ['sulfur_chunk'] = {
        label = 'Frammento di Zolfo',
        weight = 80,
        stack = true,
        description = 'Un frammento di zolfo.'
    },

    -- Risorse Oro
    ['gold_nugget'] = {
        label = 'Pepita d\'Oro',
        weight = 100,
        stack = true,
        description = 'Una piccola pepita d\'oro.'
    },
    ['gold_dust'] = {
        label = 'Polvere d\'Oro',
        weight = 50,
        stack = true,
        description = 'Un pizzico di polvere d\'oro.'
    },
    ['quartz_crystal'] = {
        label = 'Cristallo di Quarzo',
        weight = 80,
        stack = true,
        description = 'Un limpido cristallo di quarzo.'
    },

    -- Risorse Smeraldo
    ['emerald_crystal'] = {
        label = 'Cristallo di Smeraldo',
        weight = 100,
        stack = true,
        description = 'Un radioso cristallo di smeraldo.'
    },
    ['beryl_chunk'] = {
        label = 'Frammento di Berillo',
        weight = 80,
        stack = true,
        description = 'Un frammento di berillo.'
    },
    ['green_garnet'] = {
        label = 'Granato Verde',
        weight = 50,
        stack = true,
        description = 'Un prezioso granato verde.'
    },

    -- Risorse Rubino
    ['ruby_crystal'] = {
        label = 'Cristallo di Rubino',
        weight = 100,
        stack = true,
        description = 'Un brillante cristallo di rubino.'
    },
    ['corundum_chunk'] = {
        label = 'Frammento di Corindone',
        weight = 80,
        stack = true,
        description = 'Un frammento di corindone.'
    },
    ['pink_sapphire'] = {
        label = 'Zaffiro Rosa',
        weight = 50,
        stack = true,
        description = 'Un delicato zaffiro rosa.'
    },

    -- Risorse Ametista
    ['amethyst_geode'] = {
        label = 'Geode di Ametista',
        weight = 100,
        stack = true,
        description = 'Un bellissimo geode di ametista.'
    },
    ['purple_quartz'] = {
        label = 'Quarzo Viola',
        weight = 80,
        stack = true,
        description = 'Un pezzo di quarzo viola.'
    },
    ['clear_crystal'] = {
        label = 'Cristallo Trasparente',
        weight = 50,
        stack = true,
        description = 'Un cristallo limpido e puro.'
    },

    -- Risorse Diamante
    ['diamond_crystal'] = {
        label = 'Cristallo di Diamante',
        weight = 100,
        stack = true,
        description = 'Uno squisito cristallo di diamante.'
    },
    ['graphite_chunk'] = {
        label = 'Frammento di Grafite',
        weight = 80,
        stack = true,
        description = 'Un frammento di grafite.'
    },
    ['blue_diamond'] = {
        label = 'Diamante Blu',
        weight = 50,
        stack = true,
        description = 'Un raro e prezioso diamante blu.'
    },
    ['pickaxe_rusty'] = {
            label = 'Piccone Arrugginito',
            weight = 8,
            stack = false,
            close = true,
            client = {
                export = 'qs-minerjob.togglePickaxe'
            },
            server = {
                export = 'qs-minerjob.pickaxe'
            },
        },

        ['pickaxe_stone'] = {
            label = 'Piccone di Pietra',
            weight = 8,
            stack = false,
            close = true,
            client = {
                export = 'qs-minerjob.togglePickaxe'
            },
            server = {
                export = 'qs-minerjob.pickaxe'
            },
        },
        
        ['pickaxe_iron'] = {
            label = 'Piccone di Ferro',
            weight = 8,
            stack = false,
            close = true,
            client = {
                export = 'qs-minerjob.togglePickaxe'
            },
            server = {
                export = 'qs-minerjob.pickaxe'
            },
        },
        -- OX_INVENTORY — MORO WEED V2
-- Aggiungi in: ox_inventory/data/items.lua


-- Vassoio: richiesto nell'inventario, non viene consumato
['moro_tray'] = {
    label       = 'Vassoio',
    weight      = 500,
    stack       = false,
    close       = false,
    description = 'Un vassoio utilizzato per preparare e rollare le canne.',
},

-- Grinder: richiesto nell'inventario, non viene consumato
['moro_mixeur'] = {
    label       = 'Grinder',
    weight      = 200,
    stack       = false,
    close       = false,
    description = 'Un grinder utilizzato per tritare l\'erba.',
},

-- Cartina: avvia la sequenza di preparazione
['rolling_paper'] = {
    label       = 'Cartina',
    weight      = 10,
    stack       = true,
    close       = true,
    description = 'Una cartina utilizzata per preparare una canna.',
    client = {
        export = 'moro_weed_v2.useMoroRollingPaper'
    }
},

-- OG Kush: consumata durante la preparazione
['og_kush'] = {
    label       = 'OG Kush',
    weight      = 100,
    stack       = true,
    close       = false,
    description = 'OG Kush grezza, pronta per essere tritata e rollata.',
},

-- Purple Kush: consumata durante la preparazione
['purple_kush'] = {
    label       = 'Purple Kush',
    weight      = 100,
    stack       = true,
    close       = false,
    description = 'Purple Kush grezza, pronta per essere tritata e rollata.',
},

-- Candy Kush: consumata durante la preparazione
['candy_kush'] = {
    label       = 'Candy Kush',
    weight      = 100,
    stack       = true,
    close       = false,
    description = 'Candy Kush grezza, pronta per essere tritata e rollata.',
},

-- Canna OG Kush: fumabile — stack=false perché ogni canna ha metadata unici
['moro_joint_done'] = {
    label       = 'Canna OG Kush',
    weight      = 10,
    stack       = false,
    close       = true,
    description = 'Una canna di OG Kush già rollata e pronta da fumare.',
    client = {
        export = 'moro_weed_v2.useMoroJoint'
    }
},

-- Canna Candy Kush: fumabile
['moro_joint_done_r'] = {
    label       = 'Canna Candy Kush',
    weight      = 10,
    stack       = false,
    close       = true,
    description = 'Una canna di Candy Kush già rollata e pronta da fumare.',
    client = {
        export = 'moro_weed_v2.useMoroJoint_r'
    }
},

-- Canna Purple Kush: fumabile
['moro_joint_done_p'] = {
    label       = 'Canna Purple Kush',
    weight      = 10,
    stack       = false,
    close       = true,
    description = 'Una canna di Purple Kush già rollata e pronta da fumare.',
    client = {
        export = 'moro_weed_v2.useMoroJoint_p'
    }
},
        ['pickaxe_steel'] = {
            label = 'Piccone d\'Acciaio',
            weight = 8,
            stack = false,
            close = true,
            client = {
                export = 'qs-minerjob.togglePickaxe'
            },
            server = {
                export = 'qs-minerjob.pickaxe'
            },
        },
        
        ['pickaxe_diamond'] = {
            label = 'Piccone di Diamante',
            weight = 8,
            stack = false,
            close = true,
            client = {
                export = 'qs-minerjob.togglePickaxe'
            },
            server = {
                export = 'qs-minerjob.pickaxe'
            },
        },

        ['pickaxe_mythical'] = {
            label = 'Piccone Mitico',
            weight = 8,
            stack = false,
            close = true,
            client = {
                export = 'qs-minerjob.togglePickaxe'
            },
            server = {
                export = 'qs-minerjob.pickaxe'
            },
        },
    ["facility_panel"] = { label = "Pannello Struttura", weight = 500, stack = false },
["medbag"] = { label = "Borsa Medica", weight = 1000, stack = true },
["bandage_pro"] = { label = "Benda", weight = 50, stack = true },
["firstaid"] = { label = "Kit di Pronto Soccorso", weight = 300, stack = true },
["syringe"] = { label = "Siringa", weight = 20, stack = true },
["blood_sample"] = { label = "Campione di Sangue", weight = 30, stack = true, unique = true },
["blood_test_result"] = { label = "Risultato Esame Sangue", weight = 0, stack = false, unique = true },
["mr_scan_result"] = { label = "Risultato Scansione RM", weight = 0, stack = false, unique = true },
["prescription"] = { label = "Ricetta Medica", weight = 0, stack = false, unique = true },
["pill_a"] = { label = "Pillola A", weight = 5, stack = true },
["pill_b"] = { label = "Pillola B", weight = 5, stack = true },
["pill_c"] = { label = "Pillola C", weight = 5, stack = true },
["ice_pack"] = { label = "Borsa del Ghiaccio", weight = 100, stack = true },
["neck_brace"] = { label = "Collare Cervicale", weight = 180, stack = true },
["gauze_pad"] = { label = "Garza", weight = 40, stack = true },
["tourniquet"] = { label = "Laccio Emostatico", weight = 100, stack = true },
["arm_splint"] = { label = "Stecca per Braccio", weight = 200, stack = true },
["leg_splint"] = { label = "Stecca per Gamba", weight = 300, stack = true },
["trauma_kit"] = { label = "Kit Trauma", weight = 800, stack = true },
    ['volantino_lavoro'] = {
        label = 'Volantino Informativo',
        weight = 10,
        stack = false, -- False è meglio, così i foglietti di lavori diversi non si mischiano
        close = true,
        description = 'Un foglietto con le istruzioni di un lavoro.',
        client = {
            export = 'cerberus_core.useVolantino' -- Questo collega l'uso dell'item al nostro client.lua
        }
    },
    ['train_ticket'] = {
    label   = 'Biglietto del treno',
    weight  = 10,
    stack   = false,
    close   = true,
    consume = 0,
},
['ammonia'] = {
    label = 'Ammoniaca',
    weight = 500,
    stack = true,
},

['sodium_benzoate'] = {
    label = 'Benzoato di sodio',
    weight = 750,
    stack = true,
},

['meth_tray'] = {
    label = 'Vassoio per metanfetamina',
    weight = 1000,
    stack = true,
},

['meth'] = {
    label = 'Metanfetamina',
    weight = 1,
    stack = true,
},

['meth_bag'] = {
    label = 'Bustina di metanfetamina',
    weight = 50,
    stack = true,
},

['plastic_bag'] = {
    label = 'Sacchetto di plastica',
    weight = 40,
    stack = true,
},

['meth_syringe'] = {
    label = 'Siringa di metanfetamina',
    weight = 75,
    stack = true,
},

-- Articoli relativi alla cocaina
['coke_seed'] = {
    label = 'Seme di coca',
    weight = 10,
    stack = true,
},

['coke_leaf'] = {
    label = 'Foglia di coca',
    weight = 50,
    stack = true,
},

['coke_paste'] = {
    label = 'Pasta di cocaina',
    weight = 150,
    stack = true,
},

['coke'] = {
    label = 'Cocaina',
    weight = 1,
    stack = true,
},

['coke_bag'] = {
    label = 'Bustina di cocaina',
    weight = 50,
    stack = true,
},

['coke_brick'] = {
    label = 'Panetto di cocaina',
    weight = 200,
    stack = true,
},

['coke_doll'] = {
    label = 'Bambola di cocaina',
    weight = 500,
    stack = true,
},

-- Articoli relativi all'erba
['weed_seed'] = {
    label = 'Seme di erba',
    weight = 5,
    stack = true,
},

['weed_pot'] = {
    label = 'Vaso per piante',
    weight = 500,
    stack = true,
},

['trowel'] = {
    label = 'Cazzuola',
    weight = 150,
    stack = true,
},

['weed_bud'] = {
    label = 'Cima d\'erba',
    weight = 25,
    stack = true,
},

['clean_weed_bud'] = {
    label = 'Cima d\'erba pulita',
    weight = 20,
    stack = true,
},

['cookie_dough'] = {
    label = 'Impasto per biscotti',
    weight = 200,
    stack = true
},

['weed_cookie'] = {
    label = 'Biscotto all\'erba',
    weight = 50,
    stack = true
},

['weed_bag'] = {
    label = 'Bustina d\'erba',
    weight = 50,
    stack = true,
},

['weed_joint'] = {
    label = 'Canna',
    weight = 15,
    stack = true,
},

['weed_papers'] = {
    label = 'Cartine',
    weight = 5,
    stack = true,
},

-- Articoli relativi all'eroina
['poppy_seeds'] = {
    label = 'Semi di papavero',
    weight = 5,
    stack = true,
},

['poppy_plant'] = {
    label = 'Pianta di papavero',
    weight = 100,
    stack = true,
},

['opium'] = {
    label = 'Oppio',
    weight = 1,
    stack = true,
},

['heroin'] = {
    label = 'Eroina',
    weight = 1,
    stack = true,
},

['heroin_bag'] = {
    label = 'Bustina di eroina',
    weight = 50,
    stack = true,
},

['heroin_syringe'] = {
    label = 'Siringa di eroina',
    weight = 75,
    stack = true,
},

['syringe'] = {
    label = 'Siringa',
    weight = 25,
    stack = true,
},

-- Articoli relativi all'LSD
['ergot_fungus'] = {
    label = 'Segale cornuta',
    weight = 50,
    stack = true,
},

['generic_leaf'] = {
    label = 'Foglia',
    weight = 20,
    stack = true,
},

['lsd_liquid'] = {
    label = 'LSD liquido',
    weight = 25,
    stack = true,
},

['lsd'] = {
    label = 'LSD',
    weight = 1,
    stack = true,
},

['art_papers'] = {
    label = 'Carta assorbente',
    weight = 5,
    stack = true,
},

-- Articoli relativi all'ecstasy
['safrole_oil'] = {
    label = 'Olio di safrolo',
    weight = 300,
    stack = true,
},

['ecstasy_crystals'] = {
    label = 'Cristalli di ecstasy',
    weight = 1,
    stack = true,
},

['ecstasy_pill'] = {
    label = 'Pasticca di ecstasy',
    weight = 15,
    stack = true,
},

-- Articoli relativi ai funghi
['mushrooms'] = {
    label = 'Funghi',
    weight = 1,
    stack = true,
},

['mushroom_powder'] = {
    label = 'Polvere di funghi',
    weight = 1,
    stack = true,
},

['chocolate_chips'] = {
    label = 'Gocce di cioccolato',
    weight = 30,
    stack = true,
},

['mushroom_chocolate'] = {
    label = 'Cioccolato ai funghi',
    weight = 45,
    stack = true,
},

-- Articoli relativi alla ketamina
['anesthetic'] = {
    label = 'Anestetico',
    weight = 200,
    stack = true,
},

['ketamine'] = {
    label = 'Ketamina',
    weight = 1,
    stack = true,
},

['ketamine_bag'] = {
    label = 'Bustina di ketamina',
    weight = 50,
    stack = true,
},

-- Articoli relativi al crack
['baking_soda'] = {
    label = 'Bicarbonato di sodio',
    weight = 100,
    stack = true,
},

['crack'] = {
    label = 'Crack',
    weight = 1,
    stack = true,
},

['crack_bag'] = {
    label = 'Bustina di crack',
    weight = 50,
    stack = true,
},

['crack_pipe'] = {
    label = 'Pipa da crack',
    weight = 150,
    stack = true,
},

['crack_syringe'] = {
    label = 'Siringa di crack',
    weight = 75,
    stack = true,
},

['pipe'] = {
    label = 'Pipa',
    weight = 100,
    stack = true,
},

-- Articoli relativi al fentanyl
['npp_chemical'] = {
    label = 'Sostanza chimica NPP',
    weight = 300,
    stack = true,
},

['aniline_solution'] = {
    label = 'Soluzione di anilina',
    weight = 250,
    stack = true,
},

['fentanyl'] = {
    label = 'Fentanyl',
    weight = 1,
    stack = true,
},

['fentanyl_bag'] = {
    label = 'Bustina di fentanyl',
    weight = 25,
    stack = true,
},

['meth_table'] = {
    label = 'Tavolo per metanfetamina',
    weight = 2250,
    stack = false
},

['coke_table'] = {
    label = 'Tavolo per cocaina',
    weight = 2250,
    stack = false
},

['weed_table'] = {
    label = 'Tavolo per erba',
    weight = 2250,
    stack = false
},

['chem_table'] = {
    label = 'Tavolo da chimica',
    weight = 2250,
    stack = false
},

['burner_phone'] = {
    label = 'Telefono usa e getta',
    weight = 200,
    stack = true
},

['light1'] = {
    label = 'Lampada portatile',
    weight = 2000,
    stack = true
},

['light2'] = {
    label = 'Lampada portatile',
    weight = 2000,
    stack = true
},

['fertilizer'] = {
    label = 'Fertilizzante',
    weight = 250,
    stack = true
},

['water_can'] = {
    label = 'Innaffiatoio',
    weight = 250,
    stack = true
},
['documentistatali'] = {
    label = 'Documento statale',
    weight = 10,
    stack = false,
    close = true,
    consume = 0,
    description = 'Documento ufficiale',
    server = {
        export = 'GiaMMarK_documenti.documento'
    }
},

['tessera_ammu_nation'] = {
    label = 'Tessera Membro Poligono',
    weight = 0,
    stack = false,
    close = true,
    description = 'Garantisce al titolare il 50% di sconto su tutte le prove pratiche al poligono.'
},
['certificato_armi'] = {
    label = 'Certificato del Poligono',
    weight = 0,
    stack = false,
    close = true,
    consume = 0,
    description = 'Documento ufficiale che attesta l\'idoneità al maneggio delle armi da fuoco.',
    client = {
        export = 'GiaMMarK_portodarmi_documenti_italiani.certificato_armi'
    }
},

['certificato_medico'] = {
    label = 'Certificato Medico',
    weight = 10,
    stack = false,
    close = true,
    consume = 0,
    description = 'Documento ufficiale rilasciato dal S.A. Medical Department.',
    client = {
        export = 'GiaMMarK_portodarmi_documenti_italiani.certificato_medico'
    }
},
	['rubber_tube'] = {
    label = 'Tubo di gomma',
    weight = 2,
    stack = true,
    close = true,
},
['ephedrine'] = {
    label = 'Efedrina',
    weight = 100,
    stack = true,
    close = true,
    description = 'Un composto chimico essenziale per la sintesi di sostanze particolari.',
},

['acetone'] = {
    label = 'Acetone',
    weight = 250,
    stack = true,
    close = true,
    description = 'Solvente chimico industriale molto infiammabile.',
},

['lithium'] = {
    label = 'Litio',
    weight = 150,
    stack = true,
    close = true,
    description = 'Metallo reattivo estratto solitamente dalle batterie.',
},

-- [[ PRODOTTI DELLA LAVORAZIONE ]] --

['raw_meth'] = {
    label = 'Metanfetamina Grezza',
    weight = 500,
    stack = true,
    close = true,
    description = 'Un grosso blocco di metanfetamina appena cucinata, ancora da lavorare.',
},

['cracked_meth'] = {
    label = 'Metanfetamina Frammentata',
    weight = 50,
    stack = true,
    close = true,
    description = 'Cristalli di metanfetamina frantumati, pronti per essere pesati e imbustati.',
},

['meth'] = {
    label = 'Bustina di Metanfetamina',
    weight = 10,
    stack = true,
    close = true,
    description = 'Prodotto finale pronto per la vendita al dettaglio.',
},
['atm_card'] = {
        label = 'Bancomat',
        weight = 10,
        stack = false, -- Non si impilano perché ognuno ha metadati unici
        consume = 0,
        description = 'Una carta di debito bancaria.'
    },
['weed_bag'] = {
    label = 'Sacchetto di Weed',
    weight = 100,
    stack = true,
    close = true,
    description = 'Weed confezionata pronta alla vendita'
},

['weed_dry'] = {
    label = 'Weed Essiccata',
    weight = 100,
    stack = true,
    close = true,
    description = 'Weed pronta per essere imbustata'
},

['weed_plant'] = {
    label = 'Pianta di Weed',
    weight = 500,
    stack = true,
    close = true,
    description = 'Pianta in crescita'
},

['weed_seed'] = {
    label = 'Seme di Weed',
    weight = 10,
    stack = true,
    close = true,
    description = 'Usato per piantare weed'
},


['fertilizer'] = {
    label = 'Fertilizzante',
    weight = 200,
    stack = true,
    close = true,
    description = 'Accelera la crescita delle piante'
},

['water'] = {
    label = 'Acqua',
    weight = 200,
    stack = true,
    close = true,
    description = 'Necessaria per far crescere le piante'
},	

['lettera'] = {
	label = "Lettera",
	weight = 1,
	stack = true,
	close = true,
	description = ''
},

['acidoossalico'] = {
	label = "Acido Ossalico",
	weight = 1,
	stack = true,
	close = true,
},
['cartinesigarette'] = {
	label = "Cartine per sigarette",
	weight = 1,
	stack = true,
	close = true,
},
['tabletlavoro'] = {
	label = "Tablet da lavoro",
	weight = 1,
	stack = true,
	close = true,
},
['pacchetticontrabbando'] = {
	label = "Pacchetto di sigarette",
	weight = 1,
	stack = true,
	close = true,
},
['taglierina'] = {
	label = "Taglierina per carta",
	weight = 1,
	stack = true,
	close = true,
},
['sigaretteforti'] = {
	label = "Sigarette particolari",
	weight = 1,
	stack = true,
	close = true,
},
['tabaccoforte'] = {
	label = "Tabacco forte",
	weight = 1,
	stack = true,
	close = true,
},
['torture_kit'] = {
    label = 'Sedia delle torture',
    weight = 1000,
    stack = false,
    close = true,
    consume = 0,
    client = {
        export = 'dz-interrogation.useTortureKit'
    }
},	

['bmx'] = {
    label = 'BMX',
    weight = 50,
    stack = false,
    close = true,
},

['scooter'] = {
    label = 'Scooter',
    weight = 50,
    stack = false,
    close = true,
    description = 'Uno scooter per acrobazie e trick'
},

['rollers'] = {
    label = 'Rollers',
    weight = 50,
    stack = false,
    close = true,
    description = 'Pattini a rotelle per acrobazie e trick'
},

["bread"] = {
    label = "Pane",
    weight = 5,
    stack = true, -- assumendo che 'unique' falso significhi impilabile
    close = true,
    description = "Pane",
    client = {
        image = "bread.png",
    }
},

["earthworm"] = {
    label = "Lombrico",
    weight = 5,
    stack = true,
    close = true,
    description = "Lombrico",
    client = {
        image = "earthworm.png",
    }
},

["dough"] = {
    label = "Impasto",
    weight = 5,
    stack = true,
    close = true,
    description = "Impasto",
    client = {
        image = "dough.png",
    }
},

["grub"] = {
    label = "Larva",
    weight = 5,
    stack = true,
    close = true,
    description = "Larva",
    client = {
        image = "grub.png",
    }
},

["caddis_fly"] = {
    label = "Tricottero",
    weight = 5,
    stack = true,
    close = true,
    description = "Tricottero",
    client = {
        image = "caddis_fly.png",
    }
},

["cheese"] = {
    label = "Formaggio",
    weight = 5,
    stack = true,
    close = true,
    description = "Formaggio",
    client = {
        image = "cheese.png",
    }
},

["fly"] = {
    label = "Mosca",
    weight = 5,
    stack = true,
    close = true,
    description = "Mosca",
    client = {
        image = "fly.png",
    }
},

["dragonfly"] = {
    label = "Libellula",
    weight = 5,
    stack = true,
    close = true,
    description = "Libellula",
    client = {
        image = "dragonfly.png",
    }
},

["grasshoper"] = {
    label = "Cavalletta",
    weight = 5,
    stack = true,
    close = true,
    description = "Cavalletta",
    client = {
        image = "grasshoper.png",
    }
},

["shrimp"] = {
    label = "Gamberetto",
    weight = 5,
    stack = true,
    close = true,
    description = "Gamberetto",
    client = {
        image = "shrimp.png",
    }
},

["leech"] = {
    label = "Sanguisuga",
    weight = 5,
    stack = true,
    close = true,
    description = "Sanguisuga",
    client = {
        image = "leech.png",
    }
},

["snail"] = {
    label = "Lumaca",
    weight = 5,
    stack = true,
    close = true,
    description = "Lumaca",
    client = {
        image = "snail.png",
    }
},

["liver"] = {
    label = "Fegato",
    weight = 5,
    stack = true,
    close = true,
    description = "Fegato",
    client = {
        image = "liver.png",
    }
},

-- Fili
["express_fishing_super_line"] = {
    label = "Express Super Line 0.1mm",
    weight = 35,
    stack = true, -- assumendo che 'unique' falso significhi impilabile
    close = true,
    description = "Express Super Line 0.1mm",
    client = {
        image = "express_fishing_super_line.png",
    }
},

["syberia_indiana_green"] = {
    label = "Indiana Verde 0.14mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Verde 0.14mm",
    client = {
        image = "syberia_indiana_green.png",
    }
},

["syberia_indiana_white"] = {
    label = "Indiana Bianco 0.18mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Bianco 0.18mm",
    client = {
        image = "syberia_indiana_white.png",
    }
},

["simmons_mono_original"] = {
    label = "Simmons Originale 0.25mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons Originale 0.25mm",
    client = {
        image = "simmons_mono_original.png",
    }
},

["simmons_mono_ss"] = {
    label = "Simmons SS 0.28mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons SS 0.28mm",
    client = {
        image = "simmons_mono_ss.png",
    }
},

["syberia_indiana_green_2"] = {
    label = "Indiana Verde 0.32mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Verde 0.32mm",
    client = {
        image = "syberia_indiana_green_2.png",
    }
},

["syberia_indiana_white_2"] = {
    label = "Indiana Bianco 0.36mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Bianco 0.36mm",
    client = {
        image = "syberia_indiana_white_2.png",
    }
},

["snake_power_line_clr"] = {
    label = "Snake Power Line 0.41mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Snake Power Line 0.41mm",
    client = {
        image = "snake_power_line_clr.png",
    }
},

["simmons_mono_original_2"] = {
    label = "Simmons Originale 0.48mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons Originale 0.48mm",
    client = {
        image = "simmons_mono_original_2.png",
    }
},

["simmons_mono_ss_2"] = {
    label = "Simmons SS 0.52mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons SS 0.52mm",
    client = {
        image = "simmons_mono_ss_2.png",
    }
},

["snake_power_line_clr_2"] = {
    label = "Snake Power Line 0.65mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Snake Power Line 0.65mm",
    client = {
        image = "snake_power_line_clr_2.png",
    }
},

["solid_hipower_nylon"] = {
    label = "HiPower Nylon 0.8mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon 0.8mm",
    client = {
        image = "solid_hipower_nylon.png",
    }
},

["solid_hipower_nylon_lime"] = {
    label = "HiPower Nylon L 0.85mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon L 0.85mm",
    client = {
        image = "solid_hipower_nylon_lime.png",
    }
},

["solid_hipower_nylon_orange"] = {
    label = "HiPower Nylon O 0.9mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon O 0.9mm",
    client = {
        image = "solid_hipower_nylon_orange.png",
    }
},

["solid_hipower_nylon_2"] = {
    label = "HiPower Nylon 1.05mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon 1.05mm",
    client = {
        image = "solid_hipower_nylon_2.png",
    }
},

["solid_hipower_nylon_lime_2"] = {
    label = "HiPower Nylon L 1.15mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon L 1.15mm",
    client = {
        image = "solid_hipower_nylon_lime_2.png",
    }
},

["solid_hipower_nylon_orange_2"] = {
    label = "HiPower Nylon O 1.25mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon O 1.25mm",
    client = {
        image = "solid_hipower_nylon_orange_2.png",
    }
},

-- Canne
["ufe_telerod_370"] = {
    label = "UFE Telerod 370",
    weight = 75,
    stack = false, -- non impilabile
    close = true,
    description = "UFE Telerod 370",
    client = {
        image = "ufe_telerod_370.png",
    }
},

["carptack_feeder_master_250"] = {
    label = "Carptack Feeder Master 250",
    weight = 75,
    stack = false,
    close = true,
    description = "Carptack Feeder Master 250",
    client = {
        image = "carptack_feeder_master_250.png",
    }
},

["sakura_tsubarea_tsa_552_xul"] = {
    label = "Sakura Tsubarea TSA 552 XUL",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Tsubarea TSA 552 XUL",
    client = {
        image = "sakura_tsubarea_tsa_552_xul.png",
    }
},

["carpex_hybid_carp_270"] = {
    label = "Carpex Hybid Carp 270",
    weight = 75,
    stack = false,
    close = true,
    description = "Carpex Hybid Carp 270",
    client = {
        image = "carpex_hybid_carp_270.png",
    }
},

["ufe_float_x5_300"] = {
    label = "UFE Float X5 300",
    weight = 75,
    stack = false,
    close = true,
    description = "UFE Float X5 300",
    client = {
        image = "ufe_float_x5_300.png",
    }
},
['drone'] = {
	label = 'Drone',
	weight = 1000,
	stack = false,
	close = true,
	client = {
		event = 'dz-drone:client:InitiateDrone',
	},
},
['drone_lspd'] = {
	label = 'LSPD Drone',
	weight = 1000,
	stack = false,
	close = true,
	client = {
		event = 'dz-drone:client:InitiateDroneLSPD',
	},
},

["predatek_fast_perch_210"] = {
    label = "Predatek Fast Perch 210",
    weight = 75,
    stack = false,
    close = true,
    description = "Predatek Fast Perch 210",
    client = {
        image = "predatek_fast_perch_210.png",
    }
},

["sakura_ionizer_bass_insb_701_ml"] = {
    label = "Sakura Ionizer Bass INSB 701",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Ionizer Bass INSB 701",
    client = {
        image = "sakura_ionizer_bass_insb_701_ml.png",
    }
},

["sakura_redbird_rds_602_l"] = {
    label = "Sakura Redbird RDS 602 L",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Redbird RDS 602 L",
    client = {
        image = "sakura_redbird_rds_602_l.png",
    }
},

["carpex_cobalt_carp_360"] = {
    label = "Carpex Cobalt Carp 360",
    weight = 75,
    stack = false,
    close = true,
    description = "Carpex Cobalt Carp 360",
    client = {
        image = "carpex_cobalt_carp_360.png",
    }
},

["sakura_salt_sniper_salss_611_mj1"] = {
    label = "Sakura Salt Sniper SALSS 611",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Salt Sniper SALSS 611",
    client = {
        image = "sakura_salt_sniper_salss_611_mj1.png",
    }
},

["sakura_speciz_spes_light_602_zander"] = {
    label = "Sakura Speciz Spes Light 602",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Speciz Spes Light 602",
    client = {
        image = "sakura_speciz_spes_light_602_zander.png",
    }
},

["sakura_redbird_rds_662"] = {
    label = "Sakura Redbird RDS 662",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Redbird RDS 662",
    client = {
        image = "sakura_redbird_rds_662.png",
    }
},

["sakura_salt_sniper_salss_902_h"] = {
    label = "Sakura Salt Sniper SALSS 902",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Salt Sniper SALSS 902",
    client = {
        image = "sakura_salt_sniper_salss_902_h.png",
    }
},

["predatek_seahunter_230"] = {
    label = "Predatek Seahunter 230",
    weight = 75,
    stack = false,
    close = true,
    description = "Predatek Seahunter 230",
    client = {
        image = "predatek_seahunter_230.png",
    }
},

["sakura_shukan_shuc_661_lj"] = {
    label = "Sakura Shukan Shuc 661 LJ",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Shukan Shuc 661 LJ",
    client = {
        image = "sakura_shukan_shuc_661_lj.png",
    }
},

["ufe_powercatch_270"] = {
    label = "UFE Powercatch 270",
    weight = 75,
    stack = false,
    close = true,
    description = "UFE Powercatch 270",
    client = {
        image = "ufe_powercatch_270.png",
    }
},

["predatek_pilk_200"] = {
    label = "Predatek Pilk 200",
    weight = 75,
    stack = false,
    close = true,
    description = "Predatek Pilk 200",
    client = {
        image = "predatek_pilk_200.png",
    }
},

["robinson_carbonic_nordic_pilk_300"] = {
    label = "Robinson Carbonic Nordic Pilk",
    weight = 75,
    stack = false,
    close = true,
    description = "Robinson Carbonic Nordic Pilk",
    client = {
        image = "robinson_carbonic_nordic_pilk_300.png",
    }
},

["carptack_bottom_cast_360"] = {
    label = "Carptack Bottom Cast 360",
    weight = 75,
    stack = false,
    close = true,
    description = "Carptack Bottom Cast 360",
    client = {
        image = "carptack_bottom_cast_360.png",
    }
},

["seax_salfighter_170"] = {
    label = "Seax Salfighter 170",
    weight = 75,
    stack = false,
    close = true,
    description = "Seax Salfighter 170",
    client = {
        image = "seax_salfighter_170.png",
    }
},

-- Mulinelli
["ufe_canta_1000"] = {
    label = "UFE Canta 1000",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Canta 1000",
    client = {
        image = "ufe_canta_1000.png",
    }
},

["ufe_barracuda_2000bt"] = {
    label = "UFE Barracuda 2000BT",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Barracuda 2000BT",
    client = {
        image = "ufe_barracuda_2000bt.png",
    }
},

["sakura_alpax_4508"] = {
    label = "Sakura Alpax 4508",
    weight = 50,
    stack = false,
    close = true,
    description = "Sakura Alpax 4508",
    client = {
        image = "sakura_alpax_4508.png",
    }
},

["sakura_alpax_8508"] = {
    label = "Sakura Alpax 8508",
    weight = 50,
    stack = false,
    close = true,
    description = "Sakura Alpax 8508",
    client = {
        image = "sakura_alpax_8508.png",
    }
},
["chiaveascensore"] = {
    label = "Chiave Ascensore",
    weight = 1,
    stack = true,
    close = true,
},
["ufe_belona_4000"] = {
    label = "UFE Belona 4000",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Belona 4000",
    client = {
        image = "ufe_belona_4000.png",
    }
},

["ufe_bigspin_8000b"] = {
    label = "UFE Bigspin 8000B",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Bigspin 8000B",
    client = {
        image = "ufe_bigspin_8000b.png",
    }
},

["ufe_batara_8000g"] = {
    label = "UFE Batara 8000G",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Batara 8000G",
    client = {
        image = "ufe_batara_8000g.png",
    }
},

["ufe_batara_1000r"] = {
    label = "UFE Batara 1000R",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Batara 1000R",
    client = {
        image = "ufe_batara_1000r.png",
    }
},

["robinson_big_runner_807qd"] = {
    label = "Robinson Big Runner 807QD",
    weight = 50,
    stack = false,
    close = true,
    description = "Robinson Big Runner 807QD",
    client = {
        image = "robinson_big_runner_807qd.png",
    }
},

["spooler_catchpro_4000fd"] = {
    label = "Spooler Catchpro 4000FD",
    weight = 50,
    stack = false,
    close = true,
    description = "Spooler Catchpro 4000FD",
    client = {
        image = "spooler_catchpro_4000fd.png",
    }
},

["ufe_opensea_8000_x"] = {
    label = "UFE Opensea 8000-X",
    weight = 50,
    stack = false,
    close = true,
    description = "UFE Opensea 8000-X",
    client = {
        image = "ufe_opensea_8000-x.png",
    }
},

["spooler_catchpro_8000fd"] = {
    label = "Spooler Catchpro 8000FD",
    weight = 50,
    stack = false,
    close = true,
    description = "Spooler Catchpro 8000FD",
    client = {
        image = "spooler_catchpro_8000fd.png",
    }
},

["spooler_catchpro_14000fd"] = {
    label = "Spooler Catchpro 14000FD",
    weight = 50,
    stack = false,
    close = true,
    description = "Spooler Catchpro 14000FD",
    client = {
        image = "spooler_catchpro_14000fd.png",
    }
},

-- Ami
["ufa_bait_hook"] = {
    label = "UFA Esca",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Esca",
    client = {
        image = "ufa_bait_hook.png",
    }
},

["ufa_sproat_hook"] = {
    label = "UFA Sproat",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Sproat",
    client = {
        image = "ufa_sproat_hook.png",
    }
},

["captack_claw_xl_hook"] = {
    label = "Captack Claw XL",
    weight = 20,
    stack = true,
    close = true,
    description = "Captack Claw XL",
    client = {
        image = "captack_claw_xl_hook.png",
    }
},

["ufa_sproat_g_hook"] = {
    label = "UFA Sproat-G",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Sproat-G",
    client = {
        image = "ufa_sproat_g_hook.png",
    }
},

["carptack_carp_ss_hook"] = {
    label = "Carptack Carp S&S",
    weight = 20,
    stack = true,
    close = true,
    description = "Carptack Carp S&S",
    client = {
        image = "carptack_carp_ss_hook.png",
    }
},

["ufa_wide_gap_bl_hook"] = {
    label = "UFA Wide Gap BL",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Wide Gap BL",
    client = {
        image = "ufa_wide_gap_bl_hook.png",
    }
},

["ufa_aberdeen_hook"] = {
    label = "UFA Aberdeen",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Aberdeen",
    client = {
        image = "ufa_aberdeen_hook.png",
    }
},

["ufa_octopus_bl_hook"] = {
    label = "UFA Octopus BL",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Octopus BL",
    client = {
        image = "ufa_octopus_bl_hook.png",
    }
},

["ufa_livebait_hook"] = {
    label = "UFA Esca Viva",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Esca Viva",
    client = {
        image = "ufa_livebait_hook.png",
    }
},

["carptack_micro_barb_hook"] = {
    label = "Carptack Micro Barb",
    weight = 20,
    stack = true,
    close = true,
   description = "Carptack Micro Barb",
    client = {
        image = "carptack_micro_barb_hook.png",
    }
},

["carptack_carp_hook"] = {
    label = "Carptack Carp",
    weight = 20,
    stack = true,
    close = true,
    description = "Carptack Carp",
    client = {
        image = "carptack_carp_hook.png",
    }
},

["ufa_fusion_bl_hook"] = {
    label = "UFA Fusion BL",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Fusion BL",
    client = {
        image = "ufa_fusion_bl_hook.png",
    }
},

["predatek_octopus_hook"] = {
    label = "Predatek Octopus",
    weight = 20,
    stack = true,
    close = true,
    description = "Predatek Octopus",
    client = {
        image = "predatek_octopus_hook.png",
    }
},

["predatek_fusion_hook"] = {
    label = "Predatek Fusion",
    weight = 20,
    stack = true,
    close = true,
    description = "Predatek Fusion",
    client = {
        image = "predatek_fusion_hook.png",
    }
},

-- Attrezzatura Sub
["scuba"] = {
    label = "Attrezzatura subacquea",
    weight = 150,
    stack = false,
    close = true,
    description = "Attrezzatura subacquea",
    client = {
        image = "scuba.png",
    }
},

-- Pesci
["alligator_gar"] = {
    label = "Luccio Alligatore",
    weight = 275,
    stack = true,
    close = true,
    description = "Un luccio alligatore.",
    client = {
        image = "alligator_gar.png",
    }
},

["amur_pike"] = {
    label = "Luccio dell'Amur",
    weight = 375,
    stack = true,
    close = true,
    description = "Un luccio dell'Amur.",
    client = {
        image = "amur_pike.png",
    }
},

["atlantic_cod"] = {
    label = "Merluzzo Atlantico",
    weight = 150,
    stack = true,
    close = true,
    description = "Un merluzzo atlantico.",
    client = {
        image = "atlantic_cod.png",
    }
},

["fishing_gear"] = {
    label = "Attrezzatura da pesca",
    weight = 15,
    stack = false,
    close = true,
    description = "Attrezzatura essenziale per la pesca.",
    client = {
        image = "fishing_gear.png",
    }
},

["aquarium_pass"] = {
    label = "Pass per l'acquario",
    weight = 15,
    stack = false,
    close = true,
    description = "Pass per l'ingresso all'acquario.",
    client = {
        image = "aquarium_pass.png",
    }
},

["research_kit"] = {
    label = "Kit di ricerca",
    weight = 15,
    stack = false,
    close = true,
    description = "Un kit utile per condurre ricerche sul campo.",
    client = {
        image = "research_kit.png",
    }
},

["special_boots"] = {
    label = "Stivali speciali",
    weight = 15,
    stack = false,
    close = true,
    description = "Stivali progettati appositamente per terreni difficili.",
    client = {
        image = "special_boots.png",
    }
},

["museum_ticket"] = {
    label = "Biglietto del museo",
    weight = 15,
    stack = false,
    close = true,
    description = "Biglietto per l'ingresso al museo.",
    client = {
        image = "museum_ticket.png",
    }
},

["atlantic_salmon"] = {
    label = "Salmone Atlantico",
    weight = 250,
    stack = true,
    close = true,
    description = "Un salmone atlantico.",
    client = {
        image = "atlantic_salmon.png",
    }
},

["barbel"] = {
    label = "Barbo",
    weight = 300,
    stack = true,
    close = true,
    description = "Un barbo.",
    client = {
        image = "barbel.png",
    }
},

["beluga_sturgeon"] = {
    label = "Storione Beluga",
    weight = 132,
    stack = true,
    close = true,
    description = "Uno storione beluga.",
    client = {
        image = "beluga_sturgeon.png",
    }
},

["black_grayling"] = {
    label = "Temolo Nero",
    weight = 60,
    stack = true,
    close = true,
    description = "Un temolo nero.",
    client = {
        image = "black_grayling.png",
    }
},

["blacktip_reef_shark"] = {
    label = "Squalo Pinne Nere di Barriera",
    weight = 750,
    stack = true,
    close = true,
    description = "Uno squalo pinne nere di barriera.",
    client = {
        image = "blacktip_reef_shark.png",
    }
},

["blue_marlin"] = {
    label = "Marlin Blu",
    weight = 100,
    stack = true,
    close = true,
    description = "Un marlin blu.",
    client = {
        image = "blue_marlin.png",
    }
},

["bluefin_tuna"] = {
    label = "Tonno Rosso",
    weight = 135,
    stack = true,
    close = true,
    description = "Un tonno rosso.",
    client = {
        image = "bluefin_tuna.png",
    }
},

["bluegill"] = {
    label = "Persico Sole",
    weight = 60,
    stack = true,
    close = true,
    description = "Un persico sole.",
    client = {
        image = "bluegill.png",
    }
},

["brook_trout"] = {
    label = "Salmerino di Fonte",
    weight = 350,
    stack = true,
    close = true,
    description = "Un salmerino di fonte.",
    client = {
        image = "brook_trout.png",
    }
},

["brown_trout"] = {
    label = "Trota Fario",
    weight = 115,
    stack = true,
    close = true,
    description = "Una trota fario.",
    client = {
        image = "brown_trout.png",
    }
},

["bull_trout"] = {
    label = "Trota Toro",
    weight = 100,
    stack = true,
    close = true,
    description = "Una trota toro.",
    client = {
        image = "bull_trout.png",
    }
},

["chub"] = {
    label = "Cavedano",
    weight = 75,
    stack = true,
    close = true,
    description = "Un cavedano.",
    client = {
        image = "chub.png",
    }
},

["chum_salmon"] = {
    label = "Salmone Keta",
    weight = 300,
    stack = true,
    close = true,
    description = "Un salmone keta.",
    client = {
        image = "chum_salmon.png",
    }
},

["coho_salmon"] = {
    label = "Salmone Coho",
    weight = 250,
    stack = true,
    close = true,
    description = "Un salmone coho.",
    client = {
        image = "coho_salmon.png",
    }
},

["common_bleak"] = {
    label = "Alborella Comune",
    weight = 5,
    stack = true,
    close = true,
    description = "Un'alborella comune.",
    client = {
        image = "common_bleak.png",
    }
},

["common_bream"] = {
    label = "Brema Comune",
    weight = 200,
    stack = true,
    close = true,
    description = "Una brema comune.",
    client = {
        image = "common_bream.png",
    }
},

["common_carp"] = {
    label = "Carpa Comune",
    weight = 350,
    stack = true,
    close = true,
    description = "Una carpa comune.",
    client = {
        image = "common_carp.png",
    }
},

["crucian_carp"] = {
    label = "Carassio",
    weight = 70,
    stack = true,
    close = true,
    description = "Un carassio.",
    client = {
        image = "crucian_carp.png",
    }
},

["european_bass"] = {
    label = "Spigola Europea",
    weight = 125,
    stack = true,
    close = true,
    description = "Una spigola europea.",
    client = {
        image = "european_bass.png",
    }
},

["european_eel"] = {
    label = "Anguilla Europea",
    weight = 150,
    stack = true,
    close = true,
    description = "Un'anguilla europea.",
    client = {
        image = "european_eel.png",
    }
},

["european_flounder"] = {
    label = "Platessa Europea",
    weight = 85,
    stack = true,
    close = true,
    description = "Una platessa europea.",
    client = {
        image = "european_flounder.png",
    }
},

["european_perch"] = {
    label = "Persico Europeo",
    weight = 250,
    stack = true,
    close = true,
    description = "Un persico europeo.",
    client = {
        image = "european_perch.png",
    }
},

["european_sea_sturgeon"] = {
    label = "Storione di Mare Europeo",
    weight = 1000,
    stack = true,
    close = true,
    description = "Uno storione di mare europeo.",
    client = {
        image = "european_sea_sturgeon.png",
    }
},

["electric_eel"] = {
    label = "Anguilla Elettrica",
    weight = 750,
    stack = true,
    close = true,
    description = "Un'anguilla elettrica.",
    client = {
        image = "electric_eel.png",
    }
},

["garfish"] = {
    label = "Aguglia",
    weight = 25,
    stack = true,
    close = true,
    description = "Un'aguglia.",
    client = {
        image = "garfish.png",
    }
},

["giant_freshwater_stingray"] = {
    label = "Razza Gigante d'Acqua Dolce",
    weight = 175,
    stack = true,
    close = true,
    description = "Una razza gigante d'acqua dolce.",
    client = {
        image = "giant_freshwater_stingray.png",
    }
},

["giant_grouper"] = {
    label = "Cernia Gigante",
    weight = 130,
    stack = true,
    close = true,
    description = "Una cernia gigante.",
    client = {
        image = "giant_grouper.png",
    }
},

["giant_squid"] = {
    label = "Calamaro Gigante",
    weight = 1000,
    stack = true,
    close = true,
    description = "Un calamaro gigante.",
    client = {
        image = "giant_squid.png",
    }
},

["giant_trevally"] = {
    label = "Carango Gigante",
    weight = 100,
    stack = true,
    close = true,
    description = "Un carango gigante.",
    client = {
        image = "giant_trevally.png",
    }
},

["golden_trout"] = {
    label = "Trota Dorata",
    weight = 20,
    stack = true,
    close = true,
    description = "Una trota dorata.",
    client = {
        image = "golden_trout.png",
    }
},

["grass_carp"] = {
    label = "Carpa d'Erba",
    weight = 60,
    stack = true,
    close = true,
    description = "Una carpa d'erba.",
    client = {
        image = "grass_carp.png",
    }
},

["grass_pickerel"] = {
    label = "Luccio Erbaiolo",
    weight = 45,
    stack = true,
    close = true,
    description = "Un luccio erbaiolo.",
    client = {
        image = "grass_pickerel.png",
    }
},

["grayling"] = {
    label = "Temolo",
    weight = 40,
    stack = true,
    close = true,
    description = "Un temolo.",
    client = {
        image = "grayling.png",
    }
},

["great_barracuda"] = {
    label = "Grande Barracuda",
    weight = 450,
    stack = true,
    close = true,
    description = "Un grande barracuda.",
    client = {
        image = "great_barracuda.png",
    }
},

["grey_snapper"] = {
    label = "Dentice Grigio",
    weight = 200,
    stack = true,
    close = true,
    description = "Un dentice grigio.",
    client = {
        image = "grey_snapper.png",
    }
},

["huchen"] = {
    label = "Huchen",
    weight = 750,
    stack = true,
    close = true,
    description = "Un huchen.",
    client = {
        image = "huchen.png",
    }
},

["ide"] = {
    label = "Ido",
    weight = 50,
    stack = true,
    close = true,
    description = "Un ido.",
    client = {
        image = "ide.png",
    }
},

["indian_threadfish"] = {
    label = "Pesce Filo Indiano",
    weight = 125,
    stack = true,
    close = true,
    description = "Un pesce filo indiano.",
    client = {
        image = "indian_threadfish.png",
    }
},

["lake_sturgeon"] = {
    label = "Storione di Lago",
    weight = 800,
    stack = true,
    close = true,
    description = "Uno storione di lago.",
    client = {
        image = "lake_sturgeon.png",
    }
},

["largemouth_bass"] = {
    label = "Persico Trota Bocca Grande",
    weight = 50,
    stack = true,
    close = true,
    description = "Un persico trota a bocca grande.",
    client = {
        image = "largemouth_bass.png",
    }
},

["mahi_mahi"] = {
    label = "Lampuga",
    weight = 500,
    stack = true,
    close = true,
    description = "Una lampuga.",
    client = {
        image = "mahi_mahi.png",
    }
},

["malabar_grouper"] = {
    label = "Cernia del Malabar",
    weight = 750,
    stack = true,
    close = true,
    description = "Una cernia del Malabar.",
    client = {
        image = "malabar_grouper.png",
    }
},

["mirror_carp"] = {
    label = "Carpa Specchio",
    weight = 350,
    stack = true,
    close = true,
    description = "Una carpa specchio.",
    client = {
        image = "mirror_carp.png",
    }
},

["northern_pike"] = {
    label = "Luccio Nordico",
    weight = 250,
    stack = true,
    close = true,
    description = "Un luccio nordico.",
    client = {
        image = "northern_pike.png",
    }
},

["pink_river_dolphin"] = {
    label = "Delfino Rosa di Fiume",
    weight = 775,
    stack = true,
    close = true,
    description = "Un delfino rosa di fiume.",
    client = {
        image = "pink_river_dolphin.png",
    }
},

["pink_salmon"] = {
    label = "Salmone Rosa",
    weight = 100,
    stack = true,
    close = true,
    description = "Un salmone rosa.",
    client = {
        image = "pink_salmon.png",
    }
},

["prussian_carp"] = {
    label = "Carpa Prussiana",
    weight = 45,
    stack = true,
    close = true,
    description = "Una carpa prussiana.",
    client = {
        image = "prussian_carp.png",
    }
},

["pufferfish"] = {
    label = "Pesce Palla",
    weight = 75,
    stack = true,
    close = true,
    description = "Un pesce palla.",
    client = {
        image = "pufferfish.png",
    }
},

["pumpkinseed"] = {
    label = "Persico Sole Punteggiato",
    weight = 20,
    stack = true,
    close = true,
    description = "Un persico sole punteggiato.",
    client = {
        image = "pumpkinseed.png",
    }
},

["rainbow_trout"] = {
    label = "Trota Iridea",
    weight = 50,
    stack = true,
    close = true,
    description = "Una trota iridea.",
    client = {
        image = "rainbow_trout.png",
    }
},

["red_lionfish"] = {
    label = "Pesce Leone Rosso",
    weight = 50,
    stack = true,
    close = true,
    description = "Un pesce leone rosso.",
    client = {
        image = "red_lionfish.png",
    }
},

["redeye_piranha"] = {
    label = "Piranha dagli Occhi Rossi",
    weight = 60,
    stack = true,
    close = true,
    description = "Un piranha dagli occhi rossi.",
    client = {
        image = "redeye_piranha.png",
    }
},

["redfin_pickerel"] = {
    label = "Luccio Erbaiolo a Pinne Rosse",
    weight = 20,
    stack = true,
    close = true,
    description = "Un luccio erbaiolo a pinne rosse.",
    client = {
        image = "redfin_pickerel.png",
    }
},

["roach"] = {
    label = "Scardola",
    weight = 25,
    stack = true,
    close = true,
    description = "Una scardola.",
    client = {
        image = "roach.png",
    }
},

["sea_trout"] = {
    label = "Trota di Mare",
    weight = 100,
    stack = true,
    close = true,
    description = "Una trota di mare.",
    client = {
        image = "sea_trout.png",
    }
},

["silver_carp"] = {
    label = "Carpa Argento",
    weight = 500,
    stack = true,
    close = true,
    description = "Una carpa argento.",
    client = {
        image = "silver_carp.png",
    }
},

["skeleton"] = {
    label = "Scheletro",
    weight = 5,
    stack = true,
    close = true,
    description = "Uno scheletro.",
    client = {
        image = "skeleton.png",
    }
},

["smallmouth_bass"] = {
    label = "Persico Trota Bocca Piccola",
    weight = 75,
    stack = true,
    close = true,
    description = "Un persico trota a bocca piccola.",
    client = {
        image = "smallmouth_bass.png",
    }
},

["sockeye_salmon"] = {
    label = "Salmone Rosso",
    weight = 150,
    stack = true,
    close = true,
    description = "Un salmone rosso.",
    client = {
        image = "sockeye_salmon.png",
    }
},

["south_sea_pearl_oyster"] = {
    label = "Ostrica di Perle dei Mari del Sud",
    weight = 5,
    stack = true,
    close = true,
    description = "Un'ostrica di perle dei mari del sud.",
    client = {
        image = "south_sea_pearl_oyster.png",
    }
},

["tench"] = {
    label = "Tinca",
    weight = 125,
    stack = true,
    close = true,
    description = "Una tinca.",
    client = {
        image = "tench.png",
    }
},

["tiger_shark"] = {
    label = "Squalo Tigre",
    weight = 2750,
    stack = true,
    close = true,
    description = "Uno squalo tigre.",
    client = {
        image = "tiger_shark.png",
    }
},

["wels_catfish"] = {
    label = "Siluro",
    weight = 200,
    stack = true,
    close = true,
    description = "Un siluro.",
    client = {
        image = "wels_catfish.png",
    }
},

["white_sturgeon"] = {
    label = "Storione Bianco",
    weight = 400,
    stack = true,
    close = true,
    description = "Uno storione bianco.",
    client = {
        image = "white_sturgeon.png",
    }
},

["yellow_perch"] = {
    label = "Persico Giallo",
    weight = 20,
    stack = true,
    close = true,
    description = "Un persico giallo.",
    client = {
        image = "yellow_perch.png",
    }
},

["yellowfin_tuna"] = {
    label = "Tonno Pinna Gialla",
    weight = 450,
    stack = true,
    close = true,
    description = "Un tonno a pinna gialla.",
    client = {
        image = "yellowfin_tuna.png",
    }
},

["yellowtail_barracuda"] = {
    label = "Barracuda a Coda Gialla",
    weight = 55,
    stack = true,
    close = true,
    description = "Un barracuda a coda gialla.",
    client = {
        image = "yellowtail_barracuda.png",
    }
},

["zander"] = {
    label = "Lucioperca",
    weight = 100,
    stack = true,
    close = true,
    description = "Un lucioperca.",
    client = {
        image = "zander.png",
    }
},

["paddlefish"] = {
    label = "Pesce Pala",
    weight = 500,
    stack = true,
    close = true,
    description = "Un raro e illegale pesce pala.",
    client = {
        image = "paddlefish.png",
    }
},

["sawfish"] = {
    label = "Pesce Sega",
    weight = 500,
    stack = true,
    close = true,
    description = "Un raro e illegale pesce sega.",
    client = {
        image = "sawfish.png",
    }
},

["eel"] = {
    label = "Anguilla",
    weight = 500,
    stack = true,
    close = true,
    description = "Un'anguilla rara e illegale.",
    client = {
        image = "eel.png",
    }
},

["hammerheadshark"] = {
    label = "Squalo Martello",
    weight = 1250,
    stack = true,
    close = true,
    description = "Un raro e illegale squalo martello.",
    client = {
        image = "hammerheadshark.png",
    }
},

["seaturtle"] = {
    label = "Tartaruga Marina",
    weight = 1250,
    stack = true,
    close = true,
    description = "Una rara e illegale tartaruga marina.",
    client = {
        image = "seaturtle.png",
    }
},

["leopardshark"] = {
    label = "Squalo Leopardo",
    weight = 1250,
    stack = true,
    close = true,
    description = "Un raro e illegale squalo leopardo.",
    client = {
        image = "leopardshark.png",
    }
},

["blueshark"] = {
    label = "Squalo Blu",
    weight = 2000,
    stack = true,
    close = true,
    description = "Un leggendario e illegale squalo blu.",
    client = {
        image = "blueshark.png",
    }
},

["greatwhiteshark"] = {
    label = "Grande Squalo Bianco",
    weight = 5000,
    stack = true,
    close = true,
    description = "Un mitico e illegale grande squalo bianco.",
    client = {
        image = "greatwhiteshark.png",
    }
},

-- Oggetti da immersione
["ancient_artifact"] = {
    label = "Manufatto Antico",
    weight = 500,
    stack = true,
    close = true,
    description = "Un manufatto antico!",
    client = {
        image = "ancient_artifact.png",
    }
},

["antique_compass"] = {
    label = "Bussola Antica",
    weight = 500,
    stack = true,
    close = true,
    description = "Una bussola antica.",
    client = {
        image = "antique_compass.png",
    }
},

["enchanted_jewel"] = {
    label = "Gioiello Incantato",
    weight = 500,
    stack = true,
    close = true,
    description = "Un gioiello incantato.",
    client = {
        image = "enchanted_jewel.png",
    }
},

["luxury_watch"] = {
    label = "Orologio di Lusso",
    weight = 500,
    stack = true,
    close = true,
    description = "Un orologio costoso.",
    client = {
        image = "luxury_watch.png",
    }
},

["meteorite_ore"] = {
    label = "Minerale di Meteorite",
    weight = 500,
    stack = true,
    close = true,
    description = "Minerale di meteorite.",
    client = {
        image = "meteorite_ore.png",
    }
},

["mystic_crystal"] = {
    label = "Cristallo Mistico",
    weight = 500,
    stack = true,
    close = true,
    description = "Un cristallo mistico.",
    client = {
        image = "mystic_crystal.png",
    }
},

["phantom_amulet"] = {
    label = "Amuleto Fantasma",
    weight = 500,
    stack = true,
    close = true,
    description = "Un amuleto fantasma.",
    client = {
        image = "phantom_amulet.png",
    }
},

["precious_pearls"] = {
    label = "Perle Preziose",
    weight = 500,
    stack = true,
    close = true,
    description = "Una manciata di perle preziose.",
    client = {
        image = "precious_pearls.png",
    }
},

["rare_spices"] = {
    label = "Spezie Rare",
    weight = 500,
    stack = true,
    close = true,
    description = "Collezione di spezie rare.",
    client = {
        image = "rare_spices.png",
    }
},

["spy_gadget"] = {
    label = "Gadget da Spia",
    weight = 500,
    stack = true,
    close = true,
    description = "Un gadget da spia.",
    client = {
        image = "spy_gadget.png",
    }
},

	['hunting_license'] = {
         label = 'Licenza di Caccia',
        weight = 50,
        stack = false,
        close = true,
        client = {
            image = 'hunting_license.png',
        }
    },
    
    ['campfire'] = {
            label = "Falò",
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },

    ['primitive_grill'] = {
            label = "Griglia Primitiva",
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },

    ['advanced_grill'] = {
            label = "Griglia Avanzata",
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },

    ['hunting_bait'] = {
            label = "Esca da Caccia",
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },
    
    -- ### Dusa Hunting Animal Parts ###
    ['deer_beef'] = {
            label = 'Carne di Cervo', weight = 50, stack = true, close = true, description = '', client = { image = 'deer_beef.png' }
    },
    ['deer_rib'] = {
            label = 'Costata di Cervo', weight = 50, stack = true, close = true, description = '', client = { image = 'deer_rib.png' }
    },
    ['deer_leg'] = {
            label = 'Coscia di Cervo', weight = 50, stack = true, close = true, description = '', client = { image = 'deer_leg.png' }
    },
    ['rabbit_body'] = {
            label = 'Corpo di Coniglio', weight = 50, stack = true, close = true, description = '', client = { image = 'rabbit_body.png' }
    },
    ['rabbit_leg'] = {
            label = 'Zampa di Coniglio', weight = 50, stack = true, close = true, description = '', client = { image = 'rabbit_leg.png' }
    },
    ['rabbit_beef'] = {
            label = 'Carne di Coniglio', weight = 50, stack = true, close = true, description = '', client = { image = 'rabbit_beef.png' }
    },
    ['bear_beef'] = {
            label = 'Carne di Orso', weight = 50, stack = true, close = true, description = '', client = { image = 'bear_beef.png' }
    },
    ['bear_rib'] = {
            label = 'Costata di Orso', weight = 50, stack = true, close = true, description = '', client = { image = 'bear_rib.png' }
    },
    ['bear_leg'] = {
            label = 'Zampa di Orso', weight = 50, stack = true, close = true, description = '', client = { image = 'bear_leg.png' }
    },
    ['redpanda_body'] = {
            label = 'Corpo di Panda Rosso', weight = 50, stack = true, close = true, description = '', client = { image = 'redpanda_body.png' }
    },
    ['redpanda_leg'] = {
            label = 'Zampa di Panda Rosso', weight = 50, stack = true, close = true, description = '', client = { image = 'redpanda_leg.png' }
    },
    ['redpanda_beef'] = {
            label = 'Carne di Panda Rosso', weight = 50, stack = true, close = true, description = '', client = { image = 'redpanda_beef.png' }
    },
    ['boar_leg'] = {
            label = 'Zampa di Cinghiale', weight = 50, stack = true, close = true, description = '', client = { image = 'boar_leg.png' }
    },
    ['boar_beef'] = {
            label = 'Carne di Cinghiale', weight = 50, stack = true, close = true, description = '', client = { image = 'boar_beef.png' }
    },
    ['boar_rib'] = {
            label = 'Costata di Cinghiale', weight = 50, stack = true, close = true, description = '', client = { image = 'boar_rib.png' }
    },
    ['coyote_beef'] = {
            label = 'Carne di Coyote', weight = 50, stack = true, close = true, description = '', client = { image = 'coyote_beef.png' }
    },
    ['coyote_rib'] = {
            label = 'Costata di Coyote', weight = 50, stack = true, close = true, description = '', client = { image = 'coyote_rib.png' }
    },
    ['coyote_leg'] = {
            label = 'Zampa di Coyote', weight = 50, stack = true, close = true, description = '', client = { image = 'coyote_leg.png' }
    },
    ['mtlion_beef'] = {
            label = 'Carne di Puma', weight = 50, stack = true, close = true, description = '', client = { image = 'mtlion_beef.png' }
    },
    ['mtlion_rib'] = {
            label = 'Costata di Puma', weight = 50, stack = true, close = true, description = '', client = { image = 'mtlion_rib.png' }
    },
    ['mtlion_leg'] = {
            label = 'Zampa di Puma', weight = 50, stack = true, close = true, description = '', client = { image = 'mtlion_leg.png' }
    },
    ['lion_beef'] = {
            label = 'Carne di Leone', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_beef.png' }
    },
    ['lion_rib'] = {
            label = 'Costata di Leone', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_rib.png' }
    },
    ['lion_leg'] = {
            label = 'Zampa di Leone', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_leg.png' }
    },
    ['lion_body'] = {
            label = 'Corpo di Leone', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_body.png' }
    },
    ['oryx_beef'] = {
            label = 'Carne di Orice', weight = 50, stack = true, close = true, description = '', client = { image = 'oryx_beef.png' }
    },
    ['oryx_rib'] = {
            label = 'Costata di Orice', weight = 50, stack = true, close = true, description = '', client = { image = 'oryx_rib.png' }
    },
    ['oryx_leg'] = {
            label = 'Zampa di Orice', weight = 50, stack = true, close = true, description = '', client = { image = 'oryx_leg.png' }
    },
    ['antelope_beef'] = {
            label = 'Carne di Antilope', weight = 50, stack = true, close = true, description = '', client = { image = 'antelope_beef.png' }
    },
    ['antelope_rib'] = {
            label = 'Costata di Antilope', weight = 50, stack = true, close = true, description = '', client = { image = 'antelope_rib.png' }
    },
    ['antelope_leg'] = {
            label = 'Zampa di Antilope', weight = 50, stack = true, close = true, description = '', client = { image = 'antelope_leg.png' }
    },

    -- Cooked Items
    ['deer_beef_cooked'] = {
            label = 'Carne di Cervo Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'deer_beef_cooked.png' }
    },
    ['deer_rib_cooked'] = {
            label = 'Costata di Cervo Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'deer_rib_cooked.png' }
    },
    ['deer_leg_cooked'] = {
            label = 'Coscia di Cervo Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'deer_leg_cooked.png' }
    },
    ['rabbit_body_cooked'] = {
            label = 'Corpo di Coniglio Cotto', weight = 50, stack = true, close = true, description = '', client = { image = 'rabbit_body_cooked.png' }
    },

    ['rabbit_leg_cooked'] = {
            label = 'Zampa di Coniglio Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'rabbit_leg_cooked.png' }
    },
    ['rabbit_beef_cooked'] = {
            label = 'Carne di Coniglio Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'rabbit_beef_cooked.png' }
    },
    ['bear_beef_cooked'] = {
            label = 'Carne di Orso Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'bear_beef_cooked.png' }
    },
    ['bear_rib_cooked'] = {
            label = 'Costata di Orso Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'bear_rib_cooked.png' }
    },
    ['bear_leg_cooked'] = {
            label = 'Zampa di Orso Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'bear_leg_cooked.png' }
    },
    ['redpanda_body_cooked'] = {
            label = 'Corpo di Panda Rosso Cotto', weight = 50, stack = true, close = true, description = '', client = { image = 'redpanda_body_cooked.png' }
    },
    ['redpanda_leg_cooked'] = {
            label = 'Zampa di Panda Rosso Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'redpanda_leg_cooked.png' }
    },
    ['redpanda_beef_cooked'] = {
            label = 'Carne di Panda Rosso Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'redpanda_beef_cooked.png' }
    },
    ['boar_leg_cooked'] = {
            label = 'Zampa di Cinghiale Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'boar_leg_cooked.png' }
    },
    ['boar_beef_cooked'] = {
            label = 'Carne di Cinghiale Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'boar_beef_cooked.png' }
    },
    ['boar_rib_cooked'] = {
            label = 'Costata di Cinghiale Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'boar_rib_cooked.png' }
    },
    ['coyote_beef_cooked'] = {
            label = 'Carne di Coyote Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'coyote_beef_cooked.png' }
    },
    ['coyote_rib_cooked'] = {
            label = 'Costata di Coyote Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'coyote_rib_cooked.png' }
    },
    ['coyote_leg_cooked'] = {
            label = 'Zampa di Coyote Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'coyote_leg_cooked.png' }
    },
    ['mtlion_beef_cooked'] = {
            label = 'Carne di Puma Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'mtlion_beef_cooked.png' }
    },
    ['mtlion_rib_cooked'] = {
            label = 'Costata di Puma Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'mtlion_rib_cooked.png' }
    },
    ['mtlion_leg_cooked'] = {
            label = 'Zampa di Puma Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'mtlion_leg_cooked.png' }
    },
    ['lion_beef_cooked'] = {
            label = 'Carne di Leone Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_beef_cooked.png' }
    },
    ['lion_rib_cooked'] = {
            label = 'Costata di Leone Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_rib_cooked.png' }
    },
    ['lion_leg_cooked'] = {
            label = 'Zampa di Leone Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_leg_cooked.png' }
    },
    ['lion_body_cooked'] = {
            label = 'Corpo di Leone Cotto', weight = 50, stack = true, close = true, description = '', client = { image = 'lion_body_cooked.png' }
    },
    ['oryx_beef_cooked'] = {
            label = 'Carne di Orice Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'oryx_beef_cooked.png' }
    },
    ['oryx_rib_cooked'] = {
            label = 'Costata di Orice Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'oryx_rib_cooked.png' }
    },
    ['oryx_leg_cooked'] = {
            label = 'Zampa di Orice Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'oryx_leg_cooked.png' }
    },
    ['antelope_beef_cooked'] = {
            label = 'Carne di Antilope Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'antelope_beef_cooked.png' }
    },
    ['antelope_rib_cooked'] = {
            label = 'Costata di Antilope Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'antelope_rib_cooked.png' }
    },
    ['antelope_leg_cooked'] = {
            label = 'Zampa di Antilope Cotta', weight = 50, stack = true, close = true, description = '', client = { image = 'antelope_leg_cooked.png' }
    },

    ['hide'] = {
            label = "Pelle Animale",
        weight = 50,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "hide.png",
        }
    },

    ['binocular'] = {
            label = 'Binocolo',
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },

    ['hunting_trap'] = {
            label = 'Trappola da Caccia',
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },

    ['hunting_laptop'] = {
            label = 'Laptop da Caccia',
        weight = 50,
        stack = true,
        close = true,
        description = "",
    },



----------------------canna buona che toglie il 30%
['weed_seed'] = {
	    label = 'Seme di Marijuana',
    weight = 25,
     stack = true,
        close = true,
},
['weed_plant'] = {
    label = 'Pianta di Marijuana',
    weight = 250,
      stack = true,
        close = true,
},


['weed_dry'] = {
    label = 'Marijuana Essiccata',
    weight = 100,
  stack = true,
        close = true,
},
['weed_bag'] = {
    label = 'Bustina di Marijuana',
    weight = 25,
  stack = true,
        close = true,
},

--------------------------
['id_card'] = {
		label = "Carta d'identità",
		weight = 1,
		stack = false,
		close = true,
		description = "Documento di riconoscimento personale."
	},

	['driving_license'] = {
 		label = "Patente di guida",
		weight = 1,
		stack = false,
		close = true,
		description = "Licenza per condurre veicoli a motore."
	},

	['boat_license'] = {
 		label = "Patente nautica",
		weight = 1,
		stack = false,
		close = true,
		description = "Licenza per condurre imbarcazioni."
	},

	['flying_license'] = {
 		label = "Patente di volo",
		weight = 1,
		stack = false,
		close = true,
		description = "Licenza per pilotare velivoli."
	},

['portoarmi'] = {
        label = "Licenza Porto d'Armi",
        weight = 10,
        stack = false,
        close = true,
        description = "Tesserino ufficiale LSPD per il porto d'armi occultato."
    },
	['reregistration_vehicle'] = {
 		label = "Modulo Reimmatricolazione",
		weight = 1,
		stack = true,
		close = true,
		description = "Modulo ufficiale per la reimmatricolazione di un veicolo."
	},

	['change_plate'] = {
 		label = "Modulo Cambio Targa",
		weight = 1,
		stack = true,
		close = true,
		description = "Modulo ufficiale per la richiesta di cambio targa."
	},

['ziptie'] = {
    label = 'Fascette',
    weight = 25,
   stack = true,
        close = true,
},
['headbag'] = {
    label = 'Sacco per la testa',
    weight = 100,
     stack = true,
        close = true,
},


	['clerk_tablet'] = {
     label = 'Usb Dark Web',
    weight = 5,
    stack = true
},
['vehicle_sale_agreement'] = {
    label = 'Contratto di Vendita',
    weight = 2,
    stack = true
},
['signed_vehicle_sale_agreement'] = {
    label = 'Contratto Firmato',
    weight = 2,
    stack = false
},
['empty_invoice'] = {
    label = 'Fattura Vuota',
    weight = 1,
    stack = true
},
['invoice'] = {
    label = 'Fattura',
    weight = 2,
    stack = false
},
['empty_ticket'] = {
    label = 'Ticket Vuoto',
    weight = 1,
    stack = true
},
['ticket'] = {
    label = 'Ticket',
    weight = 1,
    stack = false
},
['payment_terminal'] = {
    label = 'Terminale POS',
    weight = 5,
    stack = false
},

['receipt'] = {
    label = 'Ricevuta',
    weight = 1,
    stack = false
},
	['skateboard'] = {
     label = 'Skateboard',
    weight = 100,
    stack = false,
    close = true,
},
['bandage'] = {
		label = 'Benda',
		weight = 5,  -- Prima era 50
		stack = true,
		close = true,
	},
	['barattolourine'] = {
 		label = 'Barattolo delle urine',
		weight = 5,  -- Prima era 50
		stack = true,
		close = true,
	},
['finger_scanner'] = {
		label = 'Dispositivo impronte digitali',
		weight = 5,  -- Prima era 50
		stack = true,
		close = true,
	},
	['ifak'] = {
 		label = 'IFAK', -- Kit medico individuale
		weight = 25,  -- Prima era 200
		stack = true,
		close = true,
	},

	['tourniquet'] = {
 		label = 'Laccio Emostatico',
		weight = 10,  -- Prima era 100
		stack = true,
		close = true,
	},

	['gauze'] = {
 		label = 'Garza',
		weight = 2,   -- Prima era 50
		stack = true,
		close = true,
	},

	['burn_gel'] = {
 		label = 'Gel Ustioni',
		weight = 12,  -- Prima era 100
		stack = true,
		close = true,
	},

	['surgical_kit'] = {
 		label = 'Kit Chirurgico',
		weight = 75, -- Prima era 500
		stack = true,
		close = true,
	},

	['saline_bag'] = {
 		label = 'Sacca Salina',
		weight = 50, -- Prima era 300
		stack = true,
		close = true,
	},

	['leg_brace'] = {
 		label = 'Tutore Gamba',
		weight = 50, -- Prima era 300
		stack = true,
		close = true,
	},

	['arm_brace'] = {
 		label = 'Tutore Braccio',
		weight = 50, -- Prima era 300
		stack = true,
		close = true,
	},

	['body_brace'] = {
 		label = 'Busto Ortopedico',
		weight = 150, -- Prima era 1000
		stack = true,
		close = true,
	},

	['neck_brace'] = {
 		label = 'Collare Cervicale',
		weight = 25,  -- Prima era 300
		stack = true,
		close = true,
	},

	['ice_pack'] = {
 		label = 'Ghiaccio Istantaneo',
		weight = 10,  -- Prima era 150
		stack = true,
		close = true,
	},

	['painkillers'] = {
 		label = 'Antidolorifici',
		weight = 2,   -- Prima era 50
		stack = true,
		close = true,
	},

	['defibrillator'] = {
 		label = 'Defibrillatore',
		weight = 150, -- Prima era 1000
		stack = true,
		close = true,
	},

	['adrenaline_syringe'] = {
 		label = 'Siringa Adrenalina',
		weight = 5,  -- Prima era 100
		stack = true,
		close = true,
	},

	['wheelchair'] = {
 		label = 'Sedia a Rotelle',
		weight = 250, -- Prima era 2500
		stack = false,
		close = true,
	},

	['walking_stick'] = {
 		label = 'Bastone da Passeggio',
		weight = 100, -- Prima era 1000
		stack = false,
		close = true,
	},

	['med_bag'] = {
 		label = 'Borsa Medica',
		weight = 100, -- Prima era 500
		stack = false,
		close = true,
	},

	['body_bag'] = {
 		label = 'Sacca Mortuaria',
		weight = 75, -- Prima era 500
		stack = true,
		close = true,
	},

	['ecg'] = {
 		label = 'Monitor ECG',
		weight = 100, -- Prima era 1000
		stack = true,
		close = false,
	},


['vehiclekeys'] = {
    label = 'Chiavi Veicolo',
    weight = 0,
    stack = false,
    close = true,
    description = 'Chiavi di un veicolo',
},

['adminvehiclekey'] = {
    label = 'Chiave Veicolo Admin',
    weight = 0,
    stack = false,
    close = true,
    description = 'Chiave universale che apre qualsiasi veicolo',
},

['carlockpick'] = {
    label = 'Grimaldello',
    weight = 500,
    stack = true,
    close = true,
    description = 'Usato per scassinare veicoli',
},

['caradvancedlockpick'] = {
    label = 'Grimaldello Avanzato',
    weight = 500,
    stack = true,
    close = true,
    description = 'Un grimaldello più robusto per serrature difficili',
},

['plate'] = {
    label = 'Targa',
    weight = 500,
    stack = true,
    close = true,
    description = 'Una targa di un veicolo',
},

['screwdriver'] = {
    label = 'Cacciavite',
    weight = 500,
    stack = true,
    close = true,
    description = 'Utile per cambiare le targhe',
},

['vehiclegps'] = {
    label = 'GPS Veicolo',
    weight = 500,
    stack = true,
    close = true,
    description = 'Installa un localizzatore GPS su un veicolo',
},

['vehicletracker'] = {
    label = 'Localizzatore Veicolo',
    weight = 500,
    stack = true,
    close = true,
    description = 'Individua un veicolo tracciato',
},
    ['tablet'] = { label = 'Tablet', weight = 1000, stack = false, description = 'Un tablet multifunzione' },
  

['chemicals'] = {
	label = 'Sostanze chimiche',
	weight = 1,
	stack = true,
	close = true,
	description = '',
},

['alcohol'] = {
	label = 'Alcol Etilico',
	weight = 1,
	stack = true,
	close = true,
	description = '',
},

['digiscanner'] = {
	label = 'Scanner Digitale',
	weight = 1,
	stack = true,
	close = true,
	description = 'Scanner professionale in grado di rilevare dispositivi spia tramite firme elettromagnetiche',
},



   ['libretto'] = {
        label = 'Libretto veicolo',
        weight = 50,
        stack = false,
        close = true,
        consume = 0,
        description = 'Documento di proprietà del veicolo.',
        client = {
            export = 'giammark_motorizzazione.useLibretto'
        }
    },

    ['assicurazione'] = {
        label = 'Assicurazione veicolo',
        weight = 20,
        stack = false,
        close = true,
        consume = 0,
        description = 'Contrassegno assicurativo del veicolo.',
        client = {
            export = 'giammark_motorizzazione.useInsurance'
        }
    },
['lucky_7s_tequila'] = {
    label = 'Lucky 7’s Tequila',
    weight = 5,
    stack = true,
},

['blackjack_bourbon'] = {
    label = 'Blackjack Bourbon',
    weight = 5,
    stack = true,
},
['gesso'] = {
    label = 'Gesso Medico',
    weight = 5,
    stack = true,
},

	['tvremote'] = 
	{
		label = 'Telecomando TV',
		weight = 1,
		stack = true,
		close = true,
	},
['vehicletv'] = 
	{
		label = 'Telecomando TV macchina',
		weight = 1,
		stack = true,
		close = true,
	},


	["engine_oil"] = {
     label = "Olio Motore",
    weight = 50, -- 1 litro di olio ≈ 1 kg
},
["tyre_replacement"] = {
    label = "Sostituzione Pneumatici",
    weight = 10, -- Un pneumatico medio pesa circa 10-15 kg, ma qui si intende il kit base
},
["clutch_replacement"] = {
    label = "Kit Frizione",
    weight = 7, -- Un kit frizione completo pesa circa 10-15 kg
},
["air_filter"] = {
    label = "Filtro Aria",
    weight = 1, -- Un filtro aria pesa pochi etto
},
["spark_plug"] = {
    label = "Candela di Accensione",
    weight = 1.2, -- Una candela pesa circa 50-200 grammi
},
["brakepad_replacement"] = {
    label = "Pastiglie Freno",
    weight = 1, -- Un set di pastiglie pesa circa 1-2 kg
},
["suspension_parts"] = {
    label = "Componenti Sospensioni",
    weight = 5, -- Componenti base delle sospensioni (es. ammortizzatore + molla)
},
-- Motori
["i4_engine"] = {
    label = "Motore 4 Cilindri in Linea",
    weight = 75, -- Un motore I4 pesa circa 120-180 kg
},
["v6_engine"] = {
    label = "Motore V6",
    weight = 100, -- Un motore V6 pesa circa 180-220 kg
},
["v8_engine"] = {
    label = "Motore V8",
    weight = 125, -- Un motore V8 pesa circa 200-300 kg
},
["v12_engine"] = {
    label = "Motore V12",
    weight = 150, -- Un motore V12 pesa circa 250-350 kg
},
["turbocharger"] = {
    label = "Turbocompressore",
    weight = 5, -- Un turbo pesa circa 8-15 kg
},
-- Motori Elettrici
["ev_motor"] = {
    label = "Motore Elettrico",
    weight = 40, -- Un motore elettrico compatto pesa circa 70-100 kg
},
["ev_battery"] = {
    label = "Batteria Veicolo Elettrico",
    weight = 100, -- Una batteria EV media pesa circa 200-300 kg
},
["ev_coolant"] = {
    label = "Liquido Refrigerante EV",
    weight = 2, -- 5 litri di liquido refrigerante
},
-- Trasmissione
["awd_drivetrain"] = {
    label = "Trasmissione Integrale (AWD)",
    weight = 40, -- Una trasmissione AWD pesa circa 70-100 kg
},
["rwd_drivetrain"] = {
    label = "Trasmissione Posteriore (RWD)",
    weight = 30, -- Una trasmissione RWD pesa circa 50-70 kg
},
["fwd_drivetrain"] = {
    label = "Trasmissione Anteriore (FWD)",
    weight = 25, -- Una trasmissione FWD pesa circa 40-60 kg
},
-- Tuning
["slick_tyres"] = {
    label = "Pneumatici Slick",
    weight = 5, -- Un pneumatico slick pesa circa 8-12 kg
},
["semi_slick_tyres"] = {
    label = "Pneumatici Semi-Slick",
    weight = 5,
},
["offroad_tyres"] = {
    label = "Pneumatici Fuoristrada",
    weight = 7, -- Pneumatici fuoristrada sono più pesanti
},
["drift_tuning_kit"] = {
    label = "Kit Tuning Drift",
    weight = 10, -- Kit di tuning base
},
["ceramic_brakes"] = {
    label = "Freni in Ceramica",
    weight = 4, -- Un set di dischi e pastiglie in ceramica
},
-- Componenti Estetici
["lighting_controller"] = {
    label = "Controllo Luci",
    weight = 1.5, -- Dispositivo elettronico leggero
    client = {
      event = "jg-mechanic:client:show-lighting-controller",
    }
},
["stancing_kit"] = {
    label = "Kit Distanziali",
    weight = 2, -- Componenti per regolare l'assetto
    client = {
      event = "jg-mechanic:client:show-stancer-kit",
    }
},
["cosmetic_part"] = {
    label = "Componenti Estetici",
    weight = 1, -- Es. spoiler, minigonne (varia molto, weight medio)
},
["respray_kit"] = {
    label = "Kit Verniciatura",
    weight = 5, -- Vernice, attrezzi, mascherine
},
["vehicle_wheels"] = {
    label = "Set Ruote Veicolo",
    weight = 20, -- 4 ruote in lega + pneumatici (circa 10 kg a ruota)
},
["tyre_smoke_kit"] = {
    label = "Kit Fumo Pneumatici",
    weight = 1, -- Kit per fumo (liquido + pompa)
},
["bulletproof_tyres"] = {
    label = "Pneumatici Antiproiettile",
    weight = 7, -- Più pesanti dei normali pneumatici
},
["extras_kit"] = {
    label = "Kit Extra",
    weight = 2, -- Componenti aggiuntivi vari
},
-- Nitrous e Pulizia
["nitrous_bottle"] = {
    label = "Bombola Protossido",
    weight = 5, -- Bombola da 5-10 kg
    client = {
      event = "jg-mechanic:client:use-nitrous-bottle",
    }
},
["empty_nitrous_bottle"] = {
    label = "Bombola Protossido Vuota",
    weight = 2, -- Bombola vuota
},
["nitrous_install_kit"] = {
    label = "Kit Installazione Protossido",
    weight = 1, -- Tubazioni, valvole, ecc.
},
["cleaning_kit"] = {
    label = "Kit Pulizia",
    weight = 2, -- Prodotti e panni
    client = {
      event = "jg-mechanic:client:clean-vehicle",
    }
},
["repair_kit"] = {
    label = "Kit Riparazione",
    weight = 5, -- Attrezzi e materiali di consumo
    client = {
      event = "jg-mechanic:client:repair-vehicle",
    }
},
["duct_tape"] = {
    label = "Nastro Americano",
    weight = 1.3, -- Un rotolo di nastro
    client = {
      event = "jg-mechanic:client:use-duct-tape",
    }
},
-- Prestazioni
["performance_part"] = {
    label = "Componenti Prestazionali",
    weight = 5, -- Es. centralina, filtri sportivi, ecc.
},
-- Tablet Meccanico
["mechanic_tablet"] = {
    label = "Tablet Meccanico",
    weight = 1, -- Un tablet pesa circa 500 g - 1 kg
    client = {
      event = "jg-mechanic:client:use-tablet",
    }
},
-- Cambio
["manual_gearbox"] = {
    label = "Cambio Manuale",
    weight = 20, -- Un cambio manuale pesa circa 30-50 kg
},
['fascette'] = {
    label = 'Fascette',
    weight = 100,
    stack = true,
    close = true,
    description = 'Fascette di plastica utilizzabili tramite ox_target.'
},

['nanospytablet'] = {
    label = 'Tablet Spia Nano',
    weight = 1,
    stack = false,
    close = true,
    description = 'Tablet avanzato per la sorveglianza e il monitoraggio di dispositivi spia'
},
['nanospymic'] = {
    label = 'Microfono Spia Nano',
    weight = 1,
    stack = true,
    close = true,
    description = 'Microfono nascosto per la sorveglianza audio'
},
['nanospycam'] = {
    label = 'Telecamera Spia Nano',
    weight = 1,
    stack = true,
    close = true,
    description = 'Telecamera spia nascosta per la sorveglianza visiva'
},
['nanospygps'] = {
    label = 'Localizzatore GPS Spia Nano',
    weight = 1,
    stack = true,
    close = true,
    description = 'Dispositivo GPS per la sorveglianza veicolare'
},


['goldchain'] = {
	label = 'Catena d\'oro',
	weight = 750,
	stack = true,
},

["iphone"] = {
	label = "iPhone",
	weight = 500,
	stack = true,
	close = true,
	description = "Telefono molto costoso",
	client = {
		image = "iphone.png",
	}
},
["diamond"] = {
	label = "Diamante",
	weight = 500,
	stack = true,
	close = true,
	description = "Un diamante sembra il colpo grosso!",
	client = {
		image = "diamond.png",
	}
},


	['wood'] = {
 		label = 'Legno',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	
	['metal'] = {
 		label = 'Metallo',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	
	['rope'] = {
 		label = 'Corda',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	
	['shovel'] = {
 		label = 'Pala',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	['medicalbag'] = {
 		label = 'Borsa Medica',
		weight = 110,
		stack = true,
		description = "Un kit medico completo per trattare ferite e malattie.",
	},
	
	['bandage'] = {
 		label = 'Benda',
		weight = 50,
		stack = true,
		description = "Una semplice benda usata per coprire e proteggere le ferite.",
	},
	
	['defibrillator'] = {
 		label = 'Defibrillatore',
		weight = 50,
		stack = true,
		description = "Usato per rianimare i pazienti.",
	},
	
	['tweezers'] = {
 		label = 'Pinzette',
		weight = 50,
		stack = true,
		description = "Pinzette di precisione per rimuovere oggetti estranei, come proiettili, dalle ferite.",
	},
	
	['burncream'] = {
 		label = 'Crema per Ustioni',
		weight = 50,
		stack = true,
		description = "Crema specializzata per trattare e lenire ustioni e irritazioni cutanee.",
	},
	
	['suturekit'] = {
 		label = 'Kit di Sutura',
		weight = 50,
		stack = true,
		description = "Un kit contenente strumenti chirurgici e materiali per suturare e chiudere ferite.",
	},
	
	['icepack'] = {
 		label = 'Impacco di Ghiaccio',
		weight = 100,
		stack = true,
		description = "Un impacco di ghiaccio usato per ridurre il gonfiore e alleviare il dolore e l'infiammazione.",
	},
	
	['stretcher'] = {
 		label = 'Barella',
		weight = 100,
		stack = true,
		description = "Una barella usata per spostare pazienti che necessitano di cure mediche.",
	},
	
	['emstablet'] = {
 		label = 'Ems tablet',
		weight = 100,
		stack = true,
	},
	






	["kq_outfitbag"] = {
 		label = "Borsone vestiti",
		weight = 35,
		stack = false,
		close = false,
	},
	["casinochips"] = {
 		label = "Casino Chips",
		weight = 1,
		stack = true,
		close = false,
	},
	
	--------------------------
	['binocolo'] = {
 		label = 'Binocolo',
		weight = 16,
		stack = false,
		close = true,
	},

	["targa"] = {
 		label = "Targa",
		weight = 30,
		stack = false,
		close = true,
	},

	["contrattonoleggio"] = {
 		label = "Contratto di noleggio",
		weight = 5,
		stack = false,
		close = true,
	},
	["contract"] = {
 		label = "Contratto",
		weight = 5,
		stack = true,
		close = true,
	},
	["cascolvl1"] = {
 		label = "Casco lvl 1",
		weight = 50,
        durability = 0.01,
		stack = false,
		close = true,
	},
	["cascolvl2"] = {
 		label = "Casco lvl 2",
		weight = 50,
        durability = 0.01,
		stack = false,
		close = true,
	},
['valigetta'] = {
    label = 'Valigetta',
    weight = 1000,
    stack = false,
    consume = 0, -- 0 impedisce che l'item venga rimosso dall'inventario
    client = {
        event = 'valigetta:client:usa'
    }
},
	["cascolvl3"] = {
 		label = "Casco lvl 3",
		weight = 50,
        durability = 0.01,
		stack = false,
		close = true,
	},
	['giubbo1'] = {
 		label = 'Giubotto Leggero',
		weight = 40,
        durability = 0.01,
		stack = false,
        consume = 0,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
		}
	},

	['giubbo2'] = {
 		label = 'Giubotto Pesante',
		weight = 50,
        durability = 0.01,
		stack = false,
        consume = 0,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
		}
	},
	['giubbo3'] = {
 		label = 'Giubotto Super Pesante',
		weight = 75,
        durability = 0.01,
		stack = false,
        consume = 0,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
		}
	},


    -- =========================================================
    -- GIUBBOTTI F.D.O. URBS
    -- Le immagini sono in ox_inventory/web/images/ con lo stesso nome dell'item.
    -- =========================================================
    ['giubbo_polizia'] = {
        label = 'Giubbotto Polizia di Stato',
        weight = 75,
        durability = 0.01,
        stack = false,
        consume = 0,
        close = true,
        description = 'Giubbotto antiproiettile in dotazione alla Polizia di Stato.',
        client = {
            image = 'giubbo_polizia.png',
            anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
        }
    },

    ['giubbo_carabinieri'] = {
        label = 'Giubbotto Carabinieri',
        weight = 75,
        durability = 0.01,
        stack = false,
        consume = 0,
        close = true,
        description = 'Giubbotto antiproiettile in dotazione all\'Arma dei Carabinieri.',
        client = {
            image = 'giubbo_carabinieri.png',
            anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
        }
    },

    ['giubbo_gdf'] = {
        label = 'Giubbotto Guardia di Finanza',
        weight = 75,
        durability = 0.01,
        stack = false,
        consume = 0,
        close = true,
        description = 'Giubbotto antiproiettile in dotazione alla Guardia di Finanza.',
        client = {
            image = 'giubbo_gdf.png',
            anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
        }
    },

    ['giubbo_polpen'] = {
        label = 'Giubbotto Polizia Penitenziaria',
        weight = 75,
        durability = 0.01,
        stack = false,
        consume = 0,
        close = true,
        description = 'Giubbotto antiproiettile in dotazione alla Polizia Penitenziaria.',
        client = {
            image = 'giubbo_polpen.png',
            anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
        }
    },
	["librominerali"] = {
 		label = "Libro dei Minerali in chimica",
		weight = 40,
		stack = false,
		close = false,
	},

	["racing_tablet"] = {
 		label = "Tablet per gare",
		weight = 7,
		stack = false,
		close = false,
	},
--------------zaini
["backpack"] = {
	label = "Zaino Piccolo",
	weight = 7,
	stack = false,
	close = false,
},
["backpack2"] = {
	label = "Zaino Medio",
	weight = 7,
	stack = false,
	close = false,
},
["backpack3"] = {
	label = "Zaino Grande",
	weight = 7,
	stack = false,
	close = false,
},
["backpack1"] = {
	label = "Borsone",
	weight = 7,
	stack = false,
	close = false,
},
	['tabacco'] = {
 		label = 'Tabacco',
		weight = 2,
		stack = true,
	},
	['tabaccosecco'] = {
 		label = 'Tabacco Secco',
		weight = 2,
		stack = true,
	},

	['mouthtape'] = {
 		label = 'Nastro',
		weight = 40,
		stack = true,
	},
	['portafoglio'] = {
 		label = 'Portafoglio',
		weight = 5,
		stack = false,
	},

	['torture_kit'] = {
 		label = 'Kit delle torture',
		weight = 500,
		stack = false,
		close = true,
	},

	['bandage'] = {
 		label = 'Benda',
		weight = 57,
		client = {
			anim = { dict = 'missheistdockssetup1clipboard@idle_a', clip = 'idle_a', flag = 49 },
			prop = { model = `prop_rolled_sock_02`, pos = vec3(-0.14, -0.14, -0.08), rot = vec3(-50.0, -50.0, 0.0) },
			disable = { move = true, car = true, combat = true },
			usetime = 2500,
		}
	},
--- # start 0r-heistpack
['heistpack_drone']   = { label = 'Drone da Rapina', weight = 0.0, stack = true },
['gasmask']           = { label = 'Maschera Antigas', weight = 0.0, stack = true },
['heistpack_drill']   = { label = 'Trapano', weight = 0.0, stack = true },
['lockpick']          = { label = 'Grimaldello', weight = 0.0, stack = true },
['heavy_rope']        = { label = 'Corda Robusta', weight = 0.0, stack = true },
['heistpack_anchor']  = { label = 'Gancio di Ancoraggio', weight = 0.0, stack = true },
['heistpack_grinder'] = { label = 'Smerigliatrice', weight = 1.0, stack = true },
['heistpack_tablet']  = { label = 'Tablet da Rapina', weight = 1.0, stack = true },
['heist_paint_1']     = { label = 'Quadro #1', weight = 500, stack = false, client = { image = "heist_painting.png" } },
['heist_paint_2']     = { label = 'Quadro #2', weight = 500, stack = false, client = { image = "heist_painting.png" } },
['heist_paint_3']     = { label = 'Quadro #3', weight = 500, stack = false, client = { image = "heist_painting.png" } },
['heist_paint_4']     = { label = 'Quadro #4', weight = 500, stack = false, client = { image = "heist_painting.png" } },
--- # end 0r-heistpack
	['black_money'] = {
 		label = 'Soldi Sporchi',
	},
-- MANGIARE
    ['cake_chocolate'] = {
        label = 'Torta al Cioccolato',
        weight = 310,
        stack = true,
        close = true
    },
    ['cake_chocolate2'] = {
        label = 'Torta al Cioccolato 2',
        weight = 315,
        stack = true,
        close = true
    },
    ['cake_strawberry'] = {
        label = 'Torta alle Fragole',
        weight = 320,
        stack = true,
        close = true
    },
    ['floss_blue'] = {
        label = 'Zucchero Filato Blu',
        weight = 40,
        stack = true,
        close = true
    },
    ['floss_pink'] = {
        label = 'Zucchero Filato Rosa',
        weight = 42,
        stack = true,
        close = true
    },
    ['floss_purple'] = {
        label = 'Zucchero Filato Viola',
        weight = 44,
        stack = true,
        close = true
    },
    ['floss_rainbow'] = {
        label = 'Zucchero Filato Arcobaleno',
        weight = 46,
        stack = true,
        close = true
    },
    ['pop_chocolate'] = {
        label = 'Cake Pop al Cioccolato',
        weight = 50,
        stack = true,
        close = true
    },
    ['pop_darkpurple'] = {
        label = 'Cake Pop Viola Scuro',
        weight = 51,
        stack = true,
        close = true
    },
    ['pop_lightblue'] = {
        label = 'Cake Pop Azzurro',
        weight = 52,
        stack = true,
        close = true
    },
    ['pop_lightpink'] = {
        label = 'Cake Pop Rosa Chiaro',
        weight = 53,
        stack = true,
        close = true
    },
    ['pop_white'] = {
        label = 'Cake Pop Bianco',
        weight = 54,
        stack = true,
        close = true
    },
    ['swissroll'] = {
        label = 'Rotolo Svizzero',
        weight = 150,
        stack = true,
        close = true
    },
    ['mochi_bear'] = {
        label = 'Mochi Orsetto',
        weight = 60,
        stack = true,
        close = true
    },
    ['mochi_duck'] = {
        label = 'Mochi Papera',
        weight = 61,
        stack = true,
        close = true
    },
    ['mochi_panda'] = {
        label = 'Mochi Panda',
        weight = 62,
        stack = true,
        close = true
    },
    ['mochi_pig'] = {
        label = 'Mochi Maialino',
        weight = 63,
        stack = true,
        close = true
    },
    ['mochi_seal'] = {
        label = 'Mochi Foca',
        weight = 64,
        stack = true,
        close = true
    },
    ['heartcandy'] = {
        label = 'Caramella a Cuore',
        weight = 10,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 1 ♡꘎

    ['fp1_chicken'] = {
        label = 'Pollo Fritto Croccante',
        weight = 180,
        stack = true,
        close = true
    },
    ['fp1_crunch_burger'] = {
        label = 'Burger Croccante',
        weight = 250,
        stack = true,
        close = true
    },
    ['fp1_deluxe_burger'] = {
        label = 'Burger Deluxe',
        weight = 280,
        stack = true,
        close = true
    },
    ['fp1_dunked_wing'] = {
        label = 'Aletta di Pollo',
        weight = 80,
        stack = true,
        close = true
    },
    ['fp1_wrap'] = {
        label = 'Piadina di Pollo',
        weight = 210,
        stack = true,
        close = true
    },
    ['fp1_chicken_box'] = {
        label = 'Box di Pollo',
        weight = 500,
        stack = true,
        close = true
    },
    ['fp1_chicken_nuggets'] = {
        label = 'Crocchette di Pollo',
        weight = 190,
        stack = true,
        close = true
    },
    ['fp1_coleslaw'] = {
        label = 'Insalata Coleslaw',
        weight = 120,
        stack = true,
        close = true
    },
    ['fp1_mash'] = {
        label = 'Purè di Patate',
        weight = 160,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 2 ♡꘎

    ['braai_broodjie'] = {
        label = 'Toast Braaibroodjie',
        weight = 145,
        stack = true,
        close = true
    },
    ['grilled_cheese'] = {
        label = 'Toast al Formaggio',
        weight = 148,
        stack = true,
        close = true
    },
    ['cheeseburger'] = {
        label = 'Cheeseburger',
        weight = 265,
        stack = true,
        close = true
    },
    ['grilled_russian'] = {
        label = 'Salsiccia Russa Grigliata',
        weight = 185,
        stack = true,
        close = true
    },
    ['grilled_sausage'] = {
        label = 'Salsiccia Grigliata',
        weight = 188,
        stack = true,
        close = true
    },
    ['dino_nugget'] = {
        label = 'Crocchetta Dinosauro',
        weight = 35,
        stack = true,
        close = true
    },
    ['garlic_bread'] = {
        label = 'Pane all\'Aglio',
        weight = 130,
        stack = true,
        close = true
    },
    ['hot_pockets'] = {
        label = 'Calzone Farcito',
        weight = 220,
        stack = true,
        close = true
    },
    ['hotdog'] = {
        label = 'Hotdog',
        weight = 240,
        stack = true,
        close = true
    },
    ['roasted_corn'] = {
        label = 'Pannocchia Arrosto',
        weight = 155,
        stack = true,
        close = true
    },
    ['pizza_roll'] = {
        label = 'Rotolo di Pizza',
        weight = 195,
        stack = true,
        close = true
    },
    ['roasted_mushroom'] = {
        label = 'Fungo Arrosto',
        weight = 85,
        stack = true,
        close = true
    },
    ['skewer_chicken'] = {
        label = 'Spiedino di Pollo',
        weight = 165,
        stack = true,
        close = true
    },
    ['skewer_beef'] = {
        label = 'Spiedino di Manzo',
        weight = 175,
        stack = true,
        close = true
    },
    ['skewer_cherry'] = {
        label = 'Spiedino di Ciliegie',
        weight = 105,
        stack = true,
        close = true
    },
    ['steak'] = {
        label = 'Bistecca',
        weight = 400,
        stack = true,
        close = true
    },
    ['ramen_noodles'] = {
        label = 'Ramen',
        weight = 350,
        stack = true,
        close = true
    },
    ['soup'] = {
        label = 'Zuppa',
        weight = 360,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 3 (SUSHI & SEAFOOD) ♡꘎

    ['fp3_avo_bite'] = {
        label = 'Bocconcino di Avocado',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp3_fried_bite'] = {
        label = 'Bocconcino Fritto',
        weight = 26,
        stack = true,
        close = true
    },
    ['fp3_maki'] = {
        label = 'Maki',
        weight = 30,
        stack = true,
        close = true
    },
    ['fp3_avo_nigiri'] = {
        label = 'Nigiri all\'Avocado',
        weight = 32,
        stack = true,
        close = true
    },
    ['fp3_salmon_nigiri'] = {
        label = 'Nigiri al Salmone',
        weight = 34,
        stack = true,
        close = true
    },
    ['fp3_calamari_rings'] = {
        label = 'Anelli di Calamaro',
        weight = 120,
        stack = true,
        close = true
    },
    ['fp3_fish'] = {
        label = 'Pesce',
        weight = 200,
        stack = true,
        close = true
    },
    ['fp3_fish_cake'] = {
        label = 'Tortino di Pesce',
        weight = 135,
        stack = true,
        close = true
    },
    ['fp3_octopus_leg'] = {
        label = 'Tentacolo di Polpo',
        weight = 110,
        stack = true,
        close = true
    },
    ['fp3_shrimp'] = {
        label = 'Gamberetto',
        weight = 20,
        stack = true,
        close = true
    },
    ['fp3_sushi'] = {
        label = 'Piatto Sushi',
        weight = 380,
        stack = true,
        close = true
    },
    ['fp3_dish_calamari'] = {
        label = 'Piatto di Calamari',
        weight = 385,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 4 ♡꘎

    ['meaty_footlong'] = {
        label = 'Panino Gigante',
        weight = 420,
        stack = true,
        close = true
    },
    ['mince_wrap2'] = {
        label = 'Piadina con Macinato',
        weight = 225,
        stack = true,
        close = true
    },
    ['omelet2'] = {
        label = 'Frittata',
        weight = 175,
        stack = true,
        close = true
    },
    ['pizza_1'] = {
        label = 'Pizza Intera 1',
        weight = 500,
        stack = true,
        close = true
    },
    ['spring_roll2'] = {
        label = 'Involtino Primavera',
        weight = 95,
        stack = true,
        close = true
    },
    ['cheesy_noodles'] = {
        label = 'Noodles al Formaggio',
        weight = 310,
        stack = true,
        close = true
    },
    ['cheesy_chips'] = {
        label = 'Patatine al Formaggio',
        weight = 290,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 5 (HALLOWEEN) ♡꘎

    ['berry_pie_slice'] = {
        label = 'Fetta di Crostata ai Frutti',
        weight = 115,
        stack = true,
        close = true
    },
    ['candy_corn'] = {
        label = 'Candy Corn',
        weight = 12,
        stack = true,
        close = true
    },
    ['eye_gummy'] = {
        label = 'Caramella Occhio',
        weight = 14,
        stack = true,
        close = true
    },
    ['ghost_cookie_green'] = {
        label = 'Biscotto Fantasma Verde',
        weight = 48,
        stack = true,
        close = true
    },
    ['mummy_macroon'] = {
        label = 'Macaron Mummia',
        weight = 49,
        stack = true,
        close = true
    },
    ['pizza_slice'] = {
        label = 'Trancio di Pizza',
        weight = 125,
        stack = true,
        close = true
    },
    ['mummy_sausage'] = {
        label = 'Salsiccia Mummia',
        weight = 105,
        stack = true,
        close = true
    },
    ['zombie_finger1'] = {
        label = 'Dito di Zombie',
        weight = 38,
        stack = true,
        close = true
    },
    ['pumpkin_cookie'] = {
        label = 'Biscotto Zucca',
        weight = 55,
        stack = true,
        close = true
    },
    ['vamp_donut'] = {
        label = 'Ciambella Vampiro',
        weight = 90,
        stack = true,
        close = true
    },
    ['meaty_pie'] = {
        label = 'Torta di Carne',
        weight = 370,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 6 (MEXICAN & DESSERTS) ♡꘎

    ['burrito_carnitas'] = {
        label = 'Burrito con Carnitas',
        weight = 330,
        stack = true,
        close = true
    },
    ['churros_1'] = {
        label = 'Churros',
        weight = 85,
        stack = true,
        close = true
    },
    ['churros_2'] = {
        label = 'Churros Ciotola',
        weight = 220,
        stack = true,
        close = true
    },
    ['nachos'] = {
        label = 'Nachos',
        weight = 165,
        stack = true,
        close = true
    },
    ['quesadilla_chicken'] = {
        label = 'Quesadilla di Pollo',
        weight = 215,
        stack = true,
        close = true
    },
    ['taco_steak'] = {
        label = 'Taco di Carne',
        weight = 160,
        stack = true,
        close = true
    },
    ['tres_leches_cake'] = {
        label = 'Torta Tres Leches',
        weight = 295,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 7 XMAS ♡꘎

    ['fp7_asparagus'] = {
        label = 'Asparagi',
        weight = 70,
        stack = true,
        close = true
    },
    ['fp7_baked_potato'] = {
        label = 'Patata al Forno',
        weight = 140,
        stack = true,
        close = true
    },
    ['fp7_bun'] = {
        label = 'Panino Morbido',
        weight = 95,
        stack = true,
        close = true
    },
    ['fp7_cane_bread'] = {
        label = 'Pane a Bastoncino',
        weight = 100,
        stack = true,
        close = true
    },
    ['fp7_cranberry_pie'] = {
        label = 'Torta di Mirtilli Rossi',
        weight = 345,
        stack = true,
        close = true
    },
    ['fp7_pizza_man'] = {
        label = 'Omino di Pizza',
        weight = 170,
        stack = true,
        close = true
    },
    ['fp7_pizza_sock'] = {
        label = 'Calza di Pizza',
        weight = 168,
        stack = true,
        close = true
    },
    ['fp7_mushroom'] = {
        label = 'Fungo',
        weight = 28,
        stack = true,
        close = true
    },
    ['fp7_sausage_pie'] = {
        label = 'Torta di Salsiccia',
        weight = 325,
        stack = true,
        close = true
    },
    ['fp7_deviled_egg'] = {
        label = 'Uovo Ripieno',
        weight = 38,
        stack = true,
        close = true
    },
    ['fp7_bowl_meatball'] = {
        label = 'Polpetta con Forchetta',
        weight = 45,
        stack = true,
        close = true
    },
    ['fp7_bowl_sprout'] = {
        label = 'Cavoletto di Bruxelles',
        weight = 33,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 8 - CHRISTMAS SNACKS ♡꘎

    ['fp8_cupcake_green'] = {
        label = 'Cupcake Verde',
        weight = 108,
        stack = true,
        close = true
    },
    ['fp8_fruit_stick_1'] = {
        label = 'Spiedino di Frutta 1',
        weight = 112,
        stack = true,
        close = true
    },
    ['fp8_macaroon'] = {
        label = 'Macaron',
        weight = 42,
        stack = true,
        close = true
    },
    ['fp8_nougat_red'] = {
        label = 'Torrone Rosso',
        weight = 82,
        stack = true,
        close = true
    },
    ['fp8_sberry_santa'] = {
        label = 'Babbo Natale alla Fragola',
        weight = 92,
        stack = true,
        close = true
    },
    ['fp8_tree_cookie'] = {
        label = 'Biscotto ad Albero',
        weight = 58,
        stack = true,
        close = true
    },
    ['fp8_mini_trifle'] = {
        label = 'Mini Zuppa Inglese',
        weight = 138,
        stack = true,
        close = true
    },
    ['metalx_lime'] = {
        label = 'Energy Drink al Lime',
        weight = 200,
        stack = true,
        close = true
    },
    ['metalx_orange'] = {
        label = 'Energy Drink all\'Arancia',
        weight = 201,
        stack = true,
        close = true
    },

    -- ꘎♡ CAFFETTERIA (SWEET TREATS PACK) ♡꘎

    ['smallcup_hotchoc'] = {
        label = 'Cioccolata Calda in Tazzina',
        weight = 100,
        stack = true,
        close = true
    },
    ['smallcup_latte'] = {
        label = 'Latte Macchiato in Tazzina',
        weight = 101,
        stack = true,
        close = true
    },
    ['bigcup_espresso'] = {
        label = 'Espresso Grande',
        weight = 150,
        stack = true,
        close = true
    },
    ['bigcup_hotchoc'] = {
        label = 'Cioccolata Calda Grande',
        weight = 151,
        stack = true,
        close = true
    },
    ['bigcup2_latte'] = {
        label = 'Latte Macchiato Grande 2',
        weight = 152,
        stack = true,
        close = true
    },

    -- ꘎♡ KRUSHERS E MILKSHAKE (FOOD PACK 1) ♡꘎

    ['fp1_banana_krusher'] = {
        label = 'Frullato alla Banana',
        weight = 250,
        stack = true,
        close = true
    },
    ['fp1_choc_krusher'] = {
        label = 'Frullato al Cioccolato',
        weight = 251,
        stack = true,
        close = true
    },
    ['fp1_grape_krusher'] = {
        label = 'Frullato all\'Uva',
        weight = 252,
        stack = true,
        close = true
    },
    ['fp1_oreo_krusher'] = {
        label = 'Frullato all\'Oreo',
        weight = 253,
        stack = true,
        close = true
    },

    -- ꘎♡ BIBITE E LIMONATE (FOOD PACK 2 & 3) ♡꘎

    ['drink_banana'] = {
        label = 'Bibita alla Banana',
        weight = 210,
        stack = true,
        close = true
    },
    ['drink_blueberry'] = {
        label = 'Bibita al Mirtillo',
        weight = 211,
        stack = true,
        close = true
    },
    ['drink_cherry'] = {
        label = 'Bibita alla Ciliegia',
        weight = 212,
        stack = true,
        close = true
    },
    ['drink_strawberry'] = {
        label = 'Bibita alla Fragola',
        weight = 213,
        stack = true,
        close = true
    },
    ['lemonade'] = {
        label = 'Limonata',
        weight = 214,
        stack = true,
        close = true
    },
    ['sberry_lemonade'] = {
        label = 'Limonata alla Fragola',
        weight = 215,
        stack = true,
        close = true
    },
    ['horchata'] = {
        label = 'Horchata',
        weight = 216,
        stack = true,
        close = true
    },
    ['fp3_drink_green'] = {
        label = 'Drink Verde',
        weight = 220,
        stack = true,
        close = true
    },
    ['fp3_drink_red'] = {
        label = 'Drink Rosso',
        weight = 221,
        stack = true,
        close = true
    },
    ['fp3_drink_yellow'] = {
        label = 'Drink Giallo',
        weight = 222,
        stack = true,
        close = true
    },

    -- ꘎♡ BEVANDE SCHIUMOSE (FOOD PACK 4) ♡꘎

    ['foam_drink_blue'] = {
        label = 'Bibita Schiumosa Blu',
        weight = 230,
        stack = true,
        close = true
    },
    ['foam_drink_green'] = {
        label = 'Bibita Schiumosa Verde',
        weight = 231,
        stack = true,
        close = true
    },
    ['foam_drink_orange'] = {
        label = 'Bibita Schiumosa Arancione',
        weight = 232,
        stack = true,
        close = true
    },
    ['foam_drink_purple'] = {
        label = 'Bibita Schiumosa Viola',
        weight = 233,
        stack = true,
        close = true
    },
    ['foam_drink_red'] = {
        label = 'Bibita Schiumosa Rossa',
        weight = 234,
        stack = true,
        close = true
    },

    -- ꘎♡ BEVANDE HALLOWEEN E FESTIVE (FOOD PACK 5 E 8) ♡꘎

    ['halloween_green_drink'] = {
        label = 'Bibita Verde di Halloween',
        weight = 190,
        stack = true,
        close = true
    },
    ['halloween_orange_drink'] = {
        label = 'Bibita Arancione di Halloween',
        weight = 191,
        stack = true,
        close = true
    },
    ['halloween_white_drink'] = {
        label = 'Bibita Bianca di Halloween',
        weight = 192,
        stack = true,
        close = true
    },
    ['fp8_pink_milkshake'] = {
        label = 'Milkshake Rosa',
        weight = 240,
        stack = true,
        close = true
    },

    -- ꘎♡ BIRRE (BEER PACK 1) ♡꘎

    ['bp1_beer_glass2'] = {
        label = 'Bicchiere di Birra 2',
        weight = 421,
        stack = true,
        close = true
    },
    ['bp1_beer_glass3'] = {
        label = 'Bicchiere di Birra 3',
        weight = 422,
        stack = true,
        close = true
    },
    ['bp1_can_belgian_ale'] = {
        label = 'Lattina di Belgian Ale',
        weight = 331,
        stack = true,
        close = true
    },
    ['bp1_can_pilsner'] = {
        label = 'Lattina di Pilsner',
        weight = 332,
        stack = true,
        close = true
    },
    ['bp1_bottle_ipa'] = {
        label = 'Bottiglia di Birra IPA',
        weight = 456,
        stack = true,
        close = true
    },
    ['bp1_bottle_pale_ale'] = {
        label = 'Bottiglia di Pale Ale',
        weight = 457,
        stack = true,
        close = true
    },

    -- ꘎♡ ALCOLICI E COCKTAIL (GLASS DRINKS & SHOTS) ♡꘎

    ['grapefruit_margarita'] = {
        label = 'Margarita al Pompelmo',
        weight = 260,
        stack = true,
        close = true
    },
    ['peach_margarita'] = {
        label = 'Margarita alla Pesca',
        weight = 261,
        stack = true,
        close = true
    },
    ['watermelon_margarita'] = {
        label = 'Margarita all\'Anguria',
        weight = 262,
        stack = true,
        close = true
    },
    ['collins_orange'] = {
        label = 'Collins Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_pink'] = {
        label = 'Coppa Rosa',
        weight = 271,
        stack = true,
        close = true
    },
    ['cognac_balloon_brown'] = {
        label = 'Cognac Marrone',
        weight = 272,
        stack = true,
        close = true
    },
    ['cocktail_lblue'] = {
        label = 'Cocktail Azzurro',
        weight = 273,
        stack = true,
        close = true
    },
    ['martini_red'] = {
        label = 'Martini Rosso',
        weight = 274,
        stack = true,
        close = true
    },
    ['highball_green'] = {
        label = 'Highball Verde',
        weight = 275,
        stack = true,
        close = true
    },
    ['grappa_yellow'] = {
        label = 'Grappa Gialla',
        weight = 276,
        stack = true,
        close = true
    },
    ['fp8_cranberry_shot'] = {
        label = 'Shot ai Mirtilli Rossi',
        weight = 50,
        stack = true,
        close = true
    },
    ['fp8_jello_shot_green'] = {
        label = 'Cicchetto di Gelatina Verde',
        weight = 51,
        stack = true,
        close = true
    },
    ['fp8_martini_green'] = {
        label = 'Martini Verde di Natale',
        weight = 280,
        stack = true,
        close = true
    },
    ['fp8_rum_pink'] = {
        label = 'Rum Rosa',
        weight = 281,
        stack = true,
        close = true
    },
    ['fp8_sugar_cookie_martini'] = {
        label = 'Martini al Biscotto',
        weight = 282,
        stack = true,
        close = true
    },

    -- ꘎♡ SWEET TREATS PACK ♡꘎

    ['pretty_poison'] = {
        label = 'Pretty Poison Drink',
        weight = 200,
        stack = true,
        close = true
    },
    ['smallcup'] = {
        label = 'Tazzina Piccola',
        weight = 100,
        stack = true,
        close = true
    },
    ['smallcup2'] = {
        label = 'Tazzina Piccola 2',
        weight = 100,
        stack = true,
        close = true
    },
    ['bigcup'] = {
        label = 'Tazza Grande',
        weight = 150,
        stack = true,
        close = true
    },
    ['bigcup2'] = {
        label = 'Tazza Grande 2',
        weight = 150,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 1 ♡꘎

    ['tray_meal'] = {
        label = 'Vassoio Pasto',
        weight = 500,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 2 ♡꘎

    ['chicken'] = {
        label = 'Pollo',
        weight = 185,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 3 (SUSHI & SEAFOOD) ♡꘎

    ['bowl_drink'] = {
        label = 'Drink in Ciotola',
        weight = 220,
        stack = true,
        close = true
    },
    ['prawn'] = {
        label = 'Gambero',
        weight = 20,
        stack = true,
        close = true
    },
    ['bowl_octopus'] = {
        label = 'Ciotola di Polpo',
        weight = 380,
        stack = true,
        close = true
    },
    ['fish_plate'] = {
        label = 'Piatto di Pesce',
        weight = 380,
        stack = true,
        close = true
    },
    ['prawn_plate'] = {
        label = 'Piatto di Gamberi',
        weight = 380,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 4 ♡꘎

    ['mince_wrap_plate'] = {
        label = 'Piatto Piadina',
        weight = 350,
        stack = true,
        close = true
    },
    ['omelet_plate'] = {
        label = 'Piatto Frittata',
        weight = 350,
        stack = true,
        close = true
    },
    ['spring_rolls_plate'] = {
        label = 'Piatto Involtini',
        weight = 350,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 5 (HALLOWEEN) ♡꘎

    ['macroon'] = {
        label = 'Macaron Base',
        weight = 50,
        stack = true,
        close = true
    },
    ['spooky_drink'] = {
        label = 'Spooky Drink',
        weight = 190,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 6 (MEXICAN & DESSERTS) ♡꘎

    ['mexican_drink'] = {
        label = 'Drink Messicano',
        weight = 200,
        stack = true,
        close = true
    },

    -- ꘎♡ BEER PACK 1 & GLASS DRINKS ♡꘎

    ['beer_glass'] = {
        label = 'Bicchiere di Birra',
        weight = 420,
        stack = true,
        close = true
    },
    ['beer_can'] = {
        label = 'Lattina di Birra',
        weight = 330,
        stack = true,
        close = true
    },
    ['beer_bottle'] = {
        label = 'Bottiglia di Birra',
        weight = 450,
        stack = true,
        close = true
    },
    ['collins_glass'] = {
        label = 'Bicchiere Collins',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_glass'] = {
        label = 'Coppa',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon'] = {
        label = 'Bicchiere Cognac',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_glass'] = {
        label = 'Bicchiere Cocktail',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_glass'] = {
        label = 'Bicchiere Martini',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_glass'] = {
        label = 'Bicchiere Highball',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa'] = {
        label = 'Bicchiere Grappa',
        weight = 270,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 7 (XMAS) ♡꘎

    ['fp7_burger'] = {
        label = 'Burger di Natale',
        weight = 250,
        stack = true,
        close = true
    },

    -- ꘎♡ FOOD PACK 8 (CHRISTMAS SNACKS & DRINKS) ♡꘎

    ['fp8_hot_choc'] = {
        label = 'Cioccolata Calda Natalizia',
        weight = 150,
        stack = true,
        close = true
    },
    ['fp8_cupcake_red'] = {
        label = 'Cupcake Rosso',
        weight = 108,
        stack = true,
        close = true
    },
    ['fp8_fruit_stick_2'] = {
        label = 'Spiedino di Frutta 2',
        weight = 112,
        stack = true,
        close = true
    },
    ['fp8_nougat_green'] = {
        label = 'Torrone Verde',
        weight = 82,
        stack = true,
        close = true
    },
    ['fp8_nougat_orange'] = {
        label = 'Torrone Arancione',
        weight = 82,
        stack = true,
        close = true
    },
    ['fp8_nougat_purple'] = {
        label = 'Torrone Viola',
        weight = 82,
        stack = true,
        close = true
    },
    ['fp8_nougat_yellow'] = {
        label = 'Torrone Giallo',
        weight = 82,
        stack = true,
        close = true
    },
    ['fp8_jello_shot_red'] = {
        label = 'Cicchetto di Gelatina Rossa',
        weight = 51,
        stack = true,
        close = true
    },
    ['fp8_martini_red'] = {
        label = 'Martini Rosso di Natale',
        weight = 280,
        stack = true,
        close = true
    },
    ['fp8_rum_green'] = {
        label = 'Rum Verde',
        weight = 281,
        stack = true,
        close = true
    },
    ['fp8_rum_white'] = {
        label = 'Rum Bianco',
        weight = 281,
        stack = true,
        close = true
    },

['berry_pie'] = {
        label = 'Torta ai Frutti di Bosco',
        weight = 300,
        stack = true,
        close = true
    },
    ['bigcup2_espresso'] = {
        label = 'Espresso Grande 2',
        weight = 150,
        stack = true,
        close = true
    },
    ['bigcup2_hotchoc'] = {
        label = 'Cioccolata Calda Grande 2',
        weight = 150,
        stack = true,
        close = true
    },
    ['bigcup_latte'] = {
        label = 'Latte Macchiato Grande',
        weight = 150,
        stack = true,
        close = true
    },
    ['bp1_beer_glass1'] = {
        label = 'Bicchiere di Birra 1',
        weight = 420,
        stack = true,
        close = true
    },
    ['bp1_beer_glass4'] = {
        label = 'Bicchiere di Birra 4',
        weight = 420,
        stack = true,
        close = true
    },
    ['bp1_beer_glass5'] = {
        label = 'Bicchiere di Birra 5',
        weight = 420,
        stack = true,
        close = true
    },
    ['bp1_bottle_belgian_ale'] = {
        label = 'Bottiglia di Belgian Ale',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_brown_ale'] = {
        label = 'Bottiglia di Brown Ale',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_german_bock'] = {
        label = 'Bottiglia di German Bock',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_pilsner'] = {
        label = 'Bottiglia di Pilsner',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_porter'] = {
        label = 'Bottiglia di Porter',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_sour_ale'] = {
        label = 'Bottiglia di Sour Ale',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_stout'] = {
        label = 'Bottiglia di Stout',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_bottle_wheat'] = {
        label = 'Bottiglia di Wheat Beer',
        weight = 450,
        stack = true,
        close = true
    },
    ['bp1_can_brown_ale'] = {
        label = 'Lattina di Brown Ale',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_german_bock'] = {
        label = 'Lattina di German Bock',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_ipa'] = {
        label = 'Lattina di IPA',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_pale_ale'] = {
        label = 'Lattina di Pale Ale',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_porter'] = {
        label = 'Lattina di Porter',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_sour_ale'] = {
        label = 'Lattina di Sour Ale',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_stout'] = {
        label = 'Lattina di Stout',
        weight = 330,
        stack = true,
        close = true
    },
    ['bp1_can_wheat'] = {
        label = 'Lattina di Wheat Beer',
        weight = 330,
        stack = true,
        close = true
    },
    ['burrito_chicken'] = {
        label = 'Burrito di Pollo',
        weight = 330,
        stack = true,
        close = true
    },
    ['burrito_fish'] = {
        label = 'Burrito di Pesce',
        weight = 330,
        stack = true,
        close = true
    },
    ['burrito_steak'] = {
        label = 'Burrito di Carne',
        weight = 330,
        stack = true,
        close = true
    },
    ['candy_bucket'] = {
        label = 'Cestino di Dolcetti',
        weight = 250,
        stack = true,
        close = true
    },
    ['chicken_drumstick'] = {
        label = 'Fuso di Pollo',
        weight = 120,
        stack = true,
        close = true
    },
    ['cocktail_brown'] = {
        label = 'Cocktail Marrone',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_dred'] = {
        label = 'Cocktail Rosso Scuro',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_green'] = {
        label = 'Cocktail Verde',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_orange'] = {
        label = 'Cocktail Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_pink'] = {
        label = 'Cocktail Rosa',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_red'] = {
        label = 'Cocktail Rosso',
        weight = 270,
        stack = true,
        close = true
    },
    ['cocktail_yellow'] = {
        label = 'Cocktail Giallo',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_dred'] = {
        label = 'Cognac Rosso Scuro',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_green'] = {
        label = 'Cognac Verde',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_lblue'] = {
        label = 'Cognac Azzurro',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_orange'] = {
        label = 'Cognac Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_pink'] = {
        label = 'Cognac Rosa',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_red'] = {
        label = 'Cognac Rosso',
        weight = 270,
        stack = true,
        close = true
    },
    ['cognac_balloon_yellow'] = {
        label = 'Cognac Giallo',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_brown'] = {
        label = 'Collins Marrone',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_dred'] = {
        label = 'Collins Rosso Scuro',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_green'] = {
        label = 'Collins Verde',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_lblue'] = {
        label = 'Collins Azzurro',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_pink'] = {
        label = 'Collins Rosa',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_red'] = {
        label = 'Collins Rosso',
        weight = 270,
        stack = true,
        close = true
    },
    ['collins_yellow'] = {
        label = 'Collins Giallo',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_brown'] = {
        label = 'Coppa Marrone',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_dred'] = {
        label = 'Coppa Rossa Scura',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_green'] = {
        label = 'Coppa Verde',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_lblue'] = {
        label = 'Coppa Azzurra',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_orange'] = {
        label = 'Coppa Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_red'] = {
        label = 'Coppa Rossa',
        weight = 270,
        stack = true,
        close = true
    },
    ['coupe_yellow'] = {
        label = 'Coppa Gialla',
        weight = 270,
        stack = true,
        close = true
    },
    ['drink_lime'] = {
        label = 'Bibita al Lime',
        weight = 210,
        stack = true,
        close = true
    },
    ['foam_drink_pink'] = {
        label = 'Bibita Schiumosa Rosa',
        weight = 230,
        stack = true,
        close = true
    },
    ['fp1_coleslaw_meal'] = {
        label = 'Pasto con Coleslaw',
        weight = 350,
        stack = true,
        close = true
    },
    ['fp1_crunch_box'] = {
        label = 'Box Burger Croccante',
        weight = 400,
        stack = true,
        close = true
    },
    ['fp1_crunch_meal'] = {
        label = 'Pasto Burger Croccante',
        weight = 450,
        stack = true,
        close = true
    },
    ['fp1_deluxe_box'] = {
        label = 'Box Burger Deluxe',
        weight = 450,
        stack = true,
        close = true
    },
    ['fp1_deluxe_meal'] = {
        label = 'Pasto Burger Deluxe',
        weight = 500,
        stack = true,
        close = true
    },
    ['fp1_dunked_wings_box'] = {
        label = 'Box Alette di Pollo',
        weight = 350,
        stack = true,
        close = true
    },
    ['fp1_mash_meal'] = {
        label = 'Pasto con Purè',
        weight = 350,
        stack = true,
        close = true
    },
    ['fp1_sberry_krusher'] = {
        label = 'Frullato alla Fragola',
        weight = 250,
        stack = true,
        close = true
    },
    ['fp3_bowl_drink_blue'] = {
        label = 'Drink in Ciotola Blu',
        weight = 220,
        stack = true,
        close = true
    },
    ['fp3_bowl_drink_green'] = {
        label = 'Drink in Ciotola Verde',
        weight = 220,
        stack = true,
        close = true
    },
    ['fp3_dish_fish'] = {
        label = 'Piatto di Pesce Completo',
        weight = 380,
        stack = true,
        close = true
    },
    ['fp3_dish_prawn'] = {
        label = 'Piatto di Gamberi Completo',
        weight = 380,
        stack = true,
        close = true
    },
    ['fp3_fried_nigiri'] = {
        label = 'Nigiri Fritto',
        weight = 35,
        stack = true,
        close = true
    },
    ['fp3_maki_bite'] = {
        label = 'Bocconcino Maki',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp3_nori_bite'] = {
        label = 'Bocconcino Nori',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp3_nori_nigiri'] = {
        label = 'Nigiri Nori',
        weight = 35,
        stack = true,
        close = true
    },
    ['fp3_prawn_bite'] = {
        label = 'Bocconcino di Gambero',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp3_prawn_nigiri'] = {
        label = 'Nigiri di Gambero',
        weight = 35,
        stack = true,
        close = true
    },
    ['fp3_red_fish_bite'] = {
        label = 'Bocconcino di Pesce Rosso',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp3_red_nigiri'] = {
        label = 'Nigiri Rosso',
        weight = 35,
        stack = true,
        close = true
    },
    ['fp3_salmon_bite'] = {
        label = 'Bocconcino di Salmone',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp3_shrimp_bite'] = {
        label = 'Bocconcino di Gamberetto',
        weight = 25,
        stack = true,
        close = true
    },
    ['fp7_bowl_meatballs'] = {
        label = 'Ciotola di Polpette',
        weight = 150,
        stack = true,
        close = true
    },
    ['fp7_bowl_sprouts'] = {
        label = 'Ciotola di Cavoletti',
        weight = 120,
        stack = true,
        close = true
    },
    ['fp7_bun_tree'] = {
        label = 'Panino ad Albero',
        weight = 95,
        stack = true,
        close = true
    },
    ['fp7_cane_bread_plank'] = {
        label = 'Tagliere Pane a Bastoncino',
        weight = 250,
        stack = true,
        close = true
    },
    ['fp7_mini_burgers'] = {
        label = 'Mini Burgers',
        weight = 180,
        stack = true,
        close = true
    },
    ['fp7_mini_burgers_plank'] = {
        label = 'Tagliere Mini Burgers',
        weight = 400,
        stack = true,
        close = true
    },
    ['fp7_mushroom_plank'] = {
        label = 'Tagliere Funghi',
        weight = 200,
        stack = true,
        close = true
    },
    ['fp7_pizza_man_plank'] = {
        label = 'Tagliere Omino di Pizza',
        weight = 350,
        stack = true,
        close = true
    },
    ['fp7_pizza_sock_plank'] = {
        label = 'Tagliere Calza di Pizza',
        weight = 350,
        stack = true,
        close = true
    },
    ['fp7_plated_asparagus'] = {
        label = 'Piatto di Asparagi',
        weight = 200,
        stack = true,
        close = true
    },
    ['fp7_plated_baked_potato'] = {
        label = 'Piatto Patata al Forno',
        weight = 250,
        stack = true,
        close = true
    },
    ['fp7_plated_cranberry_pie'] = {
        label = 'Piatto Torta ai Mirtilli Rossi',
        weight = 380,
        stack = true,
        close = true
    },
    ['fp7_plated_deviled_egg'] = {
        label = 'Piatto Uova Ripiene',
        weight = 150,
        stack = true,
        close = true
    },
    ['fp7_plated_sausage_pie'] = {
        label = 'Piatto Torta di Salsiccia',
        weight = 360,
        stack = true,
        close = true
    },
    ['fp8_nougat_pink'] = {
        label = 'Torrone Rosa',
        weight = 82,
        stack = true,
        close = true
    },
    ['fp8_rum_pink (2)'] = {
        label = 'Rum Rosa Doppio',
        weight = 281,
        stack = true,
        close = true
    },
    ['ghost_cookie_blue'] = {
        label = 'Biscotto Fantasma Blu',
        weight = 48,
        stack = true,
        close = true
    },
    ['ghost_cookie_pink'] = {
        label = 'Biscotto Fantasma Rosa',
        weight = 48,
        stack = true,
        close = true
    },
    ['grappa_brown'] = {
        label = 'Grappa Marrone',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa_dred'] = {
        label = 'Grappa Rossa Scura',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa_green'] = {
        label = 'Grappa Verde',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa_lblue'] = {
        label = 'Grappa Azzurra',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa_orange'] = {
        label = 'Grappa Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa_pink'] = {
        label = 'Grappa Rosa',
        weight = 270,
        stack = true,
        close = true
    },
    ['grappa_red'] = {
        label = 'Grappa Rossa',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_brown'] = {
        label = 'Highball Marrone',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_dred'] = {
        label = 'Highball Rosso Scuro',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_lblue'] = {
        label = 'Highball Azzurro',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_orange'] = {
        label = 'Highball Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_pink'] = {
        label = 'Highball Rosa',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_red'] = {
        label = 'Highball Rosso',
        weight = 270,
        stack = true,
        close = true
    },
    ['highball_yellow'] = {
        label = 'Highball Giallo',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_brown'] = {
        label = 'Martini Marrone',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_dred'] = {
        label = 'Martini Rosso Scuro',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_green'] = {
        label = 'Martini Verde',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_lblue'] = {
        label = 'Martini Azzurro',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_orange'] = {
        label = 'Martini Arancione',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_pink'] = {
        label = 'Martini Rosa',
        weight = 270,
        stack = true,
        close = true
    },
    ['martini_yellow'] = {
        label = 'Martini Giallo',
        weight = 270,
        stack = true,
        close = true
    },
    ['metalx_blueberry'] = {
        label = 'Energy Drink al Mirtillo',
        weight = 200,
        stack = true,
        close = true
    },
    ['mince_wrap'] = {
        label = 'Piadina con Macinato 1',
        weight = 220,
        stack = true,
        close = true
    },
    ['omelet'] = {
        label = 'Frittata Classica',
        weight = 175,
        stack = true,
        close = true
    },
    ['pizza_2'] = {
        label = 'Pizza Intera 2',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_3'] = {
        label = 'Pizza Intera 3',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_4'] = {
        label = 'Pizza Intera 4',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_5'] = {
        label = 'Pizza Intera 5',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_6'] = {
        label = 'Pizza Intera 6',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_7'] = {
        label = 'Pizza Intera 7',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_8'] = {
        label = 'Pizza Intera 8',
        weight = 500,
        stack = true,
        close = true
    },
    ['pizza_9'] = {
        label = 'Pizza Intera 9',
        weight = 500,
        stack = true,
        close = true
    },
    ['pop_mummy'] = {
        label = 'Cake Pop Mummia',
        weight = 50,
        stack = true,
        close = true
    },
    ['pop_pumpkin'] = {
        label = 'Cake Pop Zucca',
        weight = 50,
        stack = true,
        close = true
    },
    ['pop_purple'] = {
        label = 'Cake Pop Viola',
        weight = 50,
        stack = true,
        close = true
    },
    ['pop_red'] = {
        label = 'Cake Pop Rosso',
        weight = 50,
        stack = true,
        close = true
    },
    ['pretty_cherry'] = {
        label = 'Drink Pretty Cherry',
        weight = 200,
        stack = true,
        close = true
    },
    ['pretty_peach'] = {
        label = 'Drink Pretty Peach',
        weight = 200,
        stack = true,
        close = true
    },
    ['quesadilla_carnitas'] = {
        label = 'Quesadilla Carnitas',
        weight = 215,
        stack = true,
        close = true
    },
    ['quesadilla_fish'] = {
        label = 'Quesadilla di Pesce',
        weight = 215,
        stack = true,
        close = true
    },
    ['quesadilla_steak'] = {
        label = 'Quesadilla di Carne',
        weight = 215,
        stack = true,
        close = true
    },
    ['smallcup2_espresso'] = {
        label = 'Espresso in Tazzina 2',
        weight = 100,
        stack = true,
        close = true
    },
    ['smallcup2_hotchoc'] = {
        label = 'Cioccolata Calda in Tazzina 2',
        weight = 100,
        stack = true,
        close = true
    },
    ['smallcup2_latte'] = {
        label = 'Latte Macchiato in Tazzina 2',
        weight = 100,
        stack = true,
        close = true
    },
    ['smallcup_espresso'] = {
        label = 'Espresso in Tazzina',
        weight = 100,
        stack = true,
        close = true
    },
    ['spring_rolls'] = {
        label = 'Involtini Primavera',
        weight = 95,
        stack = true,
        close = true
    },
    ['taco_carnitas'] = {
        label = 'Taco Carnitas',
        weight = 160,
        stack = true,
        close = true
    },
    ['taco_chicken'] = {
        label = 'Taco di Pollo',
        weight = 160,
        stack = true,
        close = true
    },
    ['taco_fish'] = {
        label = 'Taco di Pesce',
        weight = 160,
        stack = true,
        close = true
    },
    ['whole_pizza'] = {
        label = 'Pizza Intera Standard',
        weight = 500,
        stack = true,
        close = true
    },
    ['zombie_finger2'] = {
        label = 'Dito di Zombie 2',
        weight = 38,
        stack = true,
        close = true
    },

---------------------ALTRO-------
	['parachute'] = {
 		label = 'Parachute',
		weight = 4000,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
			usetime = 1500
		}
	},
['oiltank'] = {
    label = 'Tanica d\'Olio',
    weight = 500,
    stack = true,
    close = true,
},
['oil_bottle'] = {
    label = 'Bottiglia d\'Olio',
    weight = 100,
    stack = true,
    close = true,
},
['nail_bag'] = {
    label = 'Sacco di Chiodi',
    weight = 100,
    stack = true,
    close = true,
},
['fire_extinguisher'] = {
    label = 'Estintore',
    weight = 1000,
    stack = true,
    close = true,
},

	['paperbag'] = {
 		label = 'Sacco di carta',
		weight = 1,
		stack = false,
		close = false,
		consume = 0
	},


-- Badge Origen Police (definizioni uniche per ox_inventory)
['lspd_badge'] = {
    label = 'Distintivo Polizia',
    weight = 200,
    stack = false,
    close = true,
    consume = 0,
    description = 'Identificazione della Polizia con grado e numero di distintivo.',
    server = {
        export = 'origen_police.lspd_badge'
    }
},

['bcsd_badge'] = {
    label = 'Distintivo Carabinieri',
    weight = 200,
    stack = false,
    close = true,
    consume = 0,
    description = 'Identificazione dei Carabinieri con grado e numero di distintivo.',
    server = {
        export = 'origen_police.bcsd_badge'
    }
},

['fib_badge'] = {
    label = 'Distintivo Guardia di Finanza',
    weight = 200,
    stack = false,
    close = true,
    consume = 0,
    description = 'Identificazione della Guardia di Finanza con dati del badge.',
    server = {
        export = 'origen_police.fib_badge'
    }
},
 
 
	['lockpick'] = {
 		label = 'Grimaldello',
		weight = 80,
	},

	["phone"] = {
		label = "Telefono",
		weight = 5,
		stack = false,
	},

	['speaker'] = {
 		label = 'Cassa Musicale',
		weight = 1,
		description = 'Cassa.',
		consume = 0,
		server = {
			export = 'rahe-speakers.speaker'
		}
	},

	['money'] = {
 		label = 'Euro',
	},
	

	['oiltank'] = {
 		label = 'Bidone di olio',
	},
['nailbag'] = { 
	  label = 'Borsa di chiodi',
	   stack = true,
	   close = true,
	},

	['radio'] = {
 		label = 'Radio',
		weight = 50,
		stack = false,
		allowArmed = true,
		consume = 0,
		client = {
			export = 'zerio-radio.Open',
			remove = function(total)
				if total < 1 then
					TriggerEvent('zerio-radio:client:removedradio')
				end
			end
		}
	},

	['armour'] = {
 		label = 'Bulletproof Vest',
		weight = 1500,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
			usetime = 3500
		}
	},


	["alive_chicken"] = {
 		label = "Living chicken",
		weight = 1,
		stack = true,
		close = true,
	},

    ["bodycam"] = {
        label = "bodycam", weight = 0, stack = false, close = true, description = "Bodycam",
        client = { image = "bodycam.png", event = "spy-bodycam:bodycamstatus" }
    },
    ["dashcam"] = {
        label = "dashcam", weight = 0, stack = false, close = true, description = "dashcam",
        client = { image = "dashcam.png", event = "spy-bodycam:toggleCarCam" }
    },

	

['instant_camera'] = {
	label = "Fotocamera Istantanea",
	weight = 100,
	server = {
		export = "origen_police.instant_camera"
	},
	consume = 0
},
['photo'] = {
	label = "Foto",
	weight = 100,
	server = {
		export = "origen_police.photo"
	},
	consume = 0
},
['report_evidence'] = {
	label = "Rapporto Prove",
	weight = 100,
	server = {
		export = "origen_police.report_evidence"
	},
	consume = 0
},
['k9'] = {
	label = "Fischietto K9",
	weight = 100,
	server = {
		export = "origen_police.k9"
	},
	consume = 0
},
['gdf'] = {
	label = "Distintivo Gdf",
	weight = 100,
	server = {
		export = "origen_police.lspd_badge"
	},
	consume = 0
},
['polizia'] = {
	label = "Distintivo Polizia",
	weight = 100,
	server = {
		export = "origen_police.lspd_badge"
	},
	consume = 0
},
['carabinieri'] = {
	label = "Distintivo Carabinieri",
	weight = 100,
	server = {
		export = "origen_police.lspd_badge"
	},
	consume = 0
},
['esercito'] = {
	label = "Distintivo Esercito",
	weight = 100,
	server = {
		export = "origen_police.lspd_badge"
	},
	consume = 0
},
['sisr'] = {
	label = "Distintivo Sisr",
	weight = 100,
	server = {
		export = "origen_police.lspd_badge"
	},
	consume = 0
},
['police_cad'] = { -- By default the item name is police_cad, but you can change in origen_police/config/commands.lua -> Config.Commands.OpenPoliceCad.item
	label = "Tablet Polizia",
	weight = 100,
	server = {
		export = "origen_police.police_cad"
	},
	consume = 0
},
['evidence_a'] = {
	label = "Prova Balistica", -- O "Bossolo"
	weight = 100,
	consume = 0
},
['evidence_az'] = {
	label = "Prova Generica",
	weight = 100,
	consume = 0
},
['evidence_b'] = {
	label = "Prova Veicolo",
	weight = 100,
	consume = 0
},
['evidence_n'] = {
	label = "Prova Impatto",
	weight = 100,
	consume = 0
},
['evidence_ne'] = {
	label = "Impronta",
	weight = 100,
	consume = 0
},
['evidence_r'] = {
	label = "Traccia Ematica", -- O "Campione di Sangue"
	weight = 100,
	consume = 0
},
['evidence_ro'] = {
	label = "Prova Generica",
	weight = 100,
	consume = 0
},
['evidence_v'] = {
	label = "Prova Stupefacenti",
	weight = 100,
	consume = 0
},
---------------------------------------------
['spray'] = {
		label = 'Spray',
		weight = 5,
		close = true,
		consume = 0,
		client = {},
		server = {
			export = 'rcore_spray.spray',
		},
	},
	['spray_remover'] = {
		label = 'Panno',
		weight = 5,
		close = true,
		consume = 0,
		client = {},
		server = {
			export = 'rcore_spray.spray_remover',
		},
	},


	["medikit"] = {
 		label = "Medikit",
		weight = 1,
		stack = true,
		close = true,
	},

	["handcuffs"] = {
 		label = "Manette",
		weight = 1,
		stack = true,
		close = true,
	},

	["liquid"] = {
 		label = "Liquido",
		weight = 5,
stack = true,
		stack = true,
		close = true,
	},
	["vape"] = {
 		label = "Sigaretta Elettonica",
		weight = 5,
stack = true,
		stack = true,
		close = true,
		
	},
	["pacchettosigarette"] = {
 		label = "Pacchetto Sigarette",
		weight = 5,
stack = true,
		stack = true,
		close = true,
	},
	["accendino"] = {
 		label = "Accendino",
		weight = 5,
stack = true,
		stack = true,
		close = true,
	},
	["pacchettosigari"] = {
 		label = "Pacchetto sigari",
		weight = 5,
stack = true,
		stack = true,
		close = true,
	},
	["sigari"] = {
 		label = "Sigari",
		weight = 5,
stack = true,
		stack = true,
		close = true,
	},
	["sigarette"] = {
 		label = "Sigarette",
		weight = 5,
stack = true,
		stack = true,
		close = true,
	},

	["drug_lsd"] = {
 		label = "LSD",
		weight = 1,
		stack = true,
		close = true,
	},
	["joint"] = {
 		label = "Canna",
		weight = 5,
		stack = true,
		close = true,
	},


['megaphone'] = {
    label = 'Megafono',
    weight = 500,
    consume = 0,
    client = {
        export = 'jraxion_megaphone.UseMegaphone',
    },
    stack = false,
},


    ["stone"] = {
            label = "Pietra",
        weight = 1,
        stack = true,
        close = true,
    },

    ["iron"] = {
            label = "Ferro",
        weight = 1,
        stack = true,
        close = true,
    },

    ["petrol_raffin"] = {
            label = "Petrolio raffinato",
        weight = 1,
        stack = true,
        close = true,
    },

    ["wood"] = {
            label = "Legno",
        weight = 1,
        stack = true,
        close = true,
    },
 ["legnopulito"] = {
            label = "Legno pulito",
        weight = 1,
        stack = true,
        close = true,
    },
    ["petrol"] = {
            label = "Petrolio greggio",
        weight = 1,
        stack = true,
        close = true,
    },



['advanced_pickaxe'] = {
	label = 'Piccone avanzato',
	weight = 60,
	stack = true,
	close = true,
	},

	['empty_bottle'] = {
 	label = 'Bottiglia vuota',
	weight = 5,
	stack = true,
	close = true,
	},
	['full_bottle'] = {
 	label = 'Bottiglia piena',
	weight = 30,
	stack = true,
	close = true,
	},
	['blackpowder'] = {
 	label = 'Polvere nera',
	weight = 30,
	stack = true,
	close = true,
	},
	['coal'] = {
 	label = 'Carbone',
	weight = 2,
	stack = true,
	close = true,
	},
	['concrete'] = {
 	label = 'Calcestruzzo',
	weight = 45,
	stack = true,
	close = true,
	},
	['copper_ingot'] = {
 	label = 'Lingotto di rame',
	weight = 40,
	stack = true,
	close = true,
	},
	['copper_ore'] = {
 	label = 'Minerale di rame',
	weight = 20,
	stack = true,
	close = true,
	},
	['diamond_ingot'] = {
 	label = 'Lingotto di diamante',
	weight = 50,
	stack = true,
	close = true,
	},
	['diamond_ore'] = {
 	label = 'Minerale di diamante',
	weight = 50,
	stack = true,
	close = true,
	},
	['glass'] = {
 	label = 'Vetro',
	weight = 35,
	stack = true,
	close = true,
	},
	['glass_mold'] = {
 	label = 'Stampo di vetro',
	weight = 50,
	stack = true,
	close = true,
	},
	['gold_ore'] = {
 	label = 'Minerale d\'oro',
	weight = 40,
	stack = true,
	close = true,
	},
	['goldingot'] = {
 	label = 'Lingotto d\'oro',
	weight = 60,
	stack = true,
	close = true,
	},
	['ingot_mold'] = {
 	label = 'Stampo per lingotti',
	weight = 50,
	stack = true,
	close = true,
	},
	['iron_ingot'] = {
 	label = 'Lingotto di ferro',
	weight = 60,
	stack = true,
	close = true,
	},
	['iron_ore'] = {
 	label = 'Minerale di ferro',
	weight = 30,
	stack = true,
	close = true,
	},
["md_rusty_key"] = {
    label = "Chiave Arrugginita",
    weight = 80,
    stack = true,
    close = false,
    description = "Una vecchia chiave ossidata trovata sotto terra.",
},
["md_old_coin"] = {
    label = "Moneta d'Epoca",
    weight = 20,
    stack = true,
    close = false,
    description = "Una moneta consumata dal tempo, interessante per i collezionisti.",
},
["md_collectible_token"] = {
    label = "Gettone da Collezione",
    weight = 15,
    stack = true,
    close = false,
    description = "Un vecchio gettone metallico da collezione.",
},
["md_military_tag"] = {
    label = "Medaglietta Militare",
    weight = 35,
    stack = true,
    close = false,
    description = "Una medaglietta militare datata, ancora leggibile.",
},
["md_silver_bracelet"] = {
    label = "Bracciale d'Argento",
    weight = 90,
    stack = true,
    close = false,
    description = "Un bracciale d'argento annerito dal tempo.",
},
["md_vintage_watch"] = {
    label = "Orologio Vintage",
    weight = 140,
    stack = true,
    close = false,
    description = "Un vecchio orologio da polso dal discreto valore collezionistico.",
},
["md_gold_ring"] = {
    label = "Anello d'Oro",
    weight = 25,
    stack = true,
    close = false,
    description = "Un anello d'oro raro trovato con il metal detector.",
},
["vehicle_tyre"] = {
	label = "Pneumatico del Veicolo",
	weight = 1,
	stack = true,
	close = false,
},
["vehicle_door"] = {
	label = "Portiera del Veicolo",
	weight = 1,
	stack = true,
	close = false,
},
	['normal_pickaxe'] = {
 		label = 'Piccone normale',
	weight = 50,
	stack = true,
	close = true,
	},
	['professional_pickaxe'] = {
 	label = 'Piccone professionale',
	weight = 60,
	stack = true,
	close = true,
	},
	['rock'] = {
 	label = 'Roccia',
	weight = 30,
	stack = true,
	close = true,
	},
	['sandstone'] = {
 	label = 'Arenaria',
	weight = 20,
	stack = true,
	close = true,
	},
	['special_water'] = {
 	label = 'Acqua speciale',
	weight = 15,
	stack = true,
	close = true,
	},
	['sticky_gel'] = {
 	label = 'Gel appiccicoso',
	weight = 15,
	stack = true,
	close = true,
	},
	['sulfur'] = {
 	label = 'Solfuro',
	weight = 40,
	stack = true,
	close = true,
	},

['iron'] = {
	label = 'Ferro',
	weight = 50,
	stack = true,
	close = true,
},
	

	["ammonium_nitrate"] = {
		label = "Ammonium nitrate",
		weight = 1,
		stack = true,
		close = true,
	},

	["cannabis"] = {
		label = "Cannabis",
		weight = 1,
		stack = true,
		close = true,
	},

	["carbon"] = {
		label = "Carbon",
		weight = 1,
		stack = true,
		close = true,
	},

	["cocaine"] = {
		label = "Cocaine",
		weight = 1,
		stack = true,
		close = true,
	},

	["cocaine_packaged"] = {
		label = "Packaged Cocaine",
		weight = 1,
		stack = true,
		close = true,
	},

	["cocaine_raw"] = {
		label = "Raw Cocaine",
		weight = 1,
		stack = true,
		close = true,
	},

	["codeine"] = {
		label = "Codeine",
		weight = 1,
		stack = true,
		close = true,
	},

	["drink_sprite"] = {
		label = "Sprite",
		weight = 1,
		stack = true,
		close = true,
	},

	["drug_ecstasy"] = {
		label = "Ecstasy",
		weight = 1,
		stack = true,
		close = true,
	},

	["drug_lean"] = {
		label = "Lean",
		weight = 1,
		stack = true,
		close = true,
	},

	["drug_meth"] = {
		label = "Meth",
		weight = 1,
		stack = true,
		close = true,
	},

	["green_gelato_cannabis"] = {
		label = "Green Gelato Cannabis",
		weight = 1,
		stack = true,
		close = true,
	},

	["hydrogen"] = {
		label = "Hydrogen",
		weight = 1,
		stack = true,
		close = true,
	},

	["ice"] = {
		label = "Ice",
		weight = 1,
		stack = true,
		close = true,
	},

	["jolly_ranchers"] = {
		label = "Jolly Ranchers",
		weight = 1,
		stack = true,
		close = true,
	},

	["liquid_sulfur"] = {
		label = "Liquid Sulfur",
		weight = 1,
		stack = true,
		close = true,
	},

	["meth_processed"] = {
		label = "Processed Meth",
		weight = 1,
		stack = true,
		close = true,
	},

	["meth_raw"] = {
		label = "Raw Meth",
		weight = 1,
		stack = true,
		close = true,
	},

	["nitrogen"] = {
		label = "Nitrogen",
		weight = 1,
		stack = true,
		close = true,
	},

	["oxygen"] = {
		label = "Oxygen",
		weight = 1,
		stack = true,
		close = true,
	},

	["pseudoefedrine"] = {
		label = "Pseudoefedrine",
		weight = 1,
		stack = true,
		close = true,
	},

	["red_sulfur"] = {
		label = "Red Sulfur",
		weight = 1,
		stack = true,
		close = true,
	},

	["sodium_hydroxide"] = {
		label = "Sodium hydroxide",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_beat"] = {
		label = "Speaker Beat",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_blast"] = {
		label = "Speaker Blast",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_retro"] = {
		label = "Speaker Retro",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_vibe"] = {
		label = "Speaker Vibe",
		weight = 1,
		stack = true,
		close = true,
	},

	["trap_phone"] = {
		label = "Trap Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["muriatic_acid"] = {
		label = "Muriatic Acid",
		weight = 1,
		stack = true,
		close = true,
	},

	["beer"] = {
		label = "Beer",
		weight = 1,
		stack = true,
		close = true,
	},

	["blackberry_ale"] = {
		label = "Blackberry Ale",
		weight = 1,
		stack = true,
		close = true,
	},

	["blowpipe"] = {
		label = "Blowtorch",
		weight = 2,
		stack = true,
		close = true,
	},

	["burger"] = {
		label = "Burger",
		weight = 1,
		stack = true,
		close = true,
	},

	["carokit"] = {
		label = "Body Kit",
		weight = 3,
		stack = true,
		close = true,
	},

	["carotool"] = {
		label = "Tools",
		weight = 2,
		stack = true,
		close = true,
	},

	["clothe"] = {
		label = "Cloth",
		weight = 1,
		stack = true,
		close = true,
	},

	["coffee"] = {
		label = "Coffee",
		weight = 1,
		stack = true,
		close = true,
	},

	["copper"] = {
		label = "Copper",
		weight = 1,
		stack = true,
		close = true,
	},

	["cutted_wood"] = {
		label = "Cut wood",
		weight = 1,
		stack = true,
		close = true,
	},

	["essence"] = {
		label = "Gas",
		weight = 1,
		stack = true,
		close = true,
	},

	["fabric"] = {
		label = "Fabric",
		weight = 1,
		stack = true,
		close = true,
	},

	["fish"] = {
		label = "Fish",
		weight = 1,
		stack = true,
		close = true,
	},

	["fixkit"] = {
		label = "Repair Kit",
		weight = 3,
		stack = true,
		close = true,
	},

	["fixtool"] = {
		label = "Repair Tools",
		weight = 2,
		stack = true,
		close = true,
	},

	["gazbottle"] = {
		label = "Gas Bottle",
		weight = 2,
		stack = true,
		close = true,
	},

	["gold"] = {
		label = "Gold",
		weight = 1,
		stack = true,
		close = true,
	},

	["marijuana"] = {
		label = "Marijuana",
		weight = 2,
		stack = true,
		close = true,
	},

	["packaged_chicken"] = {
		label = "Chicken fillet",
		weight = 1,
		stack = true,
		close = true,
	},

	["packaged_plank"] = {
		label = "Packaged wood",
		weight = 1,
		stack = true,
		close = true,
	},

	["slaughtered_chicken"] = {
		label = "Slaughtered chicken",
		weight = 1,
		stack = true,
		close = true,
	},

	["sprunk"] = {
		label = "Sprunk",
		weight = 1,
		stack = true,
		close = true,
	},

	["wool"] = {
		label = "Wool",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_black"] = {
		label = "Black Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_blue"] = {
		label = "Blue Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_green"] = {
		label = "Green Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_orange"] = {
		label = "Orange Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_pink"] = {
		label = "Pink Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_purple"] = {
		label = "Purple Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_red"] = {
		label = "Red Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["phone_yellow"] = {
		label = "Yellow Phone",
		weight = 1,
		stack = true,
		close = true,
	},

	["pizza_ham"] = {
		label = "Pizza Ham",
		weight = 1,
		stack = true,
		close = true,
	},

	["wine"] = {
		label = "Wine",
		weight = 1,
		stack = true,
		close = true,
	},

	["repairkit"] = {
		label = "Repair Kit",
		weight = 3,
		stack = true,
		close = true,
	},

	["sandwich"] = {
		label = "Sandwich",
		weight = 1,
		stack = true,
		close = true,
	},

	["washed_stone"] = {
		label = "Washed stone",
		weight = 1,
		stack = true,
		close = true,
	},
}

local stateSelf, notLoadedDataFromConfig, alwaysDisplay = false, false, false
local blockKeyboard = false
local actualDamagedBones = {}

while GetResourceState('pinkFrog_inventoryAddon') ~= "started" do
    Citizen.Wait(100)
    print('Waiting for pinkFrog_inventoryAddon to start...')
end

Citizen.CreateThread(function() if  exports['pinkFrog_inventoryAddon']:checkInstantShowPedAfterOpenInventory() then client.screenblur = false  stateSelf = true end end)


RegisterNuiCallback('getEnabledClonedPed', function(data, cb)
    if not exports['pinkFrog_inventoryAddon']:checkInstantShowPedAfterOpenInventory() then
        SendNUIMessage({
            action = 'setEnabledClonedPed',
            data = true,
        })
    else
        SendNUIMessage({
            action = 'checkAlwaysEnablePedClone',
        })
    end
    cb({ success = true }) 
end)


RegisterNUICallback('getMainColor', function(data, cb)
    local ui = exports['pinkFrog_inventoryAddon']:getUiSettings()
    SendNUIMessage({
        action = 'updateColors',
        data = {
            dataMainColor = ui.mainColor,
            dataSecondaryColor = ui.secondaryColor,
            dataCloseButtonColor = ui.closeButtonColor,
            showWeightInItemSlot = ui.showWeightInItemSlot,
            showSettingsButton = ui.showSettingsButton,
            whereIsClothingPlacedInUI = ui.whereIsClothingPlacedInUI,
        }
    })
    SendNUIMessage({
        action = 'updateItemNotificationSettings',
        data = {
            itemNotificationContainer = ui.itemNotificationContainer
        }
    })
    cb({ success = true }) 
end)


RegisterNUICallback('getBackPackSettings', function(data, cb)
    local backPackData = exports['pinkFrog_inventoryAddon']:getEnableBackPack()
    SendNUIMessage({
        action = 'updateBackPackSettings',
        data = backPackData
    })
    cb({ success = true })
end)

RegisterNUICallback('getTranslations', function(data, cb)
    SendNUIMessage({
        action = 'updateTranslations',
        data = exports['pinkFrog_inventoryAddon']:getUI_locales()
    })
    cb({ success = true }) 
end)

local pedCloneVisible = false
local pedPreviewRevision = 0
local pedPreviewX = 0.555 -- matching the fixed center layout before NUI measures it

local function startGridPedPreview()
    if pedCloneVisible then return end
    pedPreviewRevision = pedPreviewRevision + 1
    pedCloneVisible = true
    TriggerEvent('pinkFrog:startClonedPedByOx')
end

local function stopGridPedPreview()
    pedPreviewRevision = pedPreviewRevision + 1
    pedCloneVisible = false
    TriggerEvent('pinkFrog:removeClonedPedFromOxInventory')
end

RegisterNUICallback('gridPedBounds', function(data, cb)
    local x = type(data) == 'table' and data.x
    if type(x) ~= 'number' or x ~= x or x < 0.05 or x > 0.95 then
        cb({ok=false}); return
    end
    if LocalPlayer.state.invOpen ~= true then cb({ok=false}); return end
    local ok, applied = pcall(function()
        return exports['pinkFrog_inventoryAddon']:alignGridPedPreview(x)
    end)
    if not ok or applied ~= true then
        cb({ok=false,error='Installa anche la patch ped in pinkFrog_inventoryAddon'}); return
    end
    local moved = math.abs(x-pedPreviewX) > 0.0005
    pedPreviewX = x
    if moved and pedCloneVisible then
        -- Public stop/start events refresh renderer implementations that cache presets.
        -- The token prevents a resize callback from recreating the ped after closing.
        pedPreviewRevision = pedPreviewRevision + 1
        local revision = pedPreviewRevision
        TriggerEvent('pinkFrog:removeClonedPedFromOxInventory')
        CreateThread(function()
            Wait(100)
            if revision == pedPreviewRevision and pedCloneVisible and LocalPlayer.state.invOpen == true then
                TriggerEvent('pinkFrog:startClonedPedByOx')
            end
        end)
    end
    cb({ok=true,x=x})
end)

RegisterNUICallback('showPedClone', function(data, cb)
    if not pedCloneVisible then
        if client.screenblur then TriggerScreenblurFadeOut(0) end
        startGridPedPreview()
        SendNUIMessage({ action = 'displayDivider', data = { visible = false } })
    else
        if client.screenblur then TriggerScreenblurFadeIn(0) end
        stopGridPedPreview()
        SendNUIMessage({ action = 'displayDivider', data = { visible = true } })
    end

    cb({ success = true })
end)

RegisterNUICallback('alwaysEnablePedClone', function(data, cb)
    TriggerEvent('pinkFrog_syncClonePed', true)
    cb({ success = true }) 
end)


RegisterNetEvent('pinkFrog_syncClonePed', function(open, inv, player, selfOpen, noEvent)
    if open then 
        if exports['pinkFrog_inventoryAddon']:checkInstantShowPedAfterOpenInventory() then
            startGridPedPreview()
            if client.screenblur then
                TriggerScreenblurFadeOut(0)
            end
            SendNUIMessage({ action = 'displayDivider', data = { visible = false } })
        else
            SendNUIMessage({ action = 'displayDivider', data = { visible = true } })
            if client.screenblur then
                TriggerScreenblurFadeIn(0)
            end
            stopGridPedPreview()
        end
    else 
        if exports['pinkFrog_inventoryAddon']:checkInstantShowPedAfterOpenInventory() then
            stopGridPedPreview()
        else 
            SendNUIMessage({ action = 'displayDivider', data = { visible = false } })
               stopGridPedPreview()
        end
    end
end)

RegisterNetEvent('pinkFrog:updateNUISlots', function(backPackData)
    SendNUIMessage({
        action = 'updateBackPackSettings',
        data = backPackData
    })
end)

RegisterNUICallback('setClothesPosition', function(data,cb)
    exports['pinkFrog_inventoryAddon']:setClothingPositionInUI(data.position)
    cb({ success = true })
end)


RegisterNetEvent('pinkFrog_closeClonedPed', function(open)
stopGridPedPreview() 
end)

RegisterNUICallback('getActualDamagedBones', function(data, cb)
    cb(actualDamagedBones)
end)


RegisterNetEvent('pinkFrog_inventoryAddon:updateClientDamage', function(damagedBones)
    actualDamagedBones = damagedBones
    SendNUIMessage({
        action = 'updateDamageBones',
        data = damagedBones
    })
end)

RegisterNUICallback('stopKeyBoardInFivem', function(data, cb)
    -- A delayed search blur must not restore game input capture after NUI closes.
    SetNuiFocusKeepInput(data.state ~= true and IsNuiFocused() and LocalPlayer.state.invOpen == true)
    cb({ success = true })
end)

-- RegisterNetEvent('pinkFrog_syncClonePed', function(open, inv)
--     if open then 
--         TriggerEvent('pinkFrog:startClonedPedByOx')
--         if client.screenblur then 
--             TriggerScreenblurFadeOut(0) 
--         end
--         SendNUIMessage({
--             action = 'displayDivider',  
--             data = { visible = false }
--         })
--     else
      
--             SendNUIMessage({
--                 action = 'displayDivider',  
--                 data = { visible = true }
--             })
   
--         if client.screenblur then 
--             TriggerScreenblurFadeOut(0) 
--         end
--         TriggerEvent('pinkFrog:removeClonedPedFromOxInventory') 
--     end
-- end)

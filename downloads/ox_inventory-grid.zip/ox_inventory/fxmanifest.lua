fx_version 'cerulean'
use_experimental_fxv2_oal 'yes'
lua54 'yes'
game 'gta5'
name 'ox_inventory'
author 'Overextended & edited by pinkFrog.io for (pinkFrog_inventoryAddon) v2.1.3'
version '2.44.8'
repository 'https://github.com/pinkFrogFivem/ox_inventory'
description 'Inventario a slot con supporto ai metadati degli oggetti'

dependencies {
    '/server:6116',
    '/onesync',
    'oxmysql',
    'ox_lib',
}

shared_script '@ox_lib/init.lua'

ox_libs {
    'locale',
    'table',
    'math',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'init.lua',
}

client_scripts{
    'init.lua', 
    'pinkFrog/client/clientPinkFrog.lua',
}

ui_page 'web/build/index.html'

files {
    'client.lua',
    'server.lua',
    'locales/*.json',
    'web/build/index.html',
    'web/build/assets/*.js',
    'web/build/assets/*.css',
    'web/build/assets/*.svg', -- added line for pinkFrog <3
    'web/build/assets/*.png', -- added line for pinkFrog <3
    'web/public/sounds/*.mp3', -- added line for pinkFrog <3
    'web/public/images/*.png', -- added line for pinkFrog <3
    'web/images/*.png',
    'modules/**/shared.lua',
    'modules/**/client.lua',
    'modules/bridge/**/client.lua',
    'data/*.lua',
}

-- BEGIN VOID SURVIVAL CURRENCY PATCH
client_script 'void_currency.lua'
server_script 'void_currency.lua'
void_currency '1.0.0'
-- END VOID SURVIVAL CURRENCY PATCH

-- Server-authoritative multi-cell grid extension
client_script 'modules/grid/client.lua'

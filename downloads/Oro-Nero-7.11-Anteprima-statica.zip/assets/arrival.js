/** The visual entrance starts automatically; music follows its own browser policy. */
export function setupArrival(doc = document, win = window) {
  const overlay = doc.querySelector('[data-arrival]');
  if (!overlay) return null;
  const skip = overlay.querySelector('[data-arrival-skip]');
  if (!skip) return null;
  const bypass = overlay.querySelector('[data-arrival-bypass]');
  const boot = win.__oroneroArrivalBoot;
  const bootPreventedIntro = Boolean(boot?.preventIntro);
  // Restore the early inert state, retaining its visual cover until open().
  boot?.takeover?.();
  const replay = doc.querySelector('[data-replay-arrival]');
  const motion = win.matchMedia?.('(prefers-reduced-motion: reduce)');
  let active = false;
  let closing = false;
  let timer;
  let cleanupTimer;
  let safeguard;
  let previousFocus;
  let siblings = [];
  let musicPlacement;
  const clearTimers = () => {
    [timer, cleanupTimer, safeguard].forEach((id) => win.clearTimeout(id));
  };
  const restore = (focus = true) => {
    clearTimers();
    const focused = doc.activeElement;
    overlay.hidden = true;
    overlay.classList.remove('is-active', 'is-closing', 'is-skipped');
    doc.body.classList.remove('arrival-open', 'arrival-revealing');
    if (musicPlacement) {
      const {element, parent, next} = musicPlacement;
      parent.insertBefore(element, next?.parentNode === parent ? next : null);
      if (focus && focused === element) element.focus({preventScroll:true});
      musicPlacement = null;
    }
    siblings.forEach(([element, inert]) => { element.inert = inert; });
    siblings = [];
    active = false;
    closing = false;
    if (focus && [skip, bypass].includes(focused)) {
      const target = previousFocus?.matches?.('[data-replay-arrival]') ? previousFocus : doc.querySelector('main');
      if (target) {
        const hadTabindex = target.hasAttribute('tabindex');
        if (!hadTabindex) target.setAttribute('tabindex', '-1');
        target.focus({preventScroll:true});
        if (!hadTabindex) target.removeAttribute('tabindex');
      }
    }
  };
  const finish = (immediate = true) => {
    if (!active || closing) return;
    closing = true;
    win.clearTimeout(timer);
    overlay.classList.add('is-closing');
    if (immediate || motion?.matches) overlay.classList.add('is-skipped');
    doc.body.classList.add('arrival-revealing');
    cleanupTimer = win.setTimeout(() => restore(), immediate || motion?.matches ? 160 : 1100);
  };
  const open = () => {
    if (active || closing) return;
    previousFocus = doc.activeElement;
    const music = doc.querySelector('[data-music-control]');
    if (music && !overlay.contains(music)) {
      musicPlacement = {element:music, parent:music.parentNode, next:music.nextSibling};
      overlay.append(music);
    }
    siblings = [...doc.body.children].filter((element) => element !== overlay && !element.matches('[data-music-control]') && !['SCRIPT', 'STYLE'].includes(element.tagName)).map((element) => [element, element.inert]);
    siblings.forEach(([element]) => { element.inert = true; });
    overlay.hidden = false;
    overlay.classList.remove('is-active', 'is-closing', 'is-skipped');
    doc.body.classList.add('arrival-open');
    active = true;
    win.__oroneroArrivalShown = true;
    skip.setAttribute('aria-label', 'Salta l’intro ed entra nel sito');
    skip.focus({preventScroll:true});
    void overlay.offsetWidth;
    overlay.classList.add('is-active');
    // Reduced motion keeps the same automatic welcome, as a brief static mark.
    timer = win.setTimeout(() => finish(false), motion?.matches ? 900 : 3000);
    safeguard = win.setTimeout(() => restore(), 5500);
    boot?.release?.('takeover');
  };
  const onSkip = () => finish(true);
  const onBypass = () => {
    finish(true);
    doc.querySelector('[data-persistent-audio]')?.[Symbol.for('oronero.music.controller')]?.pause();
  };
  const onKey = (event) => {
    if (!active) return;
    if (event.key === 'Escape') { event.preventDefault(); onBypass(); }
    if (event.key === 'Tab') {
      const music = doc.querySelector('[data-music-control]');
      const controls = [skip, bypass, music].filter((element) => element && !element.disabled && !element.hidden);
      const current = controls.indexOf(doc.activeElement);
      const next = (current + (event.shiftKey ? -1 : 1) + controls.length) % controls.length;
      event.preventDefault();
      controls[next].focus();
    }
  };
  const onVisibility = () => { if (doc.hidden && active) finish(true); };
  const onPageHide = () => restore(false);
  const onReplay = () => open();
  skip.addEventListener('click', onSkip);
  bypass?.addEventListener('click', onBypass);
  bypass?.addEventListener('pointerdown', onBypass);
  bypass?.addEventListener('touchstart', onBypass, {passive:true});
  doc.addEventListener('keydown', onKey);
  replay?.addEventListener('click', onReplay);
  doc.addEventListener('visibilitychange', onVisibility);
  win.addEventListener('pagehide', onPageHide);
  if (!win.__oroneroArrivalShown && !bootPreventedIntro && !win.location.hash) open();
  else boot?.release?.('suppressed');
  return {open, finish, destroy() {
    restore(false);
    skip.removeEventListener('click', onSkip);
    bypass?.removeEventListener('click', onBypass);
    bypass?.removeEventListener('pointerdown', onBypass);
    bypass?.removeEventListener('touchstart', onBypass);
    doc.removeEventListener('keydown', onKey);
    replay?.removeEventListener('click', onReplay);
    doc.removeEventListener('visibilitychange', onVisibility);
    win.removeEventListener('pagehide', onPageHide);
  }};
}

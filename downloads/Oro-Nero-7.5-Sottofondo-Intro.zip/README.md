# Oro Nero · 7.5.0 Sottofondo discreto e ingresso immediato

Sito per Oro Nero Experience Bistrot, Chioggia. La direzione Laguna Nocturne unisce nero laguna, avorio e oro a un ingresso animato e un menu testuale senza foto, con navigazione musicale continua.

## Cosa include

- Intro sincronizzata alla riproduzione effettiva: durante il caricamento audio resta il logo piccolo; il movimento e la chiusura iniziano dall’evento `playing`, con attesa massima di 8 secondi e salto sempre disponibile.
- Intro con il solo emblema del logo: parte piccolo, ruota e si ingrandisce; una lucciola dorata apre il sito con un’apertura luminosa. Nessuna scritta decorativa. Salto, replay e movimento ridotto supportati.
- Nuovo estratto fornito di Vivaldi, L’inverno (circa 6 minuti e 26 secondi), in loop, attenuato per un sottofondo discreto; lettore al 70%. Avvio automatico tentato senza richiedere un comando dedicato.
- Navigazione interna senza ricaricare il documento: il medesimo lettore rimane attivo tra homepage, menu, vini, recensioni, allergeni, privacy, QR e admin, anche con Indietro/Avanti.
- Slider fotografico con controlli manuali e galleria accessibile da tastiera.
- Navigazione e azioni rapide per smartphone; prenotazione guidata tramite WhatsApp.
- Menu senza fotografie né segnaposti, con nomi, descrizioni, prezzi, allergeni, ricerca, categorie e filtro vegetariano.
- Le foto gestibili dall’admin restano archiviate, ma non vengono mostrate nel menu pubblico.
- Carta vini, suggerimenti di abbinamento, degustazioni ed eventi.
- Area amministrativa in `/admin/`, con menu condiviso tramite Netlify Blobs.
- Cartello QR stampabile e scaricabile in `/qr/`.

Il menu pubblico è ora solo testuale, compresa la testata: non mostra fotografie, riquadri “Foto in arrivo” né finestre di ingrandimento. Nomi, prezzi, descrizioni e allergeni sono mantenuti. Le foto già presenti rimangono nella homepage e nella galleria. Le associazioni fotografiche archiviate dall’admin sono conservate nei dati, senza essere mostrate al pubblico. Il Sommelier propone abbinamenti attraverso regole locali e la carta vini disponibile: non usa un servizio AI esterno né richiede chiavi API.

I font **Cormorant Garamond** e **Manrope** sono serviti dal sito, senza richieste a servizi di font esterni. Le rispettive licenze SIL Open Font License sono incluse in `site/assets/fonts/`.

## Sviluppo e controlli

Usa Node.js 22, la versione configurata anche per Netlify. Dalla cartella del progetto:

```bash
npm ci
npm run build
npm run check
npm test
```

`npm ci` installa le versioni del lockfile. La build genera `dist/`, il menu JSON di riserva e il QR. `check` controlla i file e i dati necessari; `test` esegue i test delle pagine, delle interazioni e delle funzioni.

Per un’anteprima **statica** puoi servire `dist/` con un server HTTP, ad esempio:

```bash
python3 -m http.server 8080 --directory dist
```

In questa modalità il menu usa il JSON generato dalla build; login e salvataggio amministrativo richiedono le Functions di Netlify. Per il flusso completo in locale è possibile usare Netlify CLI con `netlify dev`, configurando in modo sicuro le variabili amministrative.

## Deploy completo su Netlify

Collega a Netlify un repository contenente tutti i sorgenti. `netlify.toml` configura:

- build: `npm run build`;
- cartella pubblicata: `dist`;
- funzioni: `netlify/functions`;
- Node.js: `22`.

Nelle variabili del progetto imposta, per Production e Functions:

- `ORONERO_ADMIN_PASSWORD`: password privata di almeno 10 caratteri;
- `ORONERO_SESSION_SECRET`: segreto casuale distinto di almeno 32 caratteri.

Non inserire i valori nel codice o nel repository. Dopo averli impostati, esegui il deploy. Il pannello `/admin/` consente di aggiornare menu, vini, degustazioni, eventi e immagini dei piatti condivisi con il menu pubblico.

Il solo caricamento di `dist/` serve per un’anteprima statica: non distribuisce le Functions e non abilita l’admin persistente. Lo ZIP dei sorgenti non è un pacchetto di deploy statico.

Il QR viene generato verso `${URL}/menu/`, usando l’URL fornito da Netlify durante la build. Fuori da Netlify, imposta `URL` al dominio definitivo prima della build; il valore di riserva è `https://oronero.netlify.app`. Controlla la destinazione prima di stampare il QR.

## Manutenzione e compatibilità

Sono stati rimossi gli entrypoint TypeScript `.mts` obsoleti che duplicavano le funzioni attive e importavano un modulo assente. Login, sessioni e validazione del menu gestiscono le richieste malformate senza interrompere il servizio.

La consegna contiene i file del progetto e la build statica. **Non è stato effettuato alcun deploy del sito su Netlify.** Per le istruzioni dettagliate consulta `README_NETLIFY.md`.

## Musica e nuove fotografie

La nuova traccia fornita è inclusa in `site/assets/audio/vivaldi-winter.mp3`, ottimizzata a 160 kbit/s e attenuata di 12 dB rispetto alla versione 7.4. Il volume del lettore è al 70%; il volume fisico del dispositivo rimane quello impostato dall’ospite.

Il sito tenta la riproduzione automatica con audio udibile. Se il browser vieta l’autoplay sonoro, la prima interazione con il sito (tocco, clic o tastiera) avvia la musica senza richiedere un pulsante dedicato. Il comando rimane disponibile per mettere in pausa e la pausa esplicita viene rispettata.

I collegamenti interni alle pagine del sito vengono caricati senza sostituire il documento e il lettore: la musica continua sullo stesso elemento audio senza ripartire. I link esterni, i download e le nuove schede seguono il comportamento nativo. Un ricaricamento completo, l’apertura di una nuova scheda o l’uscita dal sito creano un nuovo documento e sono soggetti alle regole audio del browser. Posizione e pausa restano conservate nella sessione; il seeking dopo un ricaricamento richiede supporto HTTP Range dell’hosting.

Gli archivi fotografici ricevuti finora superano il limite di trasferimento di 32 MiB e non sono stati leggibili. Questa versione non contiene le nuove fotografie. Invia immagini singole o ZIP sotto i 32 MB per inserirle progressivamente. Le foto già presenti e i prezzi rimangono invariati.

## Caricamento iniziale e intro

L’animazione non consuma più i suoi 3 secondi mentre l’MP3 sta caricando: parte quando l’audio è realmente in riproduzione. Se il caricamento supera 8 secondi, si lascia proseguire l’intro per non bloccare l’accesso. Un errore audio, una pausa scelta dall’utente o un blocco autoplay del browser fanno proseguire l’intro senza aspettare. Il salto esplicito e il tasto Escape restano immediati. Questi casi non garantiscono musica durante l’intro: il blocco browser richiede un gesto consentito.

## Primo fotogramma e avvio anticipato

La homepage non deve apparire prima dell’intro: una protezione inline nel documento copre la pagina fin dal primo disegno, prima del caricamento dei moduli. Il salto e il tasto Escape funzionano anche durante questa fase. Sessioni già viste, movimento ridotto e link diretti con frammento non mostrano la copertura; senza JavaScript la pagina rimane accessibile. Se i moduli non arrivano, dopo otto secondi il sito viene sbloccato.

Il modulo leggero music-start.js inizializza il lettore prima degli altri script. L’autoplay sonoro viene tentato subito, ma resta soggetto alle regole del browser. In caso di blocco basta un normale tocco, clic o tasto sulla pagina: non occorre premere il controllo musicale. Anche componenti che interrompono la propagazione dei clic e i tentativi audio pendenti non devono far perdere l’interazione utile. Una pausa scelta dall’utente viene sempre rispettata.

Per mantenere il sottofondo basso anche sui dispositivi che ignorano il controllo volume JavaScript, è stato attenuato direttamente il file MP3. Il volume fisico rimane controllato dall’ospite.

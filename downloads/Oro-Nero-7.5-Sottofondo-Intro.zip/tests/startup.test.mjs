import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM } from 'jsdom';
import { setupArrival } from '../site/assets/arrival.js';

const html = await readFile(new URL('../site/index.html',import.meta.url),'utf8');
const startup = await readFile(new URL('../site/assets/startup.js',import.meta.url),'utf8');

function page({seen=false,reduce=false,hash='',scripts=true,storageUnavailable=false}={}) {
  const timers=new Map();
  let next=0;
  const dom=new JSDOM(html,{
    url:`https://oronero.test/${hash}`,
    pretendToBeVisual:true,
    ...(scripts ? {runScripts:'dangerously'} : {}),
    beforeParse(win) {
      win.matchMedia=()=>({matches:reduce});
      win.setTimeout=(callback,delay)=>{timers.set(++next,{callback,delay});return next;};
      win.clearTimeout=(id)=>timers.delete(id);
      if (seen) win.sessionStorage.setItem('oronero-arrival-seen-v1','1');
      if (storageUnavailable) Object.defineProperty(win,'sessionStorage',{get(){throw new Error('Storage unavailable');}});
    },
  });
  if(scripts) dom.window.eval(startup);
  const {document:doc}=dom.window;
  return {dom,doc,boot:dom.window.__oroneroArrivalBoot,run(delay){for(const[id,task]of[...timers])if(task.delay===delay){timers.delete(id);task.callback();}},close(){dom.window.__oroneroArrivalBoot?.release('expired');dom.window.close();}};
}

test('the inline first-paint guard precedes styles and keeps only the intro accessible while modules load',()=>{
  const p=page();
  try {
    assert.ok(html.indexOf('data-arrival-bootstrap')<html.indexOf('<link rel="stylesheet"'));
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    assert.equal(p.doc.querySelector('main').inert,true);
    assert.equal(p.doc.activeElement,p.doc.querySelector('[data-arrival-skip]'));
    assert.match(p.doc.querySelector('[data-arrival-critical]').textContent,/visibility:\s*hidden/);
  }finally{p.close();}
});

test('seen visits, reduced motion and direct hashes never acquire the startup cover',()=>{
  for(const options of [{seen:true},{reduce:true},{hash:'#contatti'}]){
    const p=page(options);
    try{
      assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    }finally{p.close();}
  }
});

test('no JavaScript leaves the homepage accessible with the intro hidden',()=>{
  const p=page({scripts:false});
  try{
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
  }finally{p.close();}
});

test('the bounded startup fallback releases a failed module and prevents a late intro reopening',()=>{
  const p=page();
  let controller;
  try{
    p.run(8000);
    assert.equal(p.boot.preventIntro,true);
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
  }finally{controller?.destroy();p.close();}
});

test('skip and Escape work before the main modules and remain respected without storage',()=>{
  for(const action of ['click','Escape']){
    const p=page({storageUnavailable:true});
    let controller;
    try{
      if(action==='click')p.doc.querySelector('[data-arrival-skip]').click();
      else p.doc.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:action,bubbles:true}));
      assert.equal(p.boot.preventIntro,true);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false);
      controller=setupArrival(p.doc,p.dom.window);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    }finally{controller?.destroy();p.close();}
  }
});

test('module takeover restores startup inert state before the normal intro owns and releases it',()=>{
  const p=page();
  let controller;
  try{
    const release=p.boot.release;
    let transferred=false;
    p.boot.release=(reason)=>{
      if(reason==='takeover'){
        assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),true);
        assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
        assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
        transferred=true;
      }
      release(reason);
    };
    controller=setupArrival(p.doc,p.dom.window);
    assert.equal(transferred,true);
    assert.equal(p.boot.pending,false);
    assert.equal(p.doc.documentElement.classList.contains('arrival-pending'),false);
    assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
    assert.equal(p.doc.querySelector('main').inert,true);
    p.doc.querySelector('[data-arrival-skip]').click();p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    p.run(8000);
    assert.equal(p.boot.preventIntro,false);
  }finally{controller?.destroy();p.close();}
});

import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { JSDOM } from "jsdom";
import { defaultMenu } from "../netlify/functions/menu-default.mjs";

test("menu, Sommelier, filtri e prenotazione funzionano nel browser", async () => {
  const html = await readFile(new URL("../dist/menu/index.html", import.meta.url), "utf8");
  const dom = new JSDOM(html, { url: "https://oronero.test/menu/", pretendToBeVisual: true });

  // jsdom has no audio engine; MP3 playback is verified in Chromium.
  dom.window.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
  dom.window.HTMLMediaElement.prototype.pause = function () {};
  globalThis.window = dom.window;
  globalThis.document = dom.window.document;
  globalThis.location = dom.window.location;
  globalThis.HTMLElement = dom.window.HTMLElement;
  globalThis.customElements = dom.window.customElements;
  globalThis.CustomEvent = dom.window.CustomEvent;
  globalThis.FormData = dom.window.FormData;
  globalThis.sessionStorage = dom.window.sessionStorage;
  globalThis.IntersectionObserver = class {
    constructor(callback) { this.callback = callback; }
    observe(element) { this.callback([{ isIntersecting: false, target: element }]); }
    disconnect() {}
  };
  globalThis.fetch = async () => new Response(JSON.stringify(defaultMenu), {
    status: 200,
    headers: { "content-type": "application/json" },
  });
  dom.window.open = () => null;

  await import(`../site/assets/site.js?test=${Date.now()}`);
  await import(`../site/assets/menu.js?test=${Date.now()}`);

  for (let attempt = 0; attempt < 20 && !document.querySelector(".menu-item"); attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 10));
  }

  assert.equal(document.querySelectorAll(".menu-category").length, 13);
  assert.ok([...document.querySelectorAll(".menu-category")].every((section) => !section.hasAttribute("data-reveal")));
  assert.equal(document.querySelectorAll(".wine-card").length, 4);
  assert.equal(document.querySelectorAll(".experience-card").length, 2);

  const pairing = document.querySelector("[data-pairing]");
  pairing.click();
  assert.equal(document.querySelector("#sommelier-dialog").hasAttribute("open"), true);
  assert.match(document.querySelector("#sommelier-messages").textContent, /Cosa abbino/);

  const search = document.querySelector("#menu-search");
  search.value = "scrigni";
  search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  assert.equal(document.querySelectorAll(".menu-item").length, 1);
  assert.match(document.querySelector(".menu-item").textContent, /Scrigni/);

  const booking = document.querySelector("[data-booking-note]");
  booking.click();
  assert.equal(document.querySelector("#booking-dialog").hasAttribute("open"), true);
  assert.match(document.querySelector("#booking-dialog [name=notes]").value, /Vorrei informazioni/);

  dom.window.close();
});

test("il pannello modifica vini e salva senza perdere il menu", async () => {
  const html = await readFile(new URL("../dist/admin/index.html", import.meta.url), "utf8");
  const dom = new JSDOM(html, { url: "https://oronero.test/admin/", pretendToBeVisual: true });
  // jsdom has no audio engine; MP3 playback is verified in Chromium.
  dom.window.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
  dom.window.HTMLMediaElement.prototype.pause = function () {};
  globalThis.window = dom.window;
  globalThis.document = dom.window.document;
  globalThis.location = dom.window.location;
  globalThis.HTMLElement = dom.window.HTMLElement;
  globalThis.customElements = dom.window.customElements;
  globalThis.CustomEvent = dom.window.CustomEvent;
  globalThis.FormData = dom.window.FormData;
  globalThis.sessionStorage = dom.window.sessionStorage;
  globalThis.IntersectionObserver = class {
    constructor(callback) { this.callback = callback; }
    observe(element) { this.callback([{ isIntersecting: false, target: element }]); }
    disconnect() {}
  };
  dom.window.confirm = () => true;
  let savedPayload;
  globalThis.fetch = async (input, options = {}) => {
    const url = String(input);
    if (url.endsWith("/api/admin/session")) return Response.json({ configured: true, authenticated: true });
    if (url.endsWith("/api/menu") && options.method === "PUT") {
      savedPayload = JSON.parse(options.body);
      return Response.json({ ...savedPayload, version: savedPayload.version + 1, updatedAt: new Date().toISOString() });
    }
    if (url.endsWith("/api/menu")) return Response.json(structuredClone(defaultMenu));
    if (url.endsWith("/api/admin/logout")) return Response.json({ authenticated: false });
    return new Response(null, { status: 404 });
  };

  await import(`../site/assets/site.js?admin-test=${Date.now()}`);
  await import(`../site/assets/admin.js?admin-test=${Date.now()}`);
  for (let attempt = 0; attempt < 20 && document.querySelector("#editor-view").hidden; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 10));
  }

  assert.equal(document.querySelector("#editor-view").hidden, false);
  document.querySelector('[data-admin-tab="wines"]').click();
  document.querySelector("[data-add-wine]").click();
  const newWine = [...document.querySelectorAll(".wine-admin-record")].at(-1);
  const name = newWine.querySelector('[data-field="name"]');
  name.value = "Etichetta di prova";
  name.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  document.querySelector("#save-menu").click();
  for (let attempt = 0; attempt < 20 && !/Salvato/.test(document.querySelector("#save-status").textContent); attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 10));
  }

  assert.equal(savedPayload.categories.length, 13);
  assert.equal(savedPayload.wines.at(-1).name, "Etichetta di prova");
  assert.match(document.querySelector("#save-status").textContent, /Salvato/);
  dom.window.close();
});

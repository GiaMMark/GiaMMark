import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { setupMusic } from '../site/assets/music.js';

const key = 'oronero-music-v1';
const settle = () => new Promise((resolve) => setImmediate(resolve));
function page({ saved, fail = false, deferred = false, noStorage = false, metadata = true, failureName = 'NotAllowedError' } = {}) {
  const dom = new JSDOM('<!doctype html><body><button id="enter">Entra</button><a href="/menu/">Menu</a></body>', { url: 'https://oronero.test/', pretendToBeVisual: true });
  const win = dom.window;
  if (saved) win.sessionStorage.setItem(key, JSON.stringify(saved));
  if (noStorage) Object.defineProperty(win, 'sessionStorage', { get() { throw new Error('No storage'); } });
  const states = new WeakMap();
  const state = (audio) => { if (!states.has(audio)) states.set(audio, { paused: true, plays: 0 }); return states.get(audio); };
  const prototype = win.HTMLMediaElement.prototype;
  Object.defineProperty(prototype, 'readyState', { configurable: true, get() { return metadata ? 4 : 0; } });
  Object.defineProperty(prototype, 'currentTime', { configurable: true, get() { return state(this).position || 0; }, set(value) { state(this).position = value; if (metadata) this.dispatchEvent(new win.Event('seeked')); } });
  Object.defineProperty(prototype, 'paused', { configurable: true, get() { return state(this).paused; } });
  const pendingPlays = [];
  let shouldFail = fail;
  prototype.play = function () {
    state(this).plays++;
    if (shouldFail) return Promise.reject(new win.DOMException('Playback failed', failureName));
    const started = () => { state(this).paused = false; this.dispatchEvent(new win.Event('play')); };
    if (deferred) return new Promise((resolve, reject) => { pendingPlays.push({ resolve() { started(); resolve(); }, reject(name = 'NotAllowedError') { reject(new win.DOMException('Playback failed', name)); } }); });
    started();
    return Promise.resolve();
  };
  prototype.pause = function () { state(this).paused = true; this.dispatchEvent(new win.Event('pause')); };
  const transitions = [];
  win.document.addEventListener('oronero:music-state', (event) => transitions.push({ audio: event.detail.audio, state: event.detail.state }));
  const controller = setupMusic(win.document, win);
  return { ...controller, win, doc: win.document, transitions, state: () => state(controller.audio), allow: () => { shouldFail = false; }, metadata() { metadata = true; controller.audio.dispatchEvent(new win.Event('loadedmetadata')); }, resolve: (index = pendingPlays.length - 1) => pendingPlays[index].resolve(), reject: (index, name) => pendingPlays[index].reject(name), close() { controller.destroy(); win.close(); } };
}

test('Vivaldi parte automaticamente in loop a volume contenuto e il comando pausa resta rispettato', async () => {
  const p = page();
  try {
    assert.equal(p.audio.loop, true);
    assert.equal(p.audio.volume, .7);
    assert.equal(p.audio.autoplay, true);
    assert.equal(p.audio.hasAttribute('data-persistent-audio'), true);
    assert.match(p.audio.src, /audio\/vivaldi-winter\.mp3$/);
    assert.equal(p.state().plays, 1);
    await settle();
    assert.equal(p.button.getAttribute('aria-pressed'), 'true');
    p.button.click();
    p.doc.querySelector('#enter').click();
    assert.equal(p.audio.paused, true);
    assert.equal(p.state().plays, 1);
    assert.equal(JSON.parse(p.win.sessionStorage.getItem(key)).enabled, false);
  } finally { p.close(); }
});

test('un blocco autoplay al primo accesso riprova al gesto successivo senza un comando dedicato', async () => {
  const p = page({ fail: true });
  try {
    await settle();
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    assert.match(p.button.textContent, /Avvia musica/);
    assert.equal(p.button.getAttribute('aria-busy'), 'false');
    p.allow();
    p.doc.querySelector('#enter').click();
    await settle();
    assert.equal(p.audio.paused, false);
    assert.equal(p.state().plays, 2);
  } finally { p.close(); }
});

test('la preferenza in pausa sopravvive alla navigazione e il comando esplicito riavvia', async () => {
  const p = page({ saved: { enabled: false, position: 43 } });
  try {
    p.doc.querySelector('#enter').click();
    assert.equal(p.audio.autoplay, false);
    assert.equal(p.state().plays, 0);
    p.button.click();
    await settle();
    assert.equal(p.audio.paused, false);
    assert.equal(p.audio.currentTime, 43);
    p.audio.currentTime = 51;
    p.win.dispatchEvent(new p.win.Event('pagehide'));
    assert.deepEqual(JSON.parse(p.win.sessionStorage.getItem(key)), { enabled: true, position: 51 });
  } finally { p.close(); }
});

test('mettere in pausa durante una richiesta pendente impedisce un avvio tardivo', async () => {
  const p = page({ deferred: true });
  try {
    assert.equal(p.button.getAttribute('aria-busy'), 'true');
    p.button.click();
    p.resolve();
    await settle();
    assert.equal(p.audio.paused, true);
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    assert.equal(p.button.getAttribute('aria-busy'), 'false');
    assert.equal(JSON.parse(p.win.sessionStorage.getItem(key)).enabled, false);
  } finally { p.close(); }
});

test('un errore della traccia non viene mostrato come musica in riproduzione', async () => {
  const p = page();
  try {
    await settle();
    p.audio.dispatchEvent(new p.win.Event('error'));
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    assert.match(p.button.textContent, /Riprova musica/);
  } finally { p.close(); }
});

test('il comando funziona anche senza sessionStorage e non viene duplicato', async () => {
  const p = page({ noStorage: true });
  try {
    assert.equal(setupMusic(p.doc, p.win).audio, p.audio);
    assert.equal(p.doc.querySelectorAll('[data-persistent-audio]').length, 1);
    assert.equal(p.doc.querySelectorAll('[data-music-control]').length, 1);
    await settle();
    assert.equal(p.audio.paused, false);
    p.button.click();
    assert.equal(p.audio.paused, true);
  } finally { p.close(); }
});

test('tocco, puntatore e tastiera possono sbloccare il tentativo automatico', async () => {
  for (const type of ['pointerdown', 'pointerup', 'touchstart', 'touchend', 'keydown']) {
    const p = page({ fail: true });
    try {
      await settle();
      p.allow();
      p.doc.querySelector('#enter').dispatchEvent(type === 'keydown' ? new p.win.KeyboardEvent(type, { key: 'Enter', bubbles: true }) : new p.win.Event(type, { bubbles: true }));
      await settle();
      assert.equal(p.audio.paused, false, type);
    } finally { p.close(); }
  }
});

test('la posizione precedente resta salvata durante il caricamento e viene ripristinata dai metadata', async () => {
  const p = page({ saved: { enabled: true, position: 93 }, metadata: false });
  try {
    await settle();
    assert.equal(p.audio.currentTime, 0);
    assert.equal(JSON.parse(p.win.sessionStorage.getItem(key)).position, 93);
    p.metadata();
    assert.equal(p.audio.currentTime, 93);
    p.audio.currentTime = 96;
    const link = p.doc.querySelector('a');
    link.addEventListener('click', (event) => event.preventDefault());
    link.click();
    assert.deepEqual(JSON.parse(p.win.sessionStorage.getItem(key)), { enabled: true, position: 96 });
  } finally { p.close(); }
});

test('lo stato iniziale è sincrono e il solo evento play non segnala audio pronto', async () => {
  const p = page({ deferred: true });
  try {
    assert.equal(p.audio.dataset.musicState, 'loading');
    assert.equal(p.audio.dataset.musicWanted, 'true');
    p.audio.dispatchEvent(new p.win.Event('play'));
    assert.equal(p.audio.dataset.musicState, 'loading');
    assert.deepEqual(p.transitions.map((event) => event.state), ['loading']);
    p.resolve();
    await settle();
    assert.equal(p.audio.dataset.musicState, 'playing');
    p.audio.dispatchEvent(new p.win.Event('playing'));
    p.audio.dispatchEvent(new p.win.Event('playing'));
    assert.deepEqual(p.transitions.map((event) => event.state), ['loading', 'playing']);
    assert.ok(p.transitions.every((event) => event.audio === p.audio));
    p.pause();
    assert.equal(p.audio.dataset.musicState, 'paused');
    assert.equal(p.audio.dataset.musicWanted, 'false');
  } finally { p.close(); }
});

test('autoplay negato espone blocked e un gesto produce loading poi playing', async () => {
  const p = page({ fail: true });
  try {
    await settle();
    assert.equal(p.audio.dataset.musicState, 'blocked');
    assert.equal(p.audio.dataset.musicWanted, 'true');
    p.allow();
    p.doc.querySelector('#enter').click();
    await settle();
    assert.deepEqual(p.transitions.map((event) => event.state), ['loading', 'blocked', 'loading', 'playing']);
    p.audio.dispatchEvent(new p.win.Event('error'));
    assert.equal(p.audio.dataset.musicState, 'error');
    p.button.click();
    await settle();
    assert.equal(p.audio.dataset.musicState, 'playing');
  } finally { p.close(); }
});

test('play risolto senza dati resta loading fino all’evento playing effettivo', async () => {
  const p = page({ metadata: false });
  try {
    await settle();
    assert.equal(p.audio.paused, false);
    assert.equal(p.audio.dataset.musicState, 'loading');
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    p.metadata();
    p.audio.dispatchEvent(new p.win.Event('playing'));
    assert.equal(p.audio.dataset.musicState, 'playing');
    p.audio.dispatchEvent(new p.win.Event('waiting'));
    assert.equal(p.audio.dataset.musicState, 'loading');
    p.audio.dispatchEvent(new p.win.Event('playing'));
    assert.equal(p.audio.dataset.musicState, 'playing');
  } finally { p.close(); }
});

test('un errore di riproduzione distinto dal permesso espone error e consente di riprovare', async () => {
  const p = page({ fail: true, failureName: 'NotSupportedError' });
  try {
    await settle();
    assert.equal(p.audio.dataset.musicState, 'error');
    assert.match(p.button.textContent, /Riprova musica/);
    p.allow();
    p.doc.querySelector('#enter').click();
    await settle();
    assert.equal(p.audio.dataset.musicState, 'playing');
  } finally { p.close(); }
});

test('un’interazione ordinaria sblocca la musica prima di stopPropagation del componente', async () => {
  const p = page({ fail: true });
  try {
    await settle();
    p.allow();
    p.doc.querySelector('#enter').addEventListener('click', (event) => event.stopPropagation());
    p.doc.querySelector('#enter').click();
    await settle();
    assert.equal(p.audio.dataset.musicState, 'playing');
    assert.equal(p.state().plays, 2);
  } finally { p.close(); }
});

test('il gesto ripete subito un tentativo pendente e la vecchia risposta non sovrascrive lo stato', async () => {
  const p = page({ deferred: true });
  try {
    assert.equal(p.state().plays, 1);
    p.doc.querySelector('#enter').dispatchEvent(new p.win.Event('touchend', { bubbles: true }));
    assert.equal(p.state().plays, 2);
    p.reject(0);
    await settle();
    assert.equal(p.audio.dataset.musicState, 'loading');
    p.resolve(1);
    await settle();
    assert.equal(p.audio.dataset.musicState, 'playing');
    assert.equal(p.audio.paused, false);
  } finally { p.close(); }
});

test('una pausa esplicita ferma anche i tentativi sovrapposti e resta valida ai gesti successivi', async () => {
  const p = page({ deferred: true });
  try {
    p.doc.querySelector('#enter').dispatchEvent(new p.win.Event('pointerup', { bubbles: true }));
    assert.equal(p.state().plays, 2);
    p.pause();
    p.resolve(1);
    p.resolve(0);
    await settle();
    p.doc.querySelector('#enter').click();
    assert.equal(p.audio.paused, true);
    assert.equal(p.audio.dataset.musicState, 'paused');
    assert.equal(p.state().plays, 2);
  } finally { p.close(); }
});

import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { JSDOM, VirtualConsole } from "jsdom";
import { defaultMenu } from "../netlify/functions/menu-default.mjs";

const html = await readFile(new URL("../site/menu/index.html", import.meta.url), "utf8");
const pause = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
let moduleId = 0;

function browser() {
  const errors = [];
  const virtualConsole = new VirtualConsole();
  virtualConsole.on("jsdomError", (error) => errors.push(error));
  const dom = new JSDOM(html, { url: "https://oronero.test/menu/", virtualConsole });
  globalThis.window = dom.window;
  globalThis.document = dom.window.document;
  globalThis.CustomEvent = dom.window.CustomEvent;
  return { dom, errors };
}

async function loadScript() {
  await import(`../site/assets/menu.js?edge-case=${++moduleId}`);
}

async function menuReady() {
  for (let attempt = 0; attempt < 100 && !document.querySelector(".menu-item"); attempt += 1) await pause(5);
  assert.ok(document.querySelector(".menu-item"), "Il menu deve completare il caricamento");
}

test("ricerca e filtro prima del caricamento restano applicati senza eccezioni", async () => {
  const { dom, errors } = browser();
  let releaseMenu;
  globalThis.fetch = () => new Promise((resolve) => { releaseMenu = resolve; });
  try {
    await loadScript();
    const search = document.querySelector("#menu-search");
    search.value = "tofu";
    search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
    const vegetarian = document.querySelector("#vegetarian-filter");
    vegetarian.checked = true;
    vegetarian.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
    assert.deepEqual(errors, []);
    releaseMenu(Response.json(defaultMenu));
    await menuReady();
    assert.equal(document.querySelectorAll(".menu-item").length, 1);
    assert.match(document.querySelector(".menu-item").textContent, /Tataki di tofu/);
  } finally {
    dom.window.close();
  }
});

test("una richiesta API bloccata viene interrotta e usa il menu statico", async () => {
  const { dom } = browser();
  const realSetTimeout = globalThis.setTimeout;
  const requests = [];
  let aborted = false;
  globalThis.setTimeout = (callback, milliseconds, ...args) => realSetTimeout(callback, milliseconds === 8000 ? 0 : milliseconds, ...args);
  globalThis.fetch = async (url, options) => {
    requests.push(String(url));
    if (url !== "/api/menu") return Response.json(defaultMenu);
    return new Promise((_, reject) => options.signal.addEventListener("abort", () => {
      aborted = true;
      reject(new DOMException("Richiesta interrotta", "AbortError"));
    }, { once: true }));
  };
  try {
    await loadScript();
    await menuReady();
    assert.equal(aborted, true);
    assert.equal(requests[0], "/api/menu");
    assert.match(requests[1], /default-menu\.json$/);
    assert.equal(document.querySelectorAll(".menu-category").length, defaultMenu.categories.length);
  } finally {
    globalThis.setTimeout = realSetTimeout;
    dom.window.close();
  }
});

test("il Sommelier esplicita un budget insufficiente senza suggerire vini più cari", async () => {
  const { dom } = browser();
  globalThis.fetch = async () => Response.json(defaultMenu);
  try {
    await loadScript();
    await menuReady();
    document.querySelector("#sommelier-input").value = "Un vino per pesce entro 1 euro";
    document.querySelector("#sommelier-form").dispatchEvent(new dom.window.Event("submit", { bubbles: true, cancelable: true }));
    await pause(350);
    const response = [...document.querySelectorAll(".sommelier-message.assistant")].at(-1).textContent;
    assert.match(response, /Non ho trovato etichette disponibili entro il budget/);
    assert.doesNotMatch(response, /ti consiglio/);
    assert.ok(!defaultMenu.wines.some((wine) => response.includes(wine.name)));
  } finally {
    dom.window.close();
  }
});

test("il Sommelier continua a proporre vini compatibili con il budget", async () => {
  const { dom } = browser();
  globalThis.fetch = async () => Response.json(defaultMenu);
  try {
    await loadScript();
    await menuReady();
    document.querySelector("#sommelier-input").value = "Un vino per pesce entro 18 euro";
    document.querySelector("#sommelier-form").dispatchEvent(new dom.window.Event("submit", { bubbles: true, cancelable: true }));
    await pause(350);
    const response = [...document.querySelectorAll(".sommelier-message.assistant")].at(-1).textContent;
    assert.match(response, /ti consiglio Bianco della casa/);
    assert.doesNotMatch(response, /Prosecco della casa/);
  } finally {
    dom.window.close();
  }
});

import assert from "node:assert/strict";
import test from "node:test";
import adminLogin from "../netlify/functions/admin-login.mjs";
import adminLogout from "../netlify/functions/admin-logout.mjs";
import adminSession from "../netlify/functions/admin-session.mjs";
import menuHandler from "../netlify/functions/menu.mjs";
import { createToken } from "../netlify/functions/_auth.mjs";
import { readdir } from "node:fs/promises";

const password = "PasswordOroNero!2026";
const secret = "session-secret-di-test-lungo-oltre-trentadue-caratteri";

function configure() {
  process.env.ORONERO_ADMIN_PASSWORD = password;
  process.env.ORONERO_SESSION_SECRET = secret;
}

test("il menu pubblico restituisce carta, vini e percorsi", async () => {
  const response = await menuHandler(new Request("https://example.test/api/menu"));
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.categories.length, 13);
  assert.ok(body.wines.length >= 4);
  assert.ok(body.degustations.length >= 1);
  assert.ok(body.events.length >= 1);
});

test("la sessione segnala una configurazione mancante", async () => {
  delete process.env.ORONERO_ADMIN_PASSWORD;
  delete process.env.ORONERO_SESSION_SECRET;
  const response = await adminSession(new Request("https://example.test/api/admin/session"));
  assert.deepEqual(await response.json(), { configured: false, authenticated: false });
});

test("login, sessione e logout amministratore funzionano insieme", async () => {
  configure();
  const login = await adminLogin(new Request("https://example.test/api/admin/login", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ password }),
  }));
  assert.equal(login.status, 200);
  const cookie = login.headers.get("set-cookie").split(";")[0];
  const session = await adminSession(new Request("https://example.test/api/admin/session", { headers: { cookie } }));
  assert.deepEqual(await session.json(), { configured: true, authenticated: true });
  const logout = await adminLogout();
  assert.match(logout.headers.get("set-cookie"), /Max-Age=0/);
});

test("cookie malformati e salvataggi non autorizzati non rompono le funzioni", async () => {
  configure();
  const session = await adminSession(new Request("https://example.test/api/admin/session", { headers: { cookie: "oronero_admin=%E0%A4%A" } }));
  assert.deepEqual(await session.json(), { configured: true, authenticated: false });
  const save = await menuHandler(new Request("https://example.test/api/menu", {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ categories: [] }),
  }));
  assert.equal(save.status, 401);
});

test("payload JSON null e menu malformati sono rifiutati senza errori del server", async () => {
  configure();
  const login = await adminLogin(new Request("https://example.test/api/admin/login", {
    method: "POST", headers: { "content-type": "application/json" }, body: "null",
  }));
  assert.equal(login.status, 400);
  const cookie = `oronero_admin=${createToken()}`;
  for (const payload of [null, { categories: [null] }, { categories: [{ id: "test", title: "Test", items: [null] }] }, { categories: [], wines: [null] }, { categories: [], version: "NaN" }]) {
    const save = await menuHandler(new Request("https://example.test/api/menu", {
      method: "PUT", headers: { "content-type": "application/json", cookie }, body: JSON.stringify(payload),
    }));
    assert.equal(save.status, 400);
  }
});

test("il deploy contiene un solo entrypoint per ogni funzione Netlify", async () => {
  const files = (await readdir(new URL("../netlify/functions/", import.meta.url)))
    .filter((name) => /\.(?:mjs|mts|js|ts)$/.test(name));
  const names = files.map((name) => name.replace(/\.[^.]+$/, ""));
  assert.equal(new Set(names).size, names.length, "Funzioni duplicate: Netlify non può scegliere tra implementazioni omonime");
});

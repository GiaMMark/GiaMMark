import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { JSDOM, VirtualConsole } from "jsdom";

const html = await readFile(new URL("../site/index.html", import.meta.url), "utf8");
let moduleId = 0;

async function homepage() {
  const errors = [];
  const virtualConsole = new VirtualConsole();
  virtualConsole.on("jsdomError", (error) => errors.push(error));
  const dom = new JSDOM(html, {
    url: "https://oronero.test/", pretendToBeVisual: true, virtualConsole,
  });
  const { window } = dom;
  // jsdom has no media engine; real MP3 playback is checked in Chromium.
  window.HTMLMediaElement.prototype.play = function () {
    Object.defineProperty(this, 'paused', { configurable: true, value: false });
    this.dispatchEvent(new window.Event('play'));
    return Promise.resolve();
  };
  window.HTMLMediaElement.prototype.pause = function () {
    Object.defineProperty(this, 'paused', { configurable: true, value: true });
    this.dispatchEvent(new window.Event('pause'));
  };
  globalThis.window = window;
  globalThis.document = window.document;
  globalThis.location = window.location;
  globalThis.HTMLElement = window.HTMLElement;
  globalThis.customElements = window.customElements;
  globalThis.CustomEvent = window.CustomEvent;
  globalThis.FormData = window.FormData;
  globalThis.IntersectionObserver = class {
    constructor(callback) { this.callback = callback; }
    observe(target) { this.callback([{ target, isIntersecting: true }]); }
    unobserve() {}
    disconnect() {}
  };
  window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  window.HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
    this.dispatchEvent(new window.Event("close"));
  };
  const opened = [];
  window.open = (...args) => { opened.push(args); return null; };
  globalThis.fetch = async () => { throw new Error("Nessuna richiesta esterna prevista dal test della home"); };

  // The booking focus delay must not outlive its document.
  const realSetTimeout = globalThis.setTimeout;
  const timers = new Set();
  globalThis.setTimeout = (callback, delay, ...args) => {
    const timer = realSetTimeout(callback, delay, ...args);
    timers.add(timer);
    return timer;
  };
  const close = () => {
    timers.forEach((timer) => clearTimeout(timer));
    globalThis.setTimeout = realSetTimeout;
    window.close();
  };
  try {
    await import(`../site/assets/site.js?home-test=${++moduleId}`);
    assert.deepEqual(errors, [], "La home deve inizializzarsi senza errori JavaScript");
    return { dom, opened, errors, close };
  } catch (error) {
    close();
    throw error;
  }
}

test("lo slider manuale aggiorna foto, didascalia e contatore con ritorno circolare", async () => {
  const page = await homepage();
  try {
    const slides = [...document.querySelectorAll("[data-hero-slide]")];
    const caption = document.querySelector("[data-hero-caption]");
    const counter = document.querySelector("[data-hero-current]");
    const assertSlide = (index) => {
      assert.equal(slides.filter((slide) => slide.classList.contains("is-active")).length, 1);
      assert.equal(slides[index].classList.contains("is-active"), true);
      assert.equal(caption.textContent, slides[index].dataset.caption);
      assert.equal(counter.textContent, String(index + 1).padStart(2, "0"));
    };
    assert.equal(slides.length, 3);
    assert.equal(caption.getAttribute("aria-live"), "polite");
    assertSlide(0);
    document.querySelector("[data-hero-next]").click();
    assertSlide(1);
    document.querySelector("[data-hero-next]").click();
    assertSlide(2);
    document.querySelector("[data-hero-next]").click();
    assertSlide(0);
    document.querySelector("[data-hero-prev]").click();
    assertSlide(2);
    assert.deepEqual(page.errors, []);
  } finally {
    page.close();
  }
});

test("la galleria apre da tastiera, cambia foto e si chiude", async () => {
  const page = await homepage();
  try {
    const figures = [...document.querySelectorAll(".gallery-card")];
    const photos = figures.map((figure) => figure.querySelector("img"));
    const dialog = document.querySelector("#gallery-dialog");
    const assertPhoto = (index) => {
      assert.equal(dialog.querySelector("img").src, photos[index].src);
      assert.equal(dialog.querySelector("img").alt, photos[index].alt);
      assert.equal(dialog.querySelector("figcaption").textContent, figures[index].querySelector("figcaption").textContent);
    };
    assert.equal(figures[0].getAttribute("role"), "button");
    assert.equal(figures[0].tabIndex, 0);
    figures[0].dispatchEvent(new page.dom.window.KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
    assert.equal(dialog.open, true);
    assert.equal(document.body.classList.contains("dialog-open"), true);
    assertPhoto(0);
    dialog.querySelector(".gallery-next").click();
    assertPhoto(1);
    dialog.querySelector(".gallery-next").click();
    assertPhoto(0);
    dialog.querySelector(".gallery-prev").click();
    assertPhoto(1);
    dialog.dispatchEvent(new page.dom.window.KeyboardEvent("keydown", { key: "ArrowLeft", bubbles: true }));
    assertPhoto(0);
    dialog.querySelector(".gallery-close").click();
    assert.equal(dialog.open, false);
    assert.equal(document.body.classList.contains("dialog-open"), false);
    assert.deepEqual(page.errors, []);
  } finally {
    page.close();
  }
});

test("la prenotazione prepara WhatsApp con dati codificati e link alternativo", async () => {
  const page = await homepage();
  try {
    document.querySelector("[data-booking]").click();
    const dialog = document.querySelector("#booking-dialog");
    const form = document.querySelector("#booking-form");
    const field = (name) => form.querySelector(`[name="${name}"]`);
    assert.equal(dialog.open, true);
    assert.equal(field("guests").value, "2");
    assert.equal(field("time").value, "19:30");
    assert.equal([...field("time").options].some((option) => option.value === "16:00"), false);
    field("name").value = "Luca D’Amico & Giulia";
    field("guests").value = "4";
    field("date").value = "2099-11-06";
    field("time").value = "20:15";
    field("notes").value = "Allergia: noci & sesamo. Un tavolo tranquillo, grazie!";
    assert.equal(form.checkValidity(), true);
    form.dispatchEvent(new page.dom.window.Event("submit", { bubbles: true, cancelable: true }));

    assert.equal(page.opened.length, 1);
    const [url, target, features] = page.opened[0];
    const request = new URL(url);
    assert.equal(request.origin, "https://wa.me");
    assert.equal(request.pathname, "/393442865877");
    assert.equal(target, "_blank");
    assert.equal(features, "noopener,noreferrer");
    assert.equal([...request.searchParams.keys()].join(","), "text", "I caratteri speciali devono restare nel messaggio");
    const text = request.searchParams.get("text");
    assert.match(text, /Nome: Luca D’Amico & Giulia/);
    assert.match(text, /Persone: 4/);
    assert.match(text, /Data: .*06 novembre/);
    assert.match(text, /Ora: 20:15/);
    assert.match(text, /Note: Allergia: noci & sesamo/);
    assert.ok(url.includes("%26"));
    assert.ok(url.includes("%0A"));
    const status = document.querySelector("#booking-status");
    assert.equal(status.hidden, false);
    assert.equal(status.querySelector("a").href, url);
    assert.match(status.textContent, /Attendi la risposta del ristorante per la conferma/);
    assert.equal(dialog.open, true, "Il link alternativo deve restare consultabile se il popup è bloccato");
    assert.deepEqual(page.errors, []);
  } finally {
    page.close();
  }
});

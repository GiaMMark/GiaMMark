import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM } from 'jsdom';
import { setupArrival } from '../site/assets/arrival.js';
const html = await readFile(new URL('../site/index.html', import.meta.url), 'utf8');
function page({seen = false, reduce = false, hash = '', music = false, musicState = null, musicWanted = true} = {}) {
  const dom = new JSDOM(html, { url: `https://oronero.test/${hash}`, pretendToBeVisual: true });
  dom.window.matchMedia = () => ({matches:reduce});
  let audio;
  if (musicState) {
    audio = dom.window.document.createElement('audio');
    audio.dataset.persistentAudio = '';
    audio.dataset.musicState = musicState;
    audio.dataset.musicWanted = String(musicWanted);
    dom.window.document.body.append(audio);
  }
  if (music || musicState) {
    const control = dom.window.document.createElement('button');
    control.dataset.musicControl = '';
    control.textContent = 'Musica';
    dom.window.document.body.append(control);
  }
  if (seen) dom.window.sessionStorage.setItem('oronero-arrival-seen-v1', '1');
  const tasks = new Map();
  let id = 0;
  dom.window.setTimeout = (callback, milliseconds) => { tasks.set(++id, {callback, milliseconds}); return id; };
  dom.window.clearTimeout = (timer) => tasks.delete(timer);
  const controller = setupArrival(dom.window.document,dom.window);
  return { dom, doc:dom.window.document, controller, setMusicState(state) {
    audio.dataset.musicState = state;
    dom.window.document.dispatchEvent(new dom.window.CustomEvent('oronero:music-state', {detail:{audio,state}}));
  }, run(milliseconds) {
    for (const [timer, task] of [...tasks]) if (task.milliseconds === milliseconds) { tasks.delete(timer); task.callback(); }
  }, close() {controller.destroy();dom.window.close();} };
}
test('l’ingresso apre una volta, si può saltare e ripristina il sito e il focus', () => {
  const p=page();
  try {
    const overlay=p.doc.querySelector('[data-arrival]');
    assert.equal(overlay.hidden,false);
    assert.equal(p.doc.querySelector('main').inert,true);
    assert.equal(p.doc.activeElement,p.doc.querySelector('[data-arrival-skip]'));
    p.doc.querySelector('[data-arrival-skip]').click();
    p.run(160);
    assert.equal(overlay.hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    assert.equal(p.doc.body.classList.contains('arrival-open'),false);
    assert.equal(p.dom.window.sessionStorage.getItem('oronero-arrival-seen-v1'),'1');
  } finally {p.close();}
});
test('la sequenza si chiude da sola e può essere rivista esplicitamente', () => {
  const p=page();
  try {
    p.run(3000);assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-closing'),true);
    p.run(1100);assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    const replay=p.doc.querySelector('[data-replay-arrival]');replay.focus();replay.click();
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    p.doc.querySelector('[data-arrival]').dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(p.doc.activeElement,replay);
  } finally {p.close();}
});
test('la musica resta accessibile durante l’intro e il focus percorre solo i due comandi', () => {
  const p = page({music:true});
  try {
    const music = p.doc.querySelector('[data-music-control]');
    const skip = p.doc.querySelector('[data-arrival-skip]');
    assert.equal(Boolean(music.inert), false);
    assert.equal(p.doc.querySelector('[data-arrival]').contains(music),true);
    skip.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',bubbles:true}));
    assert.equal(p.doc.activeElement,music);
    music.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',bubbles:true}));
    assert.equal(p.doc.activeElement,skip);
    skip.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',shiftKey:true,bubbles:true}));
    assert.equal(p.doc.activeElement,music);
    music.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(music.parentNode,p.doc.body);
    assert.equal(p.doc.activeElement,music);
  } finally { p.close(); }
});
test('la salvaguardia ripristina il sito anche se il completamento animato non avviene', () => {
  const p=page();
  try {
    p.run(5500);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    p.run(3000);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
  } finally {p.close();}
});
test('visita già vista, movimento ridotto e link diretto non bloccano la navigazione', () => {
  for(const options of [{seen:true},{reduce:true},{hash:'#contatti'}]) {
    const p=page(options);
    try { assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);assert.equal(Boolean(p.doc.querySelector('main').inert),false); }
    finally {p.close();}
  }
});
test('se lo storage non è disponibile e se si lascia la pagina il contenuto viene ripristinato', () => {
  const p=page({seen:true});
  try {
    Object.defineProperty(p.dom.window,'sessionStorage',{get(){throw new Error('Storage non disponibile');}});
    p.controller.open();
    p.dom.window.dispatchEvent(new p.dom.window.Event('pagehide'));
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    assert.equal(p.doc.body.classList.contains('arrival-open'),false);
  } finally {p.close();}
});
test('la sequenza e il suo conto alla rovescia iniziano solo quando la musica caricata sta suonando', () => {
  const p=page({musicState:'loading'});
  try {
    const overlay=p.doc.querySelector('[data-arrival]');
    assert.equal(overlay.classList.contains('is-waiting'),true);
    assert.equal(overlay.classList.contains('is-active'),false);
    p.run(3000);
    assert.equal(overlay.classList.contains('is-closing'),false);
    p.setMusicState('playing');
    assert.equal(overlay.classList.contains('is-waiting'),false);
    assert.equal(overlay.classList.contains('is-active'),true);
    p.run(3000);
    assert.equal(overlay.classList.contains('is-closing'),true);
    p.run(1100);
    assert.equal(overlay.hidden,true);
  } finally {p.close();}
});
test('blocco autoplay, errore e pausa esplicita fanno proseguire l’intro senza attendere audio', () => {
  for (const state of ['blocked','error','paused']) {
    const p=page({musicState:'loading'});
    try {
      p.setMusicState(state);
      const overlay=p.doc.querySelector('[data-arrival]');
      assert.equal(overlay.classList.contains('is-waiting'),false,state);
      assert.equal(overlay.classList.contains('is-active'),true,state);
      p.run(3000);p.run(1100);
      assert.equal(overlay.hidden,true,state);
    } finally {p.close();}
  }
});
test('dopo otto secondi di caricamento l’intro prosegue comunque e conserva la salvaguardia', () => {
  const p=page({musicState:'loading'});
  try {
    const overlay=p.doc.querySelector('[data-arrival]');
    p.run(8000);
    assert.equal(overlay.classList.contains('is-active'),true);
    assert.equal(overlay.classList.contains('is-waiting'),false);
    p.run(5500);
    assert.equal(overlay.hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
  } finally {p.close();}
});
test('salto, Escape e abbandono durante l’attesa annullano gli avvii musicali successivi', () => {
  for (const action of ['skip','escape','pagehide','visibility']) {
    const p=page({musicState:'loading'});
    try {
      const overlay=p.doc.querySelector('[data-arrival]');
      if (action==='skip') p.doc.querySelector('[data-arrival-skip]').click();
      if (action==='escape') p.doc.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
      if (action==='pagehide') p.dom.window.dispatchEvent(new p.dom.window.Event('pagehide'));
      if (action==='visibility') {
        Object.defineProperty(p.doc,'hidden',{configurable:true,value:true});
        p.doc.dispatchEvent(new p.dom.window.Event('visibilitychange'));
      }
      p.run(160);
      assert.equal(overlay.hidden,true,action);
      p.setMusicState('playing');p.run(8000);p.run(3000);
      assert.equal(overlay.hidden,true,action);
      assert.equal(overlay.classList.contains('is-active'),false,action);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false,action);
    } finally {p.close();}
  }
});
test('audio già avviato e preferenze senza musica non ritardano la sequenza', () => {
  for (const options of [{musicState:'playing'},{musicState:'paused',musicWanted:false}]) {
    const p=page(options);
    try {
      assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
      assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-waiting'),false);
    } finally {p.close();}
  }
});

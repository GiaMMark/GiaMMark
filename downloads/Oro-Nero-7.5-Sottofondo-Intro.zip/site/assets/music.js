const STORAGE_KEY = 'oronero-music-v1';
const CONTROLLER_KEY = Symbol.for('oronero.music.controller');
const GESTURE_EVENTS = ['pointerdown', 'pointerup', 'touchstart', 'touchend', 'click', 'keydown'];

/** One player shared by every page. Browser autoplay permission is always respected. */
export function setupMusic(doc = document, win = window) {
  const retained = doc.querySelector('[data-persistent-audio]');
  if (retained?.[CONTROLLER_KEY]) return retained[CONTROLLER_KEY];
  if (doc.querySelector('[data-music-control]')) return null;
  let saved = null;
  try { saved = JSON.parse(win.sessionStorage.getItem(STORAGE_KEY)); } catch { /* Optional storage. */ }
  let wanted = saved?.enabled !== false;
  let mayStart = saved?.enabled !== false;
  let pending = false;
  let unavailable = false;
  let playbackReady = false;
  let blocked = false;
  let mediaPaused = false;
  let lastState;
  let destroyed = false;
  let generation = 0;
  let lastSaved = -Infinity;
  const position = Number.isFinite(saved?.position) && saved.position >= 0 ? saved.position : 0;
  let positionRestored = position === 0;

  const audio = doc.createElement('audio');
  audio.src = new URL('./audio/vivaldi-winter.mp3', import.meta.url).href;
  audio.preload = wanted ? 'auto' : 'none';
  audio.autoplay = wanted;
  audio.loop = true;
  audio.volume = 0.7;
  audio.setAttribute('data-persistent-audio', '');
  audio.setAttribute('aria-hidden', 'true');

  const button = doc.createElement('button');
  button.type = 'button';
  button.className = 'site-music';
  button.setAttribute('data-music-control', '');
  button.innerHTML = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M9 18V6l11-3v12M9 10l11-3"/><ellipse cx="6" cy="18" rx="3" ry="2.5"/><ellipse cx="17" cy="15" rx="3" ry="2.5"/></svg><span class="site-music-copy"><span>Vivaldi · L’inverno</span><strong data-music-label></strong></span><span class="site-music-bars" aria-hidden="true"><i></i><i></i><i></i></span>';
  const label = button.querySelector('[data-music-label]');
  doc.body.append(audio, button);

  const save = () => {
    try {
      // A new audio element starts at zero before its metadata loads. Preserve the
      // previous page's position until the pending seek has actually completed.
      const current = positionRestored && Number.isFinite(audio.currentTime) ? audio.currentTime : position;
      win.sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ enabled: wanted, position: current }));
    } catch { /* The controls also work without storage. */ }
  };
  const render = () => {
    const state = !wanted ? 'paused' : unavailable ? 'error' : blocked ? 'blocked' : playbackReady && !audio.paused ? 'playing' : pending || !mediaPaused ? 'loading' : 'paused';
    const playing = state === 'playing';
    audio.dataset.musicWanted = String(wanted);
    audio.dataset.musicState = state;
    button.classList.toggle('is-playing', playing);
    button.setAttribute('aria-pressed', String(playing));
    button.setAttribute('aria-busy', String(state === 'loading'));
    const text = state === 'error' ? 'Riprova musica' : state === 'loading' ? 'Avvio…' : playing ? 'Pausa musica' : 'Avvia musica';
    label.textContent = text;
    button.setAttribute('aria-label', `${text} · Vivaldi, L’inverno`);
    button.title = playing ? 'Metti in pausa la musica' : 'Ascolta Vivaldi, L’inverno';
    if (lastState !== state) {
      lastState = state;
      doc.dispatchEvent(new win.CustomEvent('oronero:music-state', { detail: { audio, state } }));
    }
  };
  const restorePosition = () => {
    if (positionRestored || audio.readyState < 1) return;
    try { audio.currentTime = Number.isFinite(audio.duration) && audio.duration > 0 ? position % audio.duration : position; } catch { /* Retry after metadata loads. */ }
  };
  const onSeeked = () => {
    const target = Number.isFinite(audio.duration) && audio.duration > 0 ? position % audio.duration : position;
    if (Math.abs(audio.currentTime - target) < .5) positionRestored = true;
  };
  const pause = () => {
    generation++;
    wanted = false;
    mayStart = false;
    audio.autoplay = false;
    pending = false;
    playbackReady = false;
    blocked = false;
    audio.pause();
    save();
    render();
  };
  const play = async ({ gesture = false } = {}) => {
    if (destroyed || (playbackReady && !audio.paused)) return;
    if (!gesture && (pending || !audio.paused)) return;
    // Reissue a pending request synchronously inside user activation. Some mobile
    // browsers only unlock media at touchend/pointerup; waiting for an older
    // autoplay promise would lose that activation. Never pause healthy audio.
    const request = ++generation;
    wanted = true;
    mayStart = true;
    audio.autoplay = true;
    pending = true;
    unavailable = false;
    blocked = false;
    mediaPaused = false;
    render();
    save();
    try {
      if (audio.error) audio.load();
      await audio.play();
      if (destroyed || request !== generation) {
        if (destroyed || !wanted) audio.pause();
        return;
      }
      if (audio.readyState >= 2 && !audio.paused) playbackReady = true;
    } catch (error) {
      // A denied autoplay request remains silent until a later user gesture.
      if (request !== generation || destroyed) return;
      blocked = error?.name === 'NotAllowedError';
      unavailable = !blocked;
    }
    pending = false;
    render();
  };
  const onToggle = () => {
    if (pending || !audio.paused) pause();
    else void play();
  };
  const onGesture = (event) => {
    if (event.target?.closest?.('[data-music-control]')) return;
    if (event.type === 'keydown' && (event.repeat || event.ctrlKey || event.metaKey || event.altKey || ['Shift', 'Control', 'Alt', 'Meta'].includes(event.key))) return;
    if (mayStart && wanted) void play({ gesture: true });
  };
  const onPlayback = (event) => {
    if (!wanted && !audio.paused) audio.pause();
    if (event.type === 'pause') { playbackReady = false; mediaPaused = true; }
    else { mediaPaused = false; blocked = false; }
    render();
  };
  const onPlaying = () => {
    if (!wanted) { audio.pause(); return; }
    playbackReady = true;
    blocked = false;
    mediaPaused = false;
    unavailable = false;
    render();
  };
  const onWaiting = () => { playbackReady = false; render(); };
  const onTime = () => {
    if (Math.abs(audio.currentTime - lastSaved) < 3) return;
    lastSaved = audio.currentTime;
    save();
  };
  const onError = () => {
    pending = false;
    playbackReady = false;
    unavailable = true;
    audio.pause();
    render();
  };
  const onVisibility = () => { if (doc.hidden) save(); };
  const onPageHide = () => save();
  const onPageShow = () => { if (wanted && audio.paused) void play(); };
  const onNavigate = (event) => {
    const link = event.target?.closest?.('a[href]');
    if (link && link.origin === win.location.origin) save();
  };

  button.addEventListener('click', onToggle);
  GESTURE_EVENTS.forEach((type) => doc.addEventListener(type, onGesture, { capture: true, passive: true }));
  doc.addEventListener('click', onNavigate, true);
  audio.addEventListener('loadedmetadata', restorePosition);
  audio.addEventListener('seeked', onSeeked);
  audio.addEventListener('play', onPlayback);
  audio.addEventListener('playing', onPlaying);
  audio.addEventListener('waiting', onWaiting);
  audio.addEventListener('pause', onPlayback);
  audio.addEventListener('timeupdate', onTime);
  audio.addEventListener('error', onError);
  doc.addEventListener('visibilitychange', onVisibility);
  win.addEventListener('pagehide', onPageHide);
  win.addEventListener('pageshow', onPageShow);
  restorePosition();
  render();

  const controller = { audio, button, play, pause, destroy() {
    destroyed = true;
    generation++;
    save();
    button.removeEventListener('click', onToggle);
    GESTURE_EVENTS.forEach((type) => doc.removeEventListener(type, onGesture, true));
    doc.removeEventListener('click', onNavigate, true);
    audio.removeEventListener('loadedmetadata', restorePosition);
    audio.removeEventListener('seeked', onSeeked);
    audio.removeEventListener('play', onPlayback);
    audio.removeEventListener('playing', onPlaying);
    audio.removeEventListener('waiting', onWaiting);
    audio.removeEventListener('pause', onPlayback);
    audio.removeEventListener('timeupdate', onTime);
    audio.removeEventListener('error', onError);
    doc.removeEventListener('visibilitychange', onVisibility);
    win.removeEventListener('pagehide', onPageHide);
    win.removeEventListener('pageshow', onPageShow);
    audio.pause();
    delete audio[CONTROLLER_KEY];
    audio.remove();
    button.remove();
  } };
  audio[CONTROLLER_KEY] = controller;
  if (wanted) void play();
  return controller;
}

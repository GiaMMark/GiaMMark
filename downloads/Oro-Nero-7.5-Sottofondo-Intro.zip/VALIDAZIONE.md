# Oro Nero 7.5.0 · Sottofondo discreto e primo ingresso

## Modifiche

- MP3 attenuato direttamente di 12 dB rispetto alla versione 7.4 e lettore impostato al 70%. L’attenuazione nel file riduce il sottofondo anche sui dispositivi che ignorano il volume JavaScript. Durata e contenuto del brano sono conservati.
- Modulo musicale leggero caricato nella testata, prima dei moduli principali: tenta subito autoplay e registra tempestivamente i gesti ordinari.
- Tocco, clic o tastiera sulla pagina sbloccano il tentativo quando il browser richiede una prima interazione, senza premere il pulsante musicale. Listener in fase capture, gestione touchend/pointerup e recupero degli avvii pendenti o falliti; pausa volontaria rispettata.
- Copertura critica inline prima dei CSS: al primo ingresso la homepage non appare per un fotogramma prima dell’intro. Il logo e il comando di salto sono disponibili anche mentre i moduli caricano.
- Passaggio della gestione della copertura iniziale all’intro completa senza rimuovere la protezione prima del tempo. Ripristino corretto di focus e inert.
- Sessione già vista, movimento ridotto e frammenti diretti saltano la copertura. Senza JavaScript la homepage rimane accessibile; se il modulo principale fallisce, il sito si sblocca entro otto secondi. Skip ed Escape funzionano prima dei moduli e impediscono una riapertura tardiva.

Musica continua tra le pagine, sincronizzazione del logo all’audio effettivo, menu senza foto e dati delle 80 voci conservati.

## Verifiche

Node.js 22.23.4: build e controllo di 13 categorie e 80 voci riusciti. **62 test superati**, nessun fallimento o test saltato: inclusi 15 test musicali, 11 dell’intro, 6 del nuovo avvio e 4 della navigazione.

Livello audio: confronto RMS dei primi 30 secondi decodificati mostra circa 12,4 dB in meno rispetto al master 7.4, coerente con l’attenuazione richiesta dopo la ricodifica MP3.

Chromium: modulo principale ritardato di due secondi, campionamento fotogramma per fotogramma nei primi 1,7 secondi; nessun fotogramma della homepage esposto prima dell’intro. Copertura presente a 219 ms, passaggio all’intro completa a circa 2,1 s senza interruzione; alla chiusura il contenuto torna utilizzabile e non inert. Verificati sessione vista, movimento ridotto, link con frammento, JavaScript disabilitato, salto prima dei moduli e recupero dopo errore del modulo principale.

Con policy autoplay restrittiva: un normale tocco sull’intro avvia la musica prima del caricamento del modulo principale, senza usare il comando musicale. Verificati anche clic, tocco e Enter su elementi che interrompono la propagazione degli eventi. Osservazioni CDP con userGesture:false per evitare attivazioni artificiali.

Riconfermati intro sincronizzata con audio rapido e con MP3 ritardato di cinque secondi, continuità del medesimo lettore tra tutte le pagine e Indietro/Avanti, menu e ricerca, Sommelier, prenotazione, stampa QR e visualizzazione mobile a 390 pixel. Nessun errore JavaScript nelle verifiche funzionali; la prova che simula un modulo mancante genera intenzionalmente una risposta HTTP 404 e verifica il recupero.

## Limiti e pubblicazione

Non è possibile imporre musica udibile quando il browser vieta autoplay: il sito tenta l’avvio immediato e, in quel caso, usa la prima normale interazione. Una pausa esplicita non viene annullata. Il volume fisico resta regolato dal dispositivo.

Nessun deploy Netlify eseguito. Gli ZIP aggiornati su GitHub devono essere pubblicati sull’hosting per aggiornare il sito online. Il caricamento sul repository non aggiorna automaticamente un sito Netlify esistente. L’admin persistente richiede configurazione e deploy completi descritti nei README.

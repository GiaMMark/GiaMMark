import { configured, createToken, json, passwordMatches, sessionCookie } from "./_auth.mjs";

export default async (request) => {
  if (request.method !== "POST") return json({ error: "Metodo non consentito" }, 405);
  if (!configured()) return json({ configured: false, error: "Configurazione necessaria" }, 503);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Richiesta non valida" }, 400);
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return json({ error: "Richiesta non valida" }, 400);
  }
  if (!passwordMatches(body.password)) return json({ error: "Password non corretta" }, 401);
  return json(
    { authenticated: true },
    200,
    { "set-cookie": sessionCookie(createToken()) },
  );
};

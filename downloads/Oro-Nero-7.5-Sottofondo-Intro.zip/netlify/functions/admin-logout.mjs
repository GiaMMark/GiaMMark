import { expiredCookie, json } from "./_auth.mjs";

export default async () =>
  json({ authenticated: false }, 200, { "set-cookie": expiredCookie() });

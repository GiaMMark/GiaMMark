import { configured, isAuthenticated, json } from "./_auth.mjs";

export default async (request) =>
  json({ configured: configured(), authenticated: isAuthenticated(request) });

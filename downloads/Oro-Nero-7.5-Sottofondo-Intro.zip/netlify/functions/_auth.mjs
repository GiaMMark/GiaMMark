import crypto from "node:crypto";

const COOKIE_NAME = "oronero_admin";

export function configured() {
  return (
    typeof process.env.ORONERO_ADMIN_PASSWORD === "string" &&
    process.env.ORONERO_ADMIN_PASSWORD.length >= 10 &&
    typeof process.env.ORONERO_SESSION_SECRET === "string" &&
    process.env.ORONERO_SESSION_SECRET.length >= 32
  );
}

function signature(value) {
  return crypto
    .createHmac("sha256", process.env.ORONERO_SESSION_SECRET || "")
    .update(value)
    .digest("base64url");
}

function cookies(headers) {
  const raw = headers.get("cookie") || "";
  return Object.fromEntries(
    raw.split(";").map((part) => {
      const index = part.indexOf("=");
      if (index < 0) return [part.trim(), ""];
      const key = part.slice(0, index).trim();
      const value = part.slice(index + 1);
      try {
        return [key, decodeURIComponent(value)];
      } catch {
        return [key, value];
      }
    }),
  );
}

export function createToken() {
  const expiry = String(Date.now() + 8 * 60 * 60 * 1000);
  return `${expiry}.${signature(expiry)}`;
}

export function isAuthenticated(request) {
  if (!configured()) return false;
  const token = cookies(request.headers)[COOKIE_NAME];
  if (!token) return false;
  const [expiry, supplied, extra] = token.split(".");
  if (!/^\d+$/.test(expiry || "") || !supplied || extra !== undefined || Number(expiry) <= Date.now()) return false;
  const expected = signature(expiry);
  const left = Buffer.from(supplied);
  const right = Buffer.from(expected);
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

export function passwordMatches(candidate) {
  if (!configured() || typeof candidate !== "string") return false;
  const left = crypto.createHash("sha256").update(candidate).digest();
  const right = crypto
    .createHash("sha256")
    .update(process.env.ORONERO_ADMIN_PASSWORD)
    .digest();
  return crypto.timingSafeEqual(left, right);
}

export function sessionCookie(token) {
  return `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`;
}

export function expiredCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...headers,
    },
  });
}

import crypto from "node:crypto";
import { getStore } from "@netlify/blobs";
import { isAuthenticated, json } from "./_auth.mjs";

const MAX_BYTES = 1024 * 1024;
const types = { jpg: "image/jpeg", png: "image/png", webp: "image/webp", avif: "image/avif" };

function imageFormat(bytes) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "jpg";
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "png";
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "webp";
  if (bytes.length >= 16 && bytes.toString("ascii", 4, 8) === "ftyp" && /avif|avis/.test(bytes.toString("ascii", 8, Math.min(bytes.length, 32)))) return "avif";
  return "";
}

export function createDishImageHandler(storeFactory = getStore) {
  return async (request) => {
    if (request.method === "GET") {
      const id = new URL(request.url).searchParams.get("id") || "";
      if (!/^[a-f0-9]{64}\.(?:jpg|png|webp|avif)$/.test(id)) return json({ error: "Foto non trovata" }, 404);
      try {
        const data = await storeFactory("oronero-dish-images").get(id, { type: "arrayBuffer" });
        if (!data) return json({ error: "Foto non trovata" }, 404);
        return new Response(data, { headers: {
          "content-type": types[id.split(".").at(-1)],
          "cache-control": "public, max-age=31536000, immutable",
          "x-content-type-options": "nosniff",
          "content-security-policy": "default-src 'none'",
        } });
      } catch { return json({ error: "Foto momentaneamente non disponibile" }, 503); }
    }
    if (request.method !== "POST") return json({ error: "Metodo non consentito" }, 405, { allow: "GET, POST" });
    if (!isAuthenticated(request)) return json({ error: "Accesso non autorizzato" }, 401);
    if (Number(request.headers.get("content-length")) > MAX_BYTES) return json({ error: "La foto deve essere inferiore a 1 MB" }, 413);
    const bytes = Buffer.from(await request.arrayBuffer());
    if (!bytes.length || bytes.length > MAX_BYTES) return json({ error: "La foto deve essere inferiore a 1 MB" }, 413);
    const format = imageFormat(bytes);
    const contentType = (request.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!format || contentType !== types[format]) return json({ error: "Usa una fotografia JPEG, PNG, WebP o AVIF valida" }, 415);
    const id = `${crypto.createHash("sha256").update(bytes).digest("hex")}.${format}`;
    try {
      await storeFactory("oronero-dish-images").set(id, bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
      return json({ image: `/api/images/${id}` }, 201);
    } catch { return json({ error: "Caricamento non disponibile. Verifica il deploy Netlify e riprova." }, 503); }
  };
}

export default createDishImageHandler();

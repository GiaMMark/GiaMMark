import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

export const ADMIN_COOKIE = "oronero_admin";
const SESSION_DURATION_SECONDS = 60 * 60 * 12;

function digest(value: string) {
  return createHmac("sha256", "oronero-password-compare").update(value).digest();
}

export function safeEqual(left: string, right: string) {
  return timingSafeEqual(digest(left), digest(right));
}

export function getAdminConfiguration() {
  const password = process.env.ORONERO_ADMIN_PASSWORD?.trim() || "";
  const secret = process.env.ORONERO_SESSION_SECRET?.trim() || "";
  return {
    configured: password.length >= 10 && secret.length >= 32,
    password,
    secret,
  };
}

export function createSessionToken(secret: string, now = Date.now()) {
  const payload = Buffer.from(
    JSON.stringify({
      exp: Math.floor(now / 1000) + SESSION_DURATION_SECONDS,
      nonce: randomBytes(12).toString("hex"),
    }),
  ).toString("base64url");
  const signature = createHmac("sha256", secret).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

export function verifySessionToken(token: string, secret: string, now = Date.now()) {
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return false;
  const expected = createHmac("sha256", secret).update(payload).digest("base64url");
  if (!safeEqual(signature, expected)) return false;

  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as {
      exp?: number;
    };
    return typeof data.exp === "number" && data.exp > Math.floor(now / 1000);
  } catch {
    return false;
  }
}

export function getCookie(request: Request, name: string) {
  const cookieHeader = request.headers.get("cookie") || "";
  for (const part of cookieHeader.split(";")) {
    const [key, ...valueParts] = part.trim().split("=");
    if (key === name) return decodeURIComponent(valueParts.join("="));
  }
  return "";
}

export function isAdminRequest(request: Request) {
  const config = getAdminConfiguration();
  if (!config.configured) return false;
  const token = getCookie(request, ADMIN_COOKIE);
  return Boolean(token && verifySessionToken(token, config.secret));
}

export function isSameOrigin(request: Request) {
  const fetchSite = request.headers.get("sec-fetch-site");
  if (fetchSite === "cross-site") return false;
  const origin = request.headers.get("origin");
  if (!origin) return true;
  return origin === new URL(request.url).origin;
}

export function sessionCookie(token: string) {
  return `${ADMIN_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_DURATION_SECONDS}`;
}

export function clearSessionCookie() {
  return `${ADMIN_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

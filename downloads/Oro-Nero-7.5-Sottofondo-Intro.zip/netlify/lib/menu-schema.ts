import type { Dish, MenuCategory, MenuData } from "../../lib/menu";

const MAX_CATEGORIES = 20;
const MAX_DISHES = 200;

function text(value: unknown, field: string, maxLength: number, optional = false) {
  if (optional && (value === undefined || value === null || value === "")) return "";
  if (typeof value !== "string") throw new Error(`${field}: valore non valido`);
  const clean = value.trim().replace(/\s+/g, " ");
  if (!clean && !optional) throw new Error(`${field}: campo obbligatorio`);
  if (clean.length > maxLength) throw new Error(`${field}: massimo ${maxLength} caratteri`);
  return clean;
}

function id(value: unknown, field: string) {
  const clean = text(value, field, 64).toLocaleLowerCase("it");
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(clean)) {
    throw new Error(`${field}: identificativo non valido`);
  }
  return clean;
}

function order(value: unknown, fallback: number) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.min(9999, Math.round(number))) : fallback;
}

function parseCategory(value: unknown, index: number): MenuCategory {
  if (!value || typeof value !== "object") throw new Error("Categoria non valida");
  const category = value as Record<string, unknown>;
  return {
    id: id(category.id, "Categoria"),
    label: text(category.label, "Nome categoria", 60),
    visible: category.visible !== false,
    order: order(category.order, index + 1),
  };
}

function parseDish(value: unknown, index: number, categoryIds: Set<string>): Dish {
  if (!value || typeof value !== "object") throw new Error("Piatto non valido");
  const dish = value as Record<string, unknown>;
  const category = id(dish.category, "Categoria del piatto");
  if (!categoryIds.has(category)) throw new Error("Il piatto usa una categoria inesistente");

  let price: number | null = null;
  if (dish.price !== null && dish.price !== "" && dish.price !== undefined) {
    price = Number(dish.price);
    if (!Number.isFinite(price) || price < 0 || price > 10000) {
      throw new Error("Prezzo non valido");
    }
    price = Math.round(price * 100) / 100;
  }

  return {
    id: id(dish.id, "Piatto"),
    name: text(dish.name, "Nome piatto", 120),
    description: text(dish.description, "Descrizione", 600, true),
    category,
    label: text(dish.label, "Etichetta", 80, true),
    pairing: text(dish.pairing, "Abbinamento", 240, true),
    allergens: text(dish.allergens, "Allergeni", 80, true) || undefined,
    price,
    priceNote: text(dish.priceNote, "Nota prezzo", 80, true) || undefined,
    available: dish.available !== false,
    order: order(dish.order, index + 1),
  };
}

export function normalizeMenu(value: unknown): MenuData {
  if (!value || typeof value !== "object") throw new Error("Menu non valido");
  const raw = value as Record<string, unknown>;
  if (!Array.isArray(raw.categories) || raw.categories.length < 1 || raw.categories.length > MAX_CATEGORIES) {
    throw new Error(`Il menu deve contenere da 1 a ${MAX_CATEGORIES} categorie`);
  }
  if (!Array.isArray(raw.dishes) || raw.dishes.length > MAX_DISHES) {
    throw new Error(`Il menu può contenere al massimo ${MAX_DISHES} piatti`);
  }

  const categories = raw.categories.map(parseCategory);
  const categoryIds = new Set(categories.map((category) => category.id));
  if (categoryIds.size !== categories.length) throw new Error("Le categorie devono avere identificativi univoci");

  const dishes = raw.dishes.map((dish, index) => parseDish(dish, index, categoryIds));
  const dishIds = new Set(dishes.map((dish) => dish.id));
  if (dishIds.size !== dishes.length) throw new Error("I piatti devono avere identificativi univoci");

  return {
    restaurantName: text(raw.restaurantName, "Nome ristorante", 120) || "Oro Nero Experience Bistrot",
    currency: "EUR",
    updatedAt: new Date().toISOString(),
    categories,
    dishes,
  };
}

import { cp, mkdir, rm, writeFile, readFile, readdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import QRCode from "qrcode";
import { defaultMenu } from "../netlify/functions/menu-default.mjs";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const source = join(root, "site");
const output = join(root, "dist");

await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
await cp(source, output, { recursive: true });
await writeFile(
  join(output, "assets", "default-menu.json"),
  JSON.stringify(defaultMenu, null, 2),
  "utf8",
);
const publicBase = (process.env.URL || "https://oronero.netlify.app").replace(/\/$/, "");
// Keep canonical URLs, social cards, sitemap and printed QR host on the deployed domain.
const publicUrl = new URL(publicBase);
if (!["https:", "http:"].includes(publicUrl.protocol)) throw new Error("URL deve essere un indirizzo HTTP(S)");
async function updatePublicUrls(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) await updatePublicUrls(path);
    else if (/\.(html|xml|txt)$/.test(entry.name)) {
      const content = await readFile(path, "utf8");
      let result = content.replaceAll("https://oronero.netlify.app", publicBase);
      if (path === join(output, "qr", "index.html")) result = result.replace("<strong>oronero.netlify.app</strong>", `<strong>${publicUrl.host}</strong>`);
      if (result !== content) await writeFile(path, result, "utf8");
    }
  }
}
await updatePublicUrls(output);
const qrSvg = await QRCode.toString(`${publicBase}/menu/`, {
  type: "svg",
  errorCorrectionLevel: "H",
  margin: 2,
  color: { dark: "#090b0a", light: "#ffffff" },
});
await writeFile(join(output, "assets", "menu-qr.svg"), qrSvg, "utf8");

console.log(`Oro Nero pronto in ${output}`);

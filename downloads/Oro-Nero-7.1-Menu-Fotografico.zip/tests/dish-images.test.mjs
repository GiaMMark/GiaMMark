import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { JSDOM } from "jsdom";
import { dishImage, imageUrl, validImageFields } from "../site/assets/dish-images.js";
import { defaultMenu } from "../netlify/functions/menu-default.mjs";
import { createDishImageHandler } from "../netlify/functions/dish-image.mjs";
import menuHandler from "../netlify/functions/menu.mjs";
import { createToken } from "../netlify/functions/_auth.mjs";

let moduleId = 0;
const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
function configure() {
  process.env.ORONERO_ADMIN_PASSWORD = "test-password-not-a-real-account";
  process.env.ORONERO_SESSION_SECRET = "test-only-session-secret-at-least-thirty-two-characters";
  return { cookie: `oronero_admin=${createToken()}` };
}
async function page(route) {
  const html = await readFile(new URL(`../site/${route}/index.html`, import.meta.url), "utf8");
  const dom = new JSDOM(html, { url: `https://oronero.test/${route}/`, pretendToBeVisual: true });
  globalThis.window = dom.window;
  globalThis.document = dom.window.document;
  globalThis.location = dom.window.location;
  globalThis.CustomEvent = dom.window.CustomEvent;
  dom.window.confirm = () => true;
  return dom;
}
async function ready(selector) {
  for (let attempt = 0; attempt < 100 && !document.querySelector(selector); attempt += 1) await wait(5);
  assert.ok(document.querySelector(selector), `${selector} deve essere disponibile`);
}

test("gli URL delle immagini accettano HTTPS e asset locali, rifiutando schemi e percorsi pericolosi", () => {
  for (const url of ["https://example.test/food.jpg", "/assets/images/crudo-mare-1.webp", "assets/images/piatto.webp"]) assert.ok(imageUrl(url));
  for (const url of ["javascript:alert(1)", "data:image/svg+xml,test", "//example.test/photo.jpg", "http://example.test/photo.jpg", "https://user:secret@example.test/photo.jpg", "/assets/images/../private.jpg", "/assets/images/%2e%2e/private.jpg", "https://example.test/a\n.jpg"]) assert.equal(imageUrl(url), "");
  assert.equal(validImageFields({ image: "", imageAlt: "" }), true);
  assert.equal(validImageFields({ imageAlt: "a".repeat(241) }), false);
  assert.equal(dishImage({ id: "crudo-oronero", name: "Il crudo" }).image, "/assets/images/crudo-mare-1.webp");
  assert.equal(dishImage({ id: "crudo-oronero", image: "", name: "Il crudo" }).image, "", "La rimozione esplicita non deve ripristinare la foto iniziale");
});

test("il caricamento autenticato conserva la foto separata e la restituisce con tipo e cache corretti", async () => {
  const headers = configure();
  const blobs = new Map();
  const handler = createDishImageHandler(() => ({
    set: async (id, bytes) => { blobs.set(id, bytes); },
    get: async (id) => blobs.get(id) ?? null,
  }));
  const bytes = Buffer.from("UklGRhQAAABXRUJQVlA4IAgAAAAQAAAAAA==", "base64");
  const upload = await handler(new Request("https://oronero.test/api/admin/image", { method: "POST", headers: { ...headers, "content-type": "image/webp" }, body: bytes }));
  assert.equal(upload.status, 201);
  const { image } = await upload.json();
  assert.match(image, /^\/api\/images\/[a-f0-9]{64}\.webp$/);
  assert.ok(imageUrl(image));
  assert.equal(blobs.size, 1);
  const id = image.split("/").at(-1);
  const download = await handler(new Request(`https://oronero.test/.netlify/functions/dish-image?id=${id}`));
  assert.equal(download.status, 200);
  assert.equal(download.headers.get("content-type"), "image/webp");
  assert.match(download.headers.get("cache-control"), /immutable/);
  assert.deepEqual(Buffer.from(await download.arrayBuffer()), bytes);
  const missing = await handler(new Request(`https://oronero.test/.netlify/functions/dish-image?id=${"b".repeat(64)}.webp`));
  assert.equal(missing.status, 404);
});

test("upload non autorizzati, SVG, MIME falso e foto troppo grandi non entrano nello storage", async () => {
  let stored = 0;
  const handler = createDishImageHandler(() => ({ set: async () => { stored += 1; } }));
  const noAuth = await handler(new Request("https://oronero.test/api/admin/image", { method: "POST", body: "test" }));
  assert.equal(noAuth.status, 401);
  const headers = configure();
  for (const [type, body] of [["image/svg+xml", "<svg onload='alert(1)'/>"], ["image/jpeg", "not an image"], ["image/jpeg", Buffer.from("RIFF0000WEBP", "ascii")]]) {
    const response = await handler(new Request("https://oronero.test/api/admin/image", { method: "POST", headers: { ...headers, "content-type": type }, body }));
    assert.equal(response.status, 415);
  }
  const large = await handler(new Request("https://oronero.test/api/admin/image", { method: "POST", headers: { ...headers, "content-type": "image/jpeg" }, body: new Uint8Array(1024 * 1024 + 1) }));
  assert.equal(large.status, 413);
  assert.equal(stored, 0);
  const invalidPath = await handler(new Request("https://oronero.test/.netlify/functions/dish-image?id=../../secret"));
  assert.equal(invalidPath.status, 404);
});

test("il salvataggio menu rifiuta immagini non sicure prima di accedere a Blobs", async () => {
  const headers = configure();
  for (const field of [{ image: "javascript:alert(1)" }, { image: "data:image/png;base64,eA==" }, { image: "/private/file.png" }, { imageAlt: "a".repeat(241) }]) {
    const menu = structuredClone(defaultMenu);
    Object.assign(menu.categories[0].items[0], field);
    const result = await menuHandler(new Request("https://oronero.test/api/menu", { method: "PUT", headers: { ...headers, "content-type": "application/json" }, body: JSON.stringify(menu) }));
    assert.equal(result.status, 400);
  }
});

test("ogni piatto ha una scheda visiva, la foto reale apre il dettaglio e una foto rotta torna al segnaposto", async () => {
  const dom = await page("menu");
  globalThis.fetch = async () => Response.json(defaultMenu);
  try {
    await import(`../site/assets/menu.js?dish-photo-test=${++moduleId}`);
    await ready(".dish-card");
    const count = defaultMenu.categories.reduce((sum, category) => sum + category.items.filter((item) => item.visible).length, 0);
    assert.equal(document.querySelectorAll(".dish-card").length, count);
    assert.equal(document.querySelectorAll(".dish-visual").length, count);
    assert.equal(document.querySelectorAll(".dish-photo").length, 1);
    assert.equal(document.querySelectorAll(".dish-placeholder").length, count - 1);
    assert.equal(document.querySelectorAll("button.dish-placeholder").length, 0);
    const photo = document.querySelector(".dish-photo");
    photo.click();
    const dialog = document.querySelector("#dish-photo-dialog");
    assert.equal(dialog.open, true);
    assert.match(dialog.querySelector("img").src, /crudo-mare-1.webp$/);
    assert.match(dialog.querySelector("figcaption").textContent, /crudo di pesce/);
    dialog.querySelector(".dish-photo-close").click();
    assert.equal(dialog.open, false);
    assert.equal(document.activeElement, photo);
    photo.querySelector("img").dispatchEvent(new dom.window.Event("error"));
    assert.equal(document.querySelectorAll(".dish-photo").length, 0);
    assert.equal(document.querySelectorAll(".dish-placeholder").length, count);
    assert.ok(document.querySelector("[data-pairing]"), "Gli abbinamenti devono restare disponibili");
  } finally { dom.window.close(); }
});

test("l’editor conserva URL e descrizione della foto nel menu salvato e permette la rimozione", async () => {
  const dom = await page("admin");
  let saved;
  globalThis.fetch = async (url, options = {}) => {
    if (String(url).endsWith("/api/admin/session")) return Response.json({ configured: true, authenticated: true });
    if (options.method === "PUT") { saved = JSON.parse(options.body); return Response.json({ ...saved, version: saved.version + 1 }); }
    return Response.json(structuredClone(defaultMenu));
  };
  try {
    await import(`../site/assets/admin.js?dish-photo-test=${++moduleId}`);
    await ready(".admin-image-editor");
    const row = document.querySelector('[data-kind="menu"]');
    const set = (field, value) => { const input = row.querySelector(`[data-field="${field}"]`); input.value = value; input.dispatchEvent(new dom.window.Event("input", { bubbles: true })); };
    set("image", "https://images.example.test/pepata.webp");
    set("imageAlt", "Pepata di cozze del ristorante");
    document.querySelector("#save-menu").click();
    for (let attempt = 0; attempt < 30 && !saved; attempt += 1) await wait(5);
    assert.equal(saved.categories[0].items[0].image, "https://images.example.test/pepata.webp");
    assert.equal(saved.categories[0].items[0].imageAlt, "Pepata di cozze del ristorante");
    assert.equal(saved.categories.length, 13);
    assert.equal(saved.categories[0].items[0].price, defaultMenu.categories[0].items[0].price);
    for (let attempt = 0; attempt < 30 && document.querySelector("#save-menu").disabled; attempt += 1) await wait(5);
    row.querySelector("[data-remove-image]").click();
    saved = null;
    document.querySelector("#save-menu").click();
    for (let attempt = 0; attempt < 30 && !saved; attempt += 1) await wait(5);
    assert.equal(saved.categories[0].items[0].image, "");
    assert.equal(row.querySelector(".admin-image-preview").textContent, "Foto in arrivo");
  } finally { dom.window.close(); }
});

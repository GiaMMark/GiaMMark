# Fotografie dei piatti · Oro Nero 7.1

Il menu ha uno spazio visivo per ogni voce. Per mostrare la fotografia di una portata, inserisci una foto che ritragga davvero quel piatto: una foto del crudo non viene utilizzata per rappresentare pasta, carne o dessert.

## Materiale già disponibile

Nel progetto ci sono otto immagini: tre viste del crudo di mare, due dessert, la sala, la copertina del menu e il logo. L’associazione iniziale certa è:

| Voce del menu | File |
| --- | --- |
| Il crudo di pesce dell’ORO NERO (`crudo-oronero`) | `site/assets/images/crudo-mare-1.webp` |

Le foto dei dessert sono mantenute nel sito, ma non sono associate automaticamente a una voce del menu: il nome del file non basta a confermare la ricetta rappresentata.

Le altre voci mostrano un segnaposto grafico coordinato con la dicitura “Foto in arrivo”. Il segnaposto non è una fotografia del piatto e viene sostituito quando viene aggiunta una foto reale. Per bevande generiche e coperto si può lasciare la grafica senza attribuire una fotografia a un prodotto diverso.

## Prepara il catalogo

Apri `foto-piatti.csv` con Excel, Numbers o un altro foglio di calcolo. Contiene tutte le **80 voci** del menu, comprese bevande e coperto:

- `categoria`: sezione del menu;
- `id`: identificativo stabile della voce;
- `nome`: nome mostrato agli ospiti;
- `file_suggerito`: nome consigliato per organizzare le immagini;
- `foto_attuale`: associazione fotografica confermata nel progetto iniziale.

Per esempio, la foto degli scrigni può essere nominata `scrigni-scampi.webp`. Il nome aiuta a organizzarsi: dall’admin la foto viene associata alla voce selezionata, senza dover rinominare tutti i file.

## Scatta foto coerenti

- Fotografa il piatto completo, con luce naturale laterale e un’inquadratura pulita.
- Mantieni un po’ di spazio attorno al piatto: le anteprime devono adattarsi a telefono e desktop.
- Usa uno stile coerente per tavolo, luce e angolazione; evita scritte o prezzi dentro la fotografia.
- Una foto orizzontale o quasi quadrata, di almeno 1200 pixel sul lato lungo, è una buona base.
- Controlla che ingredienti, porzione e presentazione corrispondano a ciò che viene servito.

## Aggiungi la foto al menu

Apri `/admin/` sul sito Netlify configurato e accedi. Nella sezione Menu, trova il piatto e usa i controlli della fotografia nella sua scheda:

1. **Caricamento dal dispositivo:** scegli una foto JPEG, PNG, WebP o AVIF. Il browser ridimensiona l’immagine a un massimo di 960 pixel sul lato lungo e la prepara in WebP per alleggerire il menu. Il caricamento finale non deve superare 1 MiB.
2. **Indirizzo della foto:** in alternativa, inserisci un URL HTTPS o il percorso di un file già incluso nel sito, come `/assets/images/scrigni-scampi.webp`.
3. Controlla l’anteprima e aggiungi il testo alternativo.
4. Premi **Salva e pubblica**: il solo caricamento della foto non completa l’associazione pubblica alla voce.

Le foto caricate vengono archiviate separatamente dal menu in Netlify Blobs. Per rimuovere un’associazione, svuota il campo della foto e salva il menu: la scheda torna al segnaposto “Foto in arrivo”.

Inserisci anche il testo alternativo: una descrizione breve della portata nella foto, ad esempio “Scrigni agli scampi con carbonara di mare su piatto scuro”. Evita formule generiche come “foto” o descrizioni di ingredienti che non compaiono nell’immagine.

Salva le modifiche del menu, poi apri `/menu/` e controlla la scheda del piatto e l’ingrandimento. La breve cache del menu può richiedere una ricarica dopo il salvataggio.

La pubblicazione statica della sola cartella `dist/` non esegue le funzioni di caricamento o salvataggio. Per le immagini gestite dall’admin occorre il deploy completo Netlify descritto in `README_NETLIFY.md`.

## Foto incluse nei sorgenti

Se preferisci gestire il sito da Git, aggiungi le fotografie in `site/assets/images/` e associa a ogni voce del menu il suo percorso pubblico, per esempio `/assets/images/scrigni-scampi.webp`. Non utilizzare un percorso del tuo computer come `C:\\Foto\\piatto.jpg`: il browser degli ospiti non può accedervi.

Prima del deploy, esegui la build per includere i nuovi file in `dist/`. Le fotografie aggiunte nel pannello amministrativo e quelle incluse nei sorgenti sono due flussi diversi: non occorre usare entrambi per lo stesso piatto.

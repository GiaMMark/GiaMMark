# Oro Nero 7.1.0 · Verifica della consegna

## Cosa è stato perfezionato

- Ingresso scenografico della homepage, coordinato con l’identità Laguna Nocturne.
- Schede del menu con spazio fotografico per ogni voce, anteprima e ingrandimento delle fotografie disponibili.
- Caricamento delle foto dal dispositivo nel pannello amministrativo, ottimizzazione WebP, anteprima, testo alternativo e associazione tramite **Salva e pubblica**.
- Possibilità alternativa di associare un URL HTTPS o un’immagine già inclusa nel sito.
- Segnaposti grafici dichiarati come “Foto in arrivo” per le voci senza una fotografia corrispondente.
- Ricerca, filtri, prezzi, allergeni, carta vini, prenotazione, QR e funzioni amministrative mantenuti.

## Stato delle fotografie

L’utente ha scelto di usare **fotografie reali**. Nel catalogo iniziale, su 80 voci, è disponibile una sola associazione fotografica certa: il crudo Oro Nero (`crudo-oronero`) con `crudo-mare-1.webp`.

Le altre **79 voci** mostrano un segnaposto. Non sono state attribuite fotografie di altre portate né generate immagini che possano essere scambiate per foto reali dei piatti. Il catalogo fotografico non è completo: servono le fotografie corrispondenti alle altre voci per sostituire i segnaposti.

`FOTO_PIATTI.md` spiega come inserirle; `foto-piatti.csv` elenca tutte le 80 voci e i nomi dei file suggeriti.

## Verifiche eseguite

- Build e controllo dei contenuti riusciti: 13 categorie e 80 voci.
- Confronto con il progetto originale: nomi, prezzi, allergeni e ordine delle voci invariati.
- Suite automatica con **30 test superati in 7 file**, eseguita con **Node.js 22.23.4**.
- Browser Chromium verificato a **320, 390, 768, 1024 e 1440 pixel**.
- Controllati ingresso, salto dell’animazione, riproduzione successiva, sessione e gestione del focus.
- Controllate la foto del crudo, i 79 segnaposti, ricerca, filtro vegetariano e finestre di ingrandimento.
- Nessun errore JavaScript o scorrimento orizzontale rilevato nelle schermate verificate.

### Ingresso

L’ingresso si chiude automaticamente dopo circa **3,4 secondi**, viene mostrato alla prima apertura della homepage nella sessione ed è saltabile. Può essere riprodotto nuovamente dal relativo controllo e rispetta la preferenza di movimento ridotto.

Il menu aperto direttamente, anche tramite QR, non impone l’attesa dell’animazione.

### Caricamento delle immagini

Il flusso è stato provato in un browser reale, con ridimensionamento mediante canvas e conversione in WebP. Il file ottenuto nel caso verificato pesava **77.182 byte**.

Sono stati controllati il caricamento, l’anteprima, il salvataggio esplicito della modifica e la visualizzazione dell’immagine nel menu pubblico usando servizi di archiviazione e salvataggio simulati. I 6 test dedicati alle immagini verificano anche l’handler binario con archiviazione in memoria.

Queste verifiche non costituiscono una prova di caricamento su Netlify Blobs remoto: la persistenza reale richiede il deploy completo e la configurazione amministrativa indicata nei README.

## Deploy e consegna

Non è stato effettuato alcun deploy del sito su Netlify. Le richieste di prenotazione non sono state inviate al ristorante.

La cartella `dist/` contiene la build statica. Per autenticazione, caricamento delle foto e salvataggi amministrativi, segui `README_NETLIFY.md` ed esegui un deploy completo Netlify. Prima di stampare il QR, genera la build sul dominio definitivo e controllane la destinazione.

La presenza degli archivi su GitHub rende scaricabili i file; non pubblica automaticamente il sito su Netlify.

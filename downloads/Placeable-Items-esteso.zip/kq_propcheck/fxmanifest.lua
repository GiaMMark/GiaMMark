fx_version 'cerulean'
game 'gta5'
description 'Controllo facoltativo dei modelli configurati in KQ Placeable Items'
dependency 'kq_placeable_items'
client_scripts {
    '@kq_placeable_items/config.lua',
    'client.lua',
}

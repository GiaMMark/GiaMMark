-- Diagnostica facoltativa: non crea oggetti e non cambia la configurazione.
RegisterCommand('kqcheckprops', function()
    CreateThread(function()
        local models = {}
        local function record(model, reference)
            models[model] = models[model] or {}
            models[model][#models[model] + 1] = reference
        end
        record(Config.makeEverythingPlaceable.fallbackProp, 'fallback')
        for itemName, data in pairs(Config.items) do
            for size, model in pairs(data.sizes or {}) do
                record(model, itemName .. ' x' .. tostring(size))
            end
        end

        local ordered = {}
        for model in pairs(models) do ordered[#ordered + 1] = model end
        table.sort(ordered, function(a, b) return tostring(a) < tostring(b) end)
        local missing = 0
        for index, model in ipairs(ordered) do
            local hash = type(model) == 'number' and model or GetHashKey(model)
            if not IsModelInCdimage(hash) or not IsModelValid(hash) then
                missing = missing + 1
                table.sort(models[model])
                print(('[KQ PROPCHECK] NON DISPONIBILE: %s | %s'):format(tostring(model), table.concat(models[model], ', ')))
            end
            if index % 25 == 0 then Wait(0) end
        end
        print(('[KQ PROPCHECK] %d modelli unici, %d non disponibili.'):format(#ordered, missing))
        print('[KQ PROPCHECK] La presenza del modello non verifica collisioni, rotazione o raccolta: provarli in gioco.')
    end)
end, false)

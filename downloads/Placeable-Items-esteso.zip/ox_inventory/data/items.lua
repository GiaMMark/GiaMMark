local items = {
  
 ['rtx-9c'] = {
		label = 'Trx-9c',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},
    	["computer"] = {
		label = "Computer fisso",
		weight = 3000,
		stack = false,
		close = true,
		consume = 0,
		description = "Un computer fisso che puoi trasportare e posizionare.",
		client = { export = "electus_computers.UseLaptopItem" },
	},
	["tv"] = {
		label = "Televisore",
		weight = 4000,
		stack = false,
		close = true,
		consume = 0,
		description = "Un televisore che puoi trasportare e montare a parete.",
		client = { export = "electus_computers.UseTvItem" },
	},
	["router"] = {
		label = "Router Wi-Fi",
		weight = 250,
		stack = false,
		close = true,
		consume = 0,
		description = "Posizionalo per condividere una rete Wi-Fi con i computer vicini.",
		client = { event = "electus_computers:useRouter" },
	},
	["usb"] = {
		label = "Chiavetta USB da 10 GB",
		weight = 50,
		stack = false,
		close = true,
		description = "Chiavetta USB con 10 GB di memoria. Inseriscila nella porta USB di un computer.",
	},
	["usb_4gb"] = {
		label = "Chiavetta USB da 4 GB",
		weight = 50,
		stack = false,
		close = true,
		description = "Chiavetta USB con 4 GB di memoria. Inseriscila nella porta USB di un computer.",
	},
	["usb_antenna"] = {
		label = "Antenna USB piccola",
		weight = 50,
		stack = false,
		close = true,
		description = "Una piccola antenna USB per intercettare i segnali nelle vicinanze.",
	},
	["usb_antenna_long"] = {
		label = "Antenna USB a lungo raggio",
		weight = 100,
		stack = false,
		close = true,
		description = "Un’antenna USB a lungo raggio per intercettare segnali più lontani.",
	},
	["sim_card"] = {
		label = "Scheda SIM",
		weight = 5,
		stack = false,
		close = true,
		description = "Inseriscila in un computer per utilizzare Internet tramite rete mobile.",
	},
	["usb_cable_short"] = {
		label = "Cavo USB corto",
		weight = 25,
		stack = false,
		close = true,
		description = "Un cavo da 2 metri per collegare computer e stampanti.",
	},
	["usb_cable"] = {
		label = "Cavo USB",
		weight = 50,
		stack = false,
		close = true,
		description = "Un cavo da 5 metri per collegare computer e stampanti.",
	},
	["usb_cable_long"] = {
		label = "Cavo USB lungo",
		weight = 75,
		stack = false,
		close = true,
		description = "Un cavo da 10 metri per collegare computer e stampanti.",
	},
	["card_terminal"] = {
		label = "Terminale di pagamento",
		weight = 200,
		stack = false,
		close = true,
		consume = 0,
		description = "Posizionalo su un bancone e collegalo a un computer con un cavo USB per accettare pagamenti tramite l’app Business.",
		client = { export = "electus_computers.UseCardTerminal" },
	},
	-- DOCUMENT
	["printer"] = {
		label = "Stampante",
		weight = 2000,
		stack = false,
		close = true,
		consume = 0,
		description = "Posizionala accanto a un computer e collegala con un cavo USB per stampare documenti.",
		client = { export = "electus_computers.UsePrinter" },
	},
	["printed_document"] = {
		label = "Documento stampato",
		weight = 5,
		stack = false,
		close = true,
		consume = 0,
		description = "Una copia cartacea di una versione specifica di un documento.",
		client = { export = "electus_computers.UsePrintedDocument" },
	},
	-- LAPTOP
	["laptop"] = {
		label = "Computer portatile",
		weight = 1250,
		stack = false,
		close = true,
		consume = 0,
		description = "Un computer portatile per lavorare e divertirsi.",
		client = { export = "electus_computers.UseLaptopItem" },
	},
	["laptop_space_black"] = {
		label = "Computer portatile - Nero siderale",
		weight = 1250,
		stack = false,
		close = true,
		consume = 0,
		description = "Un computer portatile con finitura nero siderale.",
		client = { export = "electus_computers.UseLaptopItem" },
	},
	["laptop_midnight_blue"] = {
		label = "Computer portatile - Blu notte",
		weight = 1250,
		stack = false,
		close = true,
		consume = 0,
		description = "Un computer portatile con finitura blu notte.",
		client = { export = "electus_computers.UseLaptopItem" },
	},
	["laptop_soft_pink"] = {
		label = "Computer portatile - Rosa tenue",
		weight = 1250,
		stack = false,
		close = true,
		consume = 0,
		description = "Un computer portatile con finitura rosa tenue.",
		client = { export = "electus_computers.UseLaptopItem" },
	},
	["laptop_sand_gold"] = {
		label = "Computer portatile - Oro sabbia",
		weight = 1250,
		stack = false,
		close = true,
		consume = 0,
		description = "Un computer portatile con finitura oro sabbia.",
		client = { export = "electus_computers.UseLaptopItem" },
	},
	-- LAPTOP PART
	["laptop_battery"] = {
		label = "Batteria per portatile",
		weight = 175,
		stack = true,
		close = true,
		description = "Una batteria standard per portatile. Un tecnico può installarla al banco riparazioni.",
	},
	["laptop_battery_extended"] = {
		label = "Batteria maggiorata per portatile",
		weight = 225,
		stack = true,
		close = true,
		description = "Una batteria ad alta capacità che raddoppia l’autonomia del portatile.",
	},
	["laptop_cpu"] = {
		label = "Processore dual-core per portatile",
		weight = 75,
		stack = true,
		close = true,
		description = "Un processore sostitutivo per computer portatile.",
	},
	["laptop_cpu_quad"] = {
		label = "Processore quad-core per portatile",
		weight = 75,
		stack = true,
		close = true,
		description = "Un processore più veloce che aumenta il tempo disponibile nei programmi di hacking.",
	},
	["laptop_cpu_octa"] = {
		label = "Processore octa-core per portatile",
		weight = 75,
		stack = true,
		close = true,
		description = "Il processore più veloce, che offre il massimo tempo nei programmi di hacking.",
	},
	["laptop_fan"] = {
		label = "Ventola per portatile",
		weight = 40,
		stack = true,
		close = true,
		description = "Una ventola di raffreddamento sostitutiva per computer portatile.",
	},
	["laptop_fan_copper"] = {
		label = "Dissipatore in rame per portatile",
		weight = 60,
		stack = true,
		close = true,
		description = "Un dissipatore in rame che dimezza l’usura del processore.",
	},
	["laptop_ssd"] = {
		label = "SSD per portatile da 50 GB",
		weight = 15,
		stack = true,
		close = true,
		description = "Un’unità di archiviazione sostitutiva per computer portatile.",
	},
	["laptop_ssd_512"] = {
		label = "SSD per portatile da 120 GB",
		weight = 15,
		stack = true,
		close = true,
		description = "Un’unità di archiviazione più capiente per installare più applicazioni.",
	},
	["laptop_ssd_1tb"] = {
		label = "SSD per portatile da 250 GB",
		weight = 15,
		stack = true,
		close = true,
		description = "L’unità di archiviazione più capiente per computer portatile.",
	},
	["laptop_wifi_card"] = {
		label = "Scheda Wi-Fi per portatile",
		weight = 10,
		stack = true,
		close = true,
		description = "Una scheda Wi-Fi sostitutiva per computer portatile.",
	},
	["laptop_wifi_card_long"] = {
		label = "Scheda Wi-Fi a lungo raggio",
		weight = 13,
		stack = true,
		close = true,
		description = "Una scheda Wi-Fi che raggiunge i router più lontani.",
	},
	["laptop_screen"] = {
		label = "Schermo per portatile",
		weight = 200,
		stack = true,
		close = true,
		description = "Uno schermo sostitutivo per computer portatile.",
	},
	["laptop_security_chip"] = {
		label = "Chip di sicurezza rinforzato",
		weight = 8,
		stack = true,
		close = true,
		description = "Blocca prima i tentativi di indovinare la password e rallenta i programmi di reimpostazione delle password.",
	},
-- Copia questi item DENTRO la tabella in ox_inventory/data/items.lua
['condom'] = {
    label = 'Preservativo',
    weight = 10,
    stack = true,
    close = true,
},
['carrello'] = {
    label = 'Carrello della spesa',
    weight = 100, -- peso dell'item nel proprio inventario (grammi)
    stack = false,
    close = true,
    consume = 0,   -- NON consumare l'item quando si usa
    description = 'Carrello pieghevole con magazzino personale',
    client = {
        export = 'mobile_cart_fivem.useCart'
    }
},
['vehicle_tire'] = { label = 'Gomme', weight = 600, stack = true, close = false, description = 'Pneumatici recuperati da un veicolo' },
['vehicle_door'] = { label = 'Portiere', weight = 1200, stack = true, close = false, description = 'Portiere recuperate da un veicolo' },
['vehicle_sheet_metal'] = { label = 'Lamiere', weight = 500, stack = true, close = false, description = 'Lamiere recuperate da un veicolo' },
['vehicle_nylon'] = { label = 'Pezzi di nylon', weight = 150, stack = true, close = false, description = 'Nylon riciclato da veicoli' },
['vehicle_plastic'] = { label = 'Pezzi di plastica', weight = 150, stack = true, close = false, description = 'Plastica riciclata da veicoli' },
['vehicle_carbon'] = { label = 'Pezzi di carbonio', weight = 150, stack = true, close = false, description = 'Fibra di carbonio recuperata' },
['filament_nylon'] = { label = 'Filamento nylon', weight = 200, stack = true, close = false, description = 'Filamento per stampante 3D' },
['filament_plastic'] = { label = 'Filamento plastica', weight = 200, stack = true, close = false, description = 'Filamento per stampante 3D' },
['filament_carbon'] = { label = 'Filamento carbonio', weight = 200, stack = true, close = false, description = 'Filamento per stampante 3D' },

['car_rottame'] = {
    label = 'Muscle Car Rottame',
    weight = 1000,
    stack = false,
    close = true,
    consume = 0,
    description = 'Veicolo ricostruito al banco di lavoro. Usalo per registrare la macchina nel garage.',
    client = {
        export = 'muscle_rebuild.useCarToken'
    }
},

['trash_glass_bottle'] = {
    label = 'Bottiglia di vetro vuota',
    description = 'Una bottiglia trovata nella spazzatura. Recuperabile come materiale.',
    weight = 180,
    stack = true,
    close = true,
},

['trash_rags'] = {
    label = 'Stracci',
    description = 'Pezzi di stoffa recuperabili per riciclo e lavori manuali.',
    weight = 120,
    stack = true,
    close = true,
},

['trash_food_leftovers'] = {
    label = 'Avanzi di cibo',
    description = 'Resti di un pasto. Ripristina solo l\'1% circa della fame.',
    weight = 180,
    stack = true,
    close = true,
    consume = 1,
  
},

['trash_bottle_dregs'] = {
    label = 'Scoli di bottiglia',
    description = 'Un goccio avanzato, recupera appena lo 0,8% circa di sete.',
    weight = 150,
    stack = true,
    close = true,
    consume = 1,
  
},

['trash_dead_rat'] = {
    label = 'Topo morto',
    description = 'Un topo morto. Oggetto RP, non e\' un consumabile.',
    weight = 250,
    stack = true,
    close = true,
},


['testpack'] = {
    label = 'Test di gravidanza',
    weight = 50,
    stack = true,
    close = true,
},
['levonorgestrel'] = {
    label = 'Pillola del giorno dopo',
    weight = 10,
    stack = true,
    close = true,
},
['mifepristone'] = {
    label = 'Mifepristone',
    weight = 10,
    stack = true,
    close = true,
},
['viagra'] = {
    label = 'Viagra',
    weight = 10,
    stack = true,
    close = true,
},

     ['trx-9'] = {
		label = 'Trx-9',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},

     ['synapticore'] = {
		label = 'Synapticore',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},
 ['synapticore-c'] = {
		label = 'Synapticore-c',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},

     ['nova_vita'] = {
		label = 'Nova Vita',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},




    ['vehicle_manual'] = {
    label = 'Manuale del veicolo',
    weight = 15,
    close = true,
    consume = 0,
    client = {},
    server = {
        export = 'rcore_fuel.vehicle_manual',
    },
},
['metaldetector'] = {
    label = 'Metal detector',
    weight = 200,
    stack = false,
    durability =  0.04,
    buttons = {
        {
            label = 'Usa metal detector',
            action = function(slot)
                local canUse = lib.callback.await('bbs_metalDetecting:useDetector', false, slot)

                if not canUse then
                    return
                end

                exports.ox_inventory:closeInventory()
                exports['bbs_metalDetecting']:startDetecting()
            end
        },
        {
            label = 'Metti via il rilevatore.',
            action = function(slot)
                exports.ox_inventory:closeInventory()
                exports['bbs_metalDetecting']:stopDetecting()
            end
        },
    },
},
['recycler'] = {
    label = 'Riciclatore',
    weight = 15,
    buttons = {
        {
            label = 'Posizionare il riciclatore a terra.',
            action = function(slot)
                exports.ox_inventory:closeInventory()
                exports['bbs_recycler']:placeRecycler()
            end
        },
    },
},

['nanospytablet'] = {
    label = 'Tablet Spia Nano',
    weight = 3,
    stack = false,
    close = true,
    description = 'Tablet di sorveglianza avanzato per monitorare i dispositivi spia'
},

['nanospymic'] = {
    label = 'Microfono Spia Nano',
    weight = 1,
    stack = true,
    close = true,
    description = 'Microfono di sorveglianza nascosto per il monitoraggio audio'
},

['nanospycam'] = {
    label = 'Telecamera Spia Nano',
    weight = 1,
    stack = true,
    close = true,
    description = 'Telecamera spia nascosta per la sorveglianza visiva'
},

['nanospygps'] = {
    label = 'Localizzatore GPS Spia Nano',
    weight = 1,
    stack = true,
    close = true,
    description = 'Dispositivo di localizzazione GPS per il monitoraggio dei veicoli'
},

['digiscanner'] = {
    label = 'Scanner Digitale',
    weight = 1,
    stack = true,
    close = true,
    description = 'Scanner professionale in grado di rilevare dispositivi spia nelle vicinanze tramite le loro firme elettromagnetiche'
},

['sg_plush_tophat'] = {
    label = 'Peluche Gatto con Cilindro',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un gatto viola da sala giochi con un piccolo cilindro.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_tophat.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_cap'] = {
    label = 'Peluche Gatto con Cappellino',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un gatto verde da sala giochi con un piccolo cappellino blu.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_cap.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_bowtie'] = {
    label = 'Peluche Gatto con Papillon',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un gatto blu da sala giochi con un elegante papillon nero.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_bowtie.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_tuft'] = {
    label = 'Peluche Gatto con Ciuffo',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un gatto marrone da sala giochi con un buffo ciuffo di capelli.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_tuft.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_beanie'] = {
    label = 'Peluche Cane con Berretto',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un cane color crema da sala giochi con un berretto a righe.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_beanie.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_hoodie'] = {
    label = 'Peluche Gatto con Felpa',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un gatto rosso da sala giochi avvolto in una felpa blu scuro.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_hoodie.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_hero'] = {
    label = 'Peluche Eroina Anime',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un eroina dei cartoni dai capelli rosa, appena vinta alla macchina dei peluche.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_hero.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_plush_ninja'] = {
    label = 'Peluche Ragazza Ninja',
    weight = 10,
    stack = true,
    close = true,
    description = 'Una ninja dei cartoni dai capelli verdi, appena vinta alla macchina dei peluche.',
    client = { image = 'nui://0r-socialgame/items/images/sg_plush_ninja.png' },
    server = { export = '0r-socialgame.usePlushItem' },
},

['sg_frisbee'] = {
    label = 'Frisbee',
    weight = 10,
    stack = false,
    close = true,
    description = 'Un disco volante. Lancialo e tornerà indietro, a meno che non colpisca qualcosa.',
    client = { image = 'nui://0r-socialgame/items/images/sg_frisbee.png' },
    server = { export = '0r-socialgame.useFrisbeeItem' },
},

['window_cleaner'] = {
    label = 'Detergente per vetri',
    weight = 10,
    close = true,
    consume = 0,
    client = {},
    server = {
        export = 'rcore_fuel.window_cleaner',
    },
},

['fuel_pump'] = {
    label = 'Pompa carburante',
    weight = 10,
    close = true,
    consume = 0,
    client = {},
    server = {
        export = 'rcore_fuel.fuel_pump',
    },
},
['panno_graffiti'] = {
    label = 'Panno per graffiti',
    weight = 10,
    stack = true,
    close = true,
    description = 'Panno riutilizzabile per rimuovere i graffiti.',
    client = {
        export = 'oxlyn-graffiti.useCleaningCloth'
    }
},

['cocaine'] = {
    label = 'Cocaina',
    weight = 10,
    stack = true,
    close = true,
    description = 'Una confezione di cocaina',
    client = {
        export = 'moro_cocaine.use_cocaine'
    }
},

['cocaine_tray'] = {
    label = 'Vassoio di cocaina',
    weight = 5,
    stack = false,
    close = true,
    description = 'Un vassoio di cocaina — 4 utilizzi',
    consume = 0,
    client = { export = 'moro_cocaine.use_cocaine_tray' }
},

['cocaine_tube'] = {
    label = 'Cannuccia per cocaina',
    weight = 10,
    stack = false,
    close = true,
    description = 'Una cannuccia preparata con cocaina — 4 utilizzi',
    consume = 0,
    client = { export = 'moro_cocaine.use_cocaine_tube' }
},

['cocaine_table'] = {
    label = 'Cocaina sul tavolo',
    weight = 10,
    stack = false,
    close = true,
    description = 'Cocaina preparata su una superficie — 4 utilizzi',
    consume = 0,
    client = { export = 'moro_cocaine.use_cocaine_table' }
},

['table'] = {
    label = 'Tavolo',
    weight = 30,
    stack = true,
    close = true,
    description = 'Un tavolo posizionabile',
    consume = 0,
    client = { export = 'moro_cocaine.use_table' }
},

['cooking_pot'] = {
    label = 'Pentola da cucina',
    weight = 10,
    stack = false,
    close = true,
    description = 'Necessaria per la lavorazione; non viene consumata'
},

['portable_stove'] = {
    label = 'Fornello portatile',
    weight = 200,
    stack = false,
    close = true,
    description = 'Posizionalo per lavorare la sostanza e usa il target sul fornello.',
    consume = 0,
    client = { export = 'moro_cooking.portable_stove' }
},

['crack'] = {
    label = 'Crack',
    weight = 1,
    stack = true,
    close = true,
    description = 'Cocaina lavorata',
    consume = 0,
    client = { export = 'moro_cooking.use_crack' }
},

['cooked_cocaine'] = {
    label = 'Cocaina cotta',
    weight = 1,
    stack = true,
    close = true,
    description = 'Prodotto finito legacy'
},

['moro_tray'] = {
    label = 'Vassoio per rollare',
    weight = 10,
    stack = false,
    close = false,
    description = 'Un vassoio usato per preparare i joint.'
},

['moro_mixeur'] = {
    label = 'Grinder',
    weight = 1,
    stack = false,
    close = false,
    description = 'Un grinder per tritare la Kush.'
},

['rolling_paper1'] = {
    label = 'Cartina lunghe',
    weight = 1,
    stack = true,
    close = true,
},
['rolling_paper'] = {
    label = 'Cartina',
    weight = 1,
    stack = true,
    close = true,
    description = 'Una cartina per iniziare la preparazione del joint.',
    client = { export = 'moro_weed_v2.useMoroRollingPaper' }
},

['og_kush'] = {
    label = 'OG Kush',
    weight = 10,
    stack = true,
    close = false,
    description = 'OG Kush pronta per essere tritata e rollata.'
},

['purple_kush'] = {
    label = 'Purple Kush',
    weight = 10,
    stack = true,
    close = false,
    description = 'Purple Kush pronta per essere tritata e rollata.'
},

['candy_kush'] = {
    label = 'Candy Kush',
    weight = 10,
    stack = true,
    close = false,
    description = 'Candy Kush pronta per essere tritata e rollata.'
},
['weed_og_kush'] = {
    label = 'OG Kush',
    weight = 5,
    stack = true,
    close = true,
    description = 'Varietà classica e potente con un aroma terroso.'
},

['weed_purple_haze'] = {
    label = 'Purple Haze',
    weight = 5,
    stack = true,
    close = true,
    description = 'Varietà dolce e aromatica con un fumo morbido.'
},

['weed_amnesia_haze'] = {
    label = 'Amnesia Haze',
    weight = 5,
    stack = true,
    close = true,
    description = 'Varietà ricca di note agrumate con un effetto intenso.'
},

['weed_white_widow'] = {
    label = 'White Widow',
    weight = 5,
    stack = true,
    close = true,
    description = 'Ibrido equilibrato con un fumo denso.'
},

['joint_og_kush'] = {
    label = 'Canna OG Kush',
    weight = 2,
    stack = true,
    close = true,
    description = 'Canna rollata con OG Kush.'
},

['joint_purple_haze'] = {
    label = 'Canna Purple Haze',
    weight = 2,
    stack = true,
    close = true,
    description = 'Canna rollata con Purple Haze.'
},

['joint_amnesia_haze'] = {
    label = 'Canna Amnesia Haze',
    weight = 2,
    stack = true,
    close = true,
    description = 'Canna rollata con Amnesia Haze.'
},

['joint_white_widow'] = {
    label = 'Canna White Widow',
    weight = 2,
    stack = true,
    close = true,
    description = 'Canna rollata con White Widow.'
},
['moro_joint_done'] = {
    label = 'Joint OG Kush',
    weight = 3,
    stack = true,
    close = true,
    description = 'Un joint di OG Kush pronto da fumare.',
    client = { export = 'moro_weed_v2.useMoroJoint' }
},

['moro_joint_done_r'] = {
    label = 'Joint Candy Kush',
    weight = 3,
    stack = true,
    close = true,
    description = 'Un joint di Candy Kush pronto da fumare.',
    client = { export = 'moro_weed_v2.useMoroJoint_r' }
},

['moro_joint_done_p'] = {
    label = 'Joint Purple Kush',
    weight = 3,
    stack = true,
    close = true,
    description = 'Un joint di Purple Kush pronto da fumare.',
    client = { export = 'moro_weed_v2.useMoroJoint_p' }
},

['graffiti'] = {
    label = 'Bomboletta spray',
    weight = 10,
    stack = true,
    close = true,
    description = 'Permette di realizzare graffiti su muri, oggetti e veicoli.',
    client = {
        export = 'oxlyn-graffiti.useItem'
    }
},

['housekey'] = {
    label = 'Chiave di casa',
    weight = 0.15,
    stack = false,
    close = true,
    consume = false,
    description = 'La chiave della tua casa, non perderla.',
    server = {
        export = 'qs-housing.useHouseKey'
    },
    consume = 0
},

["weed_white-widow"] = {
    label = "Erba White Widow",
    weight = 1,
    stack = false,
},

["weed_skunk"] = {
    label = "Erba Skunk",
    weight = 1,
    stack = false,
},

["weed_purple-haze"] = {
    label = "Erba Purple Haze",
    weight = 1,
    stack = false,
},

["weed_og-kush"] = {
    label = "Erba OG Kush",
    weight = 1,
    stack = false,
},

["weed_amnesia"] = {
    label = "Erba Amnesia",
    weight = 1,
    stack = false,
},

["weed_ak47"] = {
    label = "Erba AK47",
    weight = 1,
    stack = false,
},

["weed_white-widow_seed"] = {
    label = "Seme di White Widow",
    weight = 1,
    stack = false,
},

["weed_skunk_seed"] = {
    label = "Seme di Skunk",
    weight = 1,
    stack = false,
},

["weed_purple-haze_seed"] = {
    label = "Seme di Purple Haze",
    weight = 1,
    stack = false,
},

["weed_og-kush_seed"] = {
    label = "Seme di OG Kush",
    weight = 1,
    stack = false,
},

["weed_amnesia_seed"] = {
    label = "Seme di Amnesia",
    weight = 1,
    stack = false,
},

["weed_ak47_seed"] = {
    label = "Seme di AK47",
    weight = 1,
    stack = false,
},

["empty_weed_bag"] = {
    label = "Bustina vuota",
    weight = 1,
    stack = true,
},

["weed_nutrition"] = {
    label = "Fertilizzante per cannabis",
    weight = 15,
    stack = false,
},

["police_stormram"] = {
    label = "Ariete della polizia",
    weight = 10,
    stack = false,
},

-- Cucina opzionale
["sausage"] = {
    label = "Salsiccia",
    weight = 10,
    stack = true,
},

["pasta"] = {
    label = "Pasta",
    weight = 5,
    stack = true,
},

["chicken"] = {
    label = "Pollo",
    weight = 5,
    stack = true,
},

["spices"] = {
    label = "Spezie",
    weight = 5,
    stack = true,
},

["wine"] = {
    label = "Vino",
    weight = 5,
    stack = true,
},

["lettuce"] = {
    label = "Lattuga",
    weight = 5,
    stack = true,
},

["egg"] = {
    label = "Uovo",
    weight = 5,
    stack = true,
},

["potato"] = {
    label = "Patata",
    weight = 5,
    stack = true,
},

["toast"] = {
    label = "Toast",
    weight = 1,
    stack = true,
},

["sandwich"] = {
    label = "Panino",
    weight = 1,
    stack = true,
},

["burger"] = {
    label = "Cheeseburger",
    weight = 20,
    stack = true,
},

["pasta_plate"] = {
    label = "Piatto di pasta",
    weight = 20,
    stack = true,
},

["pizza"] = {
    label = "Pizza",
    weight = 20,
    stack = true,
},

["chicken_meal"] = {
    label = "Piatto di pollo",
    weight = 20,
    stack = true,
},

["luxury_dinner"] = {
    label = "Cena di lusso",
    weight = 20,
    stack = false,
},

["salad"] = {
    label = "Insalata",
    weight = 20,
    stack = true,
},

["omelette"] = {
    label = "Frittata",
    weight = 20,
    stack = true,
},

["fish_chips"] = {
    label = "Pesce e patatine",
    weight = 20,
    stack = true,
},

["goverment_bodycam"] = {
        label = "Bodycam governativa",
        weight = 1,
        stack = false,
        close = true,
        server = { export = 'bbs_bodycam.GovermentCam' }, consume = 0, allowArmed = true,
    },

    ["commercial_bodycam"] = {
        label = "Bodycam commerciale",
        weight = 1,
        stack = false,
        close = true,
        server = { export = 'bbs_bodycam.CommercialCam' }, consume = 0, allowArmed = true,
    },
    ['illegal_tablet'] = { label = 'Tablet illegale', weight = 10, stack = false },
['powdered_milk'] = { label = 'Latte in polvere', weight = 10, stack = true },
['money_sheet'] = { label = 'Foglio di denaro', weight = 10, stack = true },
['plant_spray'] = { label = 'Spruzzino per piante', weight = 10, stack = true },
['sacid'] = { label = 'Acido', weight = 10, stack = true },
['atm_hack_device'] = { label = 'Dispositivo di hacking ATM', weight = 10, stack = true },
['blank_card'] = { label = 'Carta vuota', weight = 10, stack = true },
['moonshine_still'] = { label = 'Distillatore di Moonshine', weight = 10, stack = true },
['moonshine_pack'] = { label = 'Confezione di Moonshine', weight = 10, stack = true },
['stolen_bag'] = { label = 'Borsa rubata', weight = 10, stack = true },
['scrapmetal'] = { label = 'Rottame di metallo', weight = 10, stack = true },
['plastic'] = { label = 'Plastica', weight = 10, stack = true },
['glass'] = { label = 'Vetro', weight = 10, stack = true },
['copperwire'] = { label = 'Cavo di rame', weight = 10, stack = true },
['painkiller'] = { label = 'Antidolorifico', weight = 10, stack = true },
['adrenaline'] = { label = 'Adrenalina', weight = 10, stack = true },
['unpacked_coke'] = { label = 'Coca non confezionata', weight = 10, stack = true },
['cutted_coke'] = { label = 'Coca tagliata', weight = 10, stack = true },
['packed_coke'] = { label = 'Coca confezionata', weight = 10, stack = true },
['uncutted_money'] = { label = 'Denaro non tagliato', weight = 10, stack = true },
['cutted_money'] = { label = 'Denaro tagliato', weight = 10, stack = true },
['fake_credit_card'] = { label = 'Carta di credito falsa', weight = 10, stack = true },
['cooked_meth'] = { label = 'Metanfetamina cotta', weight = 10, stack = true },
['breaked_meth'] = { label = 'Metanfetamina frantumata', weight = 10, stack = true },
['packed_meth'] = { label = 'Metanfetamina confezionata', weight = 10, stack = true },
['old_corn'] = { label = 'Mais vecchio', weight = 10, stack = true },
['old_fruit'] = { label = 'Frutta vecchia', weight = 10, stack = true },
['tap_water'] = { label = 'Acqua di rubinetto', weight = 10, stack = true },
['crushed_ingredients'] = { label = 'Ingredienti schiacciati', weight = 10, stack = true },
['blended_ingredients'] = { label = 'Ingredienti frullati', weight = 10, stack = true },
['moonshine'] = { label = 'Moonshine', weight = 10, stack = true },
['unpacked_weed'] = { label = 'Erba non confezionata', weight = 10, stack = true },
['packed_weed'] = { label = 'Erba confezionata', weight = 10, stack = true },
['rolled_weed'] = { label = 'Erba rollata', weight = 10, stack = true },
--- # end 0r-illegalpack
    ['token_auto'] = {
        label = 'Token Auto BIT',
        weight = 0,
        stack = true
    },

    ['token_fullkit'] = {
        label = 'FullKit Auto BIT',
        weight = 0,
        stack = true
    },

    ['token_tattoo'] = {
        label = 'Token Tatuaggio Custom',
        weight = 0,
        stack = true
    },

--==============================================================--
----- DOLCI, CARAMELLE E SNACK -----
----- TOTALE: 54 ITEM -----
--==============================================================--

['berry_pie'] = {
        label = 'Torta ai Frutti di Bosco',
        weight = 30,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['berry_pie_slice'] = {
        label = 'Fetta di Crostata ai Frutti',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cake_chocolate'] = {
        label = 'Torta al Cioccolato',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cake_chocolate2'] = {
        label = 'Torta al Cioccolato 2',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cake_strawberry'] = {
        label = 'Torta alle Fragole',
        weight = 320,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['candy_bucket'] = {
        label = 'Cestino di Dolcetti',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['candy_corn'] = {
        label = 'Candy Corn',
        weight = 12,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['churros_1'] = {
        label = 'Churros',
        weight = 85,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['churros_2'] = {
        label = 'Churros Ciotola',
        weight = 220,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['eye_gummy'] = {
        label = 'Caramella Occhio',
        weight = 14,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['floss_blue'] = {
        label = 'Zucchero Filato Blu',
        weight = 40,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['floss_pink'] = {
        label = 'Zucchero Filato Rosa',
        weight = 42,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['floss_purple'] = {
        label = 'Zucchero Filato Viola',
        weight = 44,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['floss_rainbow'] = {
        label = 'Zucchero Filato Arcobaleno',
        weight = 46,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_cranberry_pie'] = {
        label = 'Torta di Mirtilli Rossi',
        weight = 345,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_plated_cranberry_pie'] = {
        label = 'Piatto Torta ai Mirtilli Rossi',
        weight = 380,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_cupcake_green'] = {
        label = 'Cupcake Verde',
        weight = 108,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_cupcake_red'] = {
        label = 'Cupcake Rosso',
        weight = 108,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_fruit_stick_1'] = {
        label = 'Spiedino di Frutta 1',
        weight = 112,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_fruit_stick_2'] = {
        label = 'Spiedino di Frutta 2',
        weight = 112,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_macaroon'] = {
        label = 'Macaron',
        weight = 42,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_mini_trifle'] = {
        label = 'Mini Zuppa Inglese',
        weight = 138,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_nougat_green'] = {
        label = 'Torrone Verde',
        weight = 82,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_nougat_orange'] = {
        label = 'Torrone Arancione',
        weight = 82,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_nougat_pink'] = {
        label = 'Torrone Rosa',
        weight = 82,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_nougat_red'] = {
        label = 'Torrone Rosso',
        weight = 82,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_nougat_yellow'] = {
        label = 'Torrone Giallo',
        weight = 82,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_sberry_santa'] = {
        label = 'Babbo Natale alla Fragola',
        weight = 92,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_tree_cookie'] = {
        label = 'Biscotto ad Albero',
        weight = 58,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['ghost_cookie_blue'] = {
        label = 'Biscotto Fantasma Blu',
        weight = 48,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['ghost_cookie_green'] = {
        label = 'Biscotto Fantasma Verde',
        weight = 48,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['ghost_cookie_pink'] = {
        label = 'Biscotto Fantasma Rosa',
        weight = 48,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['heartcandy'] = {
        label = 'Caramella a Cuore',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mochi_bear'] = {
        label = 'Mochi Orsetto',
        weight = 60,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mochi_duck'] = {
        label = 'Mochi Papera',
        weight = 61,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mochi_panda'] = {
        label = 'Mochi Panda',
        weight = 62,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mochi_pig'] = {
        label = 'Mochi Maialino',
        weight = 63,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },
['megaphone'] = {
    label = 'Megafono',
    weight = 30,
    consume = 0,
    client = {
        export = 'jraxion_megaphone.UseMegaphone',
    },
    stack = false,
},

['mochi_seal'] = {
        label = 'Mochi Foca',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mummy_macroon'] = {
        label = 'Macaron Mummia',
        weight = 49,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_chocolate'] = {
        label = 'Cake Pop al Cioccolato',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_darkpurple'] = {
        label = 'Cake Pop Viola Scuro',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_lightblue'] = {
        label = 'Cake Pop Azzurro',
        weight = 52,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_lightpink'] = {
        label = 'Cake Pop Rosa Chiaro',
        weight = 53,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_mummy'] = {
        label = 'Cake Pop Mummia',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_pumpkin'] = {
        label = 'Cake Pop Zucca',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_purple'] = {
        label = 'Cake Pop Viola',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_red'] = {
        label = 'Cake Pop Rosso',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pop_white'] = {
        label = 'Cake Pop Bianco',
        weight = 54,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pumpkin_cookie'] = {
        label = 'Biscotto Zucca',
        weight = 55,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['swissroll'] = {
        label = 'Rotolo Svizzero',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['tres_leches_cake'] = {
        label = 'Torta Tres Leches',
        weight = 295,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['vamp_donut'] = {
        label = 'Ciambella Vampiro',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['zombie_finger1'] = {
        label = 'Dito di Zombie',
        weight = 38,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['zombie_finger2'] = {
        label = 'Dito di Zombie 2',
        weight = 38,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- FAST FOOD, PANINI E FRITTI -----
----- TOTALE: 34 ITEM -----
--==============================================================--

['braai_broodjie'] = {
        label = 'Toast Braaibroodjie',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cheeseburger'] = {
        label = 'Cheeseburger',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['chicken_drumstick'] = {
        label = 'Fuso di Pollo',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['dino_nugget'] = {
        label = 'Crocchetta Dinosauro',
        weight = 35,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_chicken'] = {
        label = 'Pollo Fritto Croccante',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_chicken_box'] = {
        label = 'Box di Pollo',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_chicken_nuggets'] = {
        label = 'Crocchette di Pollo',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_coleslaw'] = {
        label = 'Insalata Coleslaw',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_coleslaw_meal'] = {
        label = 'Pasto con Coleslaw',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_crunch_box'] = {
        label = 'Box Burger Croccante',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_crunch_burger'] = {
        label = 'Burger Croccante',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_crunch_meal'] = {
        label = 'Pasto Burger Croccante',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_deluxe_box'] = {
        label = 'Box Burger Deluxe',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_deluxe_burger'] = {
        label = 'Burger Deluxe',
        weight = 280,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_deluxe_meal'] = {
        label = 'Pasto Burger Deluxe',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_dunked_wing'] = {
        label = 'Aletta di Pollo',
        weight = 80,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_dunked_wings_box'] = {
        label = 'Box Alette di Pollo',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_mash'] = {
        label = 'Purè di Patate',
        weight = 160,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_mash_meal'] = {
        label = 'Pasto con Purè',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_wrap'] = {
        label = 'Piadina di Pollo',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_bun'] = {
        label = 'Panino Morbido',
        weight = 95,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_bun_tree'] = {
        label = 'Panino ad Albero',
        weight = 95,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_mini_burgers'] = {
        label = 'Mini Burgers',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_mini_burgers_plank'] = {
        label = 'Tagliere Mini Burgers',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grilled_cheese'] = {
        label = 'Toast al Formaggio',
        weight = 148,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grilled_russian'] = {
        label = 'Salsiccia Russa Grigliata',
        weight = 185,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grilled_sausage'] = {
        label = 'Salsiccia Grigliata',
        weight = 188,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['hotdog'] = {
        label = 'Hotdog',
        weight = 240,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['meaty_footlong'] = {
        label = 'Panino Gigante',
        weight = 420,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mince_wrap'] = {
        label = 'Piadina con Macinato 1',
        weight = 220,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mince_wrap2'] = {
        label = 'Piadina con Macinato',
        weight = 225,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['mummy_sausage'] = {
        label = 'Salsiccia Mummia',
        weight = 105,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['spring_roll2'] = {
        label = 'Involtino Primavera',
        weight = 95,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['spring_rolls'] = {
        label = 'Involtini Primavera',
        weight = 95,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- PIZZE, CALZONI E FORNO -----
----- TOTALE: 17 ITEM -----
--==============================================================--

['fp7_pizza_man'] = {
        label = 'Omino di Pizza',
        weight = 170,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_pizza_man_plank'] = {
        label = 'Tagliere Omino di Pizza',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_pizza_sock'] = {
        label = 'Calza di Pizza',
        weight = 168,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_pizza_sock_plank'] = {
        label = 'Tagliere Calza di Pizza',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['hot_pockets'] = {
        label = 'Calzone Farcito',
        weight = 220,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_1'] = {
        label = 'Pizza Intera 1',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_2'] = {
        label = 'Pizza Intera 2',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_3'] = {
        label = 'Pizza Intera 3',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_4'] = {
        label = 'Pizza Intera 4',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_5'] = {
        label = 'Pizza Intera 5',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_6'] = {
        label = 'Pizza Intera 6',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_7'] = {
        label = 'Pizza Intera 7',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_8'] = {
        label = 'Pizza Intera 8',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_9'] = {
        label = 'Pizza Intera 9',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_roll'] = {
        label = 'Rotolo di Pizza',
        weight = 195,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pizza_slice'] = {
        label = 'Trancio di Pizza',
        weight = 125,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['whole_pizza'] = {
        label = 'Pizza Intera Standard',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- PIATTI, CONTORNI E CIBO VARIO -----
----- TOTALE: 30 ITEM -----
--==============================================================--

['cheesy_chips'] = {
        label = 'Patatine al Formaggio',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cheesy_noodles'] = {
        label = 'Noodles al Formaggio',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_asparagus'] = {
        label = 'Asparagi',
        weight = 70,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_baked_potato'] = {
        label = 'Patata al Forno',
        weight = 140,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_bowl_meatball'] = {
        label = 'Polpetta con Forchetta',
        weight = 45,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_bowl_meatballs'] = {
        label = 'Ciotola di Polpette',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_bowl_sprout'] = {
        label = 'Cavoletto di Bruxelles',
        weight = 33,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_bowl_sprouts'] = {
        label = 'Ciotola di Cavoletti',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_cane_bread'] = {
        label = 'Pane a Bastoncino',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_cane_bread_plank'] = {
        label = 'Tagliere Pane a Bastoncino',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_deviled_egg'] = {
        label = 'Uovo Ripieno',
        weight = 38,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_mushroom'] = {
        label = 'Fungo',
        weight = 28,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_mushroom_plank'] = {
        label = 'Tagliere Funghi',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_plated_asparagus'] = {
        label = 'Piatto di Asparagi',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_plated_baked_potato'] = {
        label = 'Piatto Patata al Forno',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_plated_deviled_egg'] = {
        label = 'Piatto Uova Ripiene',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_plated_sausage_pie'] = {
        label = 'Piatto Torta di Salsiccia',
        weight = 360,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp7_sausage_pie'] = {
        label = 'Torta di Salsiccia',
        weight = 325,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['garlic_bread'] = {
        label = 'Pane all\'Aglio',
        weight = 130,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['meaty_pie'] = {
        label = 'Torta di Carne',
        weight = 370,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['omelet'] = {
        label = 'Frittata Classica',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['omelet2'] = {
        label = 'Frittata',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['ramen_noodles'] = {
        label = 'Ramen',
        weight = 315,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['roasted_corn'] = {
        label = 'Pannocchia Arrosto',
        weight = 155,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['roasted_mushroom'] = {
        label = 'Fungo Arrosto',
        weight = 85,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['skewer_beef'] = {
        label = 'Spiedino di Manzo',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['skewer_cherry'] = {
        label = 'Spiedino di Ciliegie',
        weight = 105,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['skewer_chicken'] = {
        label = 'Spiedino di Pollo',
        weight = 165,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['soup'] = {
        label = 'Zuppa',
        weight = 360,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['steak'] = {
        label = 'Bistecca',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- SUSHI, PESCE E FRUTTI DI MARE -----
----- TOTALE: 24 ITEM -----
--==============================================================--

['fp3_avo_bite'] = {
        label = 'Bocconcino di Avocado',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_avo_nigiri'] = {
        label = 'Nigiri all\'Avocado',
        weight = 32,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_calamari_rings'] = {
        label = 'Anelli di Calamaro',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_dish_calamari'] = {
        label = 'Piatto di Calamari',
        weight = 385,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_dish_fish'] = {
        label = 'Piatto di Pesce Completo',
        weight = 380,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_dish_prawn'] = {
        label = 'Piatto di Gamberi Completo',
        weight = 380,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_fish'] = {
        label = 'Pesce',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_fish_cake'] = {
        label = 'Tortino di Pesce',
        weight = 135,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_fried_bite'] = {
        label = 'Bocconcino Fritto',
        weight = 26,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_fried_nigiri'] = {
        label = 'Nigiri Fritto',
        weight = 35,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_maki'] = {
        label = 'Maki',
        weight = 30,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_maki_bite'] = {
        label = 'Bocconcino Maki',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_nori_bite'] = {
        label = 'Bocconcino Nori',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_nori_nigiri'] = {
        label = 'Nigiri Nori',
        weight = 35,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_octopus_leg'] = {
        label = 'Tentacolo di Polpo',
        weight = 110,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_prawn_bite'] = {
        label = 'Bocconcino di Gambero',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_prawn_nigiri'] = {
        label = 'Nigiri di Gambero',
        weight = 35,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_red_fish_bite'] = {
        label = 'Bocconcino di Pesce Rosso',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_red_nigiri'] = {
        label = 'Nigiri Rosso',
        weight = 35,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_salmon_bite'] = {
        label = 'Bocconcino di Salmone',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_salmon_nigiri'] = {
        label = 'Nigiri al Salmone',
        weight = 34,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_shrimp'] = {
        label = 'Gamberetto',
        weight = 20,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_shrimp_bite'] = {
        label = 'Bocconcino di Gamberetto',
        weight = 25,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_sushi'] = {
        label = 'Piatto Sushi',
        weight = 380,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- CUCINA MESSICANA -----
----- TOTALE: 13 ITEM -----
--==============================================================--

['burrito_carnitas'] = {
        label = 'Burrito con Carnitas',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['burrito_chicken'] = {
        label = 'Burrito di Pollo',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['burrito_fish'] = {
        label = 'Burrito di Pesce',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['burrito_steak'] = {
        label = 'Burrito di Carne',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['nachos'] = {
        label = 'Nachos',
        weight = 165,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['quesadilla_carnitas'] = {
        label = 'Quesadilla Carnitas',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['quesadilla_chicken'] = {
        label = 'Quesadilla di Pollo',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['quesadilla_fish'] = {
        label = 'Quesadilla di Pesce',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['quesadilla_steak'] = {
        label = 'Quesadilla di Carne',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['taco_carnitas'] = {
        label = 'Taco Carnitas',
        weight = 160,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['taco_chicken'] = {
        label = 'Taco di Pollo',
        weight = 160,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['taco_fish'] = {
        label = 'Taco di Pesce',
        weight = 160,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['taco_steak'] = {
        label = 'Taco di Carne',
        weight = 160,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- BEVANDE ANALCOLICHE -----
----- TOTALE: 25 ITEM -----
--==============================================================--

['drink_banana'] = {
        label = 'Bibita alla Banana',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['drink_blueberry'] = {
        label = 'Bibita al Mirtillo',
        weight = 211,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['drink_cherry'] = {
        label = 'Bibita alla Ciliegia',
        weight = 212,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['drink_lime'] = {
        label = 'Bibita al Lime',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['drink_strawberry'] = {
        label = 'Bibita alla Fragola',
        weight = 213,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['foam_drink_blue'] = {
        label = 'Bibita Schiumosa Blu',
        weight = 230,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['foam_drink_green'] = {
        label = 'Bibita Schiumosa Verde',
        weight = 231,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['foam_drink_orange'] = {
        label = 'Bibita Schiumosa Arancione',
        weight = 232,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['foam_drink_pink'] = {
        label = 'Bibita Schiumosa Rosa',
        weight = 230,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['foam_drink_purple'] = {
        label = 'Bibita Schiumosa Viola',
        weight = 233,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['foam_drink_red'] = {
        label = 'Bibita Schiumosa Rossa',
        weight = 234,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_bowl_drink_blue'] = {
        label = 'Drink in Ciotola Blu',
        weight = 220,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_bowl_drink_green'] = {
        label = 'Drink in Ciotola Verde',
        weight = 220,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_drink_green'] = {
        label = 'Drink Verde',
        weight = 220,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_drink_red'] = {
        label = 'Drink Rosso',
        weight = 221,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp3_drink_yellow'] = {
        label = 'Drink Giallo',
        weight = 222,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['halloween_green_drink'] = {
        label = 'Bibita Verde di Halloween',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['halloween_orange_drink'] = {
        label = 'Bibita Arancione di Halloween',
        weight = 191,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['halloween_white_drink'] = {
        label = 'Bibita Bianca di Halloween',
        weight = 192,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['horchata'] = {
        label = 'Horchata',
        weight = 216,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['lemonade'] = {
        label = 'Limonata',
        weight = 214,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pretty_cherry'] = {
        label = 'Drink Pretty Cherry',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['pretty_peach'] = {
        label = 'Drink Pretty Peach',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['sberry_lemonade'] = {
        label = 'Limonata alla Fragola',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['spooky_drink'] = {
        label = 'Spooky Drink',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- CAFFETTERIA E BEVANDE CALDE -----
----- TOTALE: 13 ITEM -----
--==============================================================--

['bigcup2_espresso'] = {
        label = 'Espresso Grande 2',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bigcup2_hotchoc'] = {
        label = 'Cioccolata Calda Grande 2',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bigcup2_latte'] = {
        label = 'Latte Macchiato Grande 2',
        weight = 152,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bigcup_espresso'] = {
        label = 'Espresso Grande',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bigcup_hotchoc'] = {
        label = 'Cioccolata Calda Grande',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bigcup_latte'] = {
        label = 'Latte Macchiato Grande',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_hot_choc'] = {
        label = 'Cioccolata Calda Natalizia',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['smallcup2_espresso'] = {
        label = 'Espresso in Tazzina 2',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['smallcup2_hotchoc'] = {
        label = 'Cioccolata Calda in Tazzina 2',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['smallcup2_latte'] = {
        label = 'Latte Macchiato in Tazzina 2',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['smallcup_espresso'] = {
        label = 'Espresso in Tazzina',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['smallcup_hotchoc'] = {
        label = 'Cioccolata Calda in Tazzina',
        weight = 10,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['smallcup_latte'] = {
        label = 'Latte Macchiato in Tazzina',
        weight = 101,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- FRULLATI, MILKSHAKE ED ENERGY DRINK -----
----- TOTALE: 9 ITEM -----
--==============================================================--

['fp1_banana_krusher'] = {
        label = 'Frullato alla Banana',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_choc_krusher'] = {
        label = 'Frullato al Cioccolato',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_grape_krusher'] = {
        label = 'Frullato all\'Uva',
        weight = 252,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_oreo_krusher'] = {
        label = 'Frullato all\'Oreo',
        weight = 253,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp1_sberry_krusher'] = {
        label = 'Frullato alla Fragola',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_pink_milkshake'] = {
        label = 'Milkshake Rosa',
        weight = 240,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['metalx_blueberry'] = {
        label = 'Energy Drink al Mirtillo',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['metalx_lime'] = {
        label = 'Energy Drink al Lime',
        weight = 200,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['metalx_orange'] = {
        label = 'Energy Drink all\'Arancia',
        weight = 201,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- BIRRE - BICCHIERI -----
----- TOTALE: 5 ITEM -----
--==============================================================--

['bp1_beer_glass1'] = {
        label = 'Bicchiere di Birra 1',
        weight = 420,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_beer_glass2'] = {
        label = 'Bicchiere di Birra 2',
        weight = 421,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_beer_glass3'] = {
        label = 'Bicchiere di Birra 3',
        weight = 422,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_beer_glass4'] = {
        label = 'Bicchiere di Birra 4',
        weight = 420,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_beer_glass5'] = {
        label = 'Bicchiere di Birra 5',
        weight = 420,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- BIRRE - LATTINE -----
----- TOTALE: 10 ITEM -----
--==============================================================--

['bp1_can_belgian_ale'] = {
        label = 'Lattina di Belgian Ale',
        weight = 331,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_brown_ale'] = {
        label = 'Lattina di Brown Ale',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_german_bock'] = {
        label = 'Lattina di German Bock',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_ipa'] = {
        label = 'Lattina di IPA',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_pale_ale'] = {
        label = 'Lattina di Pale Ale',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_pilsner'] = {
        label = 'Lattina di Pilsner',
        weight = 332,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_porter'] = {
        label = 'Lattina di Porter',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_sour_ale'] = {
        label = 'Lattina di Sour Ale',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_stout'] = {
        label = 'Lattina di Stout',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_can_wheat'] = {
        label = 'Lattina di Wheat Beer',
        weight = 330,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- BIRRE - BOTTIGLIE -----
----- TOTALE: 10 ITEM -----
--==============================================================--

['bp1_bottle_belgian_ale'] = {
        label = 'Bottiglia di Belgian Ale',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_brown_ale'] = {
        label = 'Bottiglia di Brown Ale',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_german_bock'] = {
        label = 'Bottiglia di German Bock',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_ipa'] = {
        label = 'Bottiglia di Birra IPA',
        weight = 456,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_pale_ale'] = {
        label = 'Bottiglia di Pale Ale',
        weight = 457,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_pilsner'] = {
        label = 'Bottiglia di Pilsner',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_porter'] = {
        label = 'Bottiglia di Porter',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_sour_ale'] = {
        label = 'Bottiglia di Sour Ale',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_stout'] = {
        label = 'Bottiglia di Stout',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['bp1_bottle_wheat'] = {
        label = 'Bottiglia di Wheat Beer',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- COCKTAIL E APERITIVI -----
----- TOTALE: 46 ITEM -----
--==============================================================--

['cocktail_brown'] = {
        label = 'Cocktail Marrone',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_dred'] = {
        label = 'Cocktail Rosso Scuro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_green'] = {
        label = 'Cocktail Verde',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_lblue'] = {
        label = 'Cocktail Azzurro',
        weight = 273,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_orange'] = {
        label = 'Cocktail Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_pink'] = {
        label = 'Cocktail Rosa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_red'] = {
        label = 'Cocktail Rosso',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cocktail_yellow'] = {
        label = 'Cocktail Giallo',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_brown'] = {
        label = 'Collins Marrone',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_dred'] = {
        label = 'Collins Rosso Scuro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_green'] = {
        label = 'Collins Verde',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_lblue'] = {
        label = 'Collins Azzurro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_orange'] = {
        label = 'Collins Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_pink'] = {
        label = 'Collins Rosa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_red'] = {
        label = 'Collins Rosso',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['collins_yellow'] = {
        label = 'Collins Giallo',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_brown'] = {
        label = 'Coppa Marrone',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_dred'] = {
        label = 'Coppa Rossa Scura',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_green'] = {
        label = 'Coppa Verde',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_lblue'] = {
        label = 'Coppa Azzurra',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_orange'] = {
        label = 'Coppa Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_pink'] = {
        label = 'Coppa Rosa',
        weight = 271,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_red'] = {
        label = 'Coppa Rossa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['coupe_yellow'] = {
        label = 'Coppa Gialla',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_martini_green'] = {
        label = 'Martini Verde di Natale',
        weight = 280,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_martini_red'] = {
        label = 'Martini Rosso di Natale',
        weight = 280,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_sugar_cookie_martini'] = {
        label = 'Martini al Biscotto',
        weight = 282,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grapefruit_margarita'] = {
        label = 'Margarita al Pompelmo',
        weight = 260,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_brown'] = {
        label = 'Highball Marrone',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_dred'] = {
        label = 'Highball Rosso Scuro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_green'] = {
        label = 'Highball Verde',
        weight = 275,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_lblue'] = {
        label = 'Highball Azzurro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_orange'] = {
        label = 'Highball Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_pink'] = {
        label = 'Highball Rosa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_red'] = {
        label = 'Highball Rosso',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['highball_yellow'] = {
        label = 'Highball Giallo',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_brown'] = {
        label = 'Martini Marrone',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_dred'] = {
        label = 'Martini Rosso Scuro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_green'] = {
        label = 'Martini Verde',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_lblue'] = {
        label = 'Martini Azzurro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_orange'] = {
        label = 'Martini Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_pink'] = {
        label = 'Martini Rosa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_red'] = {
        label = 'Martini Rosso',
        weight = 274,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['martini_yellow'] = {
        label = 'Martini Giallo',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['peach_margarita'] = {
        label = 'Margarita alla Pesca',
        weight = 261,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['watermelon_margarita'] = {
        label = 'Margarita all\'Anguria',
        weight = 262,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

--==============================================================--
----- SUPERALCOLICI, LIQUORI E SHOT -----
----- TOTALE: 22 ITEM -----
--==============================================================--

['cognac_balloon_brown'] = {
        label = 'Cognac Marrone',
        weight = 272,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_dred'] = {
        label = 'Cognac Rosso Scuro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_green'] = {
        label = 'Cognac Verde',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_lblue'] = {
        label = 'Cognac Azzurro',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_orange'] = {
        label = 'Cognac Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_pink'] = {
        label = 'Cognac Rosa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_red'] = {
        label = 'Cognac Rosso',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['cognac_balloon_yellow'] = {
        label = 'Cognac Giallo',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_cranberry_shot'] = {
        label = 'Shot ai Mirtilli Rossi',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_jello_shot_green'] = {
        label = 'Cicchetto di Gelatina Verde',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_jello_shot_red'] = {
        label = 'Cicchetto di Gelatina Rossa',
        weight = 15,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_rum_pink'] = {
        label = 'Rum Rosa',
        weight = 281,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_rum_pink (2)'] = {
        label = 'Rum Rosa Doppio',
        weight = 281,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['fp8_rum_white'] = {
        label = 'Rum Bianco',
        weight = 281,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_brown'] = {
        label = 'Grappa Marrone',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_dred'] = {
        label = 'Grappa Rossa Scura',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_green'] = {
        label = 'Grappa Verde',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_lblue'] = {
        label = 'Grappa Azzurra',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_orange'] = {
        label = 'Grappa Arancione',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_pink'] = {
        label = 'Grappa Rosa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_red'] = {
        label = 'Grappa Rossa',
        weight = 270,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },

['grappa_yellow'] = {
        label = 'Grappa Gialla',
        weight = 276,
   
        
decay = true,
durability = 0.01,
        stack = true,
        close = true
    },


	['whiskey_glass'] = {
		label = 'Bicchiere da Whiskey',
		stack = false,
		close = true,
		client = {
			export = 'devcore_needs.useConsumeItem'
		}
	},
  ['volantino_lavoro'] = {
        label = 'Volantino Informativo',
        weight = 10,
        stack = false, -- False è meglio, così i foglietti di lavori diversi non si mischiano
        close = true,
        description = 'Un foglietto con le istruzioni di un lavoro.',
        client = {
            export = 'riverside_core.useVolantino' -- Questo collega l'uso dell'item al nostro client.lua
        }
    },
['rubber_tube'] = {
    label = 'Tubo di gomma',
    weight = 2,
    stack = true,
    close = true,
},
    

    ['fishing_rod_normal'] = {
        label = 'Canna da pesca sportiva',
        description = 'Livello 2',
        weight = 15,
        stack = false,
        client = { export = 'i_fishing.rod' },
    },

    ['fishing_rod_sport'] = {
        label = 'Canna da pesca sportiva',
        description = 'Livello 2',
        weight = 15,
        stack = false,
        client = { export = 'i_fishing.rod' },
    },

    ['fishing_rod_advanced'] = {
        label = 'Canna da pesca avanzata',
        description = 'Livello 3',
        weight = 15,
        stack = false,
        client = { export = 'i_fishing.rod' },
    },

    ['fishing_rod_super'] = {
        label = 'Super canna da pesca',
        description = 'Livello 3',
        weight = 15,
        stack = false,
        client = { export = 'i_fishing.rod' },
    },
['smodsk_heli_mission_key'] = {
	label = 'Chiave Elicottero',
	weight = 5,
},
['train_heist_medicine'] = {
	label = 'Medicinali',
	weight = 5,
},

['train_heist_biohazard'] = {
	label = 'Materiali a rischio biologico',
	weight = 5,
},

['train_heist_diamonds'] = {
	label = 'Diamanti',
	weight = 5,
},

['train_heist_art'] = {
	label = 'Opere d\'arte',
	weight = 5,
},

['train_heist_hacking_tool'] = {
	label = 'Strumento di hacking',
	weight = 5,
},

['train_heist_drill'] = {
	label = 'Trapano',
	weight = 5,
},
    -- PESCI (Gruppo base)
    ['fish1'] = { label = 'Trota', weight = 1, stack = false },
    ['fish2'] = { label = 'Orata', weight = 1, stack = false },
    ['fish3'] = { label = 'Certa', weight = 1, stack = false },
    ['fish4'] = { label = 'Maingano', weight = 1, stack = false },
    ['fish5'] = { label = 'Ciclide Octopus', weight = 1, stack = false },
    ['fish6'] = { label = 'Danio', weight = 1, stack = false },

    -- ESCHE
    ['redline_bait'] = { label = 'Esche Redline', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },
    ['corn_bait'] = { label = 'Esche al mais', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },
    ['crab_bait'] = { label = 'Esche al granchio', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },
    ['dot_bait'] = { label = 'Esche Dot', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },
    ['shrimp_bait'] = { label = 'Esche al gamberetto', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },
    ['black_mamba'] = { label = 'Esche Black Mamba', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },
    ['golden_fish_bait'] = { label = 'Esche pesce dorato', weight = 15, stack = true, client = { export = 'i_fishing.bait' } },

    -- ATTREZZATURA
    ['diving_gear'] = { label = 'Attrezzatura subacquea', weight = 15, stack = true, client = { export = 'i_fishing.divingGear' } },
    ['treasure_shovel'] = { label = 'Pala', weight = 15, stack = true, client = { export = 'i_fishing.shovel' } },
    ['lucky_hat'] = { label = 'Cappello fortunato', weight = 15, stack = true, client = { export = 'i_fishing.useClothingItemHappy' } },
    ['water_meter'] = { label = 'Misuratore livello mare', weight = 15, stack = true, client = { export = 'i_fishing.GetSeaLevel' } },
    ['dry_station'] = { label = 'Stazione di essiccazione', weight = 15, stack = true, client = { export = 'i_fishing.createStation' } },
['dummy'] = {
    label = 'Manichino',
    weight = 100,
    stack = true,
    close = true
},

['cone'] = {
    label = 'Coni',
    weight = 100,
    stack = true,
    close = true
},

['ramp'] = {
    label = 'Rampa',
    weight = 100,
    stack = true,
    close = true
},
 ["dummy"] = { label = "Manichino", weight = 100, stack = true, close = true, description = "Oggetto di prova per l'addestramento." },
    ["cone"] = { label = "Coni", weight = 100, stack = true, close = true, description = "Coni per l'addestramento del tuo animale." },
    ["ramp"] = { label = "Rampa", weight = 100, stack = true, close = true, description = "Rampa per l'addestramento del tuo animale." },
    ["hoop"] = { label = "Cerchio", weight = 100, stack = true, close = true, description = "Un ottimo gioco per gli animali, soprattutto per i cani. È semplice ed efficace per il riporto e per giocare in casa o all'aperto." },

-- Cibi e snack (9)
    ["petfood1"] = { label = "Cibo per cani al pollo", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per cani, ricco di nutrienti essenziali per la salute e il benessere." },
    ["petfood2"] = { label = "Cibo per cani alla bistecca Porterhouse", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per cani, ricco di nutrienti essenziali per la salute e il benessere." },
    ["petfood3"] = { label = "Cibo per cani al filetto mignon", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per cani, ricco di nutrienti essenziali per la salute e il benessere." },
    ["petfood4"] = { label = "Paté di pollame", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per gatti, ricco di nutrienti essenziali per la salute e il benessere." },
    ["petfood5"] = { label = "Paté Tasty Treasure", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per gatti, ricco di nutrienti essenziali per la salute e il benessere." },
    ["petfood6"] = { label = "Proactive Health", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per gatti, ricco di nutrienti essenziali per la salute e il benessere." },
    ["pettreat1"] = { label = "Biscotti al manzo e bacon", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per cani, ricco di nutrienti essenziali per la salute e il benessere." },
    ["pettreat2"] = { label = "Biscotti allo yogurt", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per cani, ricco di nutrienti essenziali per la salute e il benessere." },
    ["pettreat3"] = { label = "Biscotti al burro d'arachidi", weight = 100, stack = true, close = true, description = "Un pasto gustoso e nutriente per cani, ricco di nutrienti essenziali per la salute e il benessere." },

-- Bevande (1)
    ["cleanwater"] = { label = "Tanica d'acqua", weight = 100, stack = true, close = true, description = "Un'ottima scelta per mantenere gli animali idratati e in salute. È consigliabile usare acqua filtrata per proteggerli dalle sostanze nocive presenti nell'acqua del rubinetto." },

-- Cure veterinarie (3)
    ["petmedlow"] = { label = "Kit medico animale (effetto basso)", weight = 100, stack = true, close = true, description = "Il kit medico per animali (effetto basso) è un kit di primo soccorso compatto, adatto a piccoli infortuni e disturbi lievi." },
    ["petmedmed"] = { label = "Kit medico animale (effetto medio)", weight = 100, stack = true, close = true, description = "Il kit medico per animali (effetto medio) offre un supporto di primo soccorso completo per ferite moderate e problemi di salute di media entità." },
    ["petmedhigh"] = { label = "Kit medico animale (effetto alto)", weight = 100, stack = true, close = true, description = "Il kit medico per animali (effetto alto) è un kit di primo soccorso avanzato, pensato per ferite gravi e situazioni di emergenza." },

-- Cucce (51)
    ["bedbones"] = { label = "Cuccia - ossa", weight = 100, stack = true, close = true, description = "Cuccia - ossa. Accessorio per il tuo animale." },
    ["bedmaster"] = { label = "Cuccia - grande", weight = 100, stack = true, close = true, description = "Cuccia - grande. Accessorio per il tuo animale." },
    ["bedwood"] = { label = "Cuccia - Wooden", weight = 100, stack = true, close = true, description = "Cuccia - Wooden. Accessorio per il tuo animale." },
    ["bedcream"] = { label = "Cuccia - crema", weight = 100, stack = true, close = true, description = "Cuccia - crema. Accessorio per il tuo animale." },
    ["bedgold"] = { label = "Cuccia - oro", weight = 100, stack = true, close = true, description = "Cuccia - oro. Accessorio per il tuo animale." },
    ["bedmodern"] = { label = "Cuccia - moderna", weight = 100, stack = true, close = true, description = "Cuccia - moderna. Accessorio per il tuo animale." },
    ["bedold"] = { label = "Cuccia - vecchia", weight = 100, stack = true, close = true, description = "Cuccia - vecchia. Accessorio per il tuo animale." },
    ["bedplaid"] = { label = "Cuccia - scozzese", weight = 100, stack = true, close = true, description = "Cuccia - scozzese. Accessorio per il tuo animale." },
    ["bedbath"] = { label = "Cuccia - vasca", weight = 100, stack = true, close = true, description = "Cuccia - vasca. Accessorio per il tuo animale." },
    ["bedsmall"] = { label = "Cuccia piccola", weight = 100, stack = true, close = true, description = "Cuccia piccola. Accessorio per il tuo animale." },
    ["bedflower"] = { label = "Cuccia - floreale", weight = 100, stack = true, close = true, description = "Cuccia - floreale. Accessorio per il tuo animale." },
    ["bedhouse"] = { label = "Cuccia - casetta", weight = 100, stack = true, close = true, description = "Cuccia - casetta. Accessorio per il tuo animale." },
    ["bedhammock"] = { label = "Cuccia - Hammock", weight = 100, stack = true, close = true, description = "Cuccia - Hammock. Accessorio per il tuo animale." },
    ["bedprincess"] = { label = "Cuccia - principessa", weight = 100, stack = true, close = true, description = "Cuccia - principessa. Accessorio per il tuo animale." },
    ["bedpumpkin"] = { label = "Cuccia - zucca", weight = 100, stack = true, close = true, description = "Cuccia - zucca. Accessorio per il tuo animale." },
    ["bedpumpkinhollow"] = { label = "Cuccia - vuota zucca", weight = 100, stack = true, close = true, description = "Cuccia - vuota zucca. Accessorio per il tuo animale." },
    ["bedbath2"] = { label = "Cuccia - bagno 2", weight = 100, stack = true, close = true, description = "Cuccia - bagno 2. Accessorio per il tuo animale." },
    ["bedbath3"] = { label = "Cuccia - bagno 3", weight = 100, stack = true, close = true, description = "Cuccia - bagno 3. Accessorio per il tuo animale." },
    ["bedflower2"] = { label = "Cuccia - floreale 2", weight = 100, stack = true, close = true, description = "Cuccia - floreale 2. Accessorio per il tuo animale." },
    ["bedflower3"] = { label = "Cuccia - floreale 3", weight = 100, stack = true, close = true, description = "Cuccia - floreale 3. Accessorio per il tuo animale." },
    ["bedhouse2"] = { label = "Cuccia - casetta 2", weight = 100, stack = true, close = true, description = "Cuccia - casetta 2. Accessorio per il tuo animale." },
    ["bedhouse3"] = { label = "Cuccia - casetta 3", weight = 100, stack = true, close = true, description = "Cuccia - casetta 3. Accessorio per il tuo animale." },
    ["bedprincess2"] = { label = "Cuccia - principessa 2", weight = 100, stack = true, close = true, description = "Cuccia - principessa 2. Accessorio per il tuo animale." },
    ["bedprincess3"] = { label = "Cuccia - principessa 3", weight = 100, stack = true, close = true, description = "Cuccia - principessa 3. Accessorio per il tuo animale." },
    ["bedprincess4"] = { label = "Cuccia - principessa 4", weight = 100, stack = true, close = true, description = "Cuccia - principessa 4. Accessorio per il tuo animale." },
    ["bedpumpkin2"] = { label = "Cuccia - zucca 2", weight = 100, stack = true, close = true, description = "Cuccia - zucca 2. Accessorio per il tuo animale." },
    ["bedpumpkin3"] = { label = "Cuccia - zucca 3", weight = 100, stack = true, close = true, description = "Cuccia - zucca 3. Accessorio per il tuo animale." },
    ["bedpumpkin4"] = { label = "Cuccia - zucca 4", weight = 100, stack = true, close = true, description = "Cuccia - zucca 4. Accessorio per il tuo animale." },
    ["bedpumpkin5"] = { label = "Cuccia - zucca 5", weight = 100, stack = true, close = true, description = "Cuccia - zucca 5. Accessorio per il tuo animale." },
    ["bedpumpkin6"] = { label = "Cuccia - zucca 6", weight = 100, stack = true, close = true, description = "Cuccia - zucca 6. Accessorio per il tuo animale." },
    ["bedpumpkinhollow2"] = { label = "Cuccia - vuota 2", weight = 100, stack = true, close = true, description = "Cuccia - vuota 2. Accessorio per il tuo animale." },
    ["bedpumpkinhollow3"] = { label = "Cuccia - vuota 3", weight = 100, stack = true, close = true, description = "Cuccia - vuota 3. Accessorio per il tuo animale." },
    ["bedpumpkinhollow4"] = { label = "Cuccia - vuota 4", weight = 100, stack = true, close = true, description = "Cuccia - vuota 4. Accessorio per il tuo animale." },
    ["bedsmall2"] = { label = "Cuccia piccola 2", weight = 100, stack = true, close = true, description = "Cuccia piccola 2. Accessorio per il tuo animale." },
    ["bedsmall3"] = { label = "Cuccia piccola 3", weight = 100, stack = true, close = true, description = "Cuccia piccola 3. Accessorio per il tuo animale." },
    ["bedcomf"] = { label = "Cuccia - Comf", weight = 100, stack = true, close = true, description = "Cuccia - Comf. Accessorio per il tuo animale." },
    ["bedcomf2"] = { label = "Cuccia - Comf 2", weight = 100, stack = true, close = true, description = "Cuccia - Comf 2. Accessorio per il tuo animale." },
    ["bedcomf3"] = { label = "Cuccia - Comf 3", weight = 100, stack = true, close = true, description = "Cuccia - Comf 3. Accessorio per il tuo animale." },
    ["bedcomf4"] = { label = "Cuccia - Comf 4", weight = 100, stack = true, close = true, description = "Cuccia - Comf 4. Accessorio per il tuo animale." },
    ["bedcomf5"] = { label = "Cuccia - Comf 5", weight = 100, stack = true, close = true, description = "Cuccia - Comf 5. Accessorio per il tuo animale." },
    ["bedcomf6"] = { label = "Cuccia - Comf 6", weight = 100, stack = true, close = true, description = "Cuccia - Comf 6. Accessorio per il tuo animale." },
    ["bedcomf7"] = { label = "Cuccia - Comf 7", weight = 100, stack = true, close = true, description = "Cuccia - Comf 7. Accessorio per il tuo animale." },
    ["bedcomf8"] = { label = "Cuccia - Comf 8", weight = 100, stack = true, close = true, description = "Cuccia - Comf 8. Accessorio per il tuo animale." },
    ["bedcomf9"] = { label = "Cuccia - Comf 9", weight = 100, stack = true, close = true, description = "Cuccia - Comf 9. Accessorio per il tuo animale." },
    ["bedbasketa"] = { label = "Cuccia a cestino - marrone medio", weight = 100, stack = true, close = true },
    ["bedbasketb"] = { label = "Cuccia a cestino - marrone", weight = 100, stack = true, close = true },
    ["bedbasketc"] = { label = "Cuccia a cestino - marrone chiaro", weight = 100, stack = true, close = true },
    ["bedbasketd"] = { label = "Cuccia a cestino - bianco", weight = 100, stack = true, close = true },
    ["bedsubmarinea"] = { label = "Cuccia sottomarino - marrone", weight = 100, stack = true, close = true },
    ["bedsubmarineb"] = { label = "Cuccia sottomarino - verde", weight = 100, stack = true, close = true },
    ["bedsubmarinec"] = { label = "Cuccia sottomarino - giallo", weight = 100, stack = true, close = true },

-- Ciotole (33)
    ["bluebowl"] = { label = "Ciotola - blu", weight = 100, stack = true, close = true, description = "Ciotola - blu. Accessorio per il tuo animale." },
    ["brownbowl"] = { label = "Ciotola - marrone", weight = 100, stack = true, close = true, description = "Ciotola - marrone. Accessorio per il tuo animale." },
    ["greenbowl"] = { label = "Ciotola - verde", weight = 100, stack = true, close = true, description = "Ciotola - verde. Accessorio per il tuo animale." },
    ["redbowl"] = { label = "Ciotola - rosso", weight = 100, stack = true, close = true, description = "Ciotola - rosso. Accessorio per il tuo animale." },
    ["silverbowl"] = { label = "Ciotola - argento", weight = 100, stack = true, close = true, description = "Ciotola - argento. Accessorio per il tuo animale." },
    ["cdev_pets_bowl1_a"] = { label = "Ciotola rotonda - blu", weight = 100, stack = true, close = true, description = "Ciotola rotonda - blu. Accessorio per il tuo animale." },
    ["cdev_pets_bowl1_b"] = { label = "Ciotola rotonda - nero", weight = 100, stack = true, close = true, description = "Ciotola rotonda - nero. Accessorio per il tuo animale." },
    ["cdev_pets_bowl1_c"] = { label = "Ciotola rotonda - verde chiaro", weight = 100, stack = true, close = true, description = "Ciotola rotonda - verde chiaro. Accessorio per il tuo animale." },
    ["cdev_pets_bowl1_d"] = { label = "Ciotola rotonda - bianco/blu", weight = 100, stack = true, close = true, description = "Ciotola rotonda - bianco/blu. Accessorio per il tuo animale." },
    ["cdev_pets_bowl1_e"] = { label = "Ciotola rotonda - marrone/bianco", weight = 100, stack = true, close = true, description = "Ciotola rotonda - marrone/bianco. Accessorio per il tuo animale." },
    ["cdev_pets_bowl1_f"] = { label = "Ciotola rotonda - rosa chiaro", weight = 100, stack = true, close = true, description = "Ciotola rotonda - rosa chiaro. Accessorio per il tuo animale." },
    ["cdev_pets_bowl2_a"] = { label = "Ciotola in legno - bianco", weight = 100, stack = true, close = true, description = "Ciotola in legno - bianco. Accessorio per il tuo animale." },
    ["cdev_pets_bowl2_b"] = { label = "Ciotola in legno - blu", weight = 100, stack = true, close = true, description = "Ciotola in legno - blu. Accessorio per il tuo animale." },
    ["cdev_pets_bowl2_c"] = { label = "Ciotola in legno - rosso", weight = 100, stack = true, close = true, description = "Ciotola in legno - rosso. Accessorio per il tuo animale." },
    ["cdev_pets_bowl2_d"] = { label = "Ciotola in legno - bianco", weight = 100, stack = true, close = true, description = "Ciotola in legno - bianco. Accessorio per il tuo animale." },
    ["cdev_pets_bowl2_e"] = { label = "Ciotola in legno - verde2", weight = 100, stack = true, close = true, description = "Ciotola in legno - verde2. Accessorio per il tuo animale." },
    ["cdev_pets_bowl2_f"] = { label = "Ciotola in legno - beige", weight = 100, stack = true, close = true, description = "Ciotola in legno - beige. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_a"] = { label = "Ciotola per gatto - bianco", weight = 100, stack = true, close = true, description = "Ciotola per gatto - bianco. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_b"] = { label = "Ciotola per gatto - verde", weight = 100, stack = true, close = true, description = "Ciotola per gatto - verde. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_c"] = { label = "Ciotola per gatto - argento", weight = 100, stack = true, close = true, description = "Ciotola per gatto - argento. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_d"] = { label = "Ciotola per gatto - rosa", weight = 100, stack = true, close = true, description = "Ciotola per gatto - rosa. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_e"] = { label = "Ciotola per gatto - rosso", weight = 100, stack = true, close = true, description = "Ciotola per gatto - rosso. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_f"] = { label = "Ciotola per gatto - nero", weight = 100, stack = true, close = true, description = "Ciotola per gatto - nero. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_g"] = { label = "Ciotola per gatto - blu", weight = 100, stack = true, close = true, description = "Ciotola per gatto - blu. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_h"] = { label = "Ciotola per gatto - giallo", weight = 100, stack = true, close = true, description = "Ciotola per gatto - giallo. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_i"] = { label = "Ciotola per gatto - marrone", weight = 100, stack = true, close = true, description = "Ciotola per gatto - marrone. Accessorio per il tuo animale." },
    ["cdev_pets_bowl3_j"] = { label = "Ciotola per gatto - chiara", weight = 100, stack = true, close = true, description = "Ciotola per gatto - chiara. Accessorio per il tuo animale." },
    ["cdev_pets_bowl4_a"] = { label = "Ciotola per gatto in legno - marrone", weight = 100, stack = true, close = true, description = "Ciotola per gatto in legno - marrone. Accessorio per il tuo animale." },
    ["cdev_pets_bowl4_b"] = { label = "Ciotola per gatto in legno - rosso", weight = 100, stack = true, close = true, description = "Ciotola per gatto in legno - rosso. Accessorio per il tuo animale." },
    ["cdev_pets_bowl4_c"] = { label = "Ciotola per gatto in legno - blu", weight = 100, stack = true, close = true, description = "Ciotola per gatto in legno - blu. Accessorio per il tuo animale." },
    ["cdev_pets_bowl4_d"] = { label = "Ciotola per gatto in legno - bianco", weight = 100, stack = true, close = true, description = "Ciotola per gatto in legno - bianco. Accessorio per il tuo animale." },
    ["cdev_pets_bowl4_e"] = { label = "Ciotola per gatto in legno - verde", weight = 100, stack = true, close = true, description = "Ciotola per gatto in legno - verde. Accessorio per il tuo animale." },
    ["cdev_pets_bowl4_f"] = { label = "Ciotola per gatto in legno - baby", weight = 100, stack = true, close = true, description = "Ciotola per gatto in legno - baby. Accessorio per il tuo animale." },

-- Giochi e accessori (48)
    ["baseball"] = { label = "Palla da baseball", weight = 100, stack = true, close = true, description = "Un ottimo gioco per gli animali, soprattutto per i cani. È semplice ed efficace per il riporto e per giocare in casa o all'aperto." },
    ["cdev_pets_ball1_a"] = { label = "Palla da gioco - nero", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_b"] = { label = "Palla da gioco - bianco", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_c"] = { label = "Palla da gioco - verde", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_d"] = { label = "Palla da gioco - blu", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_e"] = { label = "Palla da gioco - giallo", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_f"] = { label = "Palla da gioco - rosso", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_g"] = { label = "Palla da gioco - viola", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_h"] = { label = "Palla da gioco - rosa", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_i"] = { label = "Palla da gioco - azzurro", weight = 100, stack = true, close = true },
    ["cdev_pets_ball1_j"] = { label = "Palla da gioco - marrone", weight = 100, stack = true, close = true },
    ["catbaga"] = { label = "Borsa per gatto - blu", weight = 100, stack = true, close = true },
    ["catbagb"] = { label = "Borsa per gatto - rosa", weight = 100, stack = true, close = true },
    ["catbagc"] = { label = "Borsa per gatto - marrone", weight = 100, stack = true, close = true },
    ["catbagd"] = { label = "Borsa per gatto - rosso", weight = 100, stack = true, close = true },
    ["catbage"] = { label = "Borsa per gatto - viola chiaro", weight = 100, stack = true, close = true },
    ["catbagf"] = { label = "Borsa per gatto - bianco", weight = 100, stack = true, close = true },
    ["catbagg"] = { label = "Borsa per gatto - viola", weight = 100, stack = true, close = true },
    ["catbagh"] = { label = "Borsa per gatto - verde", weight = 100, stack = true, close = true },
    ["catbagi"] = { label = "Borsa per gatto - rosso", weight = 100, stack = true, close = true },
    ["bigdogbaga"] = { label = "Borsa per cane grande - blu", weight = 100, stack = true, close = true },
    ["bigdogbagb"] = { label = "Borsa per cane grande - rosa", weight = 100, stack = true, close = true },
    ["bigdogbagc"] = { label = "Borsa per cane grande - giallo", weight = 100, stack = true, close = true },
    ["bigdogbagd"] = { label = "Borsa per cane grande - rosso", weight = 100, stack = true, close = true },
    ["bigdogbage"] = { label = "Borsa per cane grande - viola", weight = 100, stack = true, close = true },
    ["bigdogbagf"] = { label = "Borsa per cane grande - bianco", weight = 100, stack = true, close = true },
    ["bigdogbagg"] = { label = "Borsa per cane grande - viola", weight = 100, stack = true, close = true },
    ["bigdogbagh"] = { label = "Borsa per cane grande - verde", weight = 100, stack = true, close = true },
    ["bigdogbagi"] = { label = "Borsa per cane grande - rosso", weight = 100, stack = true, close = true },
    ["dogbaga"] = { label = "Borsa per cane - blu", weight = 100, stack = true, close = true },
    ["dogbagb"] = { label = "Borsa per cane - rosa", weight = 100, stack = true, close = true },
    ["dogbagc"] = { label = "Borsa per cane - giallo", weight = 100, stack = true, close = true },
    ["dogbagd"] = { label = "Borsa per cane - rosso", weight = 100, stack = true, close = true },
    ["dogbage"] = { label = "Borsa per cane - viola", weight = 100, stack = true, close = true },
    ["dogbagf"] = { label = "Borsa per cane - bianco", weight = 100, stack = true, close = true },
    ["dogbagg"] = { label = "Borsa per cane - viola", weight = 100, stack = true, close = true },
    ["dogbagh"] = { label = "Borsa per cane - verde", weight = 100, stack = true, close = true },
    ["dogbagi"] = { label = "Borsa per cane - rosso acceso", weight = 100, stack = true, close = true },
    ["scratch1a"] = { label = "Tiragraffi a cactus - giallo", weight = 100, stack = true, close = true },
    ["scratch1b"] = { label = "Tiragraffi a cactus - verde chiaro", weight = 100, stack = true, close = true },
    ["scratch1c"] = { label = "Tiragraffi a cactus - bianco", weight = 100, stack = true, close = true },
    ["scratch1d"] = { label = "Tiragraffi a cactus - vaniglia", weight = 100, stack = true, close = true },
    ["scratch1e"] = { label = "Tiragraffi a cactus - nero", weight = 100, stack = true, close = true },
    ["scratch1f"] = { label = "Tiragraffi a cactus - verde", weight = 100, stack = true, close = true },
    ["scratch2a"] = { label = "Tiragraffi a gallina - giallo", weight = 100, stack = true, close = true },
    ["scratch2b"] = { label = "Tiragraffi a gallina - bastoncino di zucchero", weight = 100, stack = true, close = true },
    ["scratch2c"] = { label = "Tiragraffi a gallina - giallo", weight = 100, stack = true, close = true },
    ["scratch2d"] = { label = "Tiragraffi a gallina - verde", weight = 100, stack = true, close = true },

-- Guinzagli (1)
    ["leashgreen"] = { label = "Guinzaglio - verde", weight = 100, stack = true, close = true, description = "Guinzaglio per portare il tuo cane a passeggio." },

-- Collari e bandane (57)
    ["goldcollar"] = { label = "Collare borchiato - oro", weight = 100, stack = true, close = true, description = "Collare borchiato - oro. Accessorio per il tuo animale." },
    ["whitecollar"] = { label = "Collare borchiato - bianco", weight = 100, stack = true, close = true, description = "Collare borchiato - bianco. Accessorio per il tuo animale." },
    ["blackcollarstrass"] = { label = "Collare borchiato - nero", weight = 100, stack = true, close = true, description = "Collare borchiato - nero. Accessorio per il tuo animale." },
    ["greenleathercollar"] = { label = "Collare in pelle - verde", weight = 100, stack = true, close = true, description = "Collare in pelle - verde. Accessorio per il tuo animale." },
    ["tealleathercollar"] = { label = "Collare in pelle - petrolio", weight = 100, stack = true, close = true, description = "Collare in pelle - petrolio. Accessorio per il tuo animale." },
    ["greentealleathercollar"] = { label = "Collare in pelle - verde petrolio", weight = 100, stack = true, close = true, description = "Collare in pelle - verde petrolio. Accessorio per il tuo animale." },
    ["purpleleathercollar"] = { label = "Collare in pelle - viola", weight = 100, stack = true, close = true, description = "Collare in pelle - viola. Accessorio per il tuo animale." },
    ["pinkleathercollar"] = { label = "Collare in pelle - rosa", weight = 100, stack = true, close = true, description = "Collare in pelle - rosa. Accessorio per il tuo animale." },
    ["redleathercollar"] = { label = "Collare in pelle - rosso", weight = 100, stack = true, close = true, description = "Collare in pelle - rosso. Accessorio per il tuo animale." },
    ["gunnerleathercollar"] = { label = "Collare in pelle - Gunner", weight = 100, stack = true, close = true, description = "Collare in pelle - Gunner. Accessorio per il tuo animale." },
    ["blackandredleathercollar"] = { label = "Collare in pelle - nero e rosso", weight = 100, stack = true, close = true, description = "Collare in pelle - nero e rosso. Accessorio per il tuo animale." },
    ["whitecollarbandana"] = { label = "Collare con bandana - bianco", weight = 100, stack = true, close = true, description = "Collare con bandana - bianco. Accessorio per il tuo animale." },
    ["greencollarbandana"] = { label = "Collare con bandana - verde", weight = 100, stack = true, close = true, description = "Collare con bandana - verde. Accessorio per il tuo animale." },
    ["redcollarbandana"] = { label = "Collare con bandana - rosso", weight = 100, stack = true, close = true, description = "Collare con bandana - rosso. Accessorio per il tuo animale." },
    ["greycollarbandana"] = { label = "Collare con bandana - grigio", weight = 100, stack = true, close = true, description = "Collare con bandana - grigio. Accessorio per il tuo animale." },
    ["silverpendantcollar"] = { label = "Collare con ciondolo - argento", weight = 100, stack = true, close = true, description = "Collare con ciondolo - argento. Accessorio per il tuo animale." },
    ["goldpendantcollar"] = { label = "Collare con ciondolo - oro", weight = 100, stack = true, close = true, description = "Collare con ciondolo - oro. Accessorio per il tuo animale." },
    ["silverchaincollar"] = { label = "Collare a catena - argento", weight = 100, stack = true, close = true, description = "Collare a catena - argento. Accessorio per il tuo animale." },
    ["goldchaincollar"] = { label = "Collare a catena - oro", weight = 100, stack = true, close = true, description = "Collare a catena - oro. Accessorio per il tuo animale." },
    ["blackchaincollar"] = { label = "Collare a catena - nero", weight = 100, stack = true, close = true, description = "Collare a catena - nero. Accessorio per il tuo animale." },
    ["metalcollarblack"] = { label = "Collare in metallo - nero", weight = 100, stack = true, close = true, description = "Collare in metallo - nero. Accessorio per il tuo animale." },
    ["metalcollargray"] = { label = "Collare in metallo - grigio", weight = 100, stack = true, close = true, description = "Collare in metallo - grigio. Accessorio per il tuo animale." },
    ["metalcollarwhite"] = { label = "Collare in metallo - bianco", weight = 100, stack = true, close = true, description = "Collare in metallo - bianco. Accessorio per il tuo animale." },
    ["silvermetalcollar"] = { label = "Collare in metallo - argento", weight = 100, stack = true, close = true, description = "Collare in metallo - argento. Accessorio per il tuo animale." },
    ["brownpendantleacollar"] = { label = "Collare in pelle con ciondolo - marrone", weight = 100, stack = true, close = true, description = "Collare in pelle con ciondolo - marrone. Accessorio per il tuo animale." },
    ["redpendantleacollar"] = { label = "Collare in pelle con ciondolo - rosso", weight = 100, stack = true, close = true, description = "Collare in pelle con ciondolo - rosso. Accessorio per il tuo animale." },
    ["greenpendantleacollar"] = { label = "Collare in pelle con ciondolo - verde", weight = 100, stack = true, close = true, description = "Collare in pelle con ciondolo - verde. Accessorio per il tuo animale." },
    ["tribalpendantleacollar"] = { label = "Collare in pelle con ciondolo - Tribal", weight = 100, stack = true, close = true, description = "Collare in pelle con ciondolo - Tribal. Accessorio per il tuo animale." },
    ["pinkpendantleacollar"] = { label = "Collare in pelle con ciondolo - rosa", weight = 100, stack = true, close = true, description = "Collare in pelle con ciondolo - rosa. Accessorio per il tuo animale." },
    ["whitecollarbow"] = { label = "Collare con fiocco - bianco", weight = 100, stack = true, close = true, description = "Collare con fiocco - bianco. Accessorio per il tuo animale." },
    ["darkredcollarbow"] = { label = "Collare con fiocco - rosso scuro", weight = 100, stack = true, close = true, description = "Collare con fiocco - rosso scuro. Accessorio per il tuo animale." },
    ["redcollarbow"] = { label = "Collare con fiocco - rosso", weight = 100, stack = true, close = true, description = "Collare con fiocco - rosso. Accessorio per il tuo animale." },
    ["greencollarbow"] = { label = "Collare con fiocco - verde", weight = 100, stack = true, close = true, description = "Collare con fiocco - verde. Accessorio per il tuo animale." },
    ["tealcollarbow"] = { label = "Collare con fiocco - petrolio", weight = 100, stack = true, close = true, description = "Collare con fiocco - petrolio. Accessorio per il tuo animale." },
    ["pinkcollarbow"] = { label = "Collare con fiocco - rosa", weight = 100, stack = true, close = true, description = "Collare con fiocco - rosa. Accessorio per il tuo animale." },
    ["darkbluecollarbow"] = { label = "Collare con fiocco - blu scuro", weight = 100, stack = true, close = true, description = "Collare con fiocco - blu scuro. Accessorio per il tuo animale." },
    ["beigecollarbow"] = { label = "Collare con fiocco - beige", weight = 100, stack = true, close = true, description = "Collare con fiocco - beige. Accessorio per il tuo animale." },
    ["rainbowcollar"] = { label = "Collare con ciondolo - arcobaleno", weight = 100, stack = true, close = true, description = "Collare con ciondolo - arcobaleno. Accessorio per il tuo animale." },
    ["tiedyecollar"] = { label = "Collare con ciondolo - Tie Dye", weight = 100, stack = true, close = true, description = "Collare con ciondolo - Tie Dye. Accessorio per il tuo animale." },
    ["pawcolorcollar"] = { label = "Collare con ciondolo - Paw Color", weight = 100, stack = true, close = true, description = "Collare con ciondolo - Paw Color. Accessorio per il tuo animale." },
    ["whitetie"] = { label = "Cravatta - bianco", weight = 100, stack = true, close = true, description = "Cravatta - bianco. Accessorio per il tuo animale." },
    ["greentie"] = { label = "Cravatta - verde", weight = 100, stack = true, close = true, description = "Cravatta - verde. Accessorio per il tuo animale." },
    ["blacktie"] = { label = "Cravatta - nero", weight = 100, stack = true, close = true, description = "Cravatta - nero. Accessorio per il tuo animale." },
    ["pinktie"] = { label = "Cravatta - rosa", weight = 100, stack = true, close = true, description = "Cravatta - rosa. Accessorio per il tuo animale." },
    ["chestcollar"] = { label = "Pettorina - ciano", weight = 100, stack = true, close = true, description = "Pettorina - ciano. Accessorio per il tuo animale." },
    ["blackchestcollar"] = { label = "Pettorina - nero", weight = 100, stack = true, close = true, description = "Pettorina - nero. Accessorio per il tuo animale." },
    ["bluechestcollar"] = { label = "Pettorina - blu", weight = 100, stack = true, close = true, description = "Pettorina - blu. Accessorio per il tuo animale." },
    ["pinkchestcollar"] = { label = "Pettorina - rosa", weight = 100, stack = true, close = true, description = "Pettorina - rosa. Accessorio per il tuo animale." },
    ["lightbluechestcollar"] = { label = "Pettorina - azzurro", weight = 100, stack = true, close = true, description = "Pettorina - azzurro. Accessorio per il tuo animale." },
    ["redchestcollar"] = { label = "Pettorina - rosso", weight = 100, stack = true, close = true, description = "Pettorina - rosso. Accessorio per il tuo animale." },
    ["greenchestcollar"] = { label = "Pettorina - verde", weight = 100, stack = true, close = true, description = "Pettorina - verde. Accessorio per il tuo animale." },
    ["purplechestcollar"] = { label = "Pettorina - viola", weight = 100, stack = true, close = true, description = "Pettorina - viola. Accessorio per il tuo animale." },
    ["lightpinkchestcollar"] = { label = "Pettorina - rosa chiaro", weight = 100, stack = true, close = true, description = "Pettorina - rosa chiaro. Accessorio per il tuo animale." },
    ["bluebandana"] = { label = "Bandana - blu", weight = 100, stack = true, close = true, description = "Bandana - blu. Accessorio per il tuo animale." },
    ["pinkbandana"] = { label = "Bandana - rosa", weight = 100, stack = true, close = true, description = "Bandana - rosa. Accessorio per il tuo animale." },
    ["redbandana"] = { label = "Bandana - rosso", weight = 100, stack = true, close = true, description = "Bandana - rosso. Accessorio per il tuo animale." },
    ["orangebandana"] = { label = "Bandana - arancione", weight = 100, stack = true, close = true, description = "Bandana - arancione. Accessorio per il tuo animale." },

-- Abbigliamento (241)
    ["yellowbootslong"] = { label = "Stivali lunghi - giallo", weight = 100, stack = true, close = true, description = "Stivali lunghi - giallo. Accessorio per il tuo animale." },
    ["bluebootslong"] = { label = "Stivali lunghi - ciano", weight = 100, stack = true, close = true, description = "Stivali lunghi - ciano. Accessorio per il tuo animale." },
    ["redbootslong"] = { label = "Stivali lunghi - rosso", weight = 100, stack = true, close = true, description = "Stivali lunghi - rosso. Accessorio per il tuo animale." },
    ["pinkyellowbootslong"] = { label = "Stivali lunghi - giallo/rosa", weight = 100, stack = true, close = true, description = "Stivali lunghi - giallo/rosa. Accessorio per il tuo animale." },
    ["pinkbootslong"] = { label = "Stivali lunghi - rosa", weight = 100, stack = true, close = true, description = "Stivali lunghi - rosa. Accessorio per il tuo animale." },
    ["yellowboots"] = { label = "Stivali lunghi - verde chiaro", weight = 100, stack = true, close = true, description = "Stivali lunghi - verde chiaro. Accessorio per il tuo animale." },
    ["blueboots"] = { label = "Stivali lunghi - blu", weight = 100, stack = true, close = true, description = "Stivali lunghi - blu. Accessorio per il tuo animale." },
    ["greenboots"] = { label = "Stivali lunghi - verde", weight = 100, stack = true, close = true, description = "Stivali lunghi - verde. Accessorio per il tuo animale." },
    ["purpleshoes"] = { label = "Stivali da neve - viola", weight = 100, stack = true, close = true, description = "Stivali da neve - viola. Accessorio per il tuo animale." },
    ["snowbootsgray"] = { label = "Stivali da neve - grigio", weight = 100, stack = true, close = true, description = "Stivali da neve - grigio. Accessorio per il tuo animale." },
    ["snowbootsblue"] = { label = "Stivali da neve - ciano", weight = 100, stack = true, close = true, description = "Stivali da neve - ciano. Accessorio per il tuo animale." },
    ["pinkwhitesnowboots"] = { label = "Stivali da neve - rosa e bianco", weight = 100, stack = true, close = true, description = "Stivali da neve - rosa e bianco. Accessorio per il tuo animale." },
    ["darkbluesnowboots"] = { label = "Stivali da neve - blu scuro", weight = 100, stack = true, close = true, description = "Stivali da neve - blu scuro. Accessorio per il tuo animale." },
    ["yellowsnowboots"] = { label = "Stivali da neve - verde e giallo", weight = 100, stack = true, close = true, description = "Stivali da neve - verde e giallo. Accessorio per il tuo animale." },
    ["pinksnowboots"] = { label = "Stivali da neve - rosa", weight = 100, stack = true, close = true, description = "Stivali da neve - rosa. Accessorio per il tuo animale." },
    ["greywhitesnowboots"] = { label = "Stivali da neve - grigio e bianco", weight = 100, stack = true, close = true, description = "Stivali da neve - grigio e bianco. Accessorio per il tuo animale." },
    ["darkgreensnowboots"] = { label = "Stivali da neve - verde scuro", weight = 100, stack = true, close = true, description = "Stivali da neve - verde scuro. Accessorio per il tuo animale." },
    ["sneakersblue"] = { label = "Sneakers - ciano", weight = 100, stack = true, close = true, description = "Sneakers - ciano. Accessorio per il tuo animale." },
    ["sneakerspurple"] = { label = "Sneakers - viola", weight = 100, stack = true, close = true, description = "Sneakers - viola. Accessorio per il tuo animale." },
    ["sneakersgreen"] = { label = "Sneakers - verde", weight = 100, stack = true, close = true, description = "Sneakers - verde. Accessorio per il tuo animale." },
    ["redboots"] = { label = "Sneakers - rosso", weight = 100, stack = true, close = true, description = "Sneakers - rosso. Accessorio per il tuo animale." },
    ["beigeboots"] = { label = "Sneakers - beige", weight = 100, stack = true, close = true, description = "Sneakers - beige. Accessorio per il tuo animale." },
    ["bluedarklightboots"] = { label = "Sneakers - blu scuro", weight = 100, stack = true, close = true, description = "Sneakers - blu scuro. Accessorio per il tuo animale." },
    ["yelloworangeboots"] = { label = "Sneakers - giallo e arancione", weight = 100, stack = true, close = true, description = "Sneakers - giallo e arancione. Accessorio per il tuo animale." },
    ["yellowbootsshort"] = { label = "Sneakers - giallo", weight = 100, stack = true, close = true, description = "Sneakers - giallo. Accessorio per il tuo animale." },
    ["elfwhiteboots"] = { label = "Elfo Stivali bianco", weight = 100, stack = true, close = true, description = "Elfo Stivali bianco. Accessorio per il tuo animale." },
    ["elfgreenboots"] = { label = "Elfo Stivali verde", weight = 100, stack = true, close = true, description = "Elfo Stivali verde. Accessorio per il tuo animale." },
    ["elfbrownboots"] = { label = "Elfo Stivali marrone", weight = 100, stack = true, close = true, description = "Elfo Stivali marrone. Accessorio per il tuo animale." },
    ["beigestyleboots"] = { label = "Stivali eleganti - beige", weight = 100, stack = true, close = true, description = "Stivali eleganti - beige. Accessorio per il tuo animale." },
    ["blackstyleboots"] = { label = "Stivali eleganti - nero", weight = 100, stack = true, close = true, description = "Stivali eleganti - nero. Accessorio per il tuo animale." },
    ["brownstyleboots"] = { label = "Stivali eleganti - marrone", weight = 100, stack = true, close = true, description = "Stivali eleganti - marrone. Accessorio per il tuo animale." },
    ["brownboots"] = { label = "Sneakers Star - marrone", weight = 100, stack = true, close = true, description = "Sneakers Star - marrone. Accessorio per il tuo animale." },
    ["purpleboots"] = { label = "Sneakers Star - viola", weight = 100, stack = true, close = true, description = "Sneakers Star - viola. Accessorio per il tuo animale." },
    ["redbooots"] = { label = "Sneakers Star - rosso", weight = 100, stack = true, close = true, description = "Sneakers Star - rosso. Accessorio per il tuo animale." },
    ["blackboots"] = { label = "Sneakers Star - nero", weight = 100, stack = true, close = true, description = "Sneakers Star - nero. Accessorio per il tuo animale." },
    ["greenbooots"] = { label = "Sneakers Star - verde", weight = 100, stack = true, close = true, description = "Sneakers Star - verde. Accessorio per il tuo animale." },
    ["darkgreenboots"] = { label = "Sneakers Star - verde scuro", weight = 100, stack = true, close = true, description = "Sneakers Star - verde scuro. Accessorio per il tuo animale." },
    ["beigebooots"] = { label = "Sneakers Star - beige", weight = 100, stack = true, close = true, description = "Sneakers Star - beige. Accessorio per il tuo animale." },
    ["darkergreenboots"] = { label = "Sneakers Star - verde molto scuro", weight = 100, stack = true, close = true, description = "Sneakers Star - verde molto scuro. Accessorio per il tuo animale." },
    ["blackandwhiteboots"] = { label = "Sneakers Star - nero intenso", weight = 100, stack = true, close = true, description = "Sneakers Star - nero intenso. Accessorio per il tuo animale." },
    ["purpleandwhiteboots"] = { label = "Stivali Star - viola scuro", weight = 100, stack = true, close = true, description = "Stivali Star - viola scuro. Accessorio per il tuo animale." },
    ["redairone"] = { label = "Scarpe Air One - rosso", weight = 100, stack = true, close = true, description = "Scarpe Air One - rosso. Accessorio per il tuo animale." },
    ["pinkairone"] = { label = "Scarpe Air One - rosa", weight = 100, stack = true, close = true, description = "Scarpe Air One - rosa. Accessorio per il tuo animale." },
    ["blackairone"] = { label = "Scarpe Air One - nero", weight = 100, stack = true, close = true, description = "Scarpe Air One - nero. Accessorio per il tuo animale." },
    ["blueairone"] = { label = "Scarpe Air One - blu", weight = 100, stack = true, close = true, description = "Scarpe Air One - blu. Accessorio per il tuo animale." },
    ["cyanairone"] = { label = "Scarpe Air One - ciano blu", weight = 100, stack = true, close = true, description = "Scarpe Air One - ciano blu. Accessorio per il tuo animale." },
    ["greenairone"] = { label = "Scarpe Air One - verde", weight = 100, stack = true, close = true, description = "Scarpe Air One - verde. Accessorio per il tuo animale." },
    ["darkgreenairone"] = { label = "Scarpe Air One - verde scuro", weight = 100, stack = true, close = true, description = "Scarpe Air One - verde scuro. Accessorio per il tuo animale." },
    ["yellowairone"] = { label = "Scarpe Air One - giallo", weight = 100, stack = true, close = true, description = "Scarpe Air One - giallo. Accessorio per il tuo animale." },
    ["organgeairone"] = { label = "Scarpe Air One - arancione", weight = 100, stack = true, close = true, description = "Scarpe Air One - arancione. Accessorio per il tuo animale." },
    ["darkredairone"] = { label = "Scarpe Air One - rosso scuro", weight = 100, stack = true, close = true, description = "Scarpe Air One - rosso scuro. Accessorio per il tuo animale." },
    ["brownairone"] = { label = "Scarpe Air One - marrone", weight = 100, stack = true, close = true, description = "Scarpe Air One - marrone. Accessorio per il tuo animale." },
    ["brownmask"] = { label = "Maschera umana - marrone", weight = 100, stack = true, close = true, description = "Maschera umana - marrone. Accessorio per il tuo animale." },
    ["beigemask"] = { label = "Maschera umana - beige", weight = 100, stack = true, close = true, description = "Maschera umana - beige. Accessorio per il tuo animale." },
    ["securitypatch"] = { label = "Toppa sicurezza", weight = 100, stack = true, close = true, description = "Toppa sicurezza. Accessorio per il tuo animale." },
    ["policepatch"] = { label = "Toppa polizia", weight = 100, stack = true, close = true, description = "Toppa polizia. Accessorio per il tuo animale." },
    ["rescuepatch"] = { label = "Toppa soccorso", weight = 100, stack = true, close = true, description = "Toppa soccorso. Accessorio per il tuo animale." },
    ["sheriffpatch"] = { label = "Toppa sceriffo", weight = 100, stack = true, close = true, description = "Toppa sceriffo. Accessorio per il tuo animale." },
    ["servicedogpatch"] = { label = "Toppa cane di servizio", weight = 100, stack = true, close = true, description = "Toppa cane di servizio. Accessorio per il tuo animale." },
    ["wingsred"] = { label = "Ali piccole - rosso", weight = 100, stack = true, close = true, description = "Ali piccole - rosso. Accessorio per il tuo animale." },
    ["wingsblack"] = { label = "Ali piccole - nero", weight = 100, stack = true, close = true, description = "Ali piccole - nero. Accessorio per il tuo animale." },
    ["wingsgreen"] = { label = "Ali piccole - verde", weight = 100, stack = true, close = true, description = "Ali piccole - verde. Accessorio per il tuo animale." },
    ["wingsdarkblue"] = { label = "Ali piccole - blu scuro", weight = 100, stack = true, close = true, description = "Ali piccole - blu scuro. Accessorio per il tuo animale." },
    ["candyprop"] = { label = "Secchiello di caramelle", weight = 100, stack = true, close = true, description = "Secchiello di caramelle. Accessorio per il tuo animale." },
    ["pumpkinprop"] = { label = "Secchiello a forma di zucca", weight = 100, stack = true, close = true, description = "Secchiello a forma di zucca. Accessorio per il tuo animale." },
    ["bigredwings"] = { label = "Ali grandi - rosso", weight = 100, stack = true, close = true, description = "Ali grandi - rosso. Accessorio per il tuo animale." },
    ["redorangewings"] = { label = "Ali grandi - rosso/arancione", weight = 100, stack = true, close = true, description = "Ali grandi - rosso/arancione. Accessorio per il tuo animale." },
    ["purplewings"] = { label = "Ali grandi - viola", weight = 100, stack = true, close = true, description = "Ali grandi - viola. Accessorio per il tuo animale." },
    ["pinkwings"] = { label = "Ali grandi - rosa", weight = 100, stack = true, close = true, description = "Ali grandi - rosa. Accessorio per il tuo animale." },
    ["bluewings"] = { label = "Ali grandi - blu", weight = 100, stack = true, close = true, description = "Ali grandi - blu. Accessorio per il tuo animale." },
    ["purplehoodie"] = { label = "Felpa con cappuccio - viola", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - viola. Accessorio per il tuo animale." },
    ["pinkhoodie"] = { label = "Felpa con cappuccio - rosa", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - rosa. Accessorio per il tuo animale." },
    ["greendothoodie"] = { label = "Felpa con cappuccio - verde Dot", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - verde Dot. Accessorio per il tuo animale." },
    ["lightyellowhoodie"] = { label = "Felpa con cappuccio - chiaro giallo", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - chiaro giallo. Accessorio per il tuo animale." },
    ["whitehoodie"] = { label = "Felpa con cappuccio - bianco", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - bianco. Accessorio per il tuo animale." },
    ["orangehoodie"] = { label = "Felpa con cappuccio - arancione", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - arancione. Accessorio per il tuo animale." },
    ["plaidsailorcape"] = { label = "Mantellina da marinaio - scozzese", weight = 100, stack = true, close = true, description = "Mantellina da marinaio - scozzese. Accessorio per il tuo animale." },
    ["camosailorcape"] = { label = "Mantellina da marinaio - mimetico", weight = 100, stack = true, close = true, description = "Mantellina da marinaio - mimetico. Accessorio per il tuo animale." },
    ["graysailorcape"] = { label = "Mantellina da marinaio - grigio", weight = 100, stack = true, close = true, description = "Mantellina da marinaio - grigio. Accessorio per il tuo animale." },
    ["pinksailorcape"] = { label = "Mantellina da marinaio - rosa", weight = 100, stack = true, close = true, description = "Mantellina da marinaio - rosa. Accessorio per il tuo animale." },
    ["blacksailorcape"] = { label = "Mantellina da marinaio - nero", weight = 100, stack = true, close = true, description = "Mantellina da marinaio - nero. Accessorio per il tuo animale." },
    ["camohoodie"] = { label = "Felpa con cappuccio - mimetico", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - mimetico. Accessorio per il tuo animale." },
    ["purplecamohoodie"] = { label = "Felpa con cappuccio - viola mimetico", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - viola mimetico. Accessorio per il tuo animale." },
    ["greencamohoodie"] = { label = "Felpa con cappuccio - verde mimetico", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - verde mimetico. Accessorio per il tuo animale." },
    ["pinkcamohoodie"] = { label = "Felpa con cappuccio - rosa mimetico", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - rosa mimetico. Accessorio per il tuo animale." },
    ["bluecamohoodie"] = { label = "Felpa con cappuccio - blu mimetico", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - blu mimetico. Accessorio per il tuo animale." },
    ["orangecamohoodie"] = { label = "Felpa con cappuccio - arancione mimetico", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - arancione mimetico. Accessorio per il tuo animale." },
    ["whitebrownhoodie"] = { label = "Felpa con cappuccio - bianco marrone", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - bianco marrone. Accessorio per il tuo animale." },
    ["lightpinkhoodie"] = { label = "Felpa con cappuccio - rosa chiaro", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - rosa chiaro. Accessorio per il tuo animale." },
    ["pinkskirt"] = { label = "Gonna - rosa", weight = 100, stack = true, close = true, description = "Gonna - rosa. Accessorio per il tuo animale." },
    ["greenskirt"] = { label = "Gonna - verde", weight = 100, stack = true, close = true, description = "Gonna - verde. Accessorio per il tuo animale." },
    ["redskirt"] = { label = "Gonna - rosso", weight = 100, stack = true, close = true, description = "Gonna - rosso. Accessorio per il tuo animale." },
    ["blueskirt"] = { label = "Gonna - blu", weight = 100, stack = true, close = true, description = "Gonna - blu. Accessorio per il tuo animale." },
    ["rainbowskirt"] = { label = "Gonna - arcobaleno", weight = 100, stack = true, close = true, description = "Gonna - arcobaleno. Accessorio per il tuo animale." },
    ["suit"] = { label = "Completo", weight = 100, stack = true, close = true, description = "Completo. Accessorio per il tuo animale." },
    ["pinksuit"] = { label = "Completo - rosa", weight = 100, stack = true, close = true, description = "Completo - rosa. Accessorio per il tuo animale." },
    ["greensuit"] = { label = "Completo - verde", weight = 100, stack = true, close = true, description = "Completo - verde. Accessorio per il tuo animale." },
    ["bluesuit"] = { label = "Completo - blu", weight = 100, stack = true, close = true, description = "Completo - blu. Accessorio per il tuo animale." },
    ["whitesuit"] = { label = "Completo - bianco", weight = 100, stack = true, close = true, description = "Completo - bianco. Accessorio per il tuo animale." },
    ["tealsuit"] = { label = "Completo - petrolio", weight = 100, stack = true, close = true, description = "Completo - petrolio. Accessorio per il tuo animale." },
    ["animlaspajama"] = { label = "Pigiama con animali stampati", weight = 100, stack = true, close = true, description = "Pigiama con animali stampati. Accessorio per il tuo animale." },
    ["skypajama"] = { label = "Pigiama - Sky", weight = 100, stack = true, close = true, description = "Pigiama - Sky. Accessorio per il tuo animale." },
    ["woolpajama"] = { label = "Pigiama - Wool", weight = 100, stack = true, close = true, description = "Pigiama - Wool. Accessorio per il tuo animale." },
    ["flowerspajama"] = { label = "Pigiama - fiori", weight = 100, stack = true, close = true, description = "Pigiama - fiori. Accessorio per il tuo animale." },
    ["starspajama"] = { label = "Pigiama - Stars", weight = 100, stack = true, close = true, description = "Pigiama - Stars. Accessorio per il tuo animale." },
    ["pandapajama"] = { label = "Pigiama - Panda", weight = 100, stack = true, close = true, description = "Pigiama - Panda. Accessorio per il tuo animale." },
    ["rainbowpajama"] = { label = "Pigiama - arcobaleno", weight = 100, stack = true, close = true, description = "Pigiama - arcobaleno. Accessorio per il tuo animale." },
    ["unicornpajama"] = { label = "Pigiama - Unicorn", weight = 100, stack = true, close = true, description = "Pigiama - Unicorn. Accessorio per il tuo animale." },
    ["duckpajama"] = { label = "Pigiama - Duck", weight = 100, stack = true, close = true, description = "Pigiama - Duck. Accessorio per il tuo animale." },
    ["chrismaspajama"] = { label = "Pigiama - Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - Chrismas. Accessorio per il tuo animale." },
    ["greenchrismaspajama"] = { label = "Pigiama - verde Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - verde Chrismas. Accessorio per il tuo animale." },
    ["whitechrismaspajama"] = { label = "Pigiama - bianco Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - bianco Chrismas. Accessorio per il tuo animale." },
    ["brownchrismaspajama"] = { label = "Pigiama - marrone Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - marrone Chrismas. Accessorio per il tuo animale." },
    ["greychrismaspajama"] = { label = "Pigiama - grigio Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - grigio Chrismas. Accessorio per il tuo animale." },
    ["redchrismaspajama"] = { label = "Pigiama - rosso Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - rosso Chrismas. Accessorio per il tuo animale." },
    ["cyanchrismaspajama"] = { label = "Pigiama - ciano Chrismas", weight = 100, stack = true, close = true, description = "Pigiama - ciano Chrismas. Accessorio per il tuo animale." },
    ["camovest"] = { label = "Gilet - mimetico", weight = 100, stack = true, close = true, description = "Gilet - mimetico. Accessorio per il tuo animale." },
    ["camored"] = { label = "Gilet - mimetico rosso", weight = 100, stack = true, close = true, description = "Gilet - mimetico rosso. Accessorio per il tuo animale." },
    ["camoblack"] = { label = "Gilet - mimetico nero", weight = 100, stack = true, close = true, description = "Gilet - mimetico nero. Accessorio per il tuo animale." },
    ["camobluewhite"] = { label = "Gilet - mimetico blu e bianco", weight = 100, stack = true, close = true, description = "Gilet - mimetico blu e bianco. Accessorio per il tuo animale." },
    ["camoblueyellow"] = { label = "Gilet - mimetico blu e giallo", weight = 100, stack = true, close = true, description = "Gilet - mimetico blu e giallo. Accessorio per il tuo animale." },
    ["camodarkblue"] = { label = "Gilet - mimetico blu scuro", weight = 100, stack = true, close = true, description = "Gilet - mimetico blu scuro. Accessorio per il tuo animale." },
    ["trouble"] = { label = "Felpa Trouble", weight = 100, stack = true, close = true, description = "Felpa Trouble. Accessorio per il tuo animale." },
    ["troublered"] = { label = "Trouble rosso", weight = 100, stack = true, close = true, description = "Trouble rosso. Accessorio per il tuo animale." },
    ["troublepurple"] = { label = "Trouble viola", weight = 100, stack = true, close = true, description = "Trouble viola. Accessorio per il tuo animale." },
    ["troublegreen"] = { label = "Trouble verde", weight = 100, stack = true, close = true, description = "Trouble verde. Accessorio per il tuo animale." },
    ["troubleyellow"] = { label = "Trouble giallo", weight = 100, stack = true, close = true, description = "Trouble giallo. Accessorio per il tuo animale." },
    ["troubleorange"] = { label = "Trouble arancione", weight = 100, stack = true, close = true, description = "Trouble arancione. Accessorio per il tuo animale." },
    ["troublepink"] = { label = "Trouble rosa", weight = 100, stack = true, close = true, description = "Trouble rosa. Accessorio per il tuo animale." },
    ["troubleblue"] = { label = "Trouble blu", weight = 100, stack = true, close = true, description = "Trouble blu. Accessorio per il tuo animale." },
    ["blacksweater"] = { label = "Maglione - nero", weight = 100, stack = true, close = true, description = "Maglione - nero. Accessorio per il tuo animale." },
    ["pinksweater"] = { label = "Maglione - rosa", weight = 100, stack = true, close = true, description = "Maglione - rosa. Accessorio per il tuo animale." },
    ["greensweater"] = { label = "Maglione - verde", weight = 100, stack = true, close = true, description = "Maglione - verde. Accessorio per il tuo animale." },
    ["redsweater"] = { label = "Maglione - rosso", weight = 100, stack = true, close = true, description = "Maglione - rosso. Accessorio per il tuo animale." },
    ["prop1"] = { label = "Bambola cowboy - blu", weight = 100, stack = true, close = true, description = "Bambola cowboy - blu. Accessorio per il tuo animale." },
    ["prop2"] = { label = "Bambola cowboy - nero", weight = 100, stack = true, close = true, description = "Bambola cowboy - nero. Accessorio per il tuo animale." },
    ["prop3"] = { label = "Bambola cowboy - marrone", weight = 100, stack = true, close = true, description = "Bambola cowboy - marrone. Accessorio per il tuo animale." },
    ["prop4"] = { label = "Bambola cowboy - verde", weight = 100, stack = true, close = true, description = "Bambola cowboy - verde. Accessorio per il tuo animale." },
    ["spiderprop1"] = { label = "Gilet - Spider nero", weight = 100, stack = true, close = true, description = "Gilet - Spider nero. Accessorio per il tuo animale." },
    ["spiderprop2"] = { label = "Gilet - Spider marrone", weight = 100, stack = true, close = true, description = "Gilet - Spider marrone. Accessorio per il tuo animale." },
    ["mechanicuniform"] = { label = "Uniforme da meccanico", weight = 100, stack = true, close = true, description = "Uniforme da meccanico. Accessorio per il tuo animale." },
    ["beigescarf"] = { label = "Sciarpa floreale - beige", weight = 100, stack = true, close = true, description = "Sciarpa floreale - beige. Accessorio per il tuo animale." },
    ["grayscarf"] = { label = "Sciarpa floreale - grigio", weight = 100, stack = true, close = true, description = "Sciarpa floreale - grigio. Accessorio per il tuo animale." },
    ["bluescarf"] = { label = "Sciarpa floreale - blu", weight = 100, stack = true, close = true, description = "Sciarpa floreale - blu. Accessorio per il tuo animale." },
    ["lightpinkscarf"] = { label = "Sciarpa floreale - rosa chiaro", weight = 100, stack = true, close = true, description = "Sciarpa floreale - rosa chiaro. Accessorio per il tuo animale." },
    ["pinkscarf"] = { label = "Sciarpa floreale - rosa", weight = 100, stack = true, close = true, description = "Sciarpa floreale - rosa. Accessorio per il tuo animale." },
    ["medfullyvest"] = { label = "integrale Gilet Medico rosso", weight = 100, stack = true, close = true, description = "integrale Gilet Medico rosso. Accessorio per il tuo animale." },
    ["medfullyvestpurple"] = { label = "integrale Gilet Medico viola", weight = 100, stack = true, close = true, description = "integrale Gilet Medico viola. Accessorio per il tuo animale." },
    ["k9fullyvestblack"] = { label = "Gilet integrale K9", weight = 100, stack = true, close = true, description = "Gilet integrale K9. Accessorio per il tuo animale." },
    ["k9fullyvestblackpolice"] = { label = "Gilet integrale K9 Polizia", weight = 100, stack = true, close = true, description = "Gilet integrale K9 Polizia. Accessorio per il tuo animale." },
    ["k9fullyvestbluepolice"] = { label = "Gilet integrale K9 Polizia - blu", weight = 100, stack = true, close = true, description = "Gilet integrale K9 Polizia - blu. Accessorio per il tuo animale." },
    ["k9fullyvestyellowpolice"] = { label = "Gilet integrale K9 Polizia - giallo", weight = 100, stack = true, close = true, description = "Gilet integrale K9 Polizia - giallo. Accessorio per il tuo animale." },
    ["k9fullyvestcammopolice"] = { label = "Gilet integrale K9 Polizia - mimetico", weight = 100, stack = true, close = true, description = "Gilet integrale K9 Polizia - mimetico. Accessorio per il tuo animale." },
    ["policestylishsweater"] = { label = "Maglione elegante - polizia", weight = 100, stack = true, close = true, description = "Maglione elegante - polizia. Accessorio per il tuo animale." },
    ["whiteredstylishsweater"] = { label = "Maglione elegante - bianco e rosso chiaro", weight = 100, stack = true, close = true, description = "Maglione elegante - bianco e rosso chiaro. Accessorio per il tuo animale." },
    ["purpleblackstylishsweater"] = { label = "Maglione elegante - viola e nero", weight = 100, stack = true, close = true, description = "Maglione elegante - viola e nero. Accessorio per il tuo animale." },
    ["yellowrainbowstylishsweater"] = { label = "Maglione elegante - giallo e arcobaleno", weight = 100, stack = true, close = true, description = "Maglione elegante - giallo e arcobaleno. Accessorio per il tuo animale." },
    ["whiterainbowstylishsweater"] = { label = "Maglione elegante - bianco e arcobaleno", weight = 100, stack = true, close = true, description = "Maglione elegante - bianco e arcobaleno. Accessorio per il tuo animale." },
    ["lovemomstylishsweater"] = { label = "Maglione elegante - Love mom", weight = 100, stack = true, close = true, description = "Maglione elegante - Love mom. Accessorio per il tuo animale." },
    ["lovedadstylishsweater"] = { label = "Maglione elegante - Love dad", weight = 100, stack = true, close = true, description = "Maglione elegante - Love dad. Accessorio per il tuo animale." },
    ["satanhoodie"] = { label = "Felpa con cappuccio - Satan", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - Satan. Accessorio per il tuo animale." },
    ["emohoodie"] = { label = "Felpa con cappuccio - Emo", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - Emo. Accessorio per il tuo animale." },
    ["witchhoodie"] = { label = "Felpa con cappuccio - Witch", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - Witch. Accessorio per il tuo animale." },
    ["witchfamilyhoodie"] = { label = "Felpa con cappuccio - Witch Family", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - Witch Family. Accessorio per il tuo animale." },
    ["blackmchoodie"] = { label = "Felpa con cappuccio - Full nero MC", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - Full nero MC. Accessorio per il tuo animale." },
    ["aodmchoodie"] = { label = "Felpa con cappuccio - Angels of Death MC", weight = 100, stack = true, close = true, description = "Felpa con cappuccio - Angels of Death MC. Accessorio per il tuo animale." },
    ["thelostmchoodie"] = { label = "Felpa con cappuccio - The lost MC", weight = 100, stack = true, close = true, description = "Accessorio o prodotto per il tuo animale." },
    ["halowingsgoldwhite"] = { label = "Ali con aureola - oro e bianco", weight = 100, stack = true, close = true, description = "Ali con aureola - oro e bianco. Accessorio per il tuo animale." },
    ["halowingsgold"] = { label = "Ali con aureola - oro", weight = 100, stack = true, close = true, description = "Ali con aureola - oro. Accessorio per il tuo animale." },
    ["halowingssilverblack"] = { label = "Ali con aureola - argento e nero", weight = 100, stack = true, close = true, description = "Ali con aureola - argento e nero. Accessorio per il tuo animale." },
    ["halowingsgoldpink"] = { label = "Ali con aureola - oro e rosa", weight = 100, stack = true, close = true, description = "Ali con aureola - oro e rosa. Accessorio per il tuo animale." },
    ["yellowflowers"] = { label = "Fiori - giallo", weight = 100, stack = true, close = true, description = "Fiori - giallo. Accessorio per il tuo animale." },
    ["pinkflowers"] = { label = "Fiori - rosa", weight = 100, stack = true, close = true, description = "Fiori - rosa. Accessorio per il tuo animale." },
    ["whiteflowers"] = { label = "Fiori - bianco", weight = 100, stack = true, close = true, description = "Fiori - bianco. Accessorio per il tuo animale." },
    ["heartsbow"] = { label = "Fiocco - rosa", weight = 100, stack = true, close = true, description = "Fiocco - rosa. Accessorio per il tuo animale." },
    ["flowersdarkbow"] = { label = "Fiocco - fiori scuro", weight = 100, stack = true, close = true, description = "Fiocco - fiori scuro. Accessorio per il tuo animale." },
    ["bluelinesbow"] = { label = "Fiocco - blu Lines", weight = 100, stack = true, close = true, description = "Fiocco - blu Lines. Accessorio per il tuo animale." },
    ["greenplaidbow"] = { label = "Fiocco - verde scozzese", weight = 100, stack = true, close = true, description = "Fiocco - verde scozzese. Accessorio per il tuo animale." },
    ["pinkbow"] = { label = "Fiocco - rosa", weight = 100, stack = true, close = true, description = "Fiocco - rosa. Accessorio per il tuo animale." },
    ["redsailorcap"] = { label = "Berretto da marinaio - rosso", weight = 100, stack = true, close = true, description = "Berretto da marinaio - rosso. Accessorio per il tuo animale." },
    ["policecap"] = { label = "Berretto della polizia", weight = 100, stack = true, close = true, description = "Berretto della polizia. Accessorio per il tuo animale." },
    ["kapolicecap"] = { label = "Berretto Kanpolis", weight = 100, stack = true, close = true, description = "Berretto Kanpolis. Accessorio per il tuo animale." },
    ["medicalcap"] = { label = "Berretto medico", weight = 100, stack = true, close = true, description = "Berretto medico. Accessorio per il tuo animale." },
    ["bluesailorcap"] = { label = "Berretto da marinaio - blu", weight = 100, stack = true, close = true, description = "Berretto da marinaio - blu. Accessorio per il tuo animale." },
    ["pumpkinhat"] = { label = "zucca Cappello", weight = 100, stack = true, close = true, description = "zucca Cappello. Accessorio per il tuo animale." },
    ["devilearsred"] = { label = "Orecchie da diavolo - rosso", weight = 100, stack = true, close = true, description = "Orecchie da diavolo - rosso. Accessorio per il tuo animale." },
    ["devilearsblack"] = { label = "Orecchie da diavolo - nero", weight = 100, stack = true, close = true, description = "Orecchie da diavolo - nero. Accessorio per il tuo animale." },
    ["devilearsgreen"] = { label = "Orecchie da diavolo - verde", weight = 100, stack = true, close = true, description = "Orecchie da diavolo - verde. Accessorio per il tuo animale." },
    ["devilearspink"] = { label = "Orecchie da diavolo - rosa", weight = 100, stack = true, close = true, description = "Orecchie da diavolo - rosa. Accessorio per il tuo animale." },
    ["devilearsyellow"] = { label = "Orecchie da diavolo - giallo", weight = 100, stack = true, close = true, description = "Orecchie da diavolo - giallo. Accessorio per il tuo animale." },
    ["devilearsblue"] = { label = "Orecchie da diavolo - blu", weight = 100, stack = true, close = true, description = "Orecchie da diavolo - blu. Accessorio per il tuo animale." },
    ["wgsailorhat"] = { label = "Cappello da marinaio - bianco e oro", weight = 100, stack = true, close = true, description = "Cappello da marinaio - bianco e oro. Accessorio per il tuo animale." },
    ["piratehat"] = { label = "Cappello da pirata - nero", weight = 100, stack = true, close = true, description = "Cappello da pirata - nero. Accessorio per il tuo animale." },
    ["wizhatwhite"] = { label = "Cappello da mago - bianco", weight = 100, stack = true, close = true, description = "Cappello da mago - bianco. Accessorio per il tuo animale." },
    ["wizhatpurple"] = { label = "Cappello da mago - viola", weight = 100, stack = true, close = true, description = "Cappello da mago - viola. Accessorio per il tuo animale." },
    ["cowdog"] = { label = "Cappello da mucca", weight = 100, stack = true, close = true, description = "Cappello da mucca. Accessorio per il tuo animale." },
    ["beaniewhite"] = { label = "Berretto di lana - bianco", weight = 100, stack = true, close = true, description = "Berretto di lana - bianco. Accessorio per il tuo animale." },
    ["beanieyellow"] = { label = "Berretto di lana - giallo", weight = 100, stack = true, close = true, description = "Berretto di lana - giallo. Accessorio per il tuo animale." },
    ["beanieblue"] = { label = "Berretto di lana - blu", weight = 100, stack = true, close = true, description = "Berretto di lana - blu. Accessorio per il tuo animale." },
    ["beaniepink"] = { label = "Berretto di lana - rosa", weight = 100, stack = true, close = true, description = "Berretto di lana - rosa. Accessorio per il tuo animale." },
    ["whitecap"] = { label = "Berretto - bianco", weight = 100, stack = true, close = true, description = "Berretto - bianco. Accessorio per il tuo animale." },
    ["whitepinkcap"] = { label = "Berretto - bianco rosa", weight = 100, stack = true, close = true, description = "Berretto - bianco rosa. Accessorio per il tuo animale." },
    ["whiteyellowcap"] = { label = "Berretto - bianco giallo", weight = 100, stack = true, close = true, description = "Berretto - bianco giallo. Accessorio per il tuo animale." },
    ["cowboyhat"] = { label = "Cappello da cowboy", weight = 100, stack = true, close = true, description = "Cappello da cowboy. Accessorio per il tuo animale." },
    ["deerantlerbrown"] = { label = "Corna di cervo - marrone", weight = 100, stack = true, close = true, description = "Corna di cervo - marrone. Accessorio per il tuo animale." },
    ["deerantlerwhite"] = { label = "Corna di cervo - bianco", weight = 100, stack = true, close = true, description = "Corna di cervo - bianco. Accessorio per il tuo animale." },
    ["deerantlerred"] = { label = "Corna di cervo - rosso", weight = 100, stack = true, close = true, description = "Corna di cervo - rosso. Accessorio per il tuo animale." },
    ["deerantlerlightbrown"] = { label = "Corna di cervo - marrone chiaro", weight = 100, stack = true, close = true, description = "Corna di cervo - marrone chiaro. Accessorio per il tuo animale." },
    ["deerantlerblack"] = { label = "Corna di cervo - nero", weight = 100, stack = true, close = true, description = "Corna di cervo - nero. Accessorio per il tuo animale." },
    ["blackhearttiara"] = { label = "Tiara a cuore - nero", weight = 100, stack = true, close = true, description = "Tiara a cuore - nero. Accessorio per il tuo animale." },
    ["redhearttiara"] = { label = "Tiara a cuore - rosso", weight = 100, stack = true, close = true, description = "Tiara a cuore - rosso. Accessorio per il tuo animale." },
    ["bluehearttiara"] = { label = "Tiara a cuore - blu", weight = 100, stack = true, close = true, description = "Tiara a cuore - blu. Accessorio per il tuo animale." },
    ["pinkhearttiara"] = { label = "Tiara a cuore - rosa", weight = 100, stack = true, close = true, description = "Tiara a cuore - rosa. Accessorio per il tuo animale." },
    ["purplehearttiara"] = { label = "Tiara a cuore - viola", weight = 100, stack = true, close = true, description = "Tiara a cuore - viola. Accessorio per il tuo animale." },
    ["greennoelhat"] = { label = "Cappello natalizio - verde", weight = 100, stack = true, close = true, description = "Cappello natalizio - verde. Accessorio per il tuo animale." },
    ["noelhat"] = { label = "Cappello natalizio", weight = 100, stack = true, close = true, description = "Cappello natalizio. Accessorio per il tuo animale." },
    ["yellownoelhat"] = { label = "Cappello natalizio - giallo", weight = 100, stack = true, close = true, description = "Cappello natalizio - giallo. Accessorio per il tuo animale." },
    ["orangenoelhat"] = { label = "Cappello natalizio - arancione", weight = 100, stack = true, close = true, description = "Cappello natalizio - arancione. Accessorio per il tuo animale." },
    ["pinknoelhat"] = { label = "Cappello natalizio - rosa", weight = 100, stack = true, close = true, description = "Cappello natalizio - rosa. Accessorio per il tuo animale." },
    ["bluenoelhat"] = { label = "Cappello natalizio - blu", weight = 100, stack = true, close = true, description = "Cappello natalizio - blu. Accessorio per il tuo animale." },
    ["snowcyanhat"] = { label = "Cappello invernale - ciano", weight = 100, stack = true, close = true, description = "Cappello invernale - ciano. Accessorio per il tuo animale." },
    ["snowpinkhat"] = { label = "Cappello invernale - rosa", weight = 100, stack = true, close = true, description = "Cappello invernale - rosa. Accessorio per il tuo animale." },
    ["snowblackhat"] = { label = "Cappello invernale - Pig nero", weight = 100, stack = true, close = true, description = "Cappello invernale - Pig nero. Accessorio per il tuo animale." },
    ["snowbeigehat"] = { label = "Cappello invernale - Bunny beige", weight = 100, stack = true, close = true, description = "Cappello invernale - Bunny beige. Accessorio per il tuo animale." },
    ["snowredhat"] = { label = "Cappello invernale - Striped rosso", weight = 100, stack = true, close = true, description = "Cappello invernale - Striped rosso. Accessorio per il tuo animale." },
    ["snowbluehat"] = { label = "Cappello invernale - Striped blu", weight = 100, stack = true, close = true, description = "Cappello invernale - Striped blu. Accessorio per il tuo animale." },
    ["snowpenguinhat"] = { label = "Cappello invernale - Penguin", weight = 100, stack = true, close = true, description = "Cappello invernale - Penguin. Accessorio per il tuo animale." },
    ["snowfishhat"] = { label = "Cappello invernale - Fish", weight = 100, stack = true, close = true, description = "Cappello invernale - Fish. Accessorio per il tuo animale." },
    ["darkbluepolicecap"] = { label = "Berretto della polizia - blu scuro", weight = 100, stack = true, close = true, description = "Berretto della polizia - blu scuro. Accessorio per il tuo animale." },
    ["whiteandgoldpolicecap"] = { label = "Berretto della polizia - bianco e oro", weight = 100, stack = true, close = true, description = "Berretto della polizia - bianco e oro. Accessorio per il tuo animale." },
    ["blackpolicecap"] = { label = "Berretto della polizia - nero", weight = 100, stack = true, close = true, description = "Berretto della polizia - nero. Accessorio per il tuo animale." },
    ["propellerhat"] = { label = "Cappello con elica", weight = 100, stack = true, close = true, description = "Cappello con elica. Accessorio per il tuo animale." },
    ["pinksunglasses"] = { label = "Occhiali da sole - rosa", weight = 100, stack = true, close = true, description = "Occhiali da sole - rosa. Accessorio per il tuo animale." },
    ["blacksunglasses"] = { label = "Occhiali da sole - nero", weight = 100, stack = true, close = true, description = "Occhiali da sole - nero. Accessorio per il tuo animale." },
    ["redsunglasses"] = { label = "Occhiali da sole - rosso", weight = 100, stack = true, close = true, description = "Occhiali da sole - rosso. Accessorio per il tuo animale." },
    ["whitesunglasses"] = { label = "Occhiali da sole - bianco", weight = 100, stack = true, close = true, description = "Occhiali da sole - bianco. Accessorio per il tuo animale." },
    ["roundsunglasses"] = { label = "Occhiali da sole - rotonda", weight = 100, stack = true, close = true, description = "Occhiali da sole - rotonda. Accessorio per il tuo animale." },
    ["butterflycyanglasses"] = { label = "Occhiali a farfalla - ciano", weight = 100, stack = true, close = true, description = "Occhiali a farfalla - ciano. Accessorio per il tuo animale." },
    ["butterflygreenglasses"] = { label = "Occhiali a farfalla - verde", weight = 100, stack = true, close = true, description = "Occhiali a farfalla - verde. Accessorio per il tuo animale." },
    ["butterflyyellowglasses"] = { label = "Occhiali a farfalla - giallo", weight = 100, stack = true, close = true, description = "Occhiali a farfalla - giallo. Accessorio per il tuo animale." },
    ["butterflypinkglasses"] = { label = "Occhiali a farfalla - rosa", weight = 100, stack = true, close = true, description = "Occhiali a farfalla - rosa. Accessorio per il tuo animale." },

-- Arredi e altri oggetti (11)
    ["cdev_pets_tree1_a"] = { label = "Cuccia casetta sull'albero A", weight = 100, stack = true, close = true },
    ["cdev_pets_tree1_b"] = { label = "Cuccia casetta sull'albero B", weight = 100, stack = true, close = true },
    ["cdev_pets_tree1_c"] = { label = "Cuccia casetta sull'albero C", weight = 100, stack = true, close = true },
    ["cdev_pets_tree1_d"] = { label = "Cuccia casetta sull'albero D", weight = 100, stack = true, close = true },
    ["cdev_pets_tree2_a"] = { label = "Cuccia grande casetta sull'albero A", weight = 100, stack = true, close = true },
    ["cdev_pets_tree2_b"] = { label = "Cuccia grande casetta sull'albero B", weight = 100, stack = true, close = true },
    ["cdev_pets_plataform1"] = { label = "Piattaforma", weight = 100, stack = true, close = true },
    ["cdev_pets_sandbox1_a"] = { label = "Sabbiera - marrone", weight = 100, stack = true, close = true },
    ["cdev_pets_sandbox1_b"] = { label = "Sabbiera - marrone medio", weight = 100, stack = true, close = true },
    ["cdev_pets_sandbox1_c"] = { label = "Sabbiera - marrone chiaro", weight = 100, stack = true, close = true },
    ["cdev_pets_sandbox1_d"] = { label = "Sabbiera - marrone", weight = 100, stack = true, close = true },

['hoop'] = {
    label = 'Cerchio',
    weight = 100,
    stack = true,
    close = true
},
    -- ALTRI PESCI
    ['carp'] = { label = 'Carpa', weight = 1, stack = false },
    ['crab'] = { label = 'Granchio', weight = 1, stack = false },
    ['catfish'] = { label = 'Pesce gatto', weight = 1, stack = false },
    ['tarpon'] = { label = 'Tarpon', weight = 1, stack = false },
    ['barracuda'] = { label = 'Barracuda', weight = 1, stack = false },
    ['discus'] = { label = 'Discus', weight = 1, stack = false },
    ['snapper'] = { label = 'Dentice', weight = 1, stack = false },
    ['sturgeon'] = { label = 'Storione', weight = 1, stack = false },
    ['mojarra_fish'] = { label = 'Mojarra', weight = 1, stack = false },
    ['bocachico_fish'] = { label = 'Bocachico', weight = 1, stack = false },
    ['disco_fish'] = { label = 'Pesce disco', weight = 1, stack = false },
    ['koi_fish'] = { label = 'Pesce Koi', weight = 1, stack = false },
    ['angelfishemperror'] = { label = 'Pesce Angelo Imperatore', weight = 1, stack = false },
    ['crystal_catfish'] = { label = 'Pesce gatto di cristallo', weight = 1, stack = false },
    ['flying_fish'] = { label = 'Pesce volante', weight = 1, stack = false },
    ['hammerhead'] = { label = 'Squalo martello', weight = 1, stack = false },

    -- ATTREZZI DA PESCA AVANZATI
    ['anchor'] = { label = 'Ancora', weight = 15, stack = false, client = { export = 'i_fishing.ToggleAnchor' } },
  
['fishing_net'] = {
    label = 'Rete da pesca',
    weight = 15,
    stack = false,
    consume = 0,
    breakChance = 8,
    client = {
        export = 'i_fishing.createNet'
    }
},

    ['fishing_net_plus'] = { label = 'Rete da pesca ++', weight = 15, stack = false,    breakChance = 5, client = { export = 'i_fishing.createNet' } },
    ['crab_cage'] = { label = 'Gabbia per granchi', weight = 15, stack = false, client = { export = 'i_fishing.createCage' } },
    ['crab_cage_plus'] = { label = 'Gabbia per granchi ++', weight = 15, stack = false, client = { export = 'i_fishing.createCage' } },
	["onion_seed"] = { label = 'Semi di cipolla', weight = 1 },
	["carrot_seed"] = { label = 'Semi di carota', weight = 1 },
	["mushroom_seed"] = { label = 'Semi di fungo', weight = 1 },
	["tomato_seed"] = { label = "Semi di pomodoro", weight = 1 },

	["onion"] = { label = 'Cipolla', weight = 1 },
	["carrot"] = { label = 'Carota', weight = 1 },
	["mushroom"] = { label = 'Fungo', weight = 1},
	["tomato"] = { label = 'Pomodoro', weight = 1},
	["weed"] = { label = 'Erba', weight = 1},

	["fuse1"] = {label = "Fusibile di bronzo", weight = 1},
	["fuse2"] = {label = "Fusibile d'argento", weight = 1},
	["fuse3"] = {label = "Fusibile d'oro", weight = 1},

	["waterfilter1"] = {label = "Filtro dell'acqua di bronzo", weight = 1},
	["waterfilter2"] = {label = "Filtro dell'acqua d'argento", weight = 1},
	["waterfilter3"] = {label = "Filtro dell'acqua d'oro", weight = 1},

	["fertilizermixer1"] = {label = "Miscelatore per fertilizzante di bronzo", weight = 1},
	["fertilizermixer2"] = {label = "Miscelatore per fertilizzante d'argento", weight = 1},
	["fertilizermixer3"] = {label = "Miscelatore per fertilizzante d'oro", weight = 1},

	["sm_waterpipe"] = {label = "Tubo dell'acqua", weight = 1},
	["sm_watertank"] = {label = "Serbatoio dell'acqua", weight = 1},
	["sm_fertilizer"] = {label = "Fertilizzante", weight = 1},


	['tessera_ammu_nation'] = {
		label = 'Tessera Membro Poligono',
		weight = 0,
		stack = false,
		close = true,
		description = 'Garantisce al titolare il 15% di sconto su tutte le prove pratiche al poligono.'
	},
['documentistatali'] = {
		label = 'Documenti Ufficiali',
		weight = 0,
		stack = false,
		close = true,
	},
    
	['certificato_armi'] = {
        label = 'Certificato del Poligono',
        weight = 0,
        stack = false,
        close = true,
        description = 'Documento ufficiale che attesta l\'idoneità al maneggio delle armi da fuoco.',
        client = {
            export = 'GiaMMarK_armeria.certificato_armi' 
        }
    },

['certificato_medico'] = {
        label = 'Certificato Medico',
        weight = 10,
        stack = false,
        close = true,
        consume = 0, -- FONDAMENTALE: impedisce che il certificato scompaia quando lo usi
        description = 'Documento ufficiale rilasciato dal S.A. Medical Department.',
        client = {
            export = 'GiaMMarK_ospedale.certificato_medico'
        }
    },
	
['ephedrine'] = {
    label = 'Efedrina',
    weight = 10,
    stack = true,
    close = true,
    description = 'Un composto chimico essenziale per la sintesi di sostanze particolari.',
},

['acetone'] = {
    label = 'Acetone',
    weight = 15,
    stack = true,
    close = true,
    description = 'Solvente chimico industriale molto infiammabile.',
},

['lithium'] = {
    label = 'Litio',
    weight = 15,
    stack = true,
    close = true,
    description = 'Metallo reattivo estratto solitamente dalle batterie.',
},

-- [[ PRODOTTI DELLA LAVORAZIONE ]] --

['raw_meth'] = {
    label = 'Metanfetamina Grezza',
    weight = 15,
    stack = true,
    close = true,
    description = 'Un grosso blocco di metanfetamina appena cucinata, ancora da lavorare.',
},

['cracked_meth'] = {
    label = 'Metanfetamina Frammentata',
    weight = 15,
    stack = true,
    close = true,
    description = 'Cristalli di metanfetamina frantumati, pronti per essere pesati e imbustati.',
},

['atm_card'] = {
        label = 'Bancomat',
        weight = 10,
        stack = false, -- Non si impilano perché ognuno ha metadati unici
        consume = 0,
        description = 'Una carta di debito bancaria.'
    },
['lettera'] = {
	label = "Lettera",
	weight = 1,
	stack = true,
	close = true,
	description = ''
},

['cartone'] = {
    label = "Cartone",
    weight = 1,
    stack = false,
    close = true,
    durability = true,
    consume = 0.25,
},

['acidoossalico'] = {
	label = "Acido Ossalico",
	weight = 1,
	stack = true,
	close = true,
},
['cartinesigarette'] = {
	label = "Cartine per sigarette",
	weight = 1,
	stack = true,
	close = true,
},

['tabletlavoro'] = {
    label = 'Riverside Management Tablet',
    weight = 815,
    stack = false,
    close = true,
    consume = 0,
    description = 'Tablet protetto per la gestione del dipartimento o della società.',
    client = {
        event = 'GiaMMarK_bossmenu:openTablet'
    }
},

['pacchetticontrabbando'] = {
	label = "Pacchetto di sigarette",
	weight = 1,
	stack = true,
	close = true,
},
['taglierina'] = {
	label = "Taglierina per carta",
	weight = 1,
	stack = true,
	close = true,
},
['sigaretteforti'] = {
	label = "Sigarette particolari",
	weight = 1,
	stack = true,
	close = true,
},
['tabaccoforte'] = {
	label = "Tabacco forte",
	weight = 1,
	stack = true,
	close = true,
},

['torture_kit'] = {
	label = 'Torture Kit',
	weight = 10,
	stack = false,
	close = true,
},
['slopstyle'] = {
    label       = 'Slopstyle',
    weight      = 10,
    stack       = false,
    close       = true,
    description = ''
},
['bmx'] = {
    label = 'BMX',
    weight = 15,
    stack = false,
    close = true,
},

['scooter'] = {
    label = 'Scooter',
    weight = 15,
    stack = false,
    close = true,
    description = 'Uno scooter per acrobazie e trick'
},

['rollers'] = {
    label = 'Rollers',
    weight = 15,
    stack = false,
    close = true,
    description = 'Pattini a rotelle per acrobazie e trick'
},

["bread"] = {
    label = "Pane",
    weight = 5,
    stack = true, -- assumendo che 'unique' falso significhi impilabile
    close = true,
    description = "Pane",
    client = {
        image = "bread.png",
    }
},

["earthworm"] = {
    label = "Lombrico",
    weight = 5,
    stack = true,
    close = true,
    description = "Lombrico",
    client = {
        image = "earthworm.png",
    }
},

["dough"] = {
    label = "Impasto",
    weight = 5,
    stack = true,
    close = true,
    description = "Impasto",
    client = {
        image = "dough.png",
    }
},

["grub"] = {
    label = "Larva",
    weight = 5,
    stack = true,
    close = true,
    description = "Larva",
    client = {
        image = "grub.png",
    }
},

["caddis_fly"] = {
    label = "Tricottero",
    weight = 5,
    stack = true,
    close = true,
    description = "Tricottero",
    client = {
        image = "caddis_fly.png",
    }
},

['animal_feed'] = { label = 'Mangime Animali', weight = 10, stack = true },
['animal_water'] = { label = 'Acqua Animali', weight = 10, stack = true },
['animal_medicine'] = { label = 'Medicina Animali', weight = 10, stack = true },
['animal_brush'] = { label = 'Spazzola Animali', weight = 75, stack = true },
['vet_document'] = { label = 'Documento Veterinario', weight = 15, stack = true },
['vet_ticket'] = { label = 'Ticket Veterinario', weight = 15, stack = true },
['meat'] = { label = 'Carne', weight = 15, stack = true },

["cheese"] = {
    label = "Formaggio",
    weight = 5,
    stack = true,
    close = true,
    description = "Formaggio",
    client = {
        image = "cheese.png",
    }
},

    ['adrenaline_syringe'] = {
		label = 'Siringa Adrenalina',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},

    ['siringarossa'] = {
		label = 'Siringa Rossa',
		weight = 5,  -- Prima era 10
		stack = true,
		close = true,
	},  
    ["bandage"] = {      -- Assicurati che non ci siano duplicati nell'items.lua originale
        label = 'Benda',
        description = 'Una semplice benda per fermare le emorragie minori',
        weight = 25,
        server = {
            export = "wasabi_ambulance_v2.bandage"
        }
    },
    ["medkitindividuale"] = {
        label = 'Kit Medico individuale',
        description = 'Un kit medico per curare le ferite',
        weight = 10,
    },
    ["medkit"] = {
        label = 'Kit Medico',
        description = 'Un kit medico per curare le ferite',
        weight = 15,
        server = {
            export = "wasabi_ambulance_v2.medkit"
        }
    },
    ["firstaidkit"] = {
        label = 'Kit di Primo Soccorso',
        description = 'Un kit di primo soccorso completo per ferite gravi',
        weight = 315,
        server = {
            export = "wasabi_ambulance_v2.firstaidkit"
        }
    },
    ["forceps"] = {
        label = 'Pinza Chirurgica',
        description = 'Usata per trattare le ferite da arma da fuoco',
        weight = 10,
    },
    ["suture"] = {
        label = 'Sutura',
        description = 'Usata per trattare i tagli',
        weight = 25,
    },
    ["splint"] = {
        label = 'Stecca',
        description = 'Usata per trattare le ossa rotte',
        weight = 15,
    },
    ["traumakit"] = {
        label = 'Kit Trauma',
        description = 'Usato per trattare traumi da forza contundente',
        weight = 75,
    },
    ["medbag"] = {
        label = 'Borsa Medica',
        description = 'Una borsa medica portatile contenente forniture',
        weight = 15,
        stack = false,
        close = true,
        consume = 0,
        server = {
            export = "wasabi_ambulance_v2.medbag"
        }
    },
["fly"] = {
    label = "Mosca",
    weight = 5,
    stack = true,
    close = true,
    description = "Mosca",
    client = {
        image = "fly.png",
    }
},

["dragonfly"] = {
    label = "Libellula",
    weight = 5,
    stack = true,
    close = true,
    description = "Libellula",
    client = {
        image = "dragonfly.png",
    }
},

["grasshoper"] = {
    label = "Cavalletta",
    weight = 5,
    stack = true,
    close = true,
    description = "Cavalletta",
    client = {
        image = "grasshoper.png",
    }
},

["shrimp"] = {
    label = "Gamberetto",
    weight = 5,
    stack = true,
    close = true,
    description = "Gamberetto",
    client = {
        image = "shrimp.png",
    }
},

["leech"] = {
    label = "Sanguisuga",
    weight = 5,
    stack = true,
    close = true,
    description = "Sanguisuga",
    client = {
        image = "leech.png",
    }
},

["snail"] = {
    label = "Lumaca",
    weight = 5,
    stack = true,
    close = true,
    description = "Lumaca",
    client = {
        image = "snail.png",
    }
},

["liver"] = {
    label = "Fegato",
    weight = 5,
    stack = true,
    close = true,
    description = "Fegato",
    client = {
        image = "liver.png",
    }
},

-- Fili
["express_fishing_super_line"] = {
    label = "Express Super Line 0.1mm",
    weight = 35,
    stack = true, -- assumendo che 'unique' falso significhi impilabile
    close = true,
    description = "Express Super Line 0.1mm",
    client = {
        image = "express_fishing_super_line.png",
    }
},

["syberia_indiana_green"] = {
    label = "Indiana Verde 0.14mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Verde 0.14mm",
    client = {
        image = "syberia_indiana_green.png",
    }
},

["syberia_indiana_white"] = {
    label = "Indiana Bianco 0.18mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Bianco 0.18mm",
    client = {
        image = "syberia_indiana_white.png",
    }
},

["simmons_mono_original"] = {
    label = "Simmons Originale 0.25mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons Originale 0.25mm",
    client = {
        image = "simmons_mono_original.png",
    }
},

["simmons_mono_ss"] = {
    label = "Simmons SS 0.28mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons SS 0.28mm",
    client = {
        image = "simmons_mono_ss.png",
    }
},

["syberia_indiana_green_2"] = {
    label = "Indiana Verde 0.32mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Verde 0.32mm",
    client = {
        image = "syberia_indiana_green_2.png",
    }
},

["syberia_indiana_white_2"] = {
    label = "Indiana Bianco 0.36mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Indiana Bianco 0.36mm",
    client = {
        image = "syberia_indiana_white_2.png",
    }
},

["snake_power_line_clr"] = {
    label = "Snake Power Line 0.41mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Snake Power Line 0.41mm",
    client = {
        image = "snake_power_line_clr.png",
    }
},

["simmons_mono_original_2"] = {
    label = "Simmons Originale 0.48mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons Originale 0.48mm",
    client = {
        image = "simmons_mono_original_2.png",
    }
},

["simmons_mono_ss_2"] = {
    label = "Simmons SS 0.52mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Simmons SS 0.52mm",
    client = {
        image = "simmons_mono_ss_2.png",
    }
},

["snake_power_line_clr_2"] = {
    label = "Snake Power Line 0.65mm",
    weight = 35,
    stack = true,
    close = true,
    description = "Snake Power Line 0.65mm",
    client = {
        image = "snake_power_line_clr_2.png",
    }
},

["solid_hipower_nylon"] = {
    label = "HiPower Nylon 0.8mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon 0.8mm",
    client = {
        image = "solid_hipower_nylon.png",
    }
},

["solid_hipower_nylon_lime"] = {
    label = "HiPower Nylon L 0.85mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon L 0.85mm",
    client = {
        image = "solid_hipower_nylon_lime.png",
    }
},

["solid_hipower_nylon_orange"] = {
    label = "HiPower Nylon O 0.9mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon O 0.9mm",
    client = {
        image = "solid_hipower_nylon_orange.png",
    }
},

["solid_hipower_nylon_2"] = {
    label = "HiPower Nylon 1.05mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon 1.05mm",
    client = {
        image = "solid_hipower_nylon_2.png",
    }
},

["solid_hipower_nylon_lime_2"] = {
    label = "HiPower Nylon L 1.15mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon L 1.15mm",
    client = {
        image = "solid_hipower_nylon_lime_2.png",
    }
},

["solid_hipower_nylon_orange_2"] = {
    label = "HiPower Nylon O 1.25mm",
    weight = 35,
    stack = true,
    close = true,
    description = "HiPower Nylon O 1.25mm",
    client = {
        image = "solid_hipower_nylon_orange_2.png",
    }
},

-- Canne
["ufe_telerod_370"] = {
    label = "UFE Telerod 370",
    weight = 75,
    stack = false, -- non impilabile
    close = true,
    description = "UFE Telerod 370",
    client = {
        image = "ufe_telerod_370.png",
    }
},

["carptack_feeder_master_15"] = {
    label = "Carptack Feeder Master 15",
    weight = 75,
    stack = false,
    close = true,
    description = "Carptack Feeder Master 15",
    client = {
        image = "carptack_feeder_master_15.png",
    }
},

["sakura_tsubarea_tsa_552_xul"] = {
    label = "Sakura Tsubarea TSA 552 XUL",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Tsubarea TSA 552 XUL",
    client = {
        image = "sakura_tsubarea_tsa_552_xul.png",
    }
},

["carpex_hybid_carp_270"] = {
    label = "Carpex Hybid Carp 270",
    weight = 75,
    stack = false,
    close = true,
    description = "Carpex Hybid Carp 270",
    client = {
        image = "carpex_hybid_carp_270.png",
    }
},

["ufe_float_x5_30"] = {
    label = "UFE Float X5 30",
    weight = 75,
    stack = false,
    close = true,
    description = "UFE Float X5 30",
    client = {
        image = "ufe_float_x5_30.png",
    }
},

["predatek_fast_perch_15"] = {
    label = "Predatek Fast Perch 15",
    weight = 75,
    stack = false,
    close = true,
    description = "Predatek Fast Perch 15",
    client = {
        image = "predatek_fast_perch_15.png",
    }
},

["sakura_ionizer_bass_insb_701_ml"] = {
    label = "Sakura Ionizer Bass INSB 701",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Ionizer Bass INSB 701",
    client = {
        image = "sakura_ionizer_bass_insb_701_ml.png",
    }
},

["sakura_redbird_rds_602_l"] = {
    label = "Sakura Redbird RDS 602 L",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Redbird RDS 602 L",
    client = {
        image = "sakura_redbird_rds_602_l.png",
    }
},

["carpex_cobalt_carp_360"] = {
    label = "Carpex Cobalt Carp 360",
    weight = 75,
    stack = false,
    close = true,
    description = "Carpex Cobalt Carp 360",
    client = {
        image = "carpex_cobalt_carp_360.png",
    }
},

["sakura_salt_sniper_salss_611_mj1"] = {
    label = "Sakura Salt Sniper SALSS 611",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Salt Sniper SALSS 611",
    client = {
        image = "sakura_salt_sniper_salss_611_mj1.png",
    }
},

["sakura_speciz_spes_light_602_zander"] = {
    label = "Sakura Speciz Spes Light 602",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Speciz Spes Light 602",
    client = {
        image = "sakura_speciz_spes_light_602_zander.png",
    }
},

["sakura_redbird_rds_662"] = {
    label = "Sakura Redbird RDS 662",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Redbird RDS 662",
    client = {
        image = "sakura_redbird_rds_662.png",
    }
},

["sakura_salt_sniper_salss_152_h"] = {
    label = "Sakura Salt Sniper SALSS 152",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Salt Sniper SALSS 152",
    client = {
        image = "sakura_salt_sniper_salss_152_h.png",
    }
},

["predatek_seahunter_230"] = {
    label = "Predatek Seahunter 230",
    weight = 75,
    stack = false,
    close = true,
    description = "Predatek Seahunter 230",
    client = {
        image = "predatek_seahunter_230.png",
    }
},

["sakura_shukan_shuc_661_lj"] = {
    label = "Sakura Shukan Shuc 661 LJ",
    weight = 75,
    stack = false,
    close = true,
    description = "Sakura Shukan Shuc 661 LJ",
    client = {
        image = "sakura_shukan_shuc_661_lj.png",
    }
},

["ufe_powercatch_270"] = {
    label = "UFE Powercatch 270",
    weight = 75,
    stack = false,
    close = true,
    description = "UFE Powercatch 270",
    client = {
        image = "ufe_powercatch_270.png",
    }
},

["predatek_pilk_200"] = {
    label = "Predatek Pilk 200",
    weight = 75,
    stack = false,
    close = true,
    description = "Predatek Pilk 200",
    client = {
        image = "predatek_pilk_200.png",
    }
},

["robinson_carbonic_nordic_pilk_30"] = {
    label = "Robinson Carbonic Nordic Pilk",
    weight = 75,
    stack = false,
    close = true,
    description = "Robinson Carbonic Nordic Pilk",
    client = {
        image = "robinson_carbonic_nordic_pilk_30.png",
    }
},

["carptack_bottom_cast_360"] = {
    label = "Carptack Bottom Cast 360",
    weight = 75,
    stack = false,
    close = true,
    description = "Carptack Bottom Cast 360",
    client = {
        image = "carptack_bottom_cast_360.png",
    }
},

["seax_salfighter_170"] = {
    label = "Seax Salfighter 170",
    weight = 75,
    stack = false,
    close = true,
    description = "Seax Salfighter 170",
    client = {
        image = "seax_salfighter_170.png",
    }
},

-- Mulinelli
["ufe_canta_10"] = {
    label = "UFE Canta 10",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Canta 10",
    client = {
        image = "ufe_canta_10.png",
    }
},

["ufe_barracuda_2000bt"] = {
    label = "UFE Barracuda 2000BT",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Barracuda 2000BT",
    client = {
        image = "ufe_barracuda_2000bt.png",
    }
},

["sakura_alpax_158"] = {
    label = "Sakura Alpax 158",
    weight = 15,
    stack = false,
    close = true,
    description = "Sakura Alpax 158",
    client = {
        image = "sakura_alpax_158.png",
    }
},

["sakura_alpax_8158"] = {
    label = "Sakura Alpax 8158",
    weight = 15,
    stack = false,
    close = true,
    description = "Sakura Alpax 8158",
    client = {
        image = "sakura_alpax_8158.png",
    }
},
["chiaveascensore"] = {
    label = "Chiave Ascensore",
    weight = 1,
    stack = true,
    close = true,
},
["ufe_belona_150"] = {
    label = "UFE Belona 150",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Belona 150",
    client = {
        image = "ufe_belona_150.png",
    }
},

["ufe_bigspin_8000b"] = {
    label = "UFE Bigspin 8000B",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Bigspin 8000B",
    client = {
        image = "ufe_bigspin_8000b.png",
    }
},

["ufe_batara_8000g"] = {
    label = "UFE Batara 8000G",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Batara 8000G",
    client = {
        image = "ufe_batara_8000g.png",
    }
},

["ufe_batara_10r"] = {
    label = "UFE Batara 10R",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Batara 10R",
    client = {
        image = "ufe_batara_10r.png",
    }
},

["robinson_big_runner_807qd"] = {
    label = "Robinson Big Runner 807QD",
    weight = 15,
    stack = false,
    close = true,
    description = "Robinson Big Runner 807QD",
    client = {
        image = "robinson_big_runner_807qd.png",
    }
},

["spooler_catchpro_150fd"] = {
    label = "Spooler Catchpro 150FD",
    weight = 15,
    stack = false,
    close = true,
    description = "Spooler Catchpro 150FD",
    client = {
        image = "spooler_catchpro_150fd.png",
    }
},

["ufe_opensea_8000_x"] = {
    label = "UFE Opensea 8000-X",
    weight = 15,
    stack = false,
    close = true,
    description = "UFE Opensea 8000-X",
    client = {
        image = "ufe_opensea_8000-x.png",
    }
},

["spooler_catchpro_8000fd"] = {
    label = "Spooler Catchpro 8000FD",
    weight = 15,
    stack = false,
    close = true,
    description = "Spooler Catchpro 8000FD",
    client = {
        image = "spooler_catchpro_8000fd.png",
    }
},

["spooler_catchpro_1150fd"] = {
    label = "Spooler Catchpro 1150FD",
    weight = 15,
    stack = false,
    close = true,
    description = "Spooler Catchpro 1150FD",
    client = {
        image = "spooler_catchpro_1150fd.png",
    }
},

-- Ami
["ufa_bait_hook"] = {
    label = "UFA Esca",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Esca",
    client = {
        image = "ufa_bait_hook.png",
    }
},

["ufa_sproat_hook"] = {
    label = "UFA Sproat",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Sproat",
    client = {
        image = "ufa_sproat_hook.png",
    }
},

["captack_claw_xl_hook"] = {
    label = "Captack Claw XL",
    weight = 20,
    stack = true,
    close = true,
    description = "Captack Claw XL",
    client = {
        image = "captack_claw_xl_hook.png",
    }
},

["ufa_sproat_g_hook"] = {
    label = "UFA Sproat-G",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Sproat-G",
    client = {
        image = "ufa_sproat_g_hook.png",
    }
},

["carptack_carp_ss_hook"] = {
    label = "Carptack Carp S&S",
    weight = 20,
    stack = true,
    close = true,
    description = "Carptack Carp S&S",
    client = {
        image = "carptack_carp_ss_hook.png",
    }
},

["ufa_wide_gap_bl_hook"] = {
    label = "UFA Wide Gap BL",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Wide Gap BL",
    client = {
        image = "ufa_wide_gap_bl_hook.png",
    }
},

["ufa_aberdeen_hook"] = {
    label = "UFA Aberdeen",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Aberdeen",
    client = {
        image = "ufa_aberdeen_hook.png",
    }
},

["ufa_octopus_bl_hook"] = {
    label = "UFA Octopus BL",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Octopus BL",
    client = {
        image = "ufa_octopus_bl_hook.png",
    }
},

["ufa_livebait_hook"] = {
    label = "UFA Esca Viva",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Esca Viva",
    client = {
        image = "ufa_livebait_hook.png",
    }
},

["carptack_micro_barb_hook"] = {
    label = "Carptack Micro Barb",
    weight = 20,
    stack = true,
    close = true,
   description = "Carptack Micro Barb",
    client = {
        image = "carptack_micro_barb_hook.png",
    }
},

["carptack_carp_hook"] = {
    label = "Carptack Carp",
    weight = 20,
    stack = true,
    close = true,
    description = "Carptack Carp",
    client = {
        image = "carptack_carp_hook.png",
    }
},

["ufa_fusion_bl_hook"] = {
    label = "UFA Fusion BL",
    weight = 20,
    stack = true,
    close = true,
    description = "UFA Fusion BL",
    client = {
        image = "ufa_fusion_bl_hook.png",
    }
},

["predatek_octopus_hook"] = {
    label = "Predatek Octopus",
    weight = 20,
    stack = true,
    close = true,
    description = "Predatek Octopus",
    client = {
        image = "predatek_octopus_hook.png",
    }
},

["predatek_fusion_hook"] = {
    label = "Predatek Fusion",
    weight = 20,
    stack = true,
    close = true,
    description = "Predatek Fusion",
    client = {
        image = "predatek_fusion_hook.png",
    }
},

-- Attrezzatura Sub
["scuba"] = {
    label = "Attrezzatura subacquea",
    weight = 15,
    stack = false,
    close = true,
    description = "Attrezzatura subacquea",
    client = {
        image = "scuba.png",
    }
},

-- Pesci
["alligator_gar"] = {
    label = "Luccio Alligatore",
    weight = 275,
    stack = true,
    close = true,
    description = "Un luccio alligatore.",
    client = {
        image = "alligator_gar.png",
    }
},

["amur_pike"] = {
    label = "Luccio dell'Amur",
    weight = 375,
    stack = true,
    close = true,
    description = "Un luccio dell'Amur.",
    client = {
        image = "amur_pike.png",
    }
},

["atlantic_cod"] = {
    label = "Merluzzo Atlantico",
    weight = 15,
    stack = true,
    close = true,
    description = "Un merluzzo atlantico.",
    client = {
        image = "atlantic_cod.png",
    }
},

["fishing_gear"] = {
    label = "Attrezzatura da pesca",
    weight = 15,
    stack = false,
    close = true,
    description = "Attrezzatura essenziale per la pesca.",
    client = {
        image = "fishing_gear.png",
    }
},

["aquarium_pass"] = {
    label = "Pass per l'acquario",
    weight = 15,
    stack = false,
    close = true,
    description = "Pass per l'ingresso all'acquario.",
    client = {
        image = "aquarium_pass.png",
    }
},

["research_kit"] = {
    label = "Kit di ricerca",
    weight = 15,
    stack = false,
    close = true,
    description = "Un kit utile per condurre ricerche sul campo.",
    client = {
        image = "research_kit.png",
    }
},

["special_boots"] = {
    label = "Stivali speciali",
    weight = 15,
    stack = false,
    close = true,
    description = "Stivali progettati appositamente per terreni difficili.",
    client = {
        image = "special_boots.png",
    }
},

["museum_ticket"] = {
    label = "Biglietto del museo",
    weight = 15,
    stack = false,
    close = true,
    description = "Biglietto per l'ingresso al museo.",
    client = {
        image = "museum_ticket.png",
    }
},

["atlantic_salmon"] = {
    label = "Salmone Atlantico",
    weight = 15,
    stack = true,
    close = true,
    description = "Un salmone atlantico.",
    client = {
        image = "atlantic_salmon.png",
    }
},

["barbel"] = {
    label = "Barbo",
    weight = 30,
    stack = true,
    close = true,
    description = "Un barbo.",
    client = {
        image = "barbel.png",
    }
},

["beluga_sturgeon"] = {
    label = "Storione Beluga",
    weight = 132,
    stack = true,
    close = true,
    description = "Uno storione beluga.",
    client = {
        image = "beluga_sturgeon.png",
    }
},

["black_grayling"] = {
    label = "Temolo Nero",
    weight = 60,
    stack = true,
    close = true,
    description = "Un temolo nero.",
    client = {
        image = "black_grayling.png",
    }
},

["blacktip_reef_shark"] = {
    label = "Squalo Pinne Nere di Barriera",
    weight = 715,
    stack = true,
    close = true,
    description = "Uno squalo pinne nere di barriera.",
    client = {
        image = "blacktip_reef_shark.png",
    }
},

["blue_marlin"] = {
    label = "Marlin Blu",
    weight = 10,
    stack = true,
    close = true,
    description = "Un marlin blu.",
    client = {
        image = "blue_marlin.png",
    }
},

["bluefin_tuna"] = {
    label = "Tonno Rosso",
    weight = 135,
    stack = true,
    close = true,
    description = "Un tonno rosso.",
    client = {
        image = "bluefin_tuna.png",
    }
},

["bluegill"] = {
    label = "Persico Sole",
    weight = 60,
    stack = true,
    close = true,
    description = "Un persico sole.",
    client = {
        image = "bluegill.png",
    }
},

["brook_trout"] = {
    label = "Salmerino di Fonte",
    weight = 315,
    stack = true,
    close = true,
    description = "Un salmerino di fonte.",
    client = {
        image = "brook_trout.png",
    }
},

["brown_trout"] = {
    label = "Trota Fario",
    weight = 15,
    stack = true,
    close = true,
    description = "Una trota fario.",
    client = {
        image = "brown_trout.png",
    }
},

["bull_trout"] = {
    label = "Trota Toro",
    weight = 10,
    stack = true,
    close = true,
    description = "Una trota toro.",
    client = {
        image = "bull_trout.png",
    }
},

["chub"] = {
    label = "Cavedano",
    weight = 75,
    stack = true,
    close = true,
    description = "Un cavedano.",
    client = {
        image = "chub.png",
    }
},

["chum_salmon"] = {
    label = "Salmone Keta",
    weight = 30,
    stack = true,
    close = true,
    description = "Un salmone keta.",
    client = {
        image = "chum_salmon.png",
    }
},

["coho_salmon"] = {
    label = "Salmone Coho",
    weight = 15,
    stack = true,
    close = true,
    description = "Un salmone coho.",
    client = {
        image = "coho_salmon.png",
    }
},

["common_bleak"] = {
    label = "Alborella Comune",
    weight = 5,
    stack = true,
    close = true,
    description = "Un'alborella comune.",
    client = {
        image = "common_bleak.png",
    }
},

["common_bream"] = {
    label = "Brema Comune",
    weight = 200,
    stack = true,
    close = true,
    description = "Una brema comune.",
    client = {
        image = "common_bream.png",
    }
},

["common_carp"] = {
    label = "Carpa Comune",
    weight = 315,
    stack = true,
    close = true,
    description = "Una carpa comune.",
    client = {
        image = "common_carp.png",
    }
},

["crucian_carp"] = {
    label = "Carassio",
    weight = 70,
    stack = true,
    close = true,
    description = "Un carassio.",
    client = {
        image = "crucian_carp.png",
    }
},

["european_bass"] = {
    label = "Spigola Europea",
    weight = 125,
    stack = true,
    close = true,
    description = "Una spigola europea.",
    client = {
        image = "european_bass.png",
    }
},

["european_eel"] = {
    label = "Anguilla Europea",
    weight = 15,
    stack = true,
    close = true,
    description = "Un'anguilla europea.",
    client = {
        image = "european_eel.png",
    }
},

["european_flounder"] = {
    label = "Platessa Europea",
    weight = 85,
    stack = true,
    close = true,
    description = "Una platessa europea.",
    client = {
        image = "european_flounder.png",
    }
},

["european_perch"] = {
    label = "Persico Europeo",
    weight = 15,
    stack = true,
    close = true,
    description = "Un persico europeo.",
    client = {
        image = "european_perch.png",
    }
},

["european_sea_sturgeon"] = {
    label = "Storione di Mare Europeo",
    weight = 10,
    stack = true,
    close = true,
    description = "Uno storione di mare europeo.",
    client = {
        image = "european_sea_sturgeon.png",
    }
},

["electric_eel"] = {
    label = "Anguilla Elettrica",
    weight = 715,
    stack = true,
    close = true,
    description = "Un'anguilla elettrica.",
    client = {
        image = "electric_eel.png",
    }
},

["garfish"] = {
    label = "Aguglia",
    weight = 25,
    stack = true,
    close = true,
    description = "Un'aguglia.",
    client = {
        image = "garfish.png",
    }
},

["giant_freshwater_stingray"] = {
    label = "Razza Gigante d'Acqua Dolce",
    weight = 15,
    stack = true,
    close = true,
    description = "Una razza gigante d'acqua dolce.",
    client = {
        image = "giant_freshwater_stingray.png",
    }
},

["giant_grouper"] = {
    label = "Cernia Gigante",
    weight = 130,
    stack = true,
    close = true,
    description = "Una cernia gigante.",
    client = {
        image = "giant_grouper.png",
    }
},

["giant_squid"] = {
    label = "Calamaro Gigante",
    weight = 10,
    stack = true,
    close = true,
    description = "Un calamaro gigante.",
    client = {
        image = "giant_squid.png",
    }
},

["giant_trevally"] = {
    label = "Carango Gigante",
    weight = 10,
    stack = true,
    close = true,
    description = "Un carango gigante.",
    client = {
        image = "giant_trevally.png",
    }
},

["golden_trout"] = {
    label = "Trota Dorata",
    weight = 20,
    stack = true,
    close = true,
    description = "Una trota dorata.",
    client = {
        image = "golden_trout.png",
    }
},

["grass_carp"] = {
    label = "Carpa d'Erba",
    weight = 60,
    stack = true,
    close = true,
    description = "Una carpa d'erba.",
    client = {
        image = "grass_carp.png",
    }
},

["grass_pickerel"] = {
    label = "Luccio Erbaiolo",
    weight = 45,
    stack = true,
    close = true,
    description = "Un luccio erbaiolo.",
    client = {
        image = "grass_pickerel.png",
    }
},

["grayling"] = {
    label = "Temolo",
    weight = 40,
    stack = true,
    close = true,
    description = "Un temolo.",
    client = {
        image = "grayling.png",
    }
},

["great_barracuda"] = {
    label = "Grande Barracuda",
    weight = 15,
    stack = true,
    close = true,
    description = "Un grande barracuda.",
    client = {
        image = "great_barracuda.png",
    }
},

["grey_snapper"] = {
    label = "Dentice Grigio",
    weight = 200,
    stack = true,
    close = true,
    description = "Un dentice grigio.",
    client = {
        image = "grey_snapper.png",
    }
},

["huchen"] = {
    label = "Huchen",
    weight = 715,
    stack = true,
    close = true,
    description = "Un huchen.",
    client = {
        image = "huchen.png",
    }
},

["ide"] = {
    label = "Ido",
    weight = 15,
    stack = true,
    close = true,
    description = "Un ido.",
    client = {
        image = "ide.png",
    }
},

["indian_threadfish"] = {
    label = "Pesce Filo Indiano",
    weight = 125,
    stack = true,
    close = true,
    description = "Un pesce filo indiano.",
    client = {
        image = "indian_threadfish.png",
    }
},

["lake_sturgeon"] = {
    label = "Storione di Lago",
    weight = 800,
    stack = true,
    close = true,
    description = "Uno storione di lago.",
    client = {
        image = "lake_sturgeon.png",
    }
},

["largemouth_bass"] = {
    label = "Persico Trota Bocca Grande",
    weight = 15,
    stack = true,
    close = true,
    description = "Un persico trota a bocca grande.",
    client = {
        image = "largemouth_bass.png",
    }
},

["mahi_mahi"] = {
    label = "Lampuga",
    weight = 15,
    stack = true,
    close = true,
    description = "Una lampuga.",
    client = {
        image = "mahi_mahi.png",
    }
},

["malabar_grouper"] = {
    label = "Cernia del Malabar",
    weight = 715,
    stack = true,
    close = true,
    description = "Una cernia del Malabar.",
    client = {
        image = "malabar_grouper.png",
    }
},

["mirror_carp"] = {
    label = "Carpa Specchio",
    weight = 315,
    stack = true,
    close = true,
    description = "Una carpa specchio.",
    client = {
        image = "mirror_carp.png",
    }
},

["northern_pike"] = {
    label = "Luccio Nordico",
    weight = 15,
    stack = true,
    close = true,
    description = "Un luccio nordico.",
    client = {
        image = "northern_pike.png",
    }
},

["pink_river_dolphin"] = {
    label = "Delfino Rosa di Fiume",
    weight = 775,
    stack = true,
    close = true,
    description = "Un delfino rosa di fiume.",
    client = {
        image = "pink_river_dolphin.png",
    }
},

["pink_salmon"] = {
    label = "Salmone Rosa",
    weight = 10,
    stack = true,
    close = true,
    description = "Un salmone rosa.",
    client = {
        image = "pink_salmon.png",
    }
},

["prussian_carp"] = {
    label = "Carpa Prussiana",
    weight = 45,
    stack = true,
    close = true,
    description = "Una carpa prussiana.",
    client = {
        image = "prussian_carp.png",
    }
},

["pufferfish"] = {
    label = "Pesce Palla",
    weight = 75,
    stack = true,
    close = true,
    description = "Un pesce palla.",
    client = {
        image = "pufferfish.png",
    }
},

["pumpkinseed"] = {
    label = "Persico Sole Punteggiato",
    weight = 20,
    stack = true,
    close = true,
    description = "Un persico sole punteggiato.",
    client = {
        image = "pumpkinseed.png",
    }
},

["rainbow_trout"] = {
    label = "Trota Iridea",
    weight = 15,
    stack = true,
    close = true,
    description = "Una trota iridea.",
    client = {
        image = "rainbow_trout.png",
    }
},

["red_lionfish"] = {
    label = "Pesce Leone Rosso",
    weight = 15,
    stack = true,
    close = true,
    description = "Un pesce leone rosso.",
    client = {
        image = "red_lionfish.png",
    }
},

["redeye_piranha"] = {
    label = "Piranha dagli Occhi Rossi",
    weight = 60,
    stack = true,
    close = true,
    description = "Un piranha dagli occhi rossi.",
    client = {
        image = "redeye_piranha.png",
    }
},

["redfin_pickerel"] = {
    label = "Luccio Erbaiolo a Pinne Rosse",
    weight = 20,
    stack = true,
    close = true,
    description = "Un luccio erbaiolo a pinne rosse.",
    client = {
        image = "redfin_pickerel.png",
    }
},

["roach"] = {
    label = "Scardola",
    weight = 25,
    stack = true,
    close = true,
    description = "Una scardola.",
    client = {
        image = "roach.png",
    }
},

["sea_trout"] = {
    label = "Trota di Mare",
    weight = 10,
    stack = true,
    close = true,
    description = "Una trota di mare.",
    client = {
        image = "sea_trout.png",
    }
},

["silver_carp"] = {
    label = "Carpa Argento",
    weight = 15,
    stack = true,
    close = true,
    description = "Una carpa argento.",
    client = {
        image = "silver_carp.png",
    }
},

["skeleton"] = {
    label = "Scheletro",
    weight = 5,
    stack = true,
    close = true,
    description = "Uno scheletro.",
    client = {
        image = "skeleton.png",
    }
},

["smallmouth_bass"] = {
    label = "Persico Trota Bocca Piccola",
    weight = 75,
    stack = true,
    close = true,
    description = "Un persico trota a bocca piccola.",
    client = {
        image = "smallmouth_bass.png",
    }
},

["sockeye_salmon"] = {
    label = "Salmone Rosso",
    weight = 15,
    stack = true,
    close = true,
    description = "Un salmone rosso.",
    client = {
        image = "sockeye_salmon.png",
    }
},

["south_sea_pearl_oyster"] = {
    label = "Ostrica di Perle dei Mari del Sud",
    weight = 5,
    stack = true,
    close = true,
    description = "Un'ostrica di perle dei mari del sud.",
    client = {
        image = "south_sea_pearl_oyster.png",
    }
},

["tench"] = {
    label = "Tinca",
    weight = 125,
    stack = true,
    close = true,
    description = "Una tinca.",
    client = {
        image = "tench.png",
    }
},

["tiger_shark"] = {
    label = "Squalo Tigre",
    weight = 2715,
    stack = true,
    close = true,
    description = "Uno squalo tigre.",
    client = {
        image = "tiger_shark.png",
    }
},

["wels_catfish"] = {
    label = "Siluro",
    weight = 200,
    stack = true,
    close = true,
    description = "Un siluro.",
    client = {
        image = "wels_catfish.png",
    }
},

["white_sturgeon"] = {
    label = "Storione Bianco",
    weight = 15,
    stack = true,
    close = true,
    description = "Uno storione bianco.",
    client = {
        image = "white_sturgeon.png",
    }
},

["yellow_perch"] = {
    label = "Persico Giallo",
    weight = 20,
    stack = true,
    close = true,
    description = "Un persico giallo.",
    client = {
        image = "yellow_perch.png",
    }
},

["yellowfin_tuna"] = {
    label = "Tonno Pinna Gialla",
    weight = 15,
    stack = true,
    close = true,
    description = "Un tonno a pinna gialla.",
    client = {
        image = "yellowfin_tuna.png",
    }
},

["yellowtail_barracuda"] = {
    label = "Barracuda a Coda Gialla",
    weight = 55,
    stack = true,
    close = true,
    description = "Un barracuda a coda gialla.",
    client = {
        image = "yellowtail_barracuda.png",
    }
},

["zander"] = {
    label = "Lucioperca",
    weight = 10,
    stack = true,
    close = true,
    description = "Un lucioperca.",
    client = {
        image = "zander.png",
    }
},

["paddlefish"] = {
    label = "Pesce Pala",
    weight = 15,
    stack = true,
    close = true,
    description = "Un raro e illegale pesce pala.",
    client = {
        image = "paddlefish.png",
    }
},

["sawfish"] = {
    label = "Pesce Sega",
    weight = 15,
    stack = true,
    close = true,
    description = "Un raro e illegale pesce sega.",
    client = {
        image = "sawfish.png",
    }
},

["eel"] = {
    label = "Anguilla",
    weight = 15,
    stack = true,
    close = true,
    description = "Un'anguilla rara e illegale.",
    client = {
        image = "eel.png",
    }
},

["hammerheadshark"] = {
    label = "Squalo Martello",
    weight = 115,
    stack = true,
    close = true,
    description = "Un raro e illegale squalo martello.",
    client = {
        image = "hammerheadshark.png",
    }
},

["seaturtle"] = {
    label = "Tartaruga Marina",
    weight = 115,
    stack = true,
    close = true,
    description = "Una rara e illegale tartaruga marina.",
    client = {
        image = "seaturtle.png",
    }
},

["leopardshark"] = {
    label = "Squalo Leopardo",
    weight = 115,
    stack = true,
    close = true,
    description = "Un raro e illegale squalo leopardo.",
    client = {
        image = "leopardshark.png",
    }
},

["blueshark"] = {
    label = "Squalo Blu",
    weight = 2000,
    stack = true,
    close = true,
    description = "Un leggendario e illegale squalo blu.",
    client = {
        image = "blueshark.png",
    }
},

["greatwhiteshark"] = {
    label = "Grande Squalo Bianco",
    weight = 150,
    stack = true,
    close = true,
    description = "Un mitico e illegale grande squalo bianco.",
    client = {
        image = "greatwhiteshark.png",
    }
},

-- Oggetti da immersione
["ancient_artifact"] = {
    label = "Manufatto Antico",
    weight = 15,
    stack = true,
    close = true,
    description = "Un manufatto antico!",
    client = {
        image = "ancient_artifact.png",
    }
},

["antique_compass"] = {
    label = "Bussola Antica",
    weight = 15,
    stack = true,
    close = true,
    description = "Una bussola antica.",
    client = {
        image = "antique_compass.png",
    }
},

["enchanted_jewel"] = {
    label = "Gioiello Incantato",
    weight = 15,
    stack = true,
    close = true,
    description = "Un gioiello incantato.",
    client = {
        image = "enchanted_jewel.png",
    }
},

["luxury_watch"] = {
    label = "Orologio di Lusso",
    weight = 15,
    stack = true,
    close = true,
    description = "Un orologio costoso.",
    client = {
        image = "luxury_watch.png",
    }
},

["meteorite_ore"] = {
    label = "Minerale di Meteorite",
    weight = 15,
    stack = true,
    close = true,
    description = "Minerale di meteorite.",
    client = {
        image = "meteorite_ore.png",
    }
},

["mystic_crystal"] = {
    label = "Cristallo Mistico",
    weight = 15,
    stack = true,
    close = true,
    description = "Un cristallo mistico.",
    client = {
        image = "mystic_crystal.png",
    }
},

["phantom_amulet"] = {
    label = "Amuleto Fantasma",
    weight = 15,
    stack = true,
    close = true,
    description = "Un amuleto fantasma.",
    client = {
        image = "phantom_amulet.png",
    }
},

["precious_pearls"] = {
    label = "Perle Preziose",
    weight = 15,
    stack = true,
    close = true,
    description = "Una manciata di perle preziose.",
    client = {
        image = "precious_pearls.png",
    }
},

["rare_spices"] = {
    label = "Spezie Rare",
    weight = 15,
    stack = true,
    close = true,
    description = "Collezione di spezie rare.",
    client = {
        image = "rare_spices.png",
    }
},

["spy_gadget"] = {
    label = "Gadget da Spia",
    weight = 15,
    stack = true,
    close = true,
    description = "Un gadget da spia.",
    client = {
        image = "spy_gadget.png",
    }
},

	['hunting_license'] = {
        label = 'Licenza di Caccia',
        weight = 15,
        stack = false,
        close = true,
        client = {
            image = 'hunting_license.png',
        }
    },
    
    ['campfire'] = {
            label = "Falò",
        weight = 15,
        stack = true,
        close = true,
        description = "",
    },

    ['primitive_grill'] = {
            label = "Griglia Primitiva",
        weight = 15,
        stack = true,
        close = true,
        description = "",
    },

    ['advanced_grill'] = {
            label = "Griglia Avanzata",
        weight = 15,
        stack = true,
        close = true,
        description = "",
    },

    ['hunting_bait'] = {
            label = "Esca da Caccia",
        weight = 15,
        stack = true,
        close = true,
        description = "",
    },
    

    ['binocular'] = {
            label = 'Binocolo',
        weight = 15,
        stack = true,
        close = true,
        description = "",
    },


----------------------canna buona che toglie il 30%
['weed_plant'] = {
    label = 'Pianta di Marijuana',
    weight = 15,
      stack = true,
        close = true,
},


	['boat_license'] = {
		label = "Patente nautica",
		weight = 1,
		stack = false,
		close = true,
		description = "Licenza per condurre imbarcazioni."
	},

	['flying_license'] = {
		label = "Patente di volo",
		weight = 1,
		stack = false,
		close = true,
		description = "Licenza per pilotare velivoli."
	},

    ['portoarmi'] = {
        label = 'Licenza Porto d\'Armi',
        weight = 10,
        stack = false,
        close = true,
        consume = 0,
        description = 'Tesserino ufficiale LSPD per il porto d\'armi occultato.',
        client = {
            export = 'GiaMMarK_POLIZIA.weapon_license' -- Sostituito porto_armi con weapon_license
        }
    },

['vehicle_sale_agreement'] = {
label = 'Contratto di vendita',
weight = 2,
stack = true
},
['signed_vehicle_sale_agreement'] = {
label = 'Contratto di vendita firmato',
weight = 2,
stack = false
},
['empty_invoice'] = {
label = 'Fattura vuota',
weight = 1,
stack = true
},
['thermal_paper'] = {
label = 'Carta termica',
weight = 1,
stack = true
},
['weed_dry'] = {
    label = 'Marijuana Essiccata',
    weight = 10,
  stack = true,
        close = true,
},
['muriatic_acid'] = {
    label = 'Acido Muriatico',
    weight = 75,
  stack = true,
        close = true,
},
['ammoniaca'] = {
    label = 'Ammoniaca',
    weight = 75,
  stack = true,
        close = true,
},
['ziptie'] = {
    label = 'Fascette',
    weight = 25,
   stack = true,
        close = true,
},
['headbag'] = {
    label = 'Sacco per la testa',
    weight = 10,
     stack = true,
        close = true,
},

	['clerk_tablet'] = {
    label = 'Tablet Impiegato',
    weight = 5,
    stack = true
},
['invoice'] = {
    label = 'Fattura',
    weight = 2,
    stack = false
},
['empty_ticket'] = {
    label = 'Ticket Vuoto',
    weight = 1,
    stack = true
},
['ticket'] = {
    label = 'Ticket',
    weight = 1,
    stack = false
},
['payment_terminal'] = {
    label = 'Terminale POS',
    weight = 5,
    stack = false
},

['receipt'] = {
    label = 'Ricevuta',
    weight = 1,
    stack = false
},
	['skateboard'] = {
    label = 'Skateboard',
    weight = 10,
    stack = false,
    close = true,
},

	['barattolourine'] = {
		label = 'Barattolo delle urine',
		weight = 5,  -- Prima era 15
		stack = true,
		close = true,
	},
['finger_scanner'] = {
		label = 'Dispositivo impronte digitali',
		weight = 5,  -- Prima era 15
		stack = true,
		close = true,
	},
	['ifak'] = {
		label = 'IFAK', -- Kit medico individuale
		weight = 25,  -- Prima era 200
		stack = true,
		close = true,
	},

	['tourniquet'] = {
		label = 'Laccio Emostatico',
		weight = 10,  -- Prima era 10
		stack = true,
		close = true,
	},

	['gauze'] = {
		label = 'Garza',
		weight = 2,   -- Prima era 15
		stack = true,
		close = true,
	},
['surfboard'] = {
    label = 'Tavola da surf',
    weight = 300,
    close = true,
    stack = false,
    client = {
        event = 'bodhix-surfing:client:start'
    }
},
	['burn_gel'] = {
		label = 'Gel Ustioni',
		weight = 12,  -- Prima era 10
		stack = true,
		close = true,
	},

	['surgical_kit'] = {
		label = 'Kit Chirurgico',
		weight = 75, -- Prima era 15
		stack = true,
		close = true,
	},

	['saline_bag'] = {
		label = 'Sacca Salina',
		weight = 15, -- Prima era 30
		stack = true,
		close = true,
	},

	['leg_brace'] = {
		label = 'Tutore Gamba',
		weight = 15, -- Prima era 30
		stack = true,
		close = true,
	},

	['arm_brace'] = {
		label = 'Tutore Braccio',
		weight = 15, -- Prima era 30
		stack = true,
		close = true,
	},

	['body_brace'] = {
		label = 'Busto Ortopedico',
		weight = 15, -- Prima era 10
		stack = true,
		close = true,
	},

	['neck_brace'] = {
		label = 'Collare Cervicale',
		weight = 25,  -- Prima era 30
		stack = true,
		close = true,
	},

	['ice_pack'] = {
		label = 'Ghiaccio Istantaneo',
		weight = 10,  -- Prima era 15
		stack = true,
		close = true,
	},

	['painkillers'] = {
		label = 'Antidolorifici',
		weight = 2,   -- Prima era 15
		stack = true,
		close = true,
	},

	['wheelchair'] = {
		label = 'Sedia a Rotelle',
		weight = 15, -- Prima era 15
		stack = false,
		close = true,
	},

	['walking_stick'] = {
		label = 'Bastone da Passeggio',
		weight = 10, -- Prima era 10
		stack = false,
		close = true,
	},

	['med_bag'] = {
		label = 'Borsa Medica',
		weight = 10, -- Prima era 15
		stack = false,
		close = true,
	},

	['body_bag'] = {
		label = 'Sacca Mortuaria',
		weight = 75, -- Prima era 15
		stack = true,
		close = true,
	},

	['ecg'] = {
		label = 'Monitor ECG',
		weight = 10, -- Prima era 10
		stack = true,
		close = false,
	},


['heistpack_drone']   = { label = 'Drone da Rapina', weight = 0.0, stack = true },
['heistpack_drill']   = { label = 'Trapano da Rapina', weight = 0.0, stack = true },
['heistpack_anchor']  = { label = 'Ancora', weight = 0.0, stack = true },
['heistpack_grinder'] = { label = 'Smerigliatrice Angolare', weight = 1.0, stack = true },
['heistpack_tablet']  = { label = 'Tablet Heistpack', weight = 1.0, stack = true },
['heist_paint_4']     = { label = 'Dipinto #4', weight = 15, stack = false, client = { image = "heist_painting.png" } },

['alcohol'] = {
	label = 'Alcol Etilico',
	weight = 1,
	stack = true,
	close = true,
	description = '',
},

['libretto'] = {
        label = 'Libretto veicolo',
        weight = 50,
        stack = false,
        close = true,
        consume = 0,
        description = 'Documento di proprietà del veicolo.',
        client = {
            export = 'giammark_motorizzazione.useLibretto'
        }
    },

    ['assicurazione'] = {
        label = 'Assicurazione veicolo',
        weight = 20,
        stack = false,
        close = true,
        consume = 0,
        description = 'Contrassegno assicurativo del veicolo.',
        client = {
            export = 'giammark_motorizzazione.useInsurance'
        }
    },
	['tvremote'] = 
	{
		label = 'Telecomando TV',
		weight = 1,
		stack = true,
		close = true,
	},
['vehicletv'] = 
	{
		label = 'Telecomando TV macchina',
		weight = 1,
		stack = true,
		close = true,
	},


	["engine_oil"] = {
    label = "Olio Motore",
    weight = 15, -- 1 litro di olio ≈ 1 kg
},
["tyre_replacement"] = {
    label = "Sostituzione Pneumatici",
    weight = 10, -- Un pneumatico medio pesa circa 10-15 kg, ma qui si intende il kit base
},
["clutch_replacement"] = {
    label = "Kit Frizione",
    weight = 7, -- Un kit frizione completo pesa circa 10-15 kg
},
["air_filter"] = {
    label = "Filtro Aria",
    weight = 1, -- Un filtro aria pesa pochi etto
},
["spark_plug"] = {
    label = "Candela di Accensione",
    weight = 1.2, -- Una candela pesa circa 15-200 grammi
},
["brakepad_replacement"] = {
    label = "Pastiglie Freno",
    weight = 1, -- Un set di pastiglie pesa circa 1-2 kg
},
["suspension_parts"] = {
    label = "Componenti Sospensioni",
    weight = 5, -- Componenti base delle sospensioni (es. ammortizzatore + molla)
},
-- Motori
["i4_engine"] = {
    label = "Motore 4 Cilindri in Linea",
    weight = 75, -- Un motore I4 pesa circa 15-15 kg
},
["v6_engine"] = {
    label = "Motore V6",
    weight = 10, -- Un motore V6 pesa circa 15-220 kg
},
["v8_engine"] = {
    label = "Motore V8",
    weight = 125, -- Un motore V8 pesa circa 200-30 kg
},
["v12_engine"] = {
    label = "Motore V12",
    weight = 15, -- Un motore V12 pesa circa 15-315 kg
},
["turbocharger"] = {
    label = "Turbocompressore",
    weight = 5, -- Un turbo pesa circa 8-15 kg
},
-- Motori Elettrici
["ev_motor"] = {
    label = "Motore Elettrico",
    weight = 40, -- Un motore elettrico compatto pesa circa 70-10 kg
},
["ev_battery"] = {
    label = "Batteria Veicolo Elettrico",
    weight = 10, -- Una batteria EV media pesa circa 200-30 kg
},
["ev_coolant"] = {
    label = "Liquido Refrigerante EV",
    weight = 2, -- 5 litri di liquido refrigerante
},
-- Trasmissione
["awd_drivetrain"] = {
    label = "Trasmissione Integrale (AWD)",
    weight = 40, -- Una trasmissione AWD pesa circa 70-10 kg
},
["rwd_drivetrain"] = {
    label = "Trasmissione Posteriore (RWD)",
    weight = 30, -- Una trasmissione RWD pesa circa 15-70 kg
},
["fwd_drivetrain"] = {
    label = "Trasmissione Anteriore (FWD)",
    weight = 25, -- Una trasmissione FWD pesa circa 40-60 kg
},
-- Tuning
["slick_tyres"] = {
    label = "Pneumatici Slick",
    weight = 5, -- Un pneumatico slick pesa circa 8-12 kg
},
["semi_slick_tyres"] = {
    label = "Pneumatici Semi-Slick",
    weight = 5,
},
["offroad_tyres"] = {
    label = "Pneumatici Fuoristrada",
    weight = 7, -- Pneumatici fuoristrada sono più pesanti
},
["drift_tuning_kit"] = {
    label = "Kit Tuning Drift",
    weight = 10, -- Kit di tuning base
},
["ceramic_brakes"] = {
    label = "Freni in Ceramica",
    weight = 4, -- Un set di dischi e pastiglie in ceramica
},
-- Componenti Estetici
["lighting_controller"] = {
    label = "Controllo Luci",
    weight = 1.5, -- Dispositivo elettronico leggero
    client = {
      event = "jg-mechanic:client:show-lighting-controller",
    }
},
["stancing_kit"] = {
    label = "Kit Distanziali",
    weight = 2, -- Componenti per regolare l'assetto
    client = {
      event = "jg-mechanic:client:show-stancer-kit",
    }
},

["ecu_stage1"] = {
    label = 'Centralina ECU Stage 1',
    weight = 500,
    stack = true,
    close = true,
    description = 'Centralina elettronica Stage 1',
    image = 'ecu.png'
},

["ecu_stage2"] = {
    label = 'Centralina ECU Stage 2',
    weight = 500,
    stack = true,
    close = true,
    description = 'Centralina elettronica Stage 2',
    image = 'ecu.png'
},

["ecu_stage3"] = {
    label = 'Centralina ECU Stage 3',
    weight = 500,
    stack = true,
    close = true,
    description = 'Centralina elettronica Stage 3',
    image = 'ecu.png'
},



['armour'] = {
	label = 'Giubbotto antiproiettile',
	weight = 300,
	stack = false,
	client = {
		anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
		usetime = 315
	}
},

['heavyarmour'] = {
	label = 'Giubbotto antiproiettile pesante',
	weight = 15,
	stack = false,
	client = {
		anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
		usetime = 315
	},
},

['armor_plates'] = {
	label = 'Piastre balistiche',
	weight = 800,
	stack = true,
	close = true,
	client = {
		event = 'ox_inventory:utility:applyArmorPlate'
	}
},


["cosmetic_part"] = {
    label = "Componenti Estetici",
    weight = 1, -- Es. spoiler, minigonne (varia molto, weight medio)
},
["respray_kit"] = {
    label = "Kit Verniciatura",
    weight = 5, -- Vernice, attrezzi, mascherine
},
["vehicle_wheels"] = {
    label = "Set Ruote Veicolo",
    weight = 20, -- 4 ruote in lega + pneumatici (circa 10 kg a ruota)
},
["tyre_smoke_kit"] = {
    label = "Kit Fumo Pneumatici",
    weight = 1, -- Kit per fumo (liquido + pompa)
},
["bulletproof_tyres"] = {
    label = "Pneumatici Antiproiettile",
    weight = 7, -- Più pesanti dei normali pneumatici
},
["extras_kit"] = {
    label = "Kit Extra",
    weight = 2, -- Componenti aggiuntivi vari
},
-- Nitrous e Pulizia
["nitrous_bottle"] = {
    label = "Bombola Protossido",
    weight = 5, -- Bombola da 5-10 kg
    client = {
      event = "jg-mechanic:client:use-nitrous-bottle",
    }
},
["empty_nitrous_bottle"] = {
    label = "Bombola Protossido Vuota",
    weight = 2, -- Bombola vuota
},
["nitrous_install_kit"] = {
    label = "Kit Installazione Protossido",
    weight = 1, -- Tubazioni, valvole, ecc.
},
["cleaning_kit"] = {
    label = "Kit Pulizia",
    weight = 2, -- Prodotti e panni
    client = {
      event = "jg-mechanic:client:clean-vehicle",
    }
},
["repair_kit"] = {
    label = "Kit Riparazione",
    weight = 5, -- Attrezzi e materiali di consumo
    client = {
      event = "jg-mechanic:client:repair-vehicle",
    }
},
["duct_tape"] = {
    label = "Nastro Americano",
    weight = 1.3, -- Un rotolo di nastro
    client = {
      event = "jg-mechanic:client:use-duct-tape",
    }
},
-- Prestazioni
["performance_part"] = {
    label = "Componenti Prestazionali",
    weight = 5, -- Es. centralina, filtri sportivi, ecc.
},
-- Tablet Meccanico
["mechanic_tablet"] = {
    label = "Tablet Meccanico",
    weight = 1, -- Un tablet pesa circa 15 g - 1 kg
    client = {
      event = "jg-mechanic:client:use-tablet",
    }
},
-- Cambio
["manual_gearbox"] = {
    label = "Cambio Manuale",
    weight = 20, -- Un cambio manuale pesa circa 30-15 kg
},

['goldchain'] = {
	label = 'Catena d\'oro',
	weight = 715,
	stack = true,
},
['gasmask'] = {
	label = 'Maschera antigas',
	weight = 1,
	close = true,
},
['heist_drone'] = {
	label = 'Drone da rapina',
	weight = 15,
	client = {
		image = "heist_drone.png",
	},
	close = true,
},
['heist_paint_1'] = {
	label = 'Quadro #1',
	weight = 15,
	client = {
		image = "heist_painting.png",
	},
},
['heist_paint_2'] = {
	label = 'Quadro #2',
	weight = 15,
	client = {
		image = "heist_painting.png",
	},
},
['heist_paint_3'] = {
	label = 'Quadro #3',
	weight = 15,
	client = {
		image = "heist_painting.png",
	},
},
['heist_drill'] = {
	label = 'Trapano da rapina',
	weight = 10,
	client = {
		image = "heist_drill.png",
	},
},
["iphone"] = {
	label = "iPhone",
	weight = 15,
	stack = true,
	close = true,
	description = "Telefono molto costoso",
	client = {
		image = "iphone.png",
	}
},
["diamond"] = {
	label = "Diamante",
	weight = 15,
	stack = true,
	close = true,
	description = "Un diamante sembra il colpo grosso!",
	client = {
		image = "diamond.png",
	}
},

	['bag_clothes'] = {
		label = 'Borsa (Vestiti)',
		weight = 5,
		stack = false,
		close = true,
		consume = 0,
		description = 'Una borsa elegante per trasportare i tuoi vestiti',
		rarity = 'rare',
		canRename = true,
		canChangeDescription = true,
		canThrow = true,
		propThrow = 'prop_nigel_bag_pickup',
		client = {
			export = 'pinkFrog_inventoryAddon.useBagClothes',
		},
	},

	['plate_armor'] = {
		label = 'Piastra Balistica',
		weight = 5,
		stack = true,
		close = true,
		rarity = 'rare',
		description = 'Aggiunge 15 di protezione extra al tuo giubbotto antiproiettile',
	},

	

	['compostoradex'] = {
		label = 'Composto IG Radex',
		weight = 10,
		stack = true,
		close = true,
		description = nil
	},
	['pipetta_laboratorio'] = {
		label = 'Pipetta da laboratorio',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	['becher'] = {
		label = 'Becher',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	["gold_tooth"] = {
		label = "Dente d'oro",
		weight = 1,
		stack = true,
		close = false,
	},
	["dirty_photo"] = {
		label = "Foto sporca",
		weight = 1,
		stack = true,
		close = false,
	},
	["chain"] = {
		label = "Catena",
		weight = 1,
		stack = true,
		close = false,
	},
	["medal"] = {
		label = "Medaglia",
		weight = 1,
		stack = true,
		close = false,
	},
	["rusted_tin"] = {
		label = "Latta arrugginita",
		weight = 1,
		stack = true,
		close = false,
	},
	["nail"] = {
		label = "Chiodo",
		weight = 1,
		stack = true,
		close = false,
	},
	["ring"] = {
		label = "Anello",
		weight = 1,
		stack = true,
		close = false,
	},
	["vehicle_tyre"] = {
		label = "Pneumatico veicolo",
		weight = 1,
		stack = true,
		close = false,
	},
	["vehicle_door"] = {
		label = "Porta veicolo",
		weight = 1,
		stack = true,
		close = false,
	},
	['estratto_proteico'] = {
		label = 'Estratto Proteico',
		weight = 15,
		stack = true,
		close = true,
		description = nil
	},
	['solvente'] = {
		label = 'Solvente',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	['provette'] = {
		label = 'Provette',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},


	['pillola_ig-red'] = {
		label = 'Pillola IG Red',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},





	['wood'] = {
		label = 'Legno',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	
	['metal'] = {
		label = 'Metallo',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	
	['rope'] = {
		label = 'Corda',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	
	['shovel'] = {
		label = 'Pala',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
	['medicalbag'] = {
		label = 'Borsa Medica',
		weight = 110,
		stack = true,
		description = "Un kit medico completo per trattare ferite e malattie.",
	},

	['defibrillator'] = {
		label = 'Defibrillatore',
		weight = 15,
		stack = true,
		description = "Usato per rianimare i pazienti.",
	},
	
	['tweezers'] = {
		label = 'Pinzette',
		weight = 15,
		stack = true,
		description = "Pinzette di precisione per rimuovere oggetti estranei, come proiettili, dalle ferite.",
	},
	
	['burncream'] = {
		label = 'Crema per Ustioni',
		weight = 15,
		stack = true,
		description = "Crema specializzata per trattare e lenire ustioni e irritazioni cutanee.",
	},
	
	['suturekit'] = {
		label = 'Kit di Sutura',
		weight = 15,
		stack = true,
		description = "Un kit contenente strumenti chirurgici e materiali per suturare e chiudere ferite.",
	},
	
	['icepack'] = {
		label = 'Impacco di Ghiaccio',
		weight = 10,
		stack = true,
		description = "Un impacco di ghiaccio usato per ridurre il gonfiore e alleviare il dolore e l'infiammazione.",
	},
	
	['stretcher'] = {
		label = 'Barella',
		weight = 10,
		stack = true,
		description = "Una barella usata per spostare pazienti che necessitano di cure mediche.",
	},
	
	['emstablet'] = {
		label = 'Ems tablet',
		weight = 10,
		stack = true,
	},
	









	["kq_outfitbag"] = {
		label = "Borsone vestiti",
		weight = 35,
		stack = false,
		close = false,
	},
	["casinochips"] = {
		label = "Casino Chips",
		weight = 1,
		stack = true,
		close = false,
	},
	
	["cascolvl1"] = {
		label = "Casco lvl 1",
		weight = 15,
        durability = 0.01,
		stack = false,
		close = true,
	},
	["cascolvl2"] = {
		label = "Casco lvl 2",
		weight = 15,
        durability = 0.01,
		stack = false,
		close = true,
	},
	["cascolvl3"] = {
		label = "Casco lvl 3",
		weight = 15,
        durability = 0.01,
		stack = false,
		close = true,
	},
	['giubbo1'] = {
		label = 'Giubotto Leggero',
		weight = 40,
        durability = 0.01,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 315
		}
	},

	['giubbo2'] = {
		label = 'Giubotto Pesante',
		weight = 15,
        durability = 0.01,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 315
		}
	},
	['giubbo3'] = {
		label = 'Giubotto Super Pesante',
		weight = 75,
        durability = 0.01,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 315
		}
	},
	["librominerali"] = {
		label = "Libro dei Minerali in chimica",
		weight = 40,
		stack = false,
		close = false,
	},

	["racingtablet"] = {
		label = "Tablet per gare",
		weight = 7,
		stack = false,
		close = false,
	},
    --------------zaini
    ["backpack"] = {
        label = "Zaino Piccolo",
        weight = 7,
        stack = false,
        close = false,
    },
    ["backpack2"] = {
        label = "Zaino Medio",
        weight = 7,
        stack = false,
        close = false,
    },
    ["backpack3"] = {
        label = "Zaino Grande",
        weight = 7,
        stack = false,
        close = false,
    },
    ["backpack1"] = {
        label = "Borsone",
        weight = 3,
        stack = false,
        close = false,
    },
['valigetta'] = {
    label = 'Valigetta',
    weight = 15,
    stack = false,
},
	['portafoglio'] = {
		label = 'Portafoglio',
		weight = 5,
		stack = false,
	},
['fnx_identity_card'] = {
    label = 'Carta d\'Identità',
    weight = 1,
    stack = false,
    close = true,
    description = 'Documento di identità personale.',
},

['fnx_weapon_license'] = {
    label = 'Porto d\'Armi',
    weight = 1,
    stack = false,
    close = true,
    description = 'Licenza per il possesso e porto di armi.',
},

['fnx_drive_license'] = {
    label = 'Patente di Guida',
    weight = 1,
    stack = false,
    close = true,
    description = 'Patente di guida.',
},
    ------------rapine atm
    ['heavy_rope'] = {
        label = 'Corda pesante',
        weight = 10,
        stack = true,
    },
    ['tabletfinanza'] = {
        label = 'Tablet finanza',
        weight = 10,
        stack = true,
    },
    ['atm_hack_phone'] = {
        label = 'Atm Hack Telefono',
        weight = 10,
        close = true,
    },
    ['trapano'] = {
        label = 'Trapano',
        weight = 10,
        stack = true,
    },

    ['pennetta'] = {
        label = 'Pennetta Usb',
        weight = 10,
        stack = true,
    },

    ['fnx_card'] = {
		label = 'Carta di Riverside',
		stack = false,
		close = true,
	},

    ['money'] = {
		label = 'Money',
	},

	['black_money'] = {
		label = 'Soldi Sporchi',
	},

['fascette'] = {
    label = 'Fascette',
    weight = 10,
    stack = true,
    close = true,
    description = 'Fascette di plastica utilizzabili tramite ox_target.'
},

['water'] = {
    label = 'Acqua',
    weight = 33,
decay = true,
durability = 0.01,
    stack = true,
    close = true,
},	


	---------------------ALTRO-------
	['parachute'] = {
		label = 'Parachute',
		weight = 150,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
			usetime = 15
		}
	},

		['plastica'] = {
			label = 'Plastica',
		weight = 5,
		stack = true,
		close = false,
	},
---------------------------------FOOD-------------------------


	['sacchetto'] = {
		label = 'Sacco di carta',
		weight = 1,
		stack = false,
		close = false,
		consume = 0
	},


	['lockpick'] = {
		label = 'Grimaldello',
		weight = 80,
	},

	["phone"] = {
		label = "Telefono",
		weight = 5,
		stack = false,
	},

	['speaker'] = {
		label = 'Cassa Musicale',
		weight = 1,
		description = 'Cassa.',
		consume = 0,
		server = {
			export = 'rahe-speakers.speaker'
		}
	},

	['radio'] = {
 		label = 'Radio',
		weight = 15,
		stack = false,
		allowArmed = true,
		consume = 0,
		client = {
			export = 'zerio-radio.Open',
			remove = function(total)
				if total < 1 then
					TriggerEvent('zerio-radio:client:removedradio')
				end
			end
		}
	},


    ['instant_camera'] = {
        label = "Fotocamera Istantanea",
        weight = 10,
        server = {
            export = "origen_police.instant_camera"
        },
        consume = 0
    },
    ['report_evidence'] = {
        label = "Rapporto Prove",
        weight = 10,
        server = {
            export = "origen_police.report_evidence"
        },
        consume = 0
    },
    ['k9'] = {
        label = "Fischietto K9",
        weight = 10,
        server = {
            export = "origen_police.k9"
        },
        consume = 0
    },
    ['gdf'] = {
        label = "Distintivo Gdf",
        weight = 10,
        server = {
            export = "origen_police.lspd_badge"
        },
        consume = 0
    },
    ['polizia'] = {
        label = "Distintivo Polizia",
        weight = 10,
        server = {
            export = "origen_police.lspd_badge"
        },
        consume = 0
    },
    ['carabinieri'] = {
        label = "Distintivo Carabinieri",
        weight = 10,
        server = {
            export = "origen_police.lspd_badge"
        },
        consume = 0
    },
    ['esercito'] = {
        label = "Distintivo Esercito",
        weight = 10,
        server = {
            export = "origen_police.lspd_badge"
        },
        consume = 0
    },
    ['sisr'] = {
        label = "Distintivo Sisr",
        weight = 10,
        server = {
            export = "origen_police.lspd_badge"
        },
        consume = 0
    },
    ['bcsd_badge'] = {
        label = "Distintivo BCSD",
        weight = 10,
        server = {
            export = "origen_police.bcsd_badge"
        },
        consume = 0
    },
    ['fib_badge'] = {
        label = "Distintivo FIB",
        weight = 10,
        server = {
            export = "origen_police.fib_badge"
        },
        consume = 0
    },
    ['police_cad'] = { -- By default the item name is police_cad, but you can change in origen_police/config/commands.lua -> Config.Commands.OpenPoliceCad.item
        label = "Tablet Polizia",
        weight = 10,
        server = {
            export = "origen_police.police_cad"
        },
        consume = 0
    },
    ['evidence_a'] = {
        label = "Prova Balistica", -- O "Bossolo"
        weight = 10,
        consume = 0
    },
    ['evidence_b'] = {
        label = "Prova Veicolo",
        weight = 10,
        consume = 0
    },
    ['evidence_n'] = {
        label = "Prova Impatto",
        weight = 10,
        consume = 0
    },
    ['evidence_ne'] = {
        label = "Impronta",
        weight = 10,
        consume = 0
    },
    ['evidence_r'] = {
        label = "Traccia Ematica", -- O "Campione di Sangue"
        weight = 10,
        consume = 0
    },
    ['evidence_ro'] = {
        label = "Prova Generica",
        weight = 10,
        consume = 0
    },
    ['evidence_v'] = {
        label = "Prova Stupefacenti",
        weight = 10,
        consume = 0
    },
    ['ammonium_nitrate'] = {
        label = 'Nitrato di Ammonio',
        weight = 15,
        stack = true,
        close = false,
    },

    ["handcuffs"] = {
		label = "Manette",
		weight = 1,
		stack = true,
		close = true,
	},


    ['buonopasto'] = {
        label = 'Buono Pasto',
        weight = 1,
        stack = true,
        close = true,
        description = 'Buono pasto ricevuto durante il servizio lavorativo.',
        client = {
            image = 'buonopasto.png'
        }
    },
---------------------------------------------

--[[
	["spray"] = {
		label = "Spray",
		weight = 10,
		stack = true,
		close = true,
	},

	["spray_remover"] = {
		label = "Panno",
		weight = 5,
		stack = true,
		close = true,
	},

	["medikit"] = {
		label = "Medikit",
		weight = 1,
		stack = true,
		close = true,
	},

	

	["sponge"] = {
		label = "Sponge",
		weight = 1,
		stack = true,
		close = true,
	},

	["ice"] = {
		label = "Ice",
		weight = 1,
		stack = true,
		close = true,
	},

	["ammonium_nitrate"] = {
		label = "Ammonium nitrate",
		weight = 1,
		stack = true,
		close = true,
	},

	["drug_ecstasy"] = {
		label = "Ecstasy",
		weight = 1,
		stack = true,
		close = true,
	},

	["drug_lean"] = {
		label = "Lean",
		weight = 1,
		stack = true,
		close = true,
	},
	["liquid"] = {
		label = "Liquido",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
	},
	["vape"] = {
		label = "Sigaretta Elettonica",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
		
	},
	["pacchettosigarette"] = {
		label = "Pacchetto Sigarette",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
	},
	["accendino"] = {
		label = "Accendino",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
	},
	["pacchettosigari"] = {
		label = "Pacchetto sigari",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
	},
	["sigari"] = {
		label = "Sigari",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
	},
	
	["sigarette"] = {
		label = "Sigarette",
		weight = 5,
		stack = true,
		stack = true,
		close = true,
	},

	["drug_lsd"] = {
		label = "LSD",
		weight = 1,
		stack = true,
		close = true,
	},
	["joint"] = {
		label = "Canna",
		weight = 5,
		stack = true,
		close = true,
	},

	["drug_meth"] = {
		label = "Meth",
		weight = 1,
		stack = true,
		close = true,
	},

	["sodium_hydroxide"] = {
		label = "Sodium hydroxide",
		weight = 1,
		stack = true,
		close = true,
	},

	["red_sulfur"] = {
		label = "Red Sulfur",
		weight = 1,
		stack = true,
		close = true,
	},

	["pseudoefedrine"] = {
		label = "Pseudoefedrine",
		weight = 1,
		stack = true,
		close = true,
	},

	["green_gelato_cannabis"] = {
		label = "Green Gelato Cannabis",
		weight = 1,
		stack = true,
		close = true,
	},

	["lspd_badge"] = {
		label = "LSPD badge",
		weight = 1,
		stack = false,
		close = true,
	},

	["bcsd_badge"] = {
		label = "Sheriff badge",
		weight = 1,
		stack = true,
		close = true,
	},
	['megaphone'] = {
		label = 'Megaphone',
		weight = 15,
		consume = 0,
		client = {
			export = 'jraxion_megaphone.UseMegaphone',
		},
		stack = false,
	},
	]]--

['bodycam'] = {
    label = 'Bodycam',
    weight = 15,
    stack = false,
    close = true,
    description = 'Telecamera indossabile ',
    client = {
        event = 'GiaMMarK_bodycam:bodycamstatus'
    }
},

['dashcam'] = {
    label = 'Dashcam',
    weight = 15,
    stack = false,
    close = true,
    description = 'Telecamera veicolare ',
    client = {
        event = 'GiaMMarK_bodycam:toggleCarCam'
    }
},

['bodycam_tablet'] = {
    label = 'Tablet Bodycam',
    weight = 815,
    stack = false,
    close = true,
    description = 'Centrale portatile per bodycam, dashcam e registrazioni',
    client = {
        event = 'GiaMMarK_bodycam:openControlTablet'
    }
},
["evidence_az"] = {
		label = "Prova",
		weight = 1,
		stack = true,
		close = true,
	},

	["fixkit"] = {
		label = "Kit di Riparazione",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_beat"] = {
		label = "Cassa Beat",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_blast"] = {
		label = "Cassa Blast",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_retro"] = {
		label = "Cassa Retrò",
		weight = 1,
		stack = true,
		close = true,
	},

	["speaker_vibe"] = {
		label = "Cassa Vibe",
		weight = 1,
		stack = true,
		close = true,
	},
	["advscope_attachment"] = {
		label = "Mirino Avanzato",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_SCOPE_MAX`,
			},
			usetime = 15,
		},
	},
	["barrel_attachment"] = {
		label = "Canna",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "barrel",
		client = {
			component = {
				`COMPONENT_AT_SB_BARREL_02`,
				`COMPONENT_AT_BP_BARREL_02`,
				`COMPONENT_AT_SC_BARREL_02`,
				`COMPONENT_AT_AR_BARREL_02`,
				`COMPONENT_AT_CR_BARREL_02`,
				`COMPONENT_AT_MG_BARREL_02`,
				`COMPONENT_AT_MRFL_BARREL_02`,
				`COMPONENT_AT_SR_BARREL_02`,
			},
			usetime = 15,
		},
	},
	["bellend_muzzle_brake"] = {
		label = "Freno di Bocca Bellend",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_09`,
			},
			usetime = 15,
		},
	},
	["boomcamo_attachment"] = {
		label = "Mimetica Boom",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_10`,
				`COMPONENT_PISTOL_MK2_CAMO_10`,
				`COMPONENT_REVOLVER_MK2_CAMO_10`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_10`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_10`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_10`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_10`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_10`,
				`COMPONENT_COMBATMG_MK2_CAMO_10`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_10`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_10`,
			},
			usetime = 15,
		},
	},
	["brushcamo_attachment"] = {
		label = "Mimetica Pennellata",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_02`,
				`COMPONENT_PISTOL_MK2_CAMO_02`,
				`COMPONENT_REVOLVER_MK2_CAMO_02`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_02`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_02`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_02`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_02`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_02`,
				`COMPONENT_COMBATMG_MK2_CAMO_02`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_02`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_02`,
			},
			usetime = 15,
		},
	},
	["clip_attachment"] = {
		label = "Caricatore",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "magazine",
		client = {
			component = {
				`COMPONENT_PISTOL_CLIP_02`,
				`COMPONENT_PISTOL_MK2_CLIP_02`,
				`COMPONENT_COMBATPISTOL_CLIP_02`,
				`COMPONENT_APPISTOL_CLIP_02`,
				`COMPONENT_PISTOL15_CLIP_02`,
				`COMPONENT_SNSPISTOL_CLIP_02`,
				`COMPONENT_SNSPISTOL_MK2_CLIP_02`,
				`COMPONENT_HEAVYPISTOL_CLIP_02`,
				`COMPONENT_VINTAGEPISTOL_CLIP_02`,
				`COMPONENT_CERAMICPISTOL_CLIP_02`,
				`COMPONENT_MICROSMG_CLIP_02`,
				`COMPONENT_SMG_CLIP_02`,
				`COMPONENT_ASSAULTSMG_CLIP_02`,
				`COMPONENT_MINISMG_CLIP_02`,
				`COMPONENT_SMG_MK2_CLIP_02`,
				`COMPONENT_MACHINEPISTOL_CLIP_02`,
				`COMPONENT_COMBATPDW_CLIP_02`,
				`COMPONENT_ASSAULTSHOTGUN_CLIP_02`,
				`COMPONENT_HEAVYSHOTGUN_CLIP_02`,
				`COMPONENT_ASSAULTRIFLE_CLIP_02`,
				`COMPONENT_CARBINERIFLE_CLIP_02`,
				`COMPONENT_ADVANCEDRIFLE_CLIP_02`,
				`COMPONENT_SPECIALCARBINE_CLIP_02`,
				`COMPONENT_BULLPUPRIFLE_CLIP_02`,
				`COMPONENT_BULLPUPRIFLE_MK2_CLIP_02`,
				`COMPONENT_SPECIALCARBINE_MK2_CLIP_02`,
				`COMPONENT_ASSAULTRIFLE_MK2_CLIP_02`,
				`COMPONENT_CARBINERIFLE_MK2_CLIP_02`,
				`COMPONENT_COMPACTRIFLE_CLIP_02`,
				`COMPONENT_MILITARYRIFLE_CLIP_02`,
				`COMPONENT_HEAVYRIFLE_CLIP_02`,
				`COMPONENT_MG_CLIP_02`,
				`COMPONENT_COMBATMG_CLIP_02`,
				`COMPONENT_COMBATMG_MK2_CLIP_02`,
				`COMPONENT_GUSENBERG_CLIP_02`,
				`COMPONENT_MARKSMANRIFLE_CLIP_02`,
				`COMPONENT_MARKSMANRIFLE_MK2_CLIP_02`,
				`COMPONENT_HEAVYSNIPER_MK2_CLIP_02`,
			},
			usetime = 15,
		},
	},
	["grip_attachment"] = {
		label = "Impugnatura",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "grip",
		client = {
			component = {
				`COMPONENT_AT_AR_AFGRIP`,
				`COMPONENT_AT_AR_AFGRIP_02`,
			},
			usetime = 15,
		},
	},

	["comp_attachment"] = {
		label = "Compensatore",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_PI_COMP`,
				`COMPONENT_AT_PI_COMP_02`,
				`COMPONENT_AT_PI_COMP_03`,
			},
			usetime = 15,
		},
	},
	["digicamo_attachment"] = {
		label = "Mimetica Digitale",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO`,
				`COMPONENT_PISTOL_MK2_CAMO`,
				`COMPONENT_REVOLVER_MK2_CAMO`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO`,
				`COMPONENT_COMBATMG_MK2_CAMO`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO`,
			},
			usetime = 15,
		},
	},
	["drum_attachment"] = {
		label = "Caricatore a Tamburo",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "magazine",
		client = {
			component = {
				`COMPONENT_SMG_CLIP_03`,
				`COMPONENT_MACHINEPISTOL_CLIP_03`,
				`COMPONENT_COMBATPDW_CLIP_03`,
				`COMPONENT_HEAVYSHOTGUN_CLIP_03`,
				`COMPONENT_ASSAULTRIFLE_CLIP_03`,
				`COMPONENT_CARBINERIFLE_CLIP_03`,
				`COMPONENT_SPECIALCARBINE_CLIP_03`,
				`COMPONENT_COMPACTRIFLE_CLIP_03`,
			},
			usetime = 15,
		},
	},
	["fat_end_muzzle_brake"] = {
		label = "Freno di Bocca Fat End",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_03`,
			},
			usetime = 15,
		},
	},
	["flashlight_attachment"] = {
		label = "Torcia",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "flashlight",
		client = {
			component = {
				`COMPONENT_AT_PI_FLSH`,
				`COMPONENT_AT_PI_FLSH_02`,
				`COMPONENT_AT_PI_FLSH_03`,
				`COMPONENT_AT_AR_FLSH`,
			},
			usetime = 15,
		},
	},
	["flat_muzzle_brake"] = {
		label = "Freno di Bocca Piatto",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_01`,
			},
			usetime = 15,
		},
	},
	["geocamo_attachment"] = {
		label = "Mimetica Geometrica",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_09`,
				`COMPONENT_PISTOL_MK2_CAMO_09`,
				`COMPONENT_REVOLVER_MK2_CAMO_09`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_09`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_09`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_09`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_09`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_09`,
				`COMPONENT_COMBATMG_MK2_CAMO_09`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_09`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_09`,
			},
			usetime = 15,
		},
	},
	["heavy_duty_muzzle_brake"] = {
		label = "Freno di Bocca HD",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_05`,
			},
			usetime = 15,
		},
	},
	["holoscope_attachment"] = {
		label = "Mirino Olografico",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_SIGHTS`,
			},
			usetime = 15,
		},
	},
	["largescope_attachment"] = {
		label = "Mirino Grande",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_SCOPE_LARGE`,
				`COMPONENT_AT_SCOPE_LARGE_FIXED_ZOOM`,
				`COMPONENT_AT_SCOPE_LARGE_MK2`,
			},
			usetime = 15,
		},
	},
	["leopardcamo_attachment"] = {
		label = "Mimetica Leopardo",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_07`,
				`COMPONENT_PISTOL_MK2_CAMO_07`,
				`COMPONENT_REVOLVER_MK2_CAMO_07`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_07`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_07`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_07`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_07`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_07`,
				`COMPONENT_COMBATMG_MK2_CAMO_07`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_07`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_07`,
			},
			usetime = 15,
		},
	},
	["luxuryfinish_attachment"] = {
		label = "Finitura di Lusso",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_PISTOL_VARMOD_LUXE`,
				`COMPONENT_COMBATPISTOL_VARMOD_LOWRIDER`,
				`COMPONENT_APPISTOL_VARMOD_LUXE`,
				`COMPONENT_PISTOL15_VARMOD_LUXE`,
				`COMPONENT_REVOLVER_VARMOD_GOON`,
				`COMPONENT_SNSPISTOL_VARMOD_LOWRIDER`,
				`COMPONENT_HEAVYPISTOL_VARMOD_LUXE`,
				`COMPONENT_SMG_VARMOD_LUXE`,
				`COMPONENT_ASSAULTSMG_VARMOD_LOWRIDER`,
				`COMPONENT_MICROSMG_VARMOD_LUXE`,
				`COMPONENT_PUMPSHOTGUN_VARMOD_LOWRIDER`,
				`COMPONENT_SAWNOFFSHOTGUN_VARMOD_LUXE`,
				`COMPONENT_ASSAULTRIFLE_VARMOD_LUXE`,
				`COMPONENT_CARBINERIFLE_VARMOD_LUXE`,
				`COMPONENT_ADVANCEDRIFLE_VARMOD_LUXE`,
				`COMPONENT_SPECIALCARBINE_VARMOD_LOWRIDER`,
				`COMPONENT_BULLPUPRIFLE_VARMOD_LOW`,
				`COMPONENT_MG_VARMOD_LOWRIDER`,
				`COMPONENT_COMBATMG_VARMOD_LOWRIDER`,
				`COMPONENT_SNIPERRIFLE_VARMOD_LUXE`,
				`COMPONENT_MARKSMANRIFLE_VARMOD_LUXE`,
			},
			usetime = 15,
		},
	},
	["medscope_attachment"] = {
		label = "Mirino Medio",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_SCOPE_SMALL_SMG_MK2`,
				`COMPONENT_AT_SCOPE_SMALL_MK2`,
				`COMPONENT_AT_SCOPE_MEDIUM`,
				`COMPONENT_AT_SCOPE_MEDIUM_MK2`,
			},
			usetime = 15,
		},
	},
	["nvscope_attachment"] = {
		label = "Mirino Notturno",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_SCOPE_NV`,
			},
			usetime = 15,
		},
	},
	["patriotcamo_attachment"] = {
		label = "Mimetica Patriottica",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_REVOLVER_MK2_CAMO_IND_01`,
				`COMPONENT_SNSPISTOL_MK2_CAMO_IND_01`,
				`COMPONENT_PISTOL_MK2_CAMO_IND_01`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_IND_01`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_IND_01`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_IND_01`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_IND_01`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_IND_01`,
				`COMPONENT_COMBATMG_MK2_CAMO_IND_01`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_IND_01`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_IND_01`,
			},
			usetime = 15,
		},
	},
	["perseuscamo_attachment"] = {
		label = "Mimetica Perseo",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_06`,
				`COMPONENT_PISTOL_MK2_CAMO_06`,
				`COMPONENT_REVOLVER_MK2_CAMO_06`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_06`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_06`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_06`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_06`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_06`,
				`COMPONENT_COMBATMG_MK2_CAMO_06`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_06`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_06`,
			},
			usetime = 15,
		},
	},
	["precision_muzzle_brake"] = {
		label = "Freno di Bocca di Precisione",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_04`,
			},
			usetime = 15,
		},
	},
	["sessantacamo_attachment"] = {
		label = "Mimetica Sessanta Nove",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_05`,
				`COMPONENT_PISTOL_MK2_CAMO_05`,
				`COMPONENT_REVOLVER_MK2_CAMO_05`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_05`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_05`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_05`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_05`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_05`,
				`COMPONENT_COMBATMG_MK2_CAMO_05`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_05`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_05`,
			},
			usetime = 15,
		},
	},
	["skullcamo_attachment"] = {
		label = "Mimetica Teschio",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_04`,
				`COMPONENT_PISTOL_MK2_CAMO_04`,
				`COMPONENT_REVOLVER_MK2_CAMO_04`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_04`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_04`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_04`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_04`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_04`,
				`COMPONENT_COMBATMG_MK2_CAMO_04`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_04`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_04`,
			},
			usetime = 15,
		},
	},
	["slanted_muzzle_brake"] = {
		label = "Freno di Bocca Inclinato",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_06`,
			},
			usetime = 15,
		},
	},
	["smallscope_attachment"] = {
		label = "Mirino Piccolo",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_PI_RAIL`,
				`COMPONENT_AT_PI_RAIL_02`,
				`COMPONENT_AT_SCOPE_MACRO`,
				`COMPONENT_AT_SCOPE_MACRO_02`,
				`COMPONENT_AT_SCOPE_SMALL`,
				`COMPONENT_AT_SCOPE_SMALL_02`,
				`COMPONENT_AT_SCOPE_MACRO_MK2`,
				`COMPONENT_AT_SCOPE_MACRO_02_SMG_MK2`,
				`COMPONENT_AT_SCOPE_MACRO_02_MK2`,
			},
			usetime = 15,
		},
	},
	["split_end_muzzle_brake"] = {
		label = "Freno di Bocca Split End",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_07`,
			},
			usetime = 15,
		},
	},
	["squared_muzzle_brake"] = {
		label = "Freno di Bocca Squadrato",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_08`,
			},
			usetime = 15,
		},
	},
	["suppressor_attachment"] = {
		label = "Silenziatore",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_PI_SUPP_02`,
				`COMPONENT_AT_PI_SUPP`,
				`COMPONENT_AT_AR_SUPP_02`,
				`COMPONENT_CERAMICPISTOL_SUPP`,
				`COMPONENT_AT_SR_SUPP`,
				`COMPONENT_AT_AR_SUPP`,
				`COMPONENT_AT_SR_SUPP_03`,
			},
			usetime = 15,
		},
	},
	["tactical_muzzle_brake"] = {
		label = "Freno di Bocca Tattico",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "muzzle",
		client = {
			component = {
				`COMPONENT_AT_MUZZLE_02`,
			},
			usetime = 15,
		},
	},
	["thermalscope_attachment"] = {
		label = "Mirino Termico",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "scope",
		client = {
			component = {
				`COMPONENT_AT_SCOPE_THERMAL`,
			},
			usetime = 15,
		},
	},

	["weapontint_0"] = {
		label = "Colorazione Predefinita",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_1"] = {
		label = "Colorazione Verde",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_2"] = {
		label = "Colorazione Oro",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_3"] = {
		label = "Colorazione Rosa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_4"] = {
		label = "Colorazione Militare",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_5"] = {
		label = "Colorazione LSPD",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_6"] = {
		label = "Colorazione Arancione",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_7"] = {
		label = "Colorazione Platino",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_0"] = {
		label = "Colorazione Nera Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_1"] = {
		label = "Colorazione Grigia Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_10"] = {
		label = "Colorazione a Contrasto Blu",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_11"] = {
		label = "Colorazione a Contrasto Gialla",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_12"] = {
		label = "Colorazione a Contrasto Arancione",
		weight = 1,
		stack = true,
		close = true,
	},
	["woodcamo_attachment"] = {
		label = "Mimetica Boschiva",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_03`,
				`COMPONENT_PISTOL_MK2_CAMO_03`,
				`COMPONENT_REVOLVER_MK2_CAMO_03`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_03`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_03`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_03`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_03`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_03`,
				`COMPONENT_COMBATMG_MK2_CAMO_03`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_03`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_03`,
			},
			usetime = 15,
		},
	},
	["zebracamo_attachment"] = {
		label = "Mimetica Zebra",
		weight = 1,
		stack = true,
		close = true,
		consume = 0,
		component = true,
		type = "skin",
		client = {
			component = {
				`COMPONENT_SNSPISTOL_MK2_CAMO_08`,
				`COMPONENT_PISTOL_MK2_CAMO_08`,
				`COMPONENT_REVOLVER_MK2_CAMO_08`,
				`COMPONENT_PUMPSHOTGUN_MK2_CAMO_08`,
				`COMPONENT_BULLPUPRIFLE_MK2_CAMO_08`,
				`COMPONENT_SPECIALCARBINE_MK2_CAMO_08`,
				`COMPONENT_ASSAULTRIFLE_MK2_CAMO_08`,
				`COMPONENT_CARBINERIFLE_MK2_CAMO_08`,
				`COMPONENT_COMBATMG_MK2_CAMO_08`,
				`COMPONENT_MARKSMANRIFLE_MK2_CAMO_08`,
				`COMPONENT_HEAVYSNIPER_MK2_CAMO_08`,
			},
			usetime = 15,
		},
	},

	["weapontint_mk2_13"] = {
		label = "Colorazione Rosa Accesa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_14"] = {
		label = "Colorazione Viola e Gialla Accesa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_15"] = {
		label = "Colorazione Arancione Accesa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_16"] = {
		label = "Colorazione Verde e Viola Accesa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_17"] = {
		label = "Colorazione con Dettagli Rossi Accesi",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_18"] = {
		label = "Colorazione con Dettagli Verdi Accesi",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_19"] = {
		label = "Colorazione con Dettagli Ciano Accesi",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_2"] = {
		label = "Colorazione Classica Bicolore",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_20"] = {
		label = "Colorazione con Dettagli Gialli Accesi",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_21"] = {
		label = "Colorazione Rossa e Bianca Accesa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_22"] = {
		label = "Colorazione Blu e Bianca Accesa",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_23"] = {
		label = "Colorazione Oro Metallizzato",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_24"] = {
		label = "Colorazione Platino Metallizzato",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_25"] = {
		label = "Colorazione Grigia e Lilla Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_26"] = {
		label = "Colorazione Viola e Lime Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_27"] = {
		label = "Colorazione Rossa Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_28"] = {
		label = "Colorazione Verde Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_29"] = {
		label = "Colorazione Blu Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_3"] = {
		label = "Colorazione Bianca Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_30"] = {
		label = "Colorazione Bianca e Acqua Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_31"] = {
		label = "Colorazione Arancione e Gialla Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_32"] = {
		label = "Colorazione Rossa e Gialla Metallizzata",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_4"] = {
		label = "Colorazione Beige Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_5"] = {
		label = "Colorazione Verde Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_6"] = {
		label = "Colorazione Blu Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_7"] = {
		label = "Colorazione Terra Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_8"] = {
		label = "Colorazione Marrone e Nera Classica",
		weight = 1,
		stack = true,
		close = true,
	},

	["weapontint_mk2_9"] = {
		label = "Colorazione a Contrasto Rossa",
		weight = 1,
		stack = true,
		close = true,
	},

	["hacking_computer"] = {
		label = "Computer per Hacking",
		weight = 1,
		stack = true,
		close = true,
	},

	["gas_mask"] = {
		label = "Maschera Antigas",
		weight = 1,
		stack = true,
		close = true,
	},

	["diamonds_box"] = {
		label = "Scatola di Diamanti",
		weight = 1,
		stack = true,
		close = true,
	},

	["painting"] = {
		label = "Dipinto",
		weight = 1,
		stack = true,
		close = true,
	},

	["thermal_charge"] = {
		label = "Carica Termica",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_coke"] = {
		label = "Kofola del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_donut"] = {
		label = "Ciambella del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_ego_chaser"] = {
		label = "Ego Chaser del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_luckypotion"] = {
		label = "Pozione Fortunata del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_psqs"] = {
		label = "Ps & Qs del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_sandwitch"] = {
		label = "Panino del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_sprite"] = {
		label = "Sprite del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_beer"] = {
		label = "Birra del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_burger"] = {
		label = "Hamburger del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_chips"] = {
		label = "Fish del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["casino_coffee"] = {
		label = "Caffè del Casinò",
		weight = 1,
		stack = true,
		close = true,
	},

	["slaughtered_chicken"] = {
		label = "Pollo Macellato",
		weight = 1,
		stack = true,
		close = true,
	},


    ---------- [ fumo ] ----------

	["shisha_0"] = { label = "Shisha (Blu)", weight = 1, stack = true, close = true },
	["shisha_1"] = { label = "Shisha (Rossa)", weight = 1, stack = true, close = true },
	["shisha_2"] = { label = "Shisha (Rosa)", weight = 1, stack = true, close = true },
	["shisha_3"] = { label = "Shisha (Verde)", weight = 1, stack = true, close = true },
	["shisha_4"] = { label = "Shisha (Gialla)", weight = 1, stack = true, close = true },
	["shisha_5"] = { label = "Shisha (Grigia)", weight = 1, stack = true, close = true },

	["shisha_charcoal_box"] = { label = "Scatola di carboni per shisha", weight = 1, stack = true, close = true },

	["shisha_tobacco_apple"] = { label = "Tabacco per shisha (Mela)", weight = 1, stack = true, close = true },
	["shisha_tobacco_blueberry"] = { label = "Tabacco per shisha (Mirtillo)", weight = 1, stack = true, close = true },
	["shisha_tobacco_lemon"] = { label = "Tabacco per shisha (Limone)", weight = 1, stack = true, close = true },
	["shisha_tobacco_mint"] = { label = "Tabacco per shisha (Menta)", weight = 1, stack = true, close = true },
	["shisha_tobacco_orange"] = { label = "Tabacco per shisha (Arancia)", weight = 1, stack = true, close = true },
	["shisha_tobacco_strawberry"] = { label = "Tabacco per shisha (Fragola)", weight = 1, stack = true, close = true },
	["shisha_tobacco_vanilla"] = { label = "Tabacco per shisha (Vaniglia)", weight = 1, stack = true, close = true },
	["shisha_tobacco_watermelon"] = { label = "Tabacco per shisha (Anguria)", weight = 1, stack = true, close = true },

	["eliquid_box_apple"] = { label = "E-Liquid (Mela)", weight = 1, stack = true, close = true },
	["eliquid_box_blueberry"] = { label = "E-Liquid (Mirtillo)", weight = 1, stack = true, close = true },
	["eliquid_box_cherry"] = { label = "E-Liquid (Ciliegia)", weight = 1, stack = true, close = true },
	["eliquid_box_ecola"] = { label = "E-Liquid (eCola)", weight = 1, stack = true, close = true },
	["eliquid_box_grape"] = { label = "E-Liquid (Uva)", weight = 1, stack = true, close = true },
	["eliquid_box_lemon"] = { label = "E-Liquid (Limone)", weight = 1, stack = true, close = true },
	["eliquid_box_mint"] = { label = "E-Liquid (Menta)", weight = 1, stack = true, close = true },
	["eliquid_box_orange"] = { label = "E-Liquid (Arancia)", weight = 1, stack = true, close = true },
	["eliquid_box_peach"] = { label = "E-Liquid (Pesca)", weight = 1, stack = true, close = true },
	["eliquid_box_strawberry"] = { label = "E-Liquid (Fragola)", weight = 1, stack = true, close = true },
	["eliquid_box_vanilla"] = { label = "E-Liquid (Vaniglia)", weight = 1, stack = true, close = true },
	["eliquid_box_watermelon"] = { label = "E-Liquid (Anguria)", weight = 1, stack = true, close = true },

	['vape_1_red'] = {
		label = 'Vape 1 (Rossa)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore rosso.'
	},

	['vape_1_blue'] = {
		label = 'Vape 1 (Blu)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore blu.'
	},

	['vape_1_pink'] = {
		label = 'Vape 1 (Rosa)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore rosa.'
	},

	['vape_1_turquoise'] = {
		label = 'Vape 1 (Turchese)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore turchese.'
	},

	['vape_1_yellow'] = {
		label = 'Vape 1 (Gialla)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore giallo.'
	},

	['vape_1_white'] = {
		label = 'Vape 1 (Bianca)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore bianco.'
	},

	['vape_2_red'] = {
		label = 'Vape 2 (Rossa)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore rosso.'
	},

	['vape_2_blue'] = {
		label = 'Vape 2 (Blu)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore blu.'
	},

	['vape_2_pink'] = {
		label = 'Vape 2 (Rosa)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore rosa.'
	},

	['vape_2_turquoise'] = {
		label = 'Vape 2 (Turchese)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore turchese.'
	},

	['vape_2_yellow'] = {
		label = 'Vape 2 (Gialla)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore giallo.'
	},

	['vape_2_white'] = {
		label = 'Vape 2 (Bianca)',
		weight = 1,
		stack = true,
		close = true,
		description = 'Una sigaretta elettronica di colore bianco.'
	},


	--[[
	['water'] = {
		label = 'Bottiglia d'acqua',
		weight = 15,
		degrade = 0.2,
		
decay = true,
durability = 0.01,
		stack = true,
		close = true,
		description = 'Una bottiglia di acqua potabile.'
	},
	]]--


	['lighter'] = {
		label = 'Accendino',
		weight = 10,
		stack = false,
		close = false,
		description = 'Usato per accendere sigarette, canne o sigari.'
	},

	['cigarette_redwood_pack'] = {
		label = 'Sigarette Redwood (Pacchetto)',
		weight = 200,
		stack = true,
		close = true,
		description = 'Un pacchetto di sigarette Redwood.'
	},

	['cigarette_debonair_pack'] = {
		label = 'Sigarette Debonaire (Pacchetto)',
		weight = 200,
		stack = true,
		close = true,
		description = 'Un pacchetto di sigarette Debonaire.'
	},

	['cigar_estancia_pack'] = {
		label = 'Sigari Estancia (Pacchetto)',
		weight = 15,
		stack = true,
		close = true,
		description = 'Un sigaro Estancia di alta qualità.'
	},

	['cigarette_redwood'] = {
		label = 'Sigaretta Redwood',
		weight = 10,
		stack = true,
		close = true,
		description = 'Una singola sigaretta Redwood.'
	},

	['cigarette_debonair'] = {
		label = 'Sigaretta Debonaire',
		weight = 10,
		stack = true,
		close = true,
		description = 'Una singola sigaretta Debonaire.'
	},

	['cigar_estancia'] = {
		label = 'Sigaro Estancia',
		weight = 15,
		stack = true,
		close = true,
		description = 'Un sigaro Estancia premium.'
	},
	['bong'] = {
		label = 'Bong di vetro',
		weight = 800,
		stack = false,
		close = true,
		description = 'Un bong di vetro usato per fumare marijuana.'
	},

	['rolling_papers_pack'] = {
		label = 'Cartine (Pacchetto)',
		weight = 15,
		stack = true,
		close = true,
		description = 'Un pacchetto di cartine usate per preparare le canne.'
	},

	['vape_battery'] = {
		label = 'Batteria per vape',
		weight = 15,
		stack = true,
		close = false,
		description = 'Una batteria utilizzata per alimentare le cartucce della sigaretta elettronica.'
	},

    --[[
	["medikit"] = {
		label = "Kit medico",
		weight = 2,
		stack = true,
		close = true,
	},
    ]]

	["lspd_badge"] = {
		label = "Distintivo della polizia",
		weight = 0,
		stack = true,
		close = true,
	},

	['boombox'] = {
        label = 'Boombox',
        weight = 1000,
        stack = false,
        close = true,
        consume = 0,
        client = {
            export = 'Camou_Boombox.placeBoombox'
        }
    },

    ['blank_cassette'] = {
        label = 'Cassetta vuota',
        weight = 15,
        stack = true
    },

    ['music_cassette'] = {
        label = 'Cassetta',
        weight = 15,
        stack = false
    },
    ['generialimentari'] = {
        label = 'Generi Alimentari',
        weight = 15,
        stack = true
    },
  ['generiliquidi'] = {
        label = 'Ingredienti Bevande',
        weight = 15,
        stack = true
    },

    ["diamond_pack"] = {
        label = "Sacchetto di diamanti",
        weight = 1,
        stack = true,
        close = true
    },
    ["bauxit_ingot"] = {
        label = "Lingotto di bauxite",
        weight = 1,
        stack = true,
        close = true
    },
    ["ruby_pack"] = {
        label = "Sacchetto di rubini",
        weight = 1,
        stack = true,
        close = true
    },
    ["sapphire_pack"] = {
        label = "Sacchetto di zaffiri",
        weight = 1,
        stack = true,
        close = true
    },
    ["silver_ingot"] = {
        label = "Lingotto d'argento",
        weight = 1,
        stack = true,
        close = true
    },
    ["gold_ingot"] = {
        label = "Lingotto d'oro",
        weight = 1,
        stack = true,
        close = true
    },
    ["iron_ingot"] = {
        label = "Lingotto di ferro",
        weight = 1,
        stack = true,
        close = true
    },
    ["copper_ingot"] = {
        label = "Lingotto di rame",
        weight = 1,
        stack = true,
        close = true
    },
    ["zinc_ingot"] = {
        label = "Lingotto di zinco",
        weight = 1,
        stack = true,
        close = true
    },
    ["coal_pack"] = {
        label = "Sacchetto di carbone",
        weight = 1,
        stack = true,
        close = true
    },

    ---------------------------------
['scratch_card'] = {
        label = 'Gratta e Vinci',
    },

    ['scratch_card_premium'] = {
        label = 'Gratta e Vinci Premium',
    },
    
    ['scratch_card_vip'] = {
        label = 'Gratta e Vinci VIP',
    },

	["alive_chicken"] = {
		label = "Pollo vivo",
		weight = 1,
		stack = true,
		close = true,
	},

	["blowpipe"] = {
		label = "Fiamma ossidrica",
		weight = 2,
		stack = true,
		close = true,
	},

	["cannabis"] = {
		label = "Cannabis",
		weight = 3,
		stack = true,
		close = true,
	},

	["carokit"] = {
		label = "Kit carrozzeria",
		weight = 3,
		stack = true,
		close = true,
	},

	["carotool"] = {
		label = "Attrezzi",
		weight = 2,
		stack = true,
		close = true,
	},

	["clothe"] = {
		label = "Vestiti",
		weight = 1,
		stack = true,
		close = true,
	},

	["copper"] = {
		label = "Rame",
		weight = 1,
		stack = true,
		close = true,
	},

	["cutted_wood"] = {
		label = "Legno tagliato",
		weight = 1,
		stack = true,
		close = true,
	},

	["essence"] = {
		label = "Benzina",
		weight = 1,
		stack = true,
		close = true,
	},

	["stone"] = {
		label = "Pietra",
		weight = 1,
		stack = true,
		close = true,
	},

	["washed_stone"] = {
		label = "Pietra lavata",
		weight = 1,
		stack = true,
		close = true,
	},

	["marijuana"] = {
		label = "Marijuana",
		weight = 2,
		stack = true,
		close = true,
	},

	["wool"] = {
		label = "Lana",
		weight = 1,
		stack = true,
		close = true,
	},

	["packaged_chicken"] = {
		label = "Filetto di pollo",
		weight = 1,
		stack = true,
		close = true,
	},

	["packaged_plank"] = {
		label = "Legno imballato",
		weight = 1,
		stack = true,
		close = true,
	},

	["fabric"] = {
		label = "Tessuto",
		weight = 1,
		stack = true,
		close = true,
	},

	["fish"] = {
		label = "Pesce",
		weight = 1,
		stack = true,
		close = true,
	},

	["fixtool"] = {
		label = "Attrezzi da riparazione",
		weight = 2,
		stack = true,
		close = true,
	},

	["gazbottle"] = {
		label = "Bombola di gas",
		weight = 2,
		stack = true,
		close = true,
	},

	["gold"] = {
		label = "Oro",
		weight = 1,
		stack = true,
		close = true,
	},

	["petrol_raffin"] = {
		label = "Petrolio raffinato",
		weight = 1,
		stack = true,
		close = true,
	},

	["iron"] = {
		label = "Ferro",
		weight = 1,
		stack = true,
		close = true,
	},

	["petrol"] = {
		label = "Petrolio",
		weight = 1,
		stack = true,
		close = true,
	},

    -----------------------

    ['drone'] = {
        label = 'Drone',
        weight = 10,
        stack = false,
        close = true,
        client = {
            event = 'dz-drone:client:InitiateDrone',
        },
    },
    ['drone_lspd'] = {
        label = 'LSPD Drone',
        weight = 10,
        stack = false,
        close = true,
        client = {
            event = 'dz-drone:client:InitiateDroneLSPD',
        },
    },

	["medikit"] = {
		label = "Medikit",
		weight = 2,
		stack = true,
		close = true,
	},

    ----------------------------------------------------------------------------------------
    ['ammonia'] = {
        label = 'Ammoniaca',
        weight = 15,
        stack = true,
    },

    ['sodium_benzoate'] = {
        label = 'Benzoato di sodio',
        weight = 715,
        stack = true,
    },

    ['meth_tray'] = {
        label = 'Vassoio per metanfetamina',
        weight = 10,
        stack = true,
    },

    ['meth'] = {
        label = 'Metanfetamina',
        weight = 1,
        stack = true,
    },

    ['meth_bag'] = {
        label = 'Bustina di metanfetamina',
        weight = 15,
        stack = true,
    },

    ['plastic_bag'] = {
        label = 'Bustina di plastica',
        weight = 1,
        stack = true,
    },

    ['meth_syringe'] = {
        label = 'Siringa di metanfetamina',
        weight = 75,
        stack = true,
    },

    -- Oggetti relativi alla cocaina
    ['coke_seed'] = {
        label = 'Seme di coca',
        weight = 10,
        stack = true,
    },

    ['coke_leaf'] = {
        label = 'Foglia di coca',
        weight = 15,
        stack = true,
    },

    ['coke_paste'] = {
        label = 'Pasta di coca',
        weight = 15,
        stack = true,
    },

    ['coke'] = {
        label = 'Cocaina',
        weight = 1,
        stack = true,
    },

    ['coke_bag'] = {
        label = 'Bustina di cocaina',
        weight = 15,
        stack = true,
    },

    ['coke_brick'] = {
        label = 'Panetto di cocaina',
        weight = 200,
        stack = true,
    },

    ['coke_doll'] = {
        label = 'Bambola con cocaina',
        weight = 15,
        stack = true,
    },

    -- Oggetti relativi alla marijuana
    ['weed_seed'] = {
        label = 'Seme di marijuana',
        weight = 5,
        stack = true,
    },

    ['weed_pot'] = {
        label = 'Vaso per piante',
        weight = 15,
        stack = true,
    },

    ['trowel'] = {
        label = 'Paletta da giardinaggio',
        weight = 15,
        stack = true,
    },

    ['weed_bud'] = {
        label = 'Cima di marijuana',
        weight = 25,
        stack = true,
    },

    ['clean_weed_bud'] = {
        label = 'Cima di marijuana pulita',
        weight = 20,
        stack = true,
    },

    ['cookie_dough'] = {
        label = 'Impasto per biscotti',
        weight = 200,
        stack = true
    },

    ['weed_cookie'] = {
        label = 'Biscotto alla marijuana',
        weight = 15,
        stack = true
    },

    ['weed_bag'] = {
        label = 'Bustina di marijuana',
        weight = 15,
        stack = true,
    },

    ['weed_joint'] = {
        label = 'Canna',
        weight = 15,
        stack = true,
    },

    ['weed_papers'] = {
        label = 'Cartine',
        weight = 5,
        stack = true,
    },

    -- Oggetti relativi all'eroina
    ['poppy_seeds'] = {
        label = 'Semi di papavero',
        weight = 5,
        stack = true,
    },

    ['poppy_plant'] = {
        label = 'Pianta di papavero',
        weight = 10,
        stack = true,
    },

    ['opium'] = {
        label = 'Oppio',
        weight = 1,
        stack = true,
    },

    ['heroin'] = {
        label = 'Eroina',
        weight = 1,
        stack = true,
    },

    ['heroin_bag'] = {
        label = 'Bustina di eroina',
        weight = 15,
        stack = true,
    },

    ['heroin_syringe'] = {
        label = 'Siringa di eroina',
        weight = 75,
        stack = true,
    },

    ['syringe'] = {
        label = 'Siringa',
        weight = 25,
        stack = true,
    },

    -- Oggetti relativi all'LSD
    ['ergot_fungus'] = {
        label = 'Fungo della segale cornuta',
        weight = 15,
        stack = true,
    },

    ['generic_leaf'] = {
        label = 'Foglia',
        weight = 20,
        stack = true,
    },

    ['lsd_liquid'] = {
        label = 'LSD liquido',
        weight = 25,
        stack = true,
    },

    ['lsd'] = {
        label = 'LSD',
        weight = 1,
        stack = true,
    },

    ['art_papers'] = {
        label = 'Cartoncini decorati',
        weight = 5,
        stack = true,
    },

    -- Oggetti relativi all'ecstasy
    ['safrole_oil'] = {
        label = 'Olio di safrolo',
        weight = 30,
        stack = true,
    },

    ['ecstasy_crystals'] = {
        label = 'Cristalli di ecstasy',
        weight = 1,
        stack = true,
    },

    ['ecstasy_pill'] = {
        label = 'Pillola di ecstasy',
        weight = 15,
        stack = true,
    },

    -- Oggetti relativi ai funghi
    ['mushrooms'] = {
        label = 'Funghi',
        weight = 1,
        stack = true,
    },

    ['mushroom_powder'] = {
        label = 'Polvere di funghi',
        weight = 1,
        stack = true,
    },

    ['chocolate_chips'] = {
        label = 'Gocce di cioccolato',
        weight = 30,
        stack = true,
    },

    ['mushroom_chocolate'] = {
        label = 'Cioccolato ai funghi',
        weight = 45,
        stack = true,
    },

    -- Oggetti relativi alla ketamina
    ['anesthetic'] = {
        label = 'Anestetico',
        weight = 200,
        stack = true,
    },

    ['ketamine'] = {
        label = 'Ketamina',
        weight = 1,
        stack = true,
    },

    ['ketamine_bag'] = {
        label = 'Bustina di ketamina',
        weight = 15,
        stack = true,
    },

    -- Oggetti relativi al crack
    ['baking_soda'] = {
        label = 'Bicarbonato di sodio',
        weight = 10,
        stack = true,
    },


    ['crack_bag'] = {
        label = 'Bustina di crack',
        weight = 15,
        stack = true,
    },

    ['crack_pipe'] = {
        label = 'Pipa da crack',
        weight = 15,
        stack = true,
    },

    ['crack_syringe'] = {
        label = 'Siringa di crack',
        weight = 75,
        stack = true,
    },

    ['pipe'] = {
        label = 'Pipa',
        weight = 10,
        stack = true,
    },

    -- Oggetti relativi al fentanyl
    ['npp_chemical'] = {
        label = 'Sostanza chimica NPP',
        weight = 30,
        stack = true,
    },

    ['aniline_solution'] = {
        label = 'Soluzione di anilina',
        weight = 15,
        stack = true,
    },

    ['fentanyl'] = {
        label = 'Fentanyl',
        weight = 1,
        stack = true,
    },

    ['fentanyl_bag'] = {
        label = 'Bustina di fentanyl',
        weight = 25,
        stack = true,
    },

    ['meth_table'] = {
        label = 'Banco per metanfetamina',
        weight = 215,
        stack = false
    },

    ['coke_table'] = {
        label = 'Banco per cocaina',
        weight = 215,
        stack = false
    },

    ['weed_table'] = {
        label = 'Banco per marijuana',
        weight = 215,
        stack = false
    },

    ['chem_table'] = {
        label = 'Banco da laboratorio',
        weight = 215,
        stack = false
    },

    ['burner_phone'] = {
        label = 'Telefono usa e getta',
        weight = 200,
        stack = true
    },

    ['light1'] = {
        label = 'Lampada portatile',
        weight = 2000,
        stack = true
    },

    ['light2'] = {
        label = 'Lampada portatile',
        weight = 2000,
        stack = true
    },

    ['fertilizer'] = {
        label = 'Fertilizzante',
        weight = 15,
        stack = true
    },

    ['water_can'] = {
        label = 'Annaffiatoio',
        weight = 15,
        stack = true
    },

    ----------------------------

    ["employeepictures"] = {
        label = "Foto dei dipendenti",
        weight = 25,
        stack = false,
        close = false,
        description = "Foto dei volti dei dipendenti",
    },

    ["pliers"] = {
        label = "Pinza",
        weight = 125,
        stack = false,
        close = false,
        description = "Un paio di pinze",
    },

    ["x_device"] = {
        label = "Flapper Hero",
        weight = 125,
        stack = false,
        close = false,
        description = "?????????",
    },

    ["bag"] = {
        label = "Borsone",
        weight = 15,
        stack = false,
        close = false,
        description = "Borsone da viaggio",
    },

    ["x_laptop"] = {
        label = "Laptop X",
        weight = 15,
        stack = false,
        close = false,
        description = "?????????",
    },

    ["fleecacard"] = {
        label = "Carta Fleeca",
        weight = 30,
        stack = false,
        close = false,
        description = "Carta di sicurezza della Fleeca Bank",
    },
    ['gamepad'] = {
        label = 'Gamepad',
        weight = 15,
        stack = false,
        close = true,
        description = '',
        client = {
            image = 'gamepad.png'
        }
    },

    ["gympass"] = {
        label = "Abbonamento Palestra",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },

    -- Integratori venduti al bancone
    ["acquapalestra"] = {
        label = "Acqua palestra",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["energydrink"] = {
        label = "Bevanda Energetica",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["proteinshake"] = {
        label = "Frullato Proteico",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["proteinbar"] = {
        label = "Barretta Proteica",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["creatine"] = {
        label = "Creatina",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["preworkout"] = {
        label = "Pre-Allenamento",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["bcaa"] = {
        label = "BCAA",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },
    ["vitamins"] = {
        label = "Vitamine",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },

    -- Non venduto da nessuna parte
    ["testosterone"] = {
        label = "Testosterone",
        weight = 1,
        stack = true,
        close = true,
        consume = 0,
        server = {export = "rtx_realistic_gym.UseGymItem"},
    },

    -- Fuochi d'artificio RTX
    ['fireworks_box_normal'] = {
        label = 'Scatola Fuochi d\'Artificio Normali',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_box_mega'] = {
        label = 'Scatola Fuochi d\'Artificio Mega',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_box_ultimate'] = {
        label = 'Scatola Fuochi d\'Artificio Ultimate',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_solar_flare'] = {
        label = 'Razzo Solare',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_rocket'] = {
        label = 'Razzo',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_small'] = {
        label = 'Pirotecnico Piccolo',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_medium'] = {
        label = 'Pirotecnico Medio',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_large'] = {
        label = 'Pirotecnico Grande',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_mega'] = {
        label = 'Pirotecnico Mega',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_pirate'] = {
        label = 'Pirotecnico Pirata',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_rug'] = {
        label = 'Tappeto Pirotecnico',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_ruglong'] = {
        label = 'Tappeto Pirotecnico Lungo',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_flare1'] = {
        label = 'Razzo di Segnalazione 1',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_flare2'] = {
        label = 'Razzo di Segnalazione 2',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_flare3'] = {
        label = 'Razzo di Segnalazione 3',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['fireworks_pyro_fontain'] = {
        label = 'Fontana',
        weight = 10,
        stack = true,
        close = true,
        description = 'Fuochi d\'artificio',
    },

    ['zat-notebook'] = {
        label = 'taccuino',
        weight = 15,
    },

    ["printer_m"] = {
        label = "Stampante 3D M",
        weight = 10,
        stack = false,
        close = true,
        description = "Stampante 3D",
        client = {
            image = "printer_m.png",
        }
    },

    ["printer_xl"] = {
        label = "Stampante 3D XL",
        weight = 10,
        stack = false,
        close = true,
        description = "Stampante 3D",
        client = {
            image = "printer_xl.png",
        }
    },

    ["laptop3d"] = {
        label = "Computer Portatile",
        weight = 10,
        stack = false,
        close = true,
        description = "Computer portatile per la stampa 3D",
        client = {
            image = "laptop3d.png",
        }
    },

    ["usb3d"] = {
        label = "Chiavetta USB",
        weight = 10,
        stack = false,
        close = true,
        description = "La chiavetta USB potrebbe contenere dei progetti",
        client = {
            image = "usb3d.png",
        }
    },

    -- Filamenti

    ["plastic_filament"] = {
        label = "Filamento in Plastica",
        weight = 15,
        stack = true,
        close = true,
        description = "Filamento PLA standard per la stampa 3D",
        client = {
            image = "plastic_filament.png",
        }
    },

    ["abs_filament"] = {
        label = "Filamento ABS",
        weight = 30,
        stack = true,
        close = true,
        description = "Filamento ABS resistente per stampe durevoli",
        client = {
            image = "abs_filament.png",
        }
    },

    ["carbon_filament"] = {
        label = "Filamento in Fibra di Carbonio",
        weight = 15,
        stack = true,
        close = true,
        description = "Filamento in fibra di carbonio ad alta resistenza",
        client = {
            image = "carbon_filament.png",
        }
    },

    ["metal_filament"] = {
        label = "Filamento Rinforzato con Metallo",
        weight = 15,
        stack = true,
        close = true,
        description = "Filamento con particelle metalliche per stampe rinforzate",
        client = {
            image = "metal_filament.png",
        }
    },

    ["petg_filament"] = {
        label = "Filamento PETG",
        weight = 315,
        stack = true,
        close = true,
        description = "Filamento PETG resistente per stampe antiurto",
        client = {
            image = "petg_filament.png",
        }
    },

    ["tpu_filament"] = {
        label = "Filamento TPU",
        weight = 30,
        stack = true,
        close = true,
        description = "Filamento TPU flessibile per stampe simili alla gomma",
        client = {
            image = "tpu_filament.png",
        }
    },

    ["nylon_filament"] = {
        label = "Filamento in Nylon",
        weight = 315,
        stack = true,
        close = true,
        description = "Filamento in nylon ad alta resistenza",
        client = {
            image = "nylon_filament.png",
        }
    },

["document"] = {
    label = "Documento",
    weight = 10,
    stack = false,
    close = true,
    description = "",
    client = {
        image = "document.png",
    },
    buttons = {
        {
            label = "Posiziona a terra",
            action = function(slot)
                exports['kq_placeable_items']:placeItem(slot)
            end
        }
    }
},
    ["camera"] = {
        label = "Fotocamera",
        weight = 10,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "camera.png",
        }
    },

    ["photo"] = {
        label = "Fotografia",
        weight = 10,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "photo.png",
        }
    },

    ["photo_album"] = {
        label = "Album Fotografico",
        weight = 10,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "photo_album.png",
        }
    },

    ["document_folder"] = {
        label = "Cartella Documenti",
        weight = 10,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "document_folder.png",
        }
    },

    ["envelope"] = {
        label = "Busta",
        weight = 10,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "envelope.png",
        }
    },

    ["registerkey1"] = {
        label = "Chiavi",
        weight = 10,
        stack = false,
        close = true,
        description = "",
    },

    ["registerkey2"] = {
        label = "Chiavi",
        weight = 10,
        stack = false,
        close = true,
        description = "",
    },

    ["srecuritycard"] = {
        label = "Tessera di Sicurezza",
        weight = 10,
        stack = false,
        close = true,
        description = "",
        client = {
            image = "srecuritycard.png",
        }
    },

	["sportsbettable"] = {
		label = "Sports Bet Table",
		weight = 7000,
		stack = false,
		close = true,
		description = "A table for placing sports bets",
		client = {
			image = "sportsbettable.png",
		}
	},

    -------------------------------

    ['tradingcard_common'] = {
        label = 'Trading Card Basic',
        weight = 15,
        stack = false,
        consume = 0,
        server = {
            export = 'qs-tradingcards.OpenInterationMenu',
        }
    },
    ['tradingcard_ultra'] = {
        label = 'Trading Card Ultra',
        weight = 15,
        stack = false,
        consume = 0,
        server = {
            export = 'qs-tradingcards.OpenInterationMenu',
        }
    },

    ['tradingcard_rare'] = {
        label = 'Trading Card Rare',
        weight = 15,
        stack = false,
        consume = 0,
        server = {
            export = 'qs-tradingcards.OpenInterationMenu',
        }
    },
    ['tradingcard_super_rare'] = {
        label = 'Trading Card Super Rare',
        weight = 15,
        stack = false,
        consume = 0,
        server = {
            export = 'qs-tradingcards.OpenInterationMenu',
        }
    },
    ['tradingcard_leggendary'] = {
        label = 'Trading Card Legendary',
        weight = 15,
        stack = false,
        consume = 0,
        server = {
            export = 'qs-tradingcards.OpenInterationMenu',
        }
    },

    ['tradingcard_booster_pack'] = {
        label = 'Trading Card Booster',
        weight = 15,
        stack = false,
        consume = 0,
        client = {
            export = 'qs-tradingcards.OpenBoosterPack',
        }
    },

    ['tradingcard_booster_legends'] = {
        label = 'Trading Card Booster Legends',
        weight = 15,
        stack = false,
        consume = 0,
        client = {
            export = 'qs-tradingcards.OpenBoosterPack',
        }
    },

    ['tradingcard_psa'] = {
        label = 'Trading Card Psa',
        weight = 15,
        stack = false,
        consume = 0,
        client = {
            export = 'qs-tradingcards.openPsa'
        },
    },

    ['tradingcard_stash'] = {
        label = 'Trading Card Stash',
        weight = 15,
        stack = false,
        consume = 0,
        server = {
            export = 'qs-tradingcards.openAlbum',
        },
    },

	-- Compatibility definitions retained from the update pack.
	['armor_repair_kit'] = {
		label = 'Armor Repair Kit',
		weight = 15,
		stack = true,
		close = true,
		client = {
			event = 'ox_inventory:utility:applyArmorPlate'
		}
	},

    ["backpack_small"] = {
        label = "Small Backpack",
        weight = 15,
        stack = false,
        close = false,
        description = "A small backpack for carrying extra items.",
        client = { image = "backpack_small.png" }
    },

    ["backpack_medium"] = {
        label = "Medium Backpack",
        weight = 715,
        stack = false,
        close = false,
        description = "A medium backpack for carrying more items.",
        client = { image = "backpack_medium.png" },
        rarity = "common"
    },

    ["backpack_large"] = {
        label = "Large Backpack",
        weight = 10,
        stack = false,
        close = false,
        description = "A large backpack for carrying many items.",
        client = { image = "backpack_large.png" },
        rarity = "common"
    },

    ['plate_flipper_kit'] = {
        label = 'Plate Flipper Kit',
        weight = 600,
        stack = true,
        consume = 0,
        client = { export = '402studio_plateflipper.useKit' },
    },
    
    ['plate_flipper_remote'] = {
        label = 'Plate Flipper Remote',
        weight = 80,
        stack = false,
        consume = 0,
        client = { export = '402studio_plateflipper.useRemote' },
    },
}

-- Integrazione KQ Placeable Items: conserva tutte le azioni originali.
local function placeInventoryItem(slot)
    exports['kq_placeable_items']:placeItem(slot)
end

for itemName, item in pairs(items) do
    -- document include gia il pulsante KQ nel file originale.
    if itemName ~= 'document' then
        item.buttons = item.buttons or {}
        item.buttons[#item.buttons + 1] = {
            label = 'Posiziona a terra',
            action = placeInventoryItem,
        }
    end
end

return items

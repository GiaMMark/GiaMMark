if Config.oxInventorySettings.enabled then
    
    if Config.oxInventorySettings.useFrameworkSpawnEvent then
        RegisterNetEvent('esx:playerLoaded')
        AddEventHandler('esx:playerLoaded', function()
            TriggerServerEvent('kq_materialize:server:spawnedIn')
        end)
        
        RegisterNetEvent('QBCore:Client:OnPlayerLoaded')
        AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
            TriggerServerEvent('kq_materialize:server:spawnedIn')
        end)
    else
        AddEventHandler('playerSpawned', function()
            TriggerServerEvent('kq_materialize:server:spawnedIn')
        end)
    end
    
    function GetPlayerItems()
        local items = json.decode(json.encode(exports.ox_inventory:GetPlayerItems()))
        
        local parsedItems = {}
        
        Debug(json.encode(items))
        
        for k, item in pairs(items) do
            if CanItemBePlaced(item.name) then
                if (item.count ~= nil and item.count >= 1) and (Config.items[item.name] ~= nil or Config.makeEverythingPlaceable.enabled) then
                    table.insert(parsedItems, {
                        label = item.label,
                        name = item.name,
                        sizes = GetSizesOfItem(item.name, item.count or 1)
                    })
                end
            end
        end
        
        return parsedItems
    end
end

-----------------------------
--- PLACEMENT HOOKS
-----------------------------

RegisterNetEvent('kq_materialize:client:hookPlaceItem')
AddEventHandler('kq_materialize:client:hookPlaceItem', function(itemName, size, slot)
    HookPlaceItem(itemName, size or 1, slot)
end)


RegisterNUICallback('HookPlaceItem', function(data, cb)
    HookPlaceItem(data.item, data.size or 1)
    cb(true)
end)

function HookPlaceItem(itemName, size, slot)
    if IsPedInAnyVehicle(PlayerPedId()) then
        Notify(L('~r~You may not place items while in a vehicle'))
    end
    if IS_PLACING or IsPlayerUnreachable() or UI_OPEN then
        return
    end

    if not Config.makeEverythingPlaceable.enabled and (not Config.items[itemName]) then
        Notify(L('~r~This item can not be placed'))
        return
    end

    local model = Config.makeEverythingPlaceable.fallbackProp
    model, size = GetItemModel(itemName, size)

    -- The 4th argument can be used to pass anything you wish to the server.
    -- It's been added with the "slot" in mind for inventories which use slots
    MakePlaceableObject(model, itemName, size or 1, slot)
end


-----------------------------
--- DROPPING HOOKS
-----------------------------


RegisterNUICallback('HookDropItem', function(data, cb)
    HookDropItem(data.item, data.size or 1)
    cb(true)
end)

RegisterNetEvent('kq_materialize:client:hookDropItem')
AddEventHandler('kq_materialize:client:hookDropItem', function(itemName, size, slot)
    HookDropItem(itemName, size or 1, slot or nil)
end)

function HookDropItem(itemName, size, slot)
    local model = Config.makeEverythingPlaceable.fallbackProp
    model, size = GetItemModel(itemName, size)

    ThrowItem(itemName, size, model, slot, vector3(0.0, 4.0, 0.5), 'pickup_object', 'putdown_low')
end


-----------------------------
--- THROWING HOOKS
-----------------------------


RegisterNUICallback('HookThrowItem', function(data, cb)
    HookThrowItem(data.item, data.size or 1)
    cb(true)
end)

RegisterNetEvent('kq_materialize:client:hookThrowItem')
AddEventHandler('kq_materialize:client:hookThrowItem', function(itemName, size, slot)
    HookThrowItem(itemName, size or 1, slot or nil)
end)

function HookThrowItem(itemName, size, slot)
    local model = Config.makeEverythingPlaceable.fallbackProp
    model, size = GetItemModel(itemName, size)

    ThrowItem(itemName, size, model, slot, vector3(0.0, 22.0, 12.0), 'weapons@projectile@', 'drop_underhand')
end

if Config.oxInventorySettings.enabled then
    exports("placeItem", function(slotId)
        local items = exports.ox_inventory:GetPlayerItems()
        exports.ox_inventory:closeInventory()
        
        local itemData
        for slot, data in pairs(items) do
            if slot == slotId then
                itemData = data
            end
        end
        
        TriggerEvent("kq_materialize:client:hookPlaceItem", itemData.name, itemData.count, slotId)
    end)
end

if Config.oxInventorySettings.enabled then

    
    function GetItemLabel(player, item)
        return exports.ox_inventory:GetItem(player, item, nil, false).label
    end
    
    function DoesPlayerHaveItem(player, item, amount, slot)
        return GetPlayerItemAmount(player, item, slot) >= (amount or 1)
    end
    
    function GetPlayerItemAmount(player, item, slot)
        if slot ~= nil then
            local slotData = exports.ox_inventory:GetSlot(player, slot)
            
            if slotData then
                if slotData.name ~= item then
                    return 0
                end
                return slotData.count
            end
            
            return 0
        end
        
        return exports.ox_inventory:GetItem(player, item, nil, false).count
    end
    
    function RemovePlayerItem(player, item, amount, slot)
        local itemData
        
        if slot ~= nil then
            itemData = exports.ox_inventory:GetSlot(player, slot)
        else
            itemData = exports.ox_inventory:GetSlotWithItem(player, item, nil, false)
        end
        
        exports.ox_inventory:RemoveItem(player, item, amount, itemData.metadata, itemData.slot)
        
        return itemData.metadata
    end

    function AddPlayerItem(player, item, amount, meta)
        return exports.ox_inventory:AddItem(player, item, amount, meta)
    end
end

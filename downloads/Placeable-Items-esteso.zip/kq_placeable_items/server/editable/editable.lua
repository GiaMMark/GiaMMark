local sqlDriver = Config.sql.driver


function SqlFetch(query, data)
    if sqlDriver == 'mysql' then
        return MySQL.Sync.fetchAll(query, data or {})
    end

    if sqlDriver == 'oxmysql' then
        if Config.sql.newOxMysql then
            return exports[sqlDriver]:fetchSync(query, data)
        end
        return exports[sqlDriver]:query_async(query, data)
    else
        return exports[sqlDriver]:executeSync(query, data)
    end
end

function SqlInsert(query, data)
    if sqlDriver == 'mysql' then
        MySQL.Sync.insert(query, data)
        return
    end

    if sqlDriver == 'oxmysql' then
        exports[sqlDriver]:insertSync(query, data)
    else
        exports[sqlDriver]:executeSync(query, data)
    end
end



-- entity = placed object
-- materializeId = unique kq_placeable_items identifier
-- player = server id of the player placing it
function CanObjectBePickedUp(entity, materializeId, player)
    return true
end

-- player = server id of the player placing it
-- entity = placed object
-- fullPlacementData = table. containing all the placement data
function OnObjectSpawned(player, entity, fullPlacementData)
    -- Your code here
end

-- player = server id of the player placing it
-- entity = placed object
-- item = item name
-- amount = amount of items placed
-- materializeId = unique kq_placeable_items identifier
function OnObjectPlaced(player, entity, item, amount, materializeId)
    -- Your code here
end

function OnObjectPickup(player, entity, item, amount, materializeId)
    -- Your code here
end



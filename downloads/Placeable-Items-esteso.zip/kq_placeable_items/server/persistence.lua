ITEMS_LOADING = false
ITEMS_LOADED_FULLY = false
ITEMS_LOADED = {}

function SavePlacedItem(object, item, amount, bucket, label, meta)
    local materializeId = Entity(object).state.kq_materialize_id
    local pos = GetEntityCoords(object)
    local rot = GetEntityRotation(object)
    
    local query =
    "INSERT INTO kq_placeable_items (`materialize_id`, `prop`, `item`, `label`, `amount`, `pos_x`, `pos_y`, `pos_z`, `rot_x`, `rot_y`, `rot_z`, `meta`, `bucket`) VALUES(@materialize_id, @prop, @item, @label, @amount, @pos_x, @pos_y, @pos_z, @rot_x, @rot_y, @rot_z, @meta, @bucket);"
    local data = {
        ['@materialize_id'] = materializeId,
        ['@prop'] = GetEntityModel(object),
        ['@item'] = item,
        ['@label'] = label,
        ['@amount'] = amount,
        ['@pos_x'] = pos.x,
        ['@pos_y'] = pos.y,
        ['@pos_z'] = pos.z,
        ['@rot_x'] = rot.x,
        ['@rot_y'] = rot.y,
        ['@rot_z'] = rot.z,
        ['@meta'] = json.encode({
            metadata = meta,
        }),
        ['@bucket'] = bucket,
    }
    
    SqlInsert(query, data)
    
    -- save the loaded item into the ITEMS_LOADED list
    ITEMS_LOADED[materializeId] = object

end

function DeletePlacedItem(object)
    local materializeId = Entity(object).state.kq_materialize_id
    
    local query = "DELETE FROM kq_placeable_items WHERE `materialize_id` = @materialize_id;"
    local data = {
        ['@materialize_id'] = materializeId,
    }
    
    SqlInsert(query, data)
    
    -- drop the loaded item from the ITEMS_LOADED list
    ITEMS_LOADED[materializeId] = nil

end

function LoadSavedItems()
    if ITEMS_LOADING then
        return
    end
    
    RandomRunHash()
    
    print('^2Starting to load in ^3kq_placeable_items^2 items from the database^0')
    
    local query = "SELECT * FROM kq_placeable_items"
    local data = {}
    
    local items = SqlFetch(query, data)
    
    if ITEMS_LOADING then
        return
    end
    
    ITEMS_LOADING = true
    
    local l = #items
    for k, item in pairs(items) do
        
        if ITEMS_LOADED[item.materialize_id] == nil then
            
            local coords = vector3(
                tonumber(item.pos_x),
                tonumber(item.pos_y),
                tonumber(item.pos_z)
            )
            local object = CreateObject(item.prop, coords, 1, 1, 0)
            
            Citizen.Wait(20)
            
            Debug("DEBUG: Loading item "..k.."/"..l..", id = "..item.id)
            
            -- Verify that the item has been spawned. We'll give it ~10 seconds to do so. Otherwise abort
            local timeout = 10000
            while not DoesEntityExist(object) do
                timeout = timeout - 50
                if timeout < 0 then
                    print('^1Items could not be spawned. Script will try again in a bit^0')
                    ITEMS_LOADING = false
                    return
                end
                Citizen.Wait(50)
            end
            
            InitializeSavedObject(item.item, item.amount, object, item.bucket, item.label, json.decode(item.meta), item.materialize_id)
            
            Citizen.Wait(20)
            
            -- We set them again, as FiveM does not like spawning items correctly.
            SetEntityCoords(object, coords)
            SetEntityRotation(object, vector3(
                tonumber(item.rot_x),
                tonumber(item.rot_y),
                tonumber(item.rot_z)
            ))
            
            FreezeEntityPosition(object, true)
            
            Debug('Spawned', item.materialize_id, GetEntityCoords(object))
            
            -- save the loaded item into the ITEMS_LOADED list
            ITEMS_LOADED[item.materialize_id] = object
        end
    end
    
    ITEMS_LOADED_FULLY = true
    print('^2Loaded in saved ^3kq_placeable_items^2 from the database^0')
end

local function StartLoaderThread()
    if PLAYERS_LOADED == 0 and Config.objectPersistence.enabled then
        PLAYERS_LOADED = PLAYERS_LOADED + 1
        Citizen.Wait(5000)
        Citizen.CreateThread(function()
            Citizen.Wait(1000)
            TriggerClientEvent('kq_materialize:client:wipeSavedItems', -1)
            Debug('Loader starting')
            
            -- When items are not fully loaded, loop every 5 sec and if at least 1 player is online, attempt spawning of the items
            Citizen.CreateThread(function()
                while not ITEMS_LOADED_FULLY do
                    Citizen.Wait(10000)
                    if GetNumPlayerIndices() >= 1 then
                        LoadSavedItems()
                    end
                end
            end)
        end)
    end
end


PLAYERS_LOADED = 0
RegisterServerEvent('kq_materialize:server:spawnedIn')
AddEventHandler('kq_materialize:server:spawnedIn', function()
    Debug("kq_materialize:server:spawnedIn")
    StartLoaderThread()
end)

Citizen.CreateThread(function()
    Citizen.Wait(100)
    if GetNumPlayerIndices() >= 1 then
        print('^1The script has been hot restarted! There may be ghost items on the ground! (Players will not receive the item for picking up ghost items)^0')
        StartLoaderThread()
    else
        print('^2Waiting for a player to join before respawning saved items^0^0')
    end
end)

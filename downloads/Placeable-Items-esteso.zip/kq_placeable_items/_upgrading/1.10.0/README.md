# Upgrading to 1.10.0

If your database already has the kq_placeable_items table. You will need to follow this short guide to upgrade your script

Import the `upgrade_1_10_0.sql` file into your database

That's it.
___

If you are using ox inventory. Regardless of the framework. Head over to the 
`config.lua` file, Disable all frameworks, and set `Config.oxInventorySettings` > `enabled` to `true`

This will allow you to use the official ox-inventory integration for kq_placeable_items

Now if you wish to add a "Place" option to the inventory itself, simply add the following to each item within your ox-inventory items (and weapons) lists

```lua
buttons = {{ label = 'Place', action = function(slot) exports['kq_placeable_items']:placeItem(slot) end }},
```

Here's a full example:

```lua
    ["gold"] = {
        label = "Gold",
        weight = 1,
        stack = true,
        close = true,
        buttons = {{ label = 'Place', action = function(slot) exports['kq_placeable_items']:placeItem(slot) end }},
    },
```

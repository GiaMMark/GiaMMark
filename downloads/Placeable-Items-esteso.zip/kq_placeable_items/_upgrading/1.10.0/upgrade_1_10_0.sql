ALTER TABLE `kq_placeable_items`
    ADD COLUMN `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)) AFTER `bucket`;

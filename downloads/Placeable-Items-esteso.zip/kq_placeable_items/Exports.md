# Server exports

## CreatePlacedItem
```lua
CreatePlacedItem(
    prop,
    coords,
    rotation,
    item,
    size,
    label
)
```
 
> - prop - model hash
> - coords - vector3 
> - rotation - vector3
> - item - item which players will get upon pickup
> - size - amount of items players will get upon pickup
> - label - label of the object

**Example:**

```lua
exports['kq_placeable_items']:CreatePlacedItem(
        'apa_mp_h_acc_box_trinket_02',
        vector3(-242.49, -990.21, 29.3),
        vector3(0.0, 0.0, 0.0),
        'iron', 1, 'Iron'
)
```

# Client exports

## GetObjectItemData
```lua
GetObjectItemData(
    entity
)
```

> - entity - Local entity id

**Example:**

```lua
local itemData = exports['kq_placeable_items']:GetObjectItemData(entity)

[[ Output
{
    materializeId, -- Internal placed item identifier
    owner, -- ID of the player who has placed the item (Only available on temporary items)
    available, -- Whether the item is still available
    meta, -- Metadata of the item (Only available when meta exists)
    item, -- Item name of the item
    size, -- Amount of items
}
]]
```

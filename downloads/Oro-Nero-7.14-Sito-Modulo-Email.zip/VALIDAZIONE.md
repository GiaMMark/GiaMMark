# Verifica Oro Nero 7.14.0

## Build e suite

Node.js 22.23.4. `npm run build`, `npm run check` e `npm test` completati: **102 test superati, 0 falliti, 0 saltati**. Menu con 13 categorie e 80 voci; 23 fotografie; quattro cataloghi con 615 chiavi identiche e segnaposto/importi coerenti.

I test del modulo verificano destinazione e metodo POST, campi e validazione, blocco delle date passate e honeypot, codifica dei dati nel collegamento email alternativo, nessun invio automatico e conservazione di nome/email/note alla riapertura. I test preesistenti continuano a coprire menu, funzioni, galleria, traduzioni, intro, musica e navigazione interna.

## Browser reale

Chromium su 36 combinazioni pagina/larghezza: home, menu, galleria, recensioni, allergeni e privacy a 320, 390, 768, 1024, 1440 e 1920 pixel. Nessun overflow orizzontale e nessun errore JavaScript rilevato. QR e schermata di accesso amministrativo verificati separatamente a 320, 390, 768, 1024 e 1440 pixel.

Verificati inoltre:

- Apertura del menu mobile e passaggio ai contatti.
- Espansione a 23 foto, apertura con tastiera, frecce ed Escape.
- Primo passaggio interno da home a menu: 80 voci, foglio di stile 7.14 applicato, ricerca funzionante e medesimo elemento audio mantenuto.
- Home e modulo nelle quattro lingue aggiuntive.
- Conclusione dell’intro automatica e pagina utilizzabile.
- Campi obbligatori e contenuto del POST del modulo, intercettato localmente prima di qualsiasi contatto con FormSubmit.

## Limiti espliciti

**Nessuna email reale è stata inviata.** Destinatario e payload sono verificati, ma attivazione della casella e consegna richiedono il titolare di alphascript24@gmail.com e una prova dal sito pubblicato, come descritto in `EMAIL_SETUP.md`. La verifica antispam rimane abilitata.

Le prove del browser locale usano il menu statico di riserva; il salvataggio persistente tramite Netlify Blobs non è stato verificato su un deploy reale. Non sono stati eseguiti deploy, push o attivazioni di servizi esterni. Le opinioni riportate nella pagina recensioni sono il riepilogo storico già presente nel progetto, datato agosto 2026; per i dati attuali si rimanda alla fonte.

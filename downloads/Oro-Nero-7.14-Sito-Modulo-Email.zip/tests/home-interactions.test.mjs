import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { JSDOM, VirtualConsole } from "jsdom";

const html = await readFile(new URL("../site/index.html", import.meta.url), "utf8");
let moduleId = 0;

async function homepage() {
  const errors = [];
  const virtualConsole = new VirtualConsole();
  virtualConsole.on("jsdomError", (error) => errors.push(error));
  const dom = new JSDOM(html, {
    url: "https://oronero.test/", pretendToBeVisual: true, virtualConsole,
  });
  const { window } = dom;
  // jsdom has no media engine; real MP3 playback is checked in Chromium.
  window.HTMLMediaElement.prototype.play = function () {
    Object.defineProperty(this, 'paused', { configurable: true, value: false });
    this.dispatchEvent(new window.Event('play'));
    return Promise.resolve();
  };
  window.HTMLMediaElement.prototype.pause = function () {
    Object.defineProperty(this, 'paused', { configurable: true, value: true });
    this.dispatchEvent(new window.Event('pause'));
  };
  globalThis.window = window;
  globalThis.document = window.document;
  globalThis.location = window.location;
  globalThis.HTMLElement = window.HTMLElement;
  globalThis.customElements = window.customElements;
  globalThis.CustomEvent = window.CustomEvent;
  globalThis.FormData = window.FormData;
  globalThis.IntersectionObserver = class {
    constructor(callback) { this.callback = callback; }
    observe(target) { this.callback([{ target, isIntersecting: true }]); }
    unobserve() {}
    disconnect() {}
  };
  window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  window.HTMLDialogElement.prototype.close = function () {
    this.removeAttribute("open");
    this.dispatchEvent(new window.Event("close"));
  };
  const opened = [];
  window.open = (...args) => { opened.push(args); return null; };
  globalThis.fetch = async () => { throw new Error("Nessuna richiesta esterna prevista dal test della home"); };

  // The booking focus delay must not outlive its document.
  const realSetTimeout = globalThis.setTimeout;
  const timers = new Set();
  globalThis.setTimeout = (callback, delay, ...args) => {
    const timer = realSetTimeout(callback, delay, ...args);
    timers.add(timer);
    return timer;
  };
  const close = () => {
    timers.forEach((timer) => clearTimeout(timer));
    globalThis.setTimeout = realSetTimeout;
    window.close();
  };
  try {
    await import(`../site/assets/site.js?home-test=${++moduleId}`);
    assert.deepEqual(errors, [], "La home deve inizializzarsi senza errori JavaScript");
    return { dom, opened, errors, close };
  } catch (error) {
    close();
    throw error;
  }
}

test("lo slider manuale aggiorna foto, didascalia e contatore con ritorno circolare", async () => {
  const page = await homepage();
  try {
    const slides = [...document.querySelectorAll("[data-hero-slide]")];
    const caption = document.querySelector("[data-hero-caption]");
    const counter = document.querySelector("[data-hero-current]");
    const assertSlide = (index) => {
      assert.equal(slides.filter((slide) => slide.classList.contains("is-active")).length, 1);
      assert.equal(slides[index].classList.contains("is-active"), true);
      assert.equal(caption.textContent, slides[index].dataset.caption);
      assert.equal(counter.textContent, String(index + 1).padStart(2, "0"));
    };
    assert.equal(slides.length, 3);
    assert.equal(caption.getAttribute("aria-live"), "polite");
    assertSlide(0);
    document.querySelector("[data-hero-next]").click();
    assertSlide(1);
    document.querySelector("[data-hero-next]").click();
    assertSlide(2);
    document.querySelector("[data-hero-next]").click();
    assertSlide(0);
    document.querySelector("[data-hero-prev]").click();
    assertSlide(2);
    assert.deepEqual(page.errors, []);
  } finally {
    page.close();
  }
});

test("la galleria apre da tastiera, cambia foto e si chiude", async () => {
  const page = await homepage();
  try {
    const figures = [...document.querySelectorAll('.atmosphere-gallery .gallery-card')];
    const photos = figures.map((figure) => figure.querySelector("img"));
    const dialog = document.querySelector("#gallery-dialog");
    const assertPhoto = (index) => {
      assert.equal(dialog.querySelector("img").src, new URL(photos[index].dataset.fullSrc || photos[index].src, document.baseURI).href);
      assert.equal(dialog.querySelector("img").alt, photos[index].alt);
      assert.equal(dialog.querySelector("figcaption").textContent, figures[index].querySelector("figcaption").textContent);
    };
    assert.equal(figures[0].getAttribute("role"), "button");
    assert.equal(figures[0].tabIndex, 0);
    figures[0].dispatchEvent(new page.dom.window.KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
    assert.equal(dialog.open, true);
    assert.equal(document.body.classList.contains("dialog-open"), true);
    assertPhoto(0);
    dialog.querySelector(".gallery-next").click();
    assertPhoto(1);
    dialog.querySelector(".gallery-next").click();
    assertPhoto(0);
    dialog.querySelector(".gallery-prev").click();
    assertPhoto(1);
    dialog.dispatchEvent(new page.dom.window.KeyboardEvent("keydown", { key: "ArrowLeft", bubbles: true }));
    assertPhoto(0);
    dialog.querySelector(".gallery-close").click();
    assert.equal(dialog.open, false);
    assert.equal(document.body.classList.contains("dialog-open"), false);
    assert.deepEqual(page.errors, []);
  } finally {
    page.close();
  }
});

test('la raccolta in home espande le foto e il visualizzatore scorre solo il suo gruppo in alta risoluzione', async () => {
  const page = await homepage();
  try {
    const group = document.querySelector('#galleria');
    const photos = [...group.querySelectorAll('.gallery-card img')];
    assert.equal(photos.length, 23);
    assert.equal(new Set(photos.map((image) => image.dataset.fullSrc)).size, 23);
    const extras = [...group.querySelectorAll('[data-gallery-extra]')];
    assert.equal(extras.length, 17);
    assert.ok(extras.every((figure) => figure.hidden));
    const more = group.querySelector('[data-gallery-more]');
    more.click();
    assert.equal(more.getAttribute('aria-expanded'), 'true');
    assert.ok(extras.every((figure) => !figure.hidden));
    const dialog = document.querySelector('#gallery-dialog');
    photos[0].closest('figure').click();
    const expected = (index) => new URL(photos[index].dataset.fullSrc, document.baseURI).href;
    assert.equal(dialog.querySelector('img').src, expected(0));
    assert.equal(dialog.querySelector('.gallery-position').textContent, 'Foto 1 di 23');
    dialog.querySelector('.gallery-prev').click();
    assert.equal(dialog.querySelector('img').src, expected(22));
    assert.equal(dialog.querySelector('.gallery-position').textContent, 'Foto 23 di 23');
    dialog.querySelector('.gallery-next').click();
    assert.equal(dialog.querySelector('img').src, expected(0));
    assert.doesNotMatch(dialog.querySelector('figcaption').textContent, /01$/);
    dialog.querySelector('.gallery-close').click();
    more.click();
    assert.ok(extras.every((figure) => figure.hidden));
    assert.equal(more.getAttribute('aria-expanded'), 'false');
    assert.deepEqual(page.errors, []);
  } finally { page.close(); }
});

test("la prenotazione invia via POST al destinatario email e mantiene la verifica antispam", async () => {
  const page = await homepage();
  try {
    document.querySelector("[data-booking]").click();
    const dialog = document.querySelector("#booking-dialog");
    const form = document.querySelector("#booking-form");
    const field = (name) => form.elements.namedItem(name);
    assert.equal(dialog.open, true);
    assert.equal(field("guests").value, "2");
    assert.equal(field("time").value, "19:30");
    assert.equal([...field("time").options].some((option) => option.value === "16:00"), false);
    field("name").value = "Luca D’Amico & Giulia";
    field("email").value = "luca@example.com";
    field("phone").value = "+39 123 456 789";
    field("guests").value = "4";
    field("date").value = "2099-11-06";
    field("time").value = "20:15";
    field("notes").value = "Un tavolo tranquillo & vicino alla finestra, grazie!";
    assert.equal(form.checkValidity(), true);
    const event = new page.dom.window.Event("submit", { bubbles: true, cancelable: true });
    form.dispatchEvent(event);
    assert.equal(event.defaultPrevented, false, "Il browser deve poter completare il POST nativo");
    assert.equal(form.action, "https://formsubmit.co/alphascript24@gmail.com");
    assert.equal(form.method, "post");
    assert.equal(form.target, "_blank");
    assert.equal(form.getAttribute("rel"), "noopener");
    const payload = new page.dom.window.FormData(form);
    assert.equal(payload.get("name"), "Luca D’Amico & Giulia");
    assert.equal(payload.get("email"), "luca@example.com");
    assert.equal(payload.get("phone"), "+39 123 456 789");
    assert.equal(payload.get("guests"), "4");
    assert.equal(payload.get("date"), "2099-11-06");
    assert.equal(payload.get("time"), "20:15");
    assert.equal(payload.get("notes"), field("notes").value);
    assert.equal(payload.get("_honey"), "");
    assert.notEqual(payload.get("_captcha"), "false");
    assert.equal(page.opened.length, 0, "Il sito non apre WhatsApp o invia richieste automatiche");
    const status = document.querySelector("#booking-status");
    assert.equal(status.hidden, false);
    assert.match(status.textContent, /Completa la verifica/);
    assert.doesNotMatch(status.textContent, /inviata|consegnata/);
    assert.equal(dialog.open, true);
    assert.deepEqual(page.errors, []);
  } finally { page.close(); }
});

test("prenotazione: email non valida, data passata e honeypot bloccano il POST", async () => {
  const page = await homepage();
  try {
    const form = document.querySelector("#booking-form");
    form.elements.name.value = "Luca";
    form.elements.email.value = "non-una-email";
    form.elements.date.value = "2099-11-06";
    const submit = () => {
      const event = new page.dom.window.Event("submit", { cancelable: true });
      form.dispatchEvent(event);
      return event.defaultPrevented;
    };
    assert.equal(submit(), true);
    form.elements.email.value = "luca@example.com";
    form.elements.date.value = "2000-01-01";
    assert.equal(submit(), true);
    form.elements.date.value = "2099-11-06";
    form.elements._honey.value = "spam";
    assert.equal(submit(), true);
    assert.equal(document.querySelector("#booking-status").hidden, true);
  } finally { page.close(); }
});

test("il contatto email alternativo conserva dati e caratteri speciali", async () => {
  const page = await homepage();
  try {
    const form = document.querySelector("#booking-form");
    form.elements.name.value = "Luca & Giulia";
    form.elements.email.value = "luca@example.com";
    form.elements.notes.value = "Un tavolo tranquillo? Grazie & a presto!";
    const link = form.querySelector("[data-booking-email]");
    // Prevent actual navigation; run only the local link preparation.
    link.addEventListener("click", (event) => event.preventDefault());
    link.click();
    const url = new URL(link.href);
    assert.equal(url.protocol, "mailto:");
    assert.equal(url.pathname, "alphascript24@gmail.com");
    assert.equal(url.searchParams.get("subject"), "Richiesta dal sito · Oro Nero");
    assert.match(url.searchParams.get("body"), /Nome: Luca & Giulia/);
    assert.match(url.searchParams.get("body"), /Un tavolo tranquillo\? Grazie & a presto!/);
  } finally { page.close(); }
});


test("chiudere e riaprire il modulo conserva la richiesta senza inviarla", async () => {
  const page = await homepage();
  try {
    const trigger = document.querySelector("[data-booking]:not([data-booking-note])");
    trigger.click();
    const dialog = document.querySelector("#booking-dialog");
    const form = document.querySelector("#booking-form");
    let submissions = 0;
    form.addEventListener("submit", (event) => { submissions += 1; event.preventDefault(); });
    form.elements.name.value = "Giulia Rossi";
    form.elements.email.value = "giulia@example.com";
    form.elements.notes.value = "Vorrei un tavolo vicino alla finestra, grazie.";
    document.querySelector("#booking-close").click();
    assert.equal(dialog.open, false);
    trigger.click();
    assert.equal(dialog.open, true);
    assert.equal(form.elements.name.value, "Giulia Rossi");
    assert.equal(form.elements.email.value, "giulia@example.com");
    assert.equal(form.elements.notes.value, "Vorrei un tavolo vicino alla finestra, grazie.");
    assert.equal(submissions, 0);
    assert.equal(page.opened.length, 0);
    assert.deepEqual(page.errors, []);
  } finally { page.close(); }
});

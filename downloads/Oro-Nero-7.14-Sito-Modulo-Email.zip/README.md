# Oro Nero · 7.14.0

Sito di Oro Nero Experience Bistrot, Calle Vianelli 1011, Chioggia.

## Questa versione

- Home più chiara: fondo avorio, fotografie reali senza oscuramento, nome del bistrot leggibile nella testata e pulsanti diretti a menu e prenotazione.
- Testi più concreti su ristorante, cucina e visita; didascalie descrittive, sezioni meno decorative, informazioni leggibili anche su telefono.
- Menu pubblico testuale con 13 categorie e 80 voci, ricerca, filtro vegetariano, allergeni, degustazioni, eventi e carta dei vini. Prezzi e dati del menu conservati.
- Tutte le 23 foto originali del progetto, galleria ingrandibile e navigazione da tastiera.
- Italiano, inglese, tedesco, francese e spagnolo nella stessa pagina. Quattro cataloghi locali da 615 chiavi; nessuna API di traduzione.
- Intro automatica, marchio e lettore musicale mantenuti. L’audio continua sullo stesso elemento nella navigazione interna; l’autoplay dipende dalle regole del browser.
- Modulo per richiedere un tavolo via email a **alphascript24@gmail.com**. Nome, email, persone, data e ora obbligatori; telefono e note facoltativi. Chiudere e riaprire il modulo conserva i dati.

## Invio del modulo

Il modulo esegue un POST HTTPS a FormSubmit in una nuova scheda. Il visitatore completa la verifica antispam sulla pagina del servizio, che mostra l’esito. Il clic sul sito non viene presentato come una consegna già avvenuta. La prenotazione richiede sempre la risposta del ristorante.

**Prima dell’uso, il titolare di alphascript24@gmail.com deve attivare il destinatario dall’email inviata da FormSubmit.** Poi va effettuata una nuova richiesta dal sito pubblicato e controllata la consegna. La casella non è stata attivata durante lo sviluppo. Procedura completa in [EMAIL_SETUP.md](EMAIL_SETUP.md).

Il collegamento alternativo apre il programma email con i dati compilati. I contatti pubblici e il recapito del titolare del ristorante rimangono quelli esistenti; l’indirizzo fornito è la destinazione del modulo. L’informativa privacy descrive questo flusso.

## Sviluppo

Usare Node.js 22, indicato in `.nvmrc` e `netlify.toml`:

```bash
npm ci
npm run build
npm run check
npm test
python3 -m http.server 8080 --directory dist
```

La build copia `site/` in `dist/`, genera il menu JSON di riserva e il QR. Il controllo valida dati, file, importi, segnaposto e coerenza dei cataloghi. La suite comprende **102 test**.

Nell’anteprima statica funzionano le pagine pubbliche e il modulo esterno, dopo la pubblicazione e l’attivazione del destinatario. Il salvataggio amministrativo richiede Netlify Functions e Blobs: vedere [README_NETLIFY.md](README_NETLIFY.md).

## Modificare il sito

- Pagine: `site/index.html`, `site/menu/`, `site/galleria/`, `site/recensioni/`, `site/allergeni/`, `site/privacy/`, `site/qr/` e `site/admin/`.
- Stile della versione 7.14: `site/assets/editorial.css`, caricato dopo gli stili precedenti su ogni pagina.
- Elementi condivisi e finestra prenotazioni: `site/assets/site.js`.
- Validazione e alternativa email: `site/assets/booking.js`.
- Cataloghi: `site/assets/locales/{en,de,fr,es}.json`. Aggiungere le stesse chiavi in tutte le lingue senza cambiare segnaposto e importi.
- Foto: `site/assets/images/collection-2026/`; indice `site/assets/photographs.json`. Figure e didascalie sono anche nel markup di home e galleria.
- Dati iniziali del menu: `netlify/functions/menu-default.mjs`; gestione persistente nell’admin dopo il deploy completo.

Font e fotografie sono inclusi nel progetto; le licenze dei font sono in `site/assets/fonts/`. Le foto non contengono EXIF/GPS. `foto-sito.csv` conserva l’associazione con i file di origine.

## Pubblicazione

Pubblicare l’intera nuova build, non singoli file mescolati alla versione precedente. Non è stato eseguito alcun deploy durante questo intervento. Il sito online cambia solo dopo la pubblicazione sul proprio hosting. Per il flusso completo usare la guida Netlify.

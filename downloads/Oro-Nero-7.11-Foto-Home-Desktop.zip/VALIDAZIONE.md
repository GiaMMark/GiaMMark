# Oro Nero 7.11.0 · Le tue foto nella home e desktop

## Contenuti e media

Tutti i 13 ZIP più recenti sono stati letti: 26 JPEG, 23 unici tramite SHA-256 e tre duplicati esatti. Versioni ottimizzate: 23 WebP con lato massimo 2000 pixel e 23 anteprime da 720 pixel, 6.377.524 byte complessivi. Verificati integrità, dimensioni, orientamento, conversione colore e assenza di EXIF/GPS nei file pubblici. Originali conservati solo nello staging dell’ambiente.

La galleria è in home con sei anteprime e comando per tutte le 23 foto. Le immagini iniziali degli spazi pubblici sono sostituite; apertura, cucina, proposte, cantina, atmosfera e social card usano i nuovi file. Ogni didascalia descrive ciò che è visibile, senza inventare ricette, nomi dello staff o ambienti assenti dalle foto.

## Build e test

Node.js 22.23.4: `npm run build`, `npm run check` e `npm test` riusciti. **84 test superati**, nessun fallimento o test saltato. Il controllo della build verifica tutte le 23 foto e i relativi asset. Il menu conserva 13 categorie e 80 voci.

Il nuovo test della raccolta verifica anteprima/espansione, unicità, scorrimento limitato al proprio gruppo, foto grande, contatore e didascalie senza indici decorativi. Inclusi 19 test dell’intro e 9 del primo avvio, con regressioni per movimento ridotto, vecchi indicatori di sessione, skip e ritorno interno alla homepage.

## Browser

Chromium: home e raccolta verificati a 320×568, 390×844, 768×900, 900×900, 1280×900, 1440×900 e 1920×1080. Le 23 immagini caricano correttamente, mantengono le proporzioni e si aprono nella versione grande. Nessun overflow orizzontale. Verificati tastiera, Escape, ritorno del focus, espansione/riduzione della raccolta, contatori e gruppi separati (23 foto e 2 foto dell’atmosfera). Nessuna richiesta per le vecchie fotografie e nessun errore JavaScript.

Percorso home → menu → galleria nella home, Indietro/Avanti: stesso documento e stesso lettore audio in riproduzione, un solo visualizzatore. Anche `/galleria/` contiene le 23 nuove immagini. Menu pubblico senza fotografie. Il selettore di traduzione segue la home senza inviare frammenti.

Desktop 1440 e 1920, senza user activation: intro visiva normale autonoma di circa 4,1 secondi; con movimento ridotto ingresso statico di circa 1,06 secondi, senza animazione, rotazione o lucciola. L’audio bloccato dal browser non impedisce nessuna delle due sequenze. Il primo fotogramma rimane coperto fino all’intro; salti e accessi diretti restano previsti.

Lo sfondo desktop è a tutta larghezza con una composizione orizzontale nel primo fotogramma, sfumatura per il testo e spazio tra suggerimento iniziale e controllo musicale. Impostazioni e layout mobile approvati conservati.

## Limiti e pubblicazione

Nessun deploy Netlify eseguito. Gli archivi GitHub vanno pubblicati sull’hosting per modificare il sito online; le prove riguardano la build locale, non il browser effettivo dell’utente. Non sono stati forniti ancora browser, URL e difetti specifici della sua interfaccia PC.

L’autoplay sonoro resta sotto il controllo del browser e il volume fisico del dispositivo sotto quello dell’ospite. La traduzione apre Google Translate in una nuova scheda; la resa remota, soprattutto dei contenuti dinamici, non è verificata da questo ambiente. Usare l’intera build aggiornata, senza mescolare asset di versioni diverse.

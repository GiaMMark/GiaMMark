import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM } from 'jsdom';
import { setupArrival } from '../site/assets/arrival.js';
const html = await readFile(new URL('../site/index.html', import.meta.url), 'utf8');
function page({seen = false, shown = false, reduce = false, hash = '', music = false, musicState = null, musicWanted = true} = {}) {
  const dom = new JSDOM(html, { url: `https://oronero.test/${hash}`, pretendToBeVisual: true });
  dom.window.matchMedia = () => ({matches:reduce});
  if (shown) dom.window.__oroneroArrivalShown = true;
  let audio;
  const musicCalls={play:0,pause:0};
  if (musicState) {
    audio = dom.window.document.createElement('audio');
    audio.dataset.persistentAudio = '';
    audio.dataset.musicState = musicState;
    audio.dataset.musicWanted = String(musicWanted);
    dom.window.document.body.append(audio);
    audio[Symbol.for('oronero.music.controller')]={
      play(options){assert.equal(options.gesture,true);musicCalls.play++;return Promise.resolve();},
      pause(){musicCalls.pause++;audio.dataset.musicWanted='false';},
    };
  }
  if (music || musicState) {
    const control = dom.window.document.createElement('button');
    control.dataset.musicControl = '';
    control.textContent = 'Musica';
    dom.window.document.body.append(control);
  }
  if (seen) dom.window.sessionStorage.setItem('oronero-arrival-seen-v2', '1');
  const tasks = new Map();
  let id = 0;
  dom.window.setTimeout = (callback, milliseconds) => { tasks.set(++id, {callback, milliseconds}); return id; };
  dom.window.clearTimeout = (timer) => tasks.delete(timer);
  const controller = setupArrival(dom.window.document,dom.window);
  return { dom, doc:dom.window.document, controller, musicCalls, setMusicState(state) {
    audio.dataset.musicState = state;
    dom.window.document.dispatchEvent(new dom.window.CustomEvent('oronero:music-state', {detail:{audio,state}}));
  }, run(milliseconds) {
    for (const [timer, task] of [...tasks]) if (task.milliseconds === milliseconds) { tasks.delete(timer); task.callback(); }
  }, close() {controller.destroy();dom.window.close();} };
}
test('l’ingresso apre una volta, si può saltare e ripristina il sito e il focus', () => {
  const p=page();
  try {
    const overlay=p.doc.querySelector('[data-arrival]');
    assert.equal(overlay.hidden,false);
    assert.equal(p.doc.querySelector('main').inert,true);
    assert.equal(p.doc.activeElement,p.doc.querySelector('[data-arrival-skip]'));
    p.doc.querySelector('[data-arrival-skip]').click();
    p.run(160);
    assert.equal(overlay.hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    assert.equal(p.doc.body.classList.contains('arrival-open'),false);
    assert.equal(p.dom.window.__oroneroArrivalShown,true);
  } finally {p.close();}
});
test('la sequenza si chiude da sola e può essere rivista esplicitamente', () => {
  const p=page();
  try {
    p.run(3000);assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-closing'),true);
    p.run(1100);assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    const replay=p.doc.querySelector('[data-replay-arrival]');replay.focus();replay.click();
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,false);
    p.doc.querySelector('[data-arrival]').dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(p.doc.activeElement,replay);
  } finally {p.close();}
});
test('la musica e l’uscita restano accessibili nel percorso tastiera dell’intro', () => {
  const p = page({music:true});
  try {
    const music = p.doc.querySelector('[data-music-control]');
    const skip = p.doc.querySelector('[data-arrival-skip]');
    const bypass = p.doc.querySelector('[data-arrival-bypass]');
    assert.equal(Boolean(music.inert), false);
    assert.equal(p.doc.querySelector('[data-arrival]').contains(music),true);
    skip.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',bubbles:true}));
    assert.equal(p.doc.activeElement,bypass);
    bypass.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',bubbles:true}));
    assert.equal(p.doc.activeElement,music);
    music.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',bubbles:true}));
    assert.equal(p.doc.activeElement,skip);
    skip.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Tab',shiftKey:true,bubbles:true}));
    assert.equal(p.doc.activeElement,music);
    music.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    p.run(160);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(music.parentNode,p.doc.body);
    assert.equal(p.doc.activeElement,music);
  } finally { p.close(); }
});
test('la salvaguardia ripristina il sito anche se il completamento animato non avviene', () => {
  const p=page();
  try {
    p.run(5500);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    p.run(3000);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
  } finally {p.close();}
});
test('intro già mostrata nel documento e link diretto non bloccano la navigazione', () => {
  for(const options of [{shown:true},{hash:'#contatti'}]) {
    const p=page(options);
    try { assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);assert.equal(Boolean(p.doc.querySelector('main').inert),false); }
    finally {p.close();}
  }
});
test('movimento ridotto conserva un ingresso automatico breve con uscita e ripristino del sito', () => {
  const p=page({reduce:true,musicState:'blocked'});
  try {
    const overlay=p.doc.querySelector('[data-arrival]');
    assert.equal(overlay.hidden,false);
    assert.equal(overlay.classList.contains('is-active'),true);
    assert.equal(p.dom.window.__oroneroArrivalShown,true);
    assert.equal(p.musicCalls.play,0);
    p.run(900);
    assert.equal(overlay.classList.contains('is-closing'),true);
    assert.equal(overlay.classList.contains('is-skipped'),true);
    p.run(160);
    assert.equal(overlay.hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    assert.equal(p.musicCalls.play,0);
  } finally {p.close();}
});
test('se lo storage non è disponibile e se si lascia la pagina il contenuto viene ripristinato', () => {
  const p=page({shown:true});
  try {
    Object.defineProperty(p.dom.window,'sessionStorage',{get(){throw new Error('Storage non disponibile');}});
    p.controller.open();
    p.dom.window.dispatchEvent(new p.dom.window.Event('pagehide'));
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    assert.equal(p.doc.body.classList.contains('arrival-open'),false);
  } finally {p.close();}
});
for (const state of ['loading','blocked','paused','error','playing']) {
  test(`l’intro parte e termina da sola con musica ${state}, senza chiedere play`, () => {
    const p=page({musicState:state,musicWanted:state!=='paused'});
    try {
      const overlay=p.doc.querySelector('[data-arrival]');
      assert.equal(overlay.hidden,false);
      assert.equal(overlay.classList.contains('is-active'),true);
      assert.equal(p.doc.activeElement,p.doc.querySelector('[data-arrival-skip]'));
      assert.equal(p.musicCalls.play,0);
      p.run(3000);
      assert.equal(overlay.classList.contains('is-closing'),true);
      p.run(1100);
      assert.equal(overlay.hidden,true);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false);
      assert.equal(p.musicCalls.play,0);
    } finally {p.close();}
  });
}
test('eventi musicali tardivi non riavviano né ritardano il conto alla rovescia', () => {
  const p=page({musicState:'loading'});
  try {
    const overlay=p.doc.querySelector('[data-arrival]');
    p.setMusicState('blocked');p.setMusicState('playing');p.setMusicState('loading');
    p.run(3000);
    assert.equal(overlay.classList.contains('is-closing'),true);
    p.run(1100);
    p.setMusicState('playing');p.run(8000);p.run(3000);
    assert.equal(overlay.hidden,true);
    assert.equal(overlay.classList.contains('is-active'),false);
    assert.equal(p.musicCalls.play,0);
  } finally {p.close();}
});
test('la freccia salta sempre subito indipendentemente dalla musica', () => {
  for(const state of ['loading','blocked','paused','error','playing']) {
    const p=page({musicState:state});
    try {
      const overlay=p.doc.querySelector('[data-arrival]');
      p.doc.querySelector('[data-arrival-skip]').click();
      assert.equal(overlay.classList.contains('is-skipped'),true,state);
      p.run(160);
      assert.equal(overlay.hidden,true,state);
      assert.equal(p.musicCalls.play,0,state);
      assert.equal(p.musicCalls.pause,0,state);
    } finally {p.close();}
  }
});
test('uscita silenziosa ed Escape fermano la musica e annullano la sequenza', () => {
  for(const action of ['bypass','escape']) {
    const p=page({musicState:'playing'});
    try {
      if(action==='bypass')p.doc.querySelector('[data-arrival-bypass]').click();
      else p.doc.dispatchEvent(new p.dom.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
      p.run(160);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
      assert.equal(p.musicCalls.pause,1);
      p.setMusicState('playing');p.run(3000);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    } finally {p.close();}
  }
});
test('abbandono e cambio visibilità ripristinano subito il contenuto senza riavviarlo', () => {
  for(const action of ['pagehide','visibility']) {
    const p=page({musicState:'blocked'});
    try {
      if(action==='pagehide')p.dom.window.dispatchEvent(new p.dom.window.Event('pagehide'));
      else {
        Object.defineProperty(p.doc,'hidden',{configurable:true,value:true});
        p.doc.dispatchEvent(new p.dom.window.Event('visibilitychange'));p.run(160);
      }
      p.setMusicState('playing');p.run(3000);
      assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
      assert.equal(Boolean(p.doc.querySelector('main').inert),false);
    } finally {p.close();}
  }
});
test('il logo centrale è decorativo e non è un comando di avvio', () => {
  const p=page();
  try {
    const mark=p.doc.querySelector('.arrival-start');
    assert.equal(mark.tagName,'DIV');
    assert.equal(mark.getAttribute('aria-hidden'),'true');
    assert.equal(p.doc.querySelector('[data-arrival-start]'),null);
    assert.equal(mark.hasAttribute('tabindex'),false);
  } finally {p.close();}
});
test('vecchie preferenze seen non impediscono l’intro in un nuovo documento o dopo reload', () => {
  for(let reload=0;reload<2;reload++) {
    const p=page({seen:true});
    try {
      assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
      assert.equal(p.dom.window.__oroneroArrivalShown,true);
      assert.equal(p.dom.window.sessionStorage.getItem('oronero-arrival-seen-v2'),'1');
    }finally{p.close();}
  }
});
test('ritornare alla home nello stesso documento non interrompe di nuovo; replay resta disponibile', () => {
  const p=page();
  let returned;
  try {
    p.run(3000);p.run(1100);
    p.controller.destroy();
    returned=setupArrival(p.doc,p.dom.window);
    assert.equal(p.doc.querySelector('[data-arrival]').hidden,true);
    p.doc.querySelector('[data-replay-arrival]').click();
    assert.equal(p.doc.querySelector('[data-arrival]').classList.contains('is-active'),true);
  }finally{returned?.destroy();p.close();}
});

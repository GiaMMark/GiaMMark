/** A skippable, sound-synchronised entrance that never hides a silent exit. */
export function setupArrival(doc = document, win = window) {
  const overlay = doc.querySelector('[data-arrival]');
  if (!overlay) return null;
  const skip = overlay.querySelector('[data-arrival-skip]');
  if (!skip) return null;
  const enter = overlay.querySelector('[data-arrival-start]');
  const bypass = overlay.querySelector('[data-arrival-bypass]');
  const boot = win.__oroneroArrivalBoot;
  const bootPreventedIntro = Boolean(boot?.preventIntro);
  boot?.takeover?.();
  const replay = doc.querySelector('[data-replay-arrival]');
  const key = 'oronero-arrival-seen-v2';
  const motion = win.matchMedia?.('(prefers-reduced-motion: reduce)');
  let active = false;
  let closing = false;
  let waiting = false;
  let entryIntent = false;
  let timer;
  let cleanupTimer;
  let safeguard;
  let previousFocus;
  let siblings = [];
  let musicPlacement;
  let musicWaitTimer;
  let musicWaitListener;
  const audio = () => doc.querySelector('[data-persistent-audio]');
  const musicController = () => audio()?.[Symbol.for('oronero.music.controller')];
  const clearMusicWait = () => {
    win.clearTimeout(musicWaitTimer);
    if (musicWaitListener) doc.removeEventListener('oronero:music-state', musicWaitListener);
    musicWaitListener = null;
  };
  const clearTimers = () => {
    [timer, cleanupTimer, safeguard].forEach((id) => win.clearTimeout(id));
    clearMusicWait();
  };
  const restore = (focus = true) => {
    clearTimers();
    const focused = doc.activeElement;
    overlay.hidden = true;
    overlay.classList.remove('is-active', 'is-closing', 'is-skipped', 'is-waiting', 'is-awaiting-gesture');
    doc.body.classList.remove('arrival-open', 'arrival-revealing');
    if (musicPlacement) {
      const {element, parent, next} = musicPlacement;
      parent.insertBefore(element, next?.parentNode === parent ? next : null);
      if (focus && focused === element) element.focus({ preventScroll: true });
      musicPlacement = null;
    }
    siblings.forEach(([element, inert]) => { element.inert = inert; });
    siblings = [];
    active = false;
    closing = false;
    waiting = false;
    entryIntent = false;
    if (focus && [skip, enter, bypass].includes(focused)) {
      const target = previousFocus?.matches?.('[data-replay-arrival]') ? previousFocus : doc.querySelector('main');
      if (target) {
        const hadTabindex = target.hasAttribute('tabindex');
        if (!hadTabindex) target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
        if (!hadTabindex) target.removeAttribute('tabindex');
      }
    }
  };
  const finish = (immediate = true) => {
    if (!active || closing) return;
    closing = true;
    win.clearTimeout(timer);
    clearMusicWait();
    try { win.sessionStorage.setItem(key, '1'); } catch { /* Optional storage. */ }
    overlay.classList.add('is-closing');
    if (immediate || motion?.matches) overlay.classList.add('is-skipped');
    doc.body.classList.add('arrival-revealing');
    cleanupTimer = win.setTimeout(() => restore(), immediate || motion?.matches ? 160 : 1100);
  };
  const startSequence = () => {
    if (!active || closing) return;
    clearMusicWait();
    waiting = false;
    overlay.classList.remove('is-waiting', 'is-awaiting-gesture');
    if (enter) {
      if (doc.activeElement === enter) skip.focus({preventScroll:true});
      enter.disabled = true;
    }
    skip.setAttribute('aria-label', 'Salta l’intro ed entra nel sito');
    void overlay.offsetWidth;
    overlay.classList.add('is-active');
    timer = win.setTimeout(() => finish(false), motion?.matches ? 500 : 3000);
    win.clearTimeout(safeguard);
    safeguard = win.setTimeout(() => restore(), 5500);
  };
  const handleMusicState = (state) => {
    if (!active || closing || !waiting) return;
    win.clearTimeout(musicWaitTimer);
    win.clearTimeout(safeguard);
    if (state === 'playing' || state === 'error' || state === 'paused') {
      startSequence();
      return;
    }
    if (state === 'blocked') {
      // The browser needs a gesture. Keep the welcome ready for that gesture,
      // with a separate visible bypass and Escape available at every moment.
      overlay.classList.add('is-awaiting-gesture');
      return;
    }
    overlay.classList.remove('is-awaiting-gesture');
    musicWaitTimer = win.setTimeout(startSequence, 8000);
    safeguard = win.setTimeout(() => restore(), 13500);
  };
  const requestEntry = () => {
    if (!active || closing || !waiting) return;
    void musicController()?.play({gesture:true});
  };
  const open = () => {
    if (active || closing) return;
    previousFocus = doc.activeElement;
    const music = doc.querySelector('[data-music-control]');
    if (music && !overlay.contains(music)) {
      musicPlacement = {element: music, parent: music.parentNode, next: music.nextSibling};
      overlay.append(music);
    }
    siblings = [...doc.body.children].filter((element) => element !== overlay && !element.matches('[data-music-control]') && !['SCRIPT', 'STYLE'].includes(element.tagName)).map((element) => [element, element.inert]);
    siblings.forEach(([element]) => { element.inert = true; });
    overlay.hidden = false;
    overlay.classList.remove('is-active', 'is-closing', 'is-skipped', 'is-waiting', 'is-awaiting-gesture');
    doc.body.classList.add('arrival-open');
    active = true;
    const player = audio();
    if (!motion?.matches && player?.dataset.musicWanted === 'true' && ['loading', 'blocked'].includes(player.dataset.musicState)) {
      waiting = true;
      overlay.classList.add('is-waiting');
      if (enter) enter.disabled = false;
      skip.setAttribute('aria-label', 'Entra con musica');
      (enter || skip).focus({preventScroll:true});
      musicWaitListener = (event) => {
        if (event.detail?.audio === player) handleMusicState(event.detail.state);
      };
      doc.addEventListener('oronero:music-state', musicWaitListener);
      handleMusicState(player.dataset.musicState);
      if (boot?.entryRequested) requestEntry();
    } else {
      skip.focus({preventScroll:true});
      startSequence();
    }
    boot?.release?.('takeover');
  };
  const onSkip = () => {
    if (waiting || entryIntent) { entryIntent = false; requestEntry(); }
    else finish(true);
  };
  const onEntry = () => { entryIntent = false; requestEntry(); };
  const onBypass = () => {
    finish(true);
    musicController()?.pause();
  };
  const rememberEntryIntent = (event) => {
    if (!waiting || event.target.closest?.('[data-arrival-bypass]')) return;
    if (event.type !== 'keydown' || ['Enter', ' '].includes(event.key)) entryIntent = true;
  };
  const clearEntryIntent = () => { entryIntent = false; };
  const onKey = (event) => {
    if (!active) return;
    if (event.key === 'Escape') { event.preventDefault(); onBypass(); }
    if (event.key === 'Tab') {
      const music = doc.querySelector('[data-music-control]');
      const controls = [enter, skip, bypass, music].filter((element) => element && !element.disabled && !element.hidden);
      const current = controls.indexOf(doc.activeElement);
      const next = (current + (event.shiftKey ? -1 : 1) + controls.length) % controls.length;
      event.preventDefault();
      controls[next].focus();
    }
  };
  const onVisibility = () => { if (doc.hidden && active) finish(true); };
  const onPageHide = () => restore(false);
  const onReplay = () => open();
  skip.addEventListener('click', onSkip);
  enter?.addEventListener('click', onEntry);
  bypass?.addEventListener('click', onBypass);
  bypass?.addEventListener('pointerdown', onBypass);
  bypass?.addEventListener('touchstart', onBypass, {passive:true});
  overlay.addEventListener('pointerdown', rememberEntryIntent, true);
  overlay.addEventListener('touchstart', rememberEntryIntent, {capture:true,passive:true});
  overlay.addEventListener('keydown', rememberEntryIntent, true);
  overlay.addEventListener('click', clearEntryIntent);
  doc.addEventListener('keydown', onKey);
  replay?.addEventListener('click', onReplay);
  doc.addEventListener('visibilitychange', onVisibility);
  win.addEventListener('pagehide', onPageHide);
  let seen = false;
  try { seen = win.sessionStorage.getItem(key) === '1'; } catch { /* Storage is optional. */ }
  if (!seen && !bootPreventedIntro && !motion?.matches && !win.location.hash) open();
  else boot?.release?.('suppressed');
  return {
    open, finish,
    destroy() {
      restore(false);
      skip.removeEventListener('click', onSkip);
      enter?.removeEventListener('click', onEntry);
      bypass?.removeEventListener('click', onBypass);
      bypass?.removeEventListener('pointerdown', onBypass);
      bypass?.removeEventListener('touchstart', onBypass);
      overlay.removeEventListener('pointerdown', rememberEntryIntent, true);
      overlay.removeEventListener('touchstart', rememberEntryIntent, true);
      overlay.removeEventListener('keydown', rememberEntryIntent, true);
      overlay.removeEventListener('click', clearEntryIntent);
      doc.removeEventListener('keydown', onKey);
      replay?.removeEventListener('click', onReplay);
      doc.removeEventListener('visibilitychange', onVisibility);
      win.removeEventListener('pagehide', onPageHide);
    },
  };
}

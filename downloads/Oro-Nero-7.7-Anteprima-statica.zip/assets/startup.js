/* Early keyboard/inert support for the first-paint cover, before modules load. */
(() => {
  const boot = window.__oroneroArrivalBoot;
  if (!boot?.pending) return;
  const previous = new Map();
  let focused = false;
  const prepare = () => {
    if (!boot.pending) return;
    const overlay = document.querySelector('[data-arrival]');
    if (!overlay) return;
    overlay.hidden = false;
    for (const element of document.body.children) {
      if (element === overlay || element.matches('script, style, [data-music-control], [data-persistent-audio]')) continue;
      if (!previous.has(element)) previous.set(element, element.inert);
      element.inert = true;
    }
    if (!focused) {
      overlay.querySelector('[data-arrival-start], [data-arrival-skip]')?.focus({preventScroll:true});
      focused = true;
    }
  };
  const observer = new MutationObserver(prepare);
  observer.observe(document.documentElement, {childList: true, subtree: true});
  const cleanup = () => {
    observer.disconnect();
    previous.forEach((inert, element) => { element.inert = inert; });
    previous.clear();
    document.removeEventListener('oronero:arrival-boot-end', cleanup);
  };
  document.addEventListener('oronero:arrival-boot-end', cleanup);
  prepare();
})();

export const defaultMenu = {
  version: 3,
  catalogRevision: "esperienza-completa-2026-08-12-v2",
  updatedAt: "2026-08-12T00:00:00.000Z",
  currency: "EUR",
  wines: [
    {
      id: "bianco-casa",
      name: "Bianco della casa",
      producer: "Selezione Oro Nero",
      region: "Veneto",
      type: "Bianco",
      vintage: "",
      description: "Fresco e versatile, proposto al calice o in bottiglia.",
      glassPrice: 5,
      bottlePrice: 18,
      pairings: ["pesce", "crudi", "vegetariano", "antipasti"],
      visible: true
    },
    {
      id: "rosso-casa",
      name: "Rosso della casa",
      producer: "Selezione Oro Nero",
      region: "Veneto",
      type: "Rosso",
      vintage: "",
      description: "Morbido ed equilibrato, pensato per la cucina di carne.",
      glassPrice: 5,
      bottlePrice: 18,
      pairings: ["carne", "manzo", "maiale", "formaggi"],
      visible: true
    },
    {
      id: "prosecco-casa",
      name: "Prosecco della casa",
      producer: "Selezione Oro Nero",
      region: "Veneto",
      type: "Bollicine",
      vintage: "",
      description: "Bollicina fresca per aperitivo, crudi e fritture.",
      glassPrice: 6,
      bottlePrice: 20,
      pairings: ["aperitivo", "crudi", "frittura", "pesce"],
      visible: true
    },
    {
      id: "calice-oro-nero",
      name: "Calice dalla selezione Oro Nero",
      producer: "Etichetta scelta dalla sala",
      region: "Selezione stagionale",
      type: "Selezione al calice",
      vintage: "",
      description: "Una proposta che cambia secondo piatto, stagione e disponibilità.",
      glassPrice: 10,
      bottlePrice: null,
      pairings: ["pesce", "carne", "vegetariano", "dessert"],
      visible: true
    },
    {
      id: "nuova-etichetta-bianca",
      name: "Nuova etichetta bianca",
      producer: "Da completare nel pannello admin",
      region: "",
      type: "Bianco",
      vintage: "",
      description: "Inserisci produttore, annata, prezzi e abbinamenti prima di renderla visibile.",
      glassPrice: null,
      bottlePrice: null,
      pairings: ["pesce"],
      visible: false
    },
    {
      id: "nuova-etichetta-rossa",
      name: "Nuova etichetta rossa",
      producer: "Da completare nel pannello admin",
      region: "",
      type: "Rosso",
      vintage: "",
      description: "Inserisci produttore, annata, prezzi e abbinamenti prima di renderla visibile.",
      glassPrice: null,
      bottlePrice: null,
      pairings: ["carne"],
      visible: false
    }
  ],
  degustations: [
    {
      id: "percorso-oro-nero",
      title: "Percorso Oro Nero",
      subtitle: "5 passaggi · costruito sul momento",
      description: "Un percorso dello chef tra mare, territorio e dessert, adattato alla disponibilità giornaliera e alle esigenze comunicate al personale.",
      price: null,
      visible: true
    },
    {
      id: "percorso-laguna",
      title: "Degustazione della Laguna",
      subtitle: "4 passaggi · dedicati al mare",
      description: "Una selezione per scoprire la cucina di pesce Oro Nero, disponibile su prenotazione.",
      price: null,
      visible: true
    }
  ],
  events: [
    {
      id: "serate-degustazione",
      title: "Serate di degustazione",
      dateText: "Prossime date in aggiornamento",
      description: "Menu dedicati e abbinamenti dalla cantina. Contattaci per conoscere il prossimo appuntamento.",
      visible: true
    },
    {
      id: "eventi-privati",
      title: "Il tuo evento all’Oro Nero",
      dateText: "Su prenotazione",
      description: "Cene private, ricorrenze e piccoli eventi con proposta personalizzata.",
      visible: true
    }
  ],
  categories: [
    {
      id: "pesce-tradizione",
      title: "Della tradizione · Pesce",
      eyebrow: "Menu di pesce",
      items: [
        { id: "pepata-cozze", name: "Pepata di cozze con pomodorino confit", price: 14, allergens: [5, 6, 9, 12, 14], visible: true },
        { id: "saute-vongole", name: "Sauté di vongole lupini in cassopipa", price: 16, allergens: [6, 9, 12, 14], visible: true },
        { id: "mantecati", name: "I nostri mantecati", description: "Baccalà e orata", price: 16, allergens: [2, 4, 6, 7, 9, 12], visible: true },
        { id: "polenta-moscardini", name: "Polenta con moscardini in tocio", price: 18, allergens: [2, 6, 9, 12, 14], visible: true },
        { id: "cappesante-canestrelli", name: "Cappesante e canestrelli al forno", price: 20, allergens: [12, 14], visible: true },
        { id: "saore-laguna", name: "Saore di Laguna scomposto", price: 16, allergens: [1, 2, 4], visible: true },
        { id: "spaghetti-vongole", name: "Spaghetti alle vongole lupini con bottarga", price: 17, allergens: [1, 2, 6, 9, 12, 14], visible: true },
        { id: "risotto-erbette", name: "Risotto con erbette di campo e mazzancolle", price: 23, allergens: [2, 4, 5, 6, 9, 12], visible: true },
        { id: "frittura-paranza", name: "Frittura di paranza con verdurine", price: 24, allergens: [1, 4, 9], visible: true },
        { id: "frittura-calamari", name: "Frittura di calamari e gamberi", price: 17, allergens: [1, 2, 4], visible: true },
        { id: "gallinella", name: "Gallinella incovercià", price: 20, allergens: [1, 4, 6, 12], visible: true }
      ]
    },
    {
      id: "pesce-antipasti",
      title: "Le specialità degli chef",
      eyebrow: "Antipasti di pesce",
      items: [
        { id: "polentina-calamaretti", name: "Polentina marmorizzata con calamaretti spillo e carota viola", price: 20, allergens: [5, 6, 9, 14], visible: true },
        { id: "polpo-patate", name: "Polpo con patate al rosmarino e cremoso di patate", price: 20, allergens: [6, 9, 14], visible: true },
        { id: "tartare-tonno", name: "Tartare di tonno crudo con pesto mediterraneo", price: 24, allergens: [4, 6], visible: true },
        { id: "insalata-mare", name: "Insalata di mare tiepida con verdure all’agro", price: 24, allergens: [2, 4, 5, 6, 9, 12, 14], visible: true },
        { id: "salumeria-mare", name: "Salumeria di mare con julienne di verdure", price: 24, allergens: [4, 7], visible: true },
        { id: "crudo-oronero", name: "Il crudo di pesce dell’ORO NERO", description: "Selezione dal pescato di pesce in crudité con salse", price: 38, allergens: [2, 4, 6, 7, 14], visible: true, featured: true },
        { id: "bollitone-oronero", name: "Il bollitone dell’ORO NERO", description: "Selezione dal pescato cotto al vapore con salse", price: 30, allergens: [2, 4, 6, 9, 14], visible: true, featured: true }
      ]
    },
    {
      id: "pesce-primi",
      title: "Primi piatti di pesce",
      eyebrow: "Pasta e risotti",
      items: [
        { id: "spaghettino-pesto-gambero", name: "Spaghettino tiepido al pesto di basilico con battuta di gambero rosa e scampi marinato al limone e lime", price: 22, allergens: [1, 2, 6, 8, 12], visible: true },
        { id: "tagliolino-cappesante", name: "Tagliolino cappesante e pistacchio", price: 18, allergens: [1, 4, 6, 8, 9, 12], visible: true },
        { id: "scrigni-scampi", name: "Scrigni agli scampi in carbonara di mare", price: 22, allergens: [1, 2, 3, 4, 6, 7, 9, 12, 14], visible: true, featured: true },
        { id: "paccheri-tonno", name: "Paccheri con tonno e trito alla mediterranea", price: 18, allergens: [1, 4, 6, 9, 12], visible: true },
        { id: "fusilloni-seppie", name: "Fusilloni di pasta fresca con seppie in tocio e crumble aromatico", price: 18, allergens: [1, 2, 6, 12, 14], visible: true }
      ]
    },
    {
      id: "pesce-secondi",
      title: "Secondi piatti di pesce",
      eyebrow: "Dal mare",
      items: [
        { id: "bosega-agrumi", name: "Bosega agli agrumi con pane aromatico, crema di asparagi e chips di carota viola", price: 20, allergens: [1, 2, 4, 6, 9, 12], visible: true },
        { id: "sandwich-triglia", name: "Sandwich di triglia in beccafico su cremoso di melanzana e mentuccia", price: 18, allergens: [1, 2, 4, 6, 8, 9, 12], visible: true },
        { id: "merluzzo-panko", name: "Filetto di merluzzo in panure di panko su salsa allo zafferano e parmigiano", price: 18, allergens: [1, 4, 7], visible: true },
        { id: "tataki-tonno", name: "Tataki di tonno con verdure all’agro croccanti", price: 24, allergens: [4, 6, 11], visible: true },
        { id: "orata-forno", name: "Orata al forno su cremoso di patata e salsa alla pizzaiola", price: 23, allergens: [4, 7, 12], visible: true },
        { id: "pescato-giorno", name: "Pescato del giorno locale al forno con verdure", price: 7, priceSuffix: "– 9 € / hg", allergens: [4, 9, 12], visible: true, featured: true }
      ]
    },
    {
      id: "carne-antipasti",
      title: "Antipasti di carne",
      eyebrow: "La carne",
      items: [
        { id: "roast-beef", name: "Roast-beef dell’ORO NERO con crudo di verdure marinate, salsa alla Walchester e scaglie di mandorle", price: 19, allergens: [4, 6, 7, 8, 9], visible: true, featured: true },
        { id: "culatello", name: "Culatello su insalatina di verdure, gnocco fritto e caprino al finocchietto", price: 19, allergens: [1, 7, 10], visible: true },
        { id: "manzo-saor", name: "Manzo in saor con cipolla alla veneziana", price: 16, allergens: [1, 8, 12], visible: true },
        { id: "parmigiana-bolognese", name: "La parmigiana alla bolognese", price: 16, allergens: [1, 6, 7, 9, 12], visible: true },
        { id: "tartare-manzo", name: "Tartare di manzo con fiocchi di burro e ristretto di soia", price: 24, allergens: [6, 7], visible: true }
      ]
    },
    {
      id: "carne-primi",
      title: "Primi piatti di carne",
      eyebrow: "La carne",
      items: [
        { id: "spaghettino-pomodoro", name: "Spaghettino al pomodoro in tre cotture con coulis di basilico e burrata", price: 15, allergens: [1, 6, 7, 9, 12], visible: true },
        { id: "paccheri-ragu", name: "Paccheri al ragù di manzo", price: 16, allergens: [1, 6, 9, 12], visible: true },
        { id: "bigoli-anatra", name: "Bigoli di pasta fresca all’anatra con scaglie di Piave selezione ORO", price: 18, allergens: [1, 6, 7, 9, 12], visible: true },
        { id: "chicche-formaggi", name: "Chicche ai 4 formaggi con speck croccante", price: 16, allergens: [1, 6, 7, 9, 12], visible: true }
      ]
    },
    {
      id: "carne-secondi",
      title: "Secondi piatti di carne",
      eyebrow: "La carne",
      items: [
        { id: "tagliata-manzo", name: "Tagliata di manzo con bieta variegata e scaglie di parmigiano", price: 24, allergens: [6, 9, 12], visible: true },
        { id: "guancia-manzo", name: "Guancia di manzo in CBT con salsa al fondo bruno e patate", price: 22, allergens: [9, 12], visible: true },
        { id: "rolle-faraona", name: "Rollè di faraona alla cacciatora con cremoso di patata alla clorofilla di spinaci e verdure", price: 19, allergens: [9, 12], visible: true },
        { id: "filetto-manzo", name: "Filetto di manzo al fondo bruno e patate", price: 25, allergens: [9, 12], visible: true },
        { id: "trancetto-maiale", name: "Trancetto di maiale in salsa alla senape e miele di barena", price: 20, allergens: [6, 9, 10, 12], visible: true },
        { id: "fiorentina", name: "Fiorentina di manzo", description: "Su disponibilità", price: 6.5, priceSuffix: " / etto", allergens: [], visible: true }
      ]
    },
    {
      id: "vegetariani",
      title: "Piatti vegetariani",
      eyebrow: "Proposte vegetali",
      items: [
        { id: "tortino-patate", name: "Tortino di patate con ortiche al salto e perle di parmigiano dorate in salsa allo zafferano", price: 16, allergens: [1, 3, 6, 7, 9], visible: true, vegetarian: true },
        { id: "terrina-verdure", name: "Terrina di verdure al forno con trito mediterraneo su fonduta di Piave selezione ORO e mentuccia", price: 16, allergens: [6, 7, 9, 12], visible: true, vegetarian: true },
        { id: "risotto-pesto", name: "Risotto al pesto genovese con trito di noci e pepe rosa", price: 22, allergens: [8, 9, 12], visible: true, vegetarian: true },
        { id: "polpette-ceci", name: "Polpette di ceci e miso con cuore filante e salsa alle melanzane confit", price: 17, allergens: [1, 6, 9, 12], visible: true, vegetarian: true },
        { id: "tataki-tofu", name: "Tataki di tofu con alga marinata, verdure all’agro e salsa di soia", price: 18, allergens: [6, 11, 12], visible: true, vegetarian: true }
      ]
    },
    {
      id: "contorni",
      title: "Contorni",
      eyebrow: "Per accompagnare",
      items: [
        { id: "pomodori-gratinati", name: "Pomodori gratinati al forno", price: 7, allergens: [1, 9, 12], visible: true, vegetarian: true },
        { id: "insalatina-mista", name: "Insalatina mista", price: 7, allergens: [5, 6, 8, 9, 10, 11, 13], visible: true, vegetarian: true },
        { id: "patate-forno", name: "Patate al forno", price: 7, allergens: [5, 6, 8, 9, 10, 11, 13], visible: true, vegetarian: true },
        { id: "patate-fritte", name: "Patate fritte", price: 6, allergens: [1, 5, 6, 7, 8, 9, 10, 11], visible: true, vegetarian: true },
        { id: "verdura-vapore", name: "Verdura al vapore", price: 7, allergens: [5, 6, 8, 9, 10, 11, 13], visible: true, vegetarian: true },
        { id: "caponata", name: "Caponata", price: 7, allergens: [9, 12], visible: true, vegetarian: true }
      ]
    },
    {
      id: "dessert",
      title: "Dessert fatti in casa",
      eyebrow: "Il finale",
      items: [
        { id: "sfoglia-chantilly", name: "Sfoglia con crema chantilly, caramello salato, cioccolata e arachidi tostate", price: 9, allergens: [1, 7, 8], visible: true },
        { id: "trilogia-profiterol", name: "Trilogia di profiterol con cioccolato al pistacchio, latte e nocciola", price: 9, allergens: [1, 3, 7], visible: true, featured: true },
        { id: "tiramisu", name: "Tiramisù con cremoso al mascarpone e caffè", price: 9, allergens: [1, 8], visible: true },
        { id: "pavlova", name: "Pavlova con gelato, panna e frutti di bosco", price: 9, allergens: [3, 7], visible: true },
        { id: "torta-chioggiotta", name: "Torta Chioggiotta", description: "Carote, radicchio, noci e salsa brandy", price: 9, allergens: [1, 3, 7, 8], visible: true, featured: true },
        { id: "tartella", name: "Tartella con crema chantilly, frutta fresca e coulis di bosco", price: 9, allergens: [1, 3, 7], visible: true }
      ]
    },
    {
      id: "aperitivi",
      title: "Aperitivi classici e speciali",
      eyebrow: "Dal banco",
      items: [
        { id: "spritz-classico", name: "Spritz Aperol, Campari, Misto o Bianco", price: 6, allergens: [], visible: true },
        { id: "spritz-speciale", name: "Spritz Limoncello, Cynar o Anima Nera", price: 8, allergens: [], visible: true },
        { id: "hugo", name: "Hugo", price: 8, allergens: [], visible: true },
        { id: "negroni-americano", name: "Negroni o Americano", price: 9, allergens: [], visible: true },
        { id: "aperitivo-oronero", name: "Aperitivo ORO NERO", price: 10, allergens: [], visible: true, featured: true }
      ]
    },
    {
      id: "bevande",
      title: "Analcolici e vini della casa",
      eyebrow: "Da bere",
      items: [
        { id: "acqua", name: "Acqua naturale o frizzante 0,75 l", price: 3, allergens: [], visible: true },
        { id: "birra-artigianale", name: "Birra artigianale", price: 7, allergens: [1], visible: true },
        { id: "bibite", name: "Bibite analcoliche", description: "Coca-Cola, Fanta, tè", price: 5, allergens: [], visible: true },
        { id: "succo", name: "Succo di frutta", price: 4, allergens: [], visible: true },
        { id: "calice-fermo", name: "Calice della casa di vino fermo", price: 5, allergens: [12], visible: true },
        { id: "calice-prosecco", name: "Calice della casa Prosecco", price: 6, allergens: [12], visible: true },
        { id: "calice-selezione", name: "Calice dalla selezione ORO NERO", price: 10, allergens: [12], visible: true },
        { id: "bottiglia-casa", name: "Bottiglia della casa bianco o rosso", price: 18, allergens: [12], visible: true },
        { id: "bottiglia-prosecco", name: "Bottiglia Prosecco", price: 20, allergens: [12], visible: true },
        { id: "coperto", name: "Coperto", price: 3.5, allergens: [], visible: true }
      ]
    },
    {
      id: "amari-distillati",
      title: "Amari e distillati",
      eyebrow: "Dopo cena",
      items: [
        { id: "amari-classici", name: "Amari classici", price: 5, priceSuffix: " da", allergens: [], visible: true },
        { id: "grappe", name: "Grappe bianche e barricate", price: 6, priceSuffix: " da", allergens: [], visible: true },
        { id: "rum-whisky", name: "Rum e whisky dalla selezione", price: 8, priceSuffix: " da", allergens: [], visible: true },
        { id: "distillati-premium", name: "Distillati premium", description: "Chiedi la selezione disponibile al personale", price: 10, priceSuffix: " da", allergens: [], visible: true }
      ]
    }
  ]
};

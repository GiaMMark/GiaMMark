import { getStore } from "@netlify/blobs";
import { isAuthenticated, json } from "./_auth.mjs";
import { defaultMenu } from "./menu-default.mjs";

const STORE = "oronero-menu";
const KEY = "current";

function validRecord(record, nameField = "name") {
  return record && typeof record === "object" && !Array.isArray(record) &&
    typeof record.id === "string" && record.id.length > 0 &&
    typeof record[nameField] === "string" && record[nameField].trim().length > 0;
}

function validPrice(value) {
  return value === null || value === undefined || (typeof value === "number" && Number.isFinite(value) && value >= 0);
}

function validMenu(value) {
  return (
    value &&
    typeof value === "object" &&
    Array.isArray(value.categories) &&
    value.categories.every(
      (category) =>
        validRecord(category, "title") &&
        Array.isArray(category.items) &&
        category.items.every((item) => validRecord(item) && validPrice(item.price) &&
          (item.allergens === undefined || (Array.isArray(item.allergens) && item.allergens.every((allergen) => Number.isInteger(allergen) && allergen >= 1 && allergen <= 14)))),
    ) &&
    (value.wines === undefined || (Array.isArray(value.wines) && value.wines.every((wine) => validRecord(wine) && validPrice(wine.glassPrice) && validPrice(wine.bottlePrice) &&
      (wine.pairings === undefined || (Array.isArray(wine.pairings) && wine.pairings.every((pairing) => typeof pairing === "string")))))) &&
    (value.degustations === undefined || (Array.isArray(value.degustations) && value.degustations.every((item) => validRecord(item, "title") && validPrice(item.price)))) &&
    (value.events === undefined || (Array.isArray(value.events) && value.events.every((item) => validRecord(item, "title")))) &&
    (value.version === undefined || (Number.isSafeInteger(value.version) && value.version >= 0))
  );
}

async function currentMenu() {
  try {
    const store = getStore(STORE);
    const saved = await store.get(KEY, { type: "json" });
    if (!saved) return defaultMenu;
    if (saved.catalogRevision !== defaultMenu.catalogRevision) {
      const refreshed = {
        ...defaultMenu,
        categories: Array.isArray(saved.categories) ? saved.categories : defaultMenu.categories,
        wines: Array.isArray(saved.wines) ? saved.wines : defaultMenu.wines,
        degustations: Array.isArray(saved.degustations) ? saved.degustations : defaultMenu.degustations,
        events: Array.isArray(saved.events) ? saved.events : defaultMenu.events,
        updatedAt: new Date().toISOString(),
      };
      try {
        await store.setJSON(KEY, refreshed);
      } catch {
        // Il menu migrato resta disponibile anche se la persistenza è temporaneamente irraggiungibile.
      }
      return refreshed;
    }
    return saved;
  } catch {
    return defaultMenu;
  }
}

export default async (request) => {
  if (request.method === "GET") {
    return json(await currentMenu(), 200, { "cache-control": "public, max-age=30, stale-while-revalidate=120" });
  }

  if (request.method !== "PUT") return json({ error: "Metodo non consentito" }, 405);
  if (!isAuthenticated(request)) return json({ error: "Accesso non autorizzato" }, 401);

  let payload;
  try {
    payload = await request.json();
  } catch {
    return json({ error: "Dati non validi" }, 400);
  }
  if (!validMenu(payload)) return json({ error: "Struttura menu non valida" }, 400);

  const normalized = {
    ...payload,
    version: Number(payload.version || 0) + 1,
    updatedAt: new Date().toISOString(),
  };

  try {
    const store = getStore(STORE);
    await store.setJSON(KEY, normalized);
  } catch (error) {
    return json({ error: "Salvataggio non disponibile", detail: error.message }, 503);
  }

  return json(normalized);
};

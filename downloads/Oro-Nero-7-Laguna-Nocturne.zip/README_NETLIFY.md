# Oro Nero 7.0.0 · Laguna Nocturne · Guida Netlify

Questa versione conserva menu, vini, degustazioni, eventi, allergeni, QR e pannello amministrativo. La nuova home usa nero laguna, avorio e oro, slider fotografico manuale, galleria accessibile da tastiera e una navigazione dedicata agli schermi piccoli.

I font Cormorant Garamond e Manrope sono locali; le licenze SIL Open Font License si trovano in `site/assets/fonts/`. I doppioni obsoleti `menu.mts` e `admin-session.mts` sono stati rimossi: gli endpoint attivi sono i file `.mjs`.

## 1. Installazione e verifica

Con Node.js 22, esegui dalla cartella contenente `package.json`:

```bash
npm ci
npm run build
npm run check
npm test
```

- `npm ci` usa il lockfile senza aggiornare le dipendenze.
- `build` genera `dist/`, il menu statico e il QR.
- `check` verifica file esportati, sezioni e dati del menu.
- `test` verifica pagine, interazioni e funzioni amministrative.

Per l’anteprima statica puoi servire la cartella generata:

```bash
python3 -m http.server 8080 --directory dist
```

Questa anteprima non esegue le Functions: usa il menu JSON di riserva e non permette salvataggi amministrativi. Per provare l’intero flusso con Netlify CLI, usa `netlify dev` e configura le variabili segrete tramite gli strumenti sicuri di Netlify o dell’ambiente locale.

## 2. Pubblicazione completa da Git

1. Estrai lo ZIP sorgente e carica tutti i sorgenti in un repository GitHub.
2. In Netlify scegli **Add new project → Import an existing project** e seleziona il repository.
3. Controlla le impostazioni lette da `netlify.toml`:
   - Build command: `npm run build`;
   - Publish directory: `dist`;
   - Functions directory: `netlify/functions`;
   - Node.js: `22`.
4. Configura le variabili indicate sotto ed esegui il deploy.

Il collegamento Git consente di distribuire sia le pagine sia le Functions che gestiscono autenticazione e salvataggio in Netlify Blobs. Non occorrono chiavi di servizi AI: il Sommelier usa regole locali e le etichette visibili della carta vini.

## 3. Variabili dell’area amministrativa

In **Project configuration → Environment variables**, imposta per **Production** e ambito **Functions**:

| Variabile | Requisito |
| --- | --- |
| `ORONERO_ADMIN_PASSWORD` | Password privata di almeno 10 caratteri. |
| `ORONERO_SESSION_SECRET` | Segreto casuale distinto di almeno 32 caratteri. |

Non inserire i valori nei file o su GitHub. Dopo averli impostati o cambiati, esegui un nuovo deploy. Senza queste variabili il pannello spiega che la configurazione è incompleta; il menu pubblico resta consultabile.

La sessione dura **8 ore** e usa un cookie Secure, HttpOnly e SameSite=Strict. Le credenziali sono controllate dalle Functions.

## 4. Aggiornare il menu

1. Apri `/admin/` sul dominio pubblicato e accedi.
2. Modifica piatti, prezzi, disponibilità, vini, degustazioni o eventi.
3. Salva le modifiche e verifica il risultato in `/menu/`.

Le modifiche vengono memorizzate in Netlify Blobs e condivise con chi apre il menu, anche dal QR. La breve cache del menu pubblico può ritardare la visualizzazione di un aggiornamento: ricarica dopo il salvataggio. Il QR punta alla pagina del menu, quindi non va ristampato per ogni modifica dei piatti.

I dati iniziali restano quelli forniti nel progetto. Verifica con il ristorante prezzi, disponibilità e allergeni prima di rendere operativo il sito.

## 5. QR e dominio definitivo

La build legge la variabile `URL` fornita da Netlify e genera il QR verso il percorso `/menu/` di quel dominio. Se costruisci altrove, imposta `URL` al dominio definitivo prima di eseguire `npm run build`; in sua assenza viene usato `https://oronero.netlify.app`.

Apri `/qr/`, controlla la destinazione con il telefono e poi stampa il cartello oppure scarica il file SVG. Una build locale con il dominio di riserva non produce automaticamente un QR per il tuo nuovo progetto.

## 6. Upload statico di `dist/`

Per una semplice anteprima puoi caricare **solo il contenuto generato in `dist/`** su un hosting statico. Non trascinare lo ZIP sorgente come deploy statico.

In questa modalità funzionano pagine, foto, menu di riserva, filtri, galleria e richiesta WhatsApp. L’admin non dispone delle Functions né del salvataggio persistente; per queste capacità usa il deploy Git Netlify descritto sopra.

Questa consegna non ha pubblicato né aggiornato un sito online. La pubblicazione richiede il deploy del progetto sul tuo account Netlify.

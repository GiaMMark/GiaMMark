# Oro Nero 7.0.0 · Verifica della consegna

## Cosa è stato perfezionato

- Identità Laguna Nocturne: nero laguna, avorio, oro caldo, font locali e composizione editoriale.
- Homepage riprogettata con fotografie originali del ristorante e controlli fotografici manuali.
- Sezioni cucina, esperienze, cantina, atmosfera e contatti; galleria da mouse, touch e tastiera.
- Navigazione mobile con gestione del focus e chiusura da tastiera; link per saltare al contenuto.
- Prenotazione con orari separati per pranzo/cena, messaggio WhatsApp codificato e link alternativo.
- Menu resistente ai filtri durante il caricamento; timeout con menu statico di riserva.
- Sommelier basato sulla carta che rispetta il budget e segnala l’assenza di etichette compatibili.
- Funzioni duplicate obsolete rimosse; richieste amministrative malformate rifiutate correttamente.
- Build che adatta canonical, sitemap, metadati social e cartello QR al dominio configurato.

## Verifiche eseguite

- Build e controllo contenuti: riusciti, 13 categorie e 80 voci mantenute.
- Suite automatica: 20 casi superati in 5 file (pagine, funzioni, menu/admin, casi limite menu, interazioni home).
- Build e suite eseguite anche con Node.js 22.23.4, compatibile con la configurazione Netlify.
- Browser Chromium: home e menu verificati a 320, 390, 768, 1024 e 1440 pixel.
- Slider, galleria, ricerca, filtri, navigazione mobile e preparazione della richiesta verificati.
- Nessun errore JavaScript o scorrimento orizzontale rilevato nelle schermate verificate.
- Controllate anche le pagine allergeni, recensioni, privacy, QR e admin.
- Verificata la sostituzione del dominio nella build con un dominio di prova.

## Pubblicazione

Non è stato effettuato alcun deploy. Le richieste di prenotazione non sono state inviate al ristorante.

L’area amministrativa è stata provata con test delle funzioni e salvataggi simulati: la persistenza reale su Netlify Blobs richiede un deploy Netlify e le due variabili indicate nei README. Non è stata verificata su un sito online.

La cartella `dist/` è una build statica già pronta da consultare tramite un server HTTP. Per distribuire le funzioni e abilitare i salvataggi amministrativi, segui `README_NETLIFY.md`. Prima di stampare il QR, genera la build sul dominio definitivo e controllane la destinazione.

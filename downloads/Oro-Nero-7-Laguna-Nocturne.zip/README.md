# Oro Nero · 7.0.0 Laguna Nocturne

Sito per Oro Nero Experience Bistrot, Chioggia. La nuova home unisce nero laguna, avorio e oro, fotografie del ristorante e una composizione editoriale dedicata alla cucina e all’ospitalità.

## Cosa include

- Home ridisegnata, slider fotografico con controlli manuali e galleria accessibile da tastiera.
- Navigazione e azioni rapide per smartphone; prenotazione guidata tramite WhatsApp.
- Menu con ricerca, categorie, filtro vegetariano e allergeni.
- Carta vini, suggerimenti di abbinamento, degustazioni ed eventi.
- Area amministrativa in `/admin/`, con menu condiviso tramite Netlify Blobs.
- Cartello QR stampabile e scaricabile in `/qr/`.

Menu, prezzi, contatti e fotografie forniti nel progetto sono mantenuti. Il Sommelier propone abbinamenti attraverso regole locali e la carta vini disponibile: non usa un servizio AI esterno né richiede chiavi API.

I font **Cormorant Garamond** e **Manrope** sono serviti dal sito, senza richieste a servizi di font esterni. Le rispettive licenze SIL Open Font License sono incluse in `site/assets/fonts/`.

## Sviluppo e controlli

Usa Node.js 22, la versione configurata anche per Netlify. Dalla cartella del progetto:

```bash
npm ci
npm run build
npm run check
npm test
```

`npm ci` installa le versioni del lockfile. La build genera `dist/`, il menu JSON di riserva e il QR. `check` controlla i file e i dati necessari; `test` esegue i test delle pagine, delle interazioni e delle funzioni.

Per un’anteprima **statica** puoi servire `dist/` con un server HTTP, ad esempio:

```bash
python3 -m http.server 8080 --directory dist
```

In questa modalità il menu usa il JSON generato dalla build; login e salvataggio amministrativo richiedono le Functions di Netlify. Per il flusso completo in locale è possibile usare Netlify CLI con `netlify dev`, configurando in modo sicuro le variabili amministrative.

## Deploy completo su Netlify

Collega a Netlify un repository contenente tutti i sorgenti. `netlify.toml` configura:

- build: `npm run build`;
- cartella pubblicata: `dist`;
- funzioni: `netlify/functions`;
- Node.js: `22`.

Nelle variabili del progetto imposta, per Production e Functions:

- `ORONERO_ADMIN_PASSWORD`: password privata di almeno 10 caratteri;
- `ORONERO_SESSION_SECRET`: segreto casuale distinto di almeno 32 caratteri.

Non inserire i valori nel codice o nel repository. Dopo averli impostati, esegui il deploy. Il pannello `/admin/` consente di aggiornare menu, vini, degustazioni ed eventi condivisi con il menu pubblico.

Il solo caricamento di `dist/` serve per un’anteprima statica: non distribuisce le Functions e non abilita l’admin persistente. Lo ZIP dei sorgenti non è un pacchetto di deploy statico.

Il QR viene generato verso `${URL}/menu/`, usando l’URL fornito da Netlify durante la build. Fuori da Netlify, imposta `URL` al dominio definitivo prima della build; il valore di riserva è `https://oronero.netlify.app`. Controlla la destinazione prima di stampare il QR.

## Manutenzione 7.0.0

Sono stati rimossi gli entrypoint TypeScript `.mts` obsoleti che duplicavano le funzioni attive e importavano un modulo assente. Login, sessioni e validazione del menu gestiscono le richieste malformate senza interrompere il servizio.

La consegna contiene i file del progetto e la build statica. **Non è stata effettuata alcuna pubblicazione online.** Per le istruzioni dettagliate consulta `README_NETLIFY.md`.

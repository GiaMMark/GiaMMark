import { setupMusic } from './music.js?v=7.12.0';

// Start loading and register ordinary interaction handlers before the rest of
// the page's modules finish. The shared controller keeps the same player alive.
setupMusic();

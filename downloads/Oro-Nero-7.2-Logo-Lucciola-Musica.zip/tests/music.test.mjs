import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { setupMusic } from '../site/assets/music.js';

const key = 'oronero-music-v1';
const settle = () => new Promise((resolve) => setImmediate(resolve));
function page({ saved, fail = false, deferred = false, noStorage = false, metadata = true } = {}) {
  const dom = new JSDOM('<!doctype html><body><button id="enter">Entra</button><a href="/menu/">Menu</a></body>', { url: 'https://oronero.test/', pretendToBeVisual: true });
  const win = dom.window;
  if (saved) win.sessionStorage.setItem(key, JSON.stringify(saved));
  if (noStorage) Object.defineProperty(win, 'sessionStorage', { get() { throw new Error('No storage'); } });
  const states = new WeakMap();
  const state = (audio) => { if (!states.has(audio)) states.set(audio, { paused: true, plays: 0 }); return states.get(audio); };
  const prototype = win.HTMLMediaElement.prototype;
  Object.defineProperty(prototype, 'readyState', { configurable: true, get() { return metadata ? 4 : 0; } });
  Object.defineProperty(prototype, 'currentTime', { configurable: true, get() { return state(this).position || 0; }, set(value) { state(this).position = value; if (metadata) this.dispatchEvent(new win.Event('seeked')); } });
  Object.defineProperty(prototype, 'paused', { configurable: true, get() { return state(this).paused; } });
  let resolvePlay;
  let shouldFail = fail;
  prototype.play = function () {
    state(this).plays++;
    if (shouldFail) return Promise.reject(new win.DOMException('User activation needed', 'NotAllowedError'));
    const started = () => { state(this).paused = false; this.dispatchEvent(new win.Event('play')); };
    if (deferred) return new Promise((resolve) => { resolvePlay = () => { started(); resolve(); }; });
    started();
    return Promise.resolve();
  };
  prototype.pause = function () { state(this).paused = true; this.dispatchEvent(new win.Event('pause')); };
  const controller = setupMusic(win.document, win);
  return { ...controller, win, doc: win.document, state: () => state(controller.audio), allow: () => { shouldFail = false; }, metadata() { metadata = true; controller.audio.dispatchEvent(new win.Event('loadedmetadata')); }, resolve: () => resolvePlay(), close() { controller.destroy(); win.close(); } };
}

test('la prima interazione avvia Vivaldi in loop e il comando pausa resta rispettato', async () => {
  const p = page();
  try {
    assert.equal(p.audio.loop, true);
    assert.equal(p.audio.volume, .22);
    assert.match(p.audio.src, /audio\/vivaldi-winter\.mp3$/);
    assert.equal(p.state().plays, 0);
    p.doc.querySelector('#enter').click();
    await settle();
    assert.equal(p.button.getAttribute('aria-pressed'), 'true');
    p.button.click();
    p.doc.querySelector('#enter').click();
    assert.equal(p.audio.paused, true);
    assert.equal(p.state().plays, 1);
    assert.equal(JSON.parse(p.win.sessionStorage.getItem(key)).enabled, false);
  } finally { p.close(); }
});

test('un blocco autoplay mostra lo stato reale e riprova al gesto successivo', async () => {
  const p = page({ saved: { enabled: true, position: 17 }, fail: true });
  try {
    await settle();
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    assert.match(p.button.textContent, /Avvia musica/);
    assert.equal(p.button.getAttribute('aria-busy'), 'false');
    p.allow();
    p.doc.querySelector('#enter').click();
    await settle();
    assert.equal(p.audio.paused, false);
    assert.equal(p.audio.currentTime, 17);
  } finally { p.close(); }
});

test('la preferenza in pausa sopravvive alla navigazione e il comando esplicito riavvia', async () => {
  const p = page({ saved: { enabled: false, position: 43 } });
  try {
    p.doc.querySelector('#enter').click();
    assert.equal(p.state().plays, 0);
    p.button.click();
    await settle();
    assert.equal(p.audio.paused, false);
    assert.equal(p.audio.currentTime, 43);
    p.audio.currentTime = 51;
    p.win.dispatchEvent(new p.win.Event('pagehide'));
    assert.deepEqual(JSON.parse(p.win.sessionStorage.getItem(key)), { enabled: true, position: 51 });
  } finally { p.close(); }
});

test('mettere in pausa durante una richiesta pendente impedisce un avvio tardivo', async () => {
  const p = page({ deferred: true });
  try {
    p.button.click();
    assert.equal(p.button.getAttribute('aria-busy'), 'true');
    p.button.click();
    p.resolve();
    await settle();
    assert.equal(p.audio.paused, true);
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    assert.equal(p.button.getAttribute('aria-busy'), 'false');
    assert.equal(JSON.parse(p.win.sessionStorage.getItem(key)).enabled, false);
  } finally { p.close(); }
});

test('un errore della traccia non viene mostrato come musica in riproduzione', async () => {
  const p = page();
  try {
    p.button.click();
    await settle();
    p.audio.dispatchEvent(new p.win.Event('error'));
    assert.equal(p.button.getAttribute('aria-pressed'), 'false');
    assert.match(p.button.textContent, /Riprova musica/);
  } finally { p.close(); }
});

test('il comando funziona anche senza sessionStorage e non viene duplicato', async () => {
  const p = page({ noStorage: true });
  try {
    assert.equal(setupMusic(p.doc, p.win), null);
    p.button.click();
    await settle();
    assert.equal(p.audio.paused, false);
    p.button.click();
    assert.equal(p.audio.paused, true);
  } finally { p.close(); }
});

test('la posizione precedente resta salvata durante il caricamento e viene ripristinata dai metadata', async () => {
  const p = page({ saved: { enabled: true, position: 93 }, metadata: false });
  try {
    await settle();
    assert.equal(p.audio.currentTime, 0);
    assert.equal(JSON.parse(p.win.sessionStorage.getItem(key)).position, 93);
    p.metadata();
    assert.equal(p.audio.currentTime, 93);
    p.audio.currentTime = 96;
    const link = p.doc.querySelector('a');
    link.addEventListener('click', (event) => event.preventDefault());
    link.click();
    assert.deepEqual(JSON.parse(p.win.sessionStorage.getItem(key)), { enabled: true, position: 96 });
  } finally { p.close(); }
});

# Oro Nero · 7.2.0 Logo, lucciola e musica

Sito per Oro Nero Experience Bistrot, Chioggia. La direzione Laguna Nocturne unisce nero laguna, avorio e oro a un ingresso animato e un menu organizzato in schede con spazio fotografico per ogni voce.

## Cosa include

- Intro con il solo emblema del logo: parte piccolo, ruota e si ingrandisce; una lucciola dorata apre il sito con un’apertura luminosa. Nessuna scritta decorativa. Salto, replay e movimento ridotto supportati.
- Vivaldi, L’inverno, completo e in loop su tutte le pagine, con comando Avvia/Pausa. Il primo tocco abilita l’audio secondo le regole del browser; pausa e posizione sono ricordate nella sessione.
- Slider fotografico con controlli manuali e galleria accessibile da tastiera.
- Navigazione e azioni rapide per smartphone; prenotazione guidata tramite WhatsApp.
- Menu senza fotografie né segnaposti, con nomi, descrizioni, prezzi, allergeni, ricerca, categorie e filtro vegetariano.
- Le foto gestibili dall’admin restano archiviate, ma non vengono mostrate nel menu pubblico.
- Carta vini, suggerimenti di abbinamento, degustazioni ed eventi.
- Area amministrativa in `/admin/`, con menu condiviso tramite Netlify Blobs.
- Cartello QR stampabile e scaricabile in `/qr/`.

Il menu pubblico è ora solo testuale, compresa la testata: non mostra fotografie, riquadri “Foto in arrivo” né finestre di ingrandimento. Nomi, prezzi, descrizioni e allergeni sono mantenuti. Le foto già presenti rimangono nella homepage e nella galleria. Le associazioni fotografiche archiviate dall’admin sono conservate nei dati, senza essere mostrate al pubblico. Il Sommelier propone abbinamenti attraverso regole locali e la carta vini disponibile: non usa un servizio AI esterno né richiede chiavi API.

I font **Cormorant Garamond** e **Manrope** sono serviti dal sito, senza richieste a servizi di font esterni. Le rispettive licenze SIL Open Font License sono incluse in `site/assets/fonts/`.

## Sviluppo e controlli

Usa Node.js 22, la versione configurata anche per Netlify. Dalla cartella del progetto:

```bash
npm ci
npm run build
npm run check
npm test
```

`npm ci` installa le versioni del lockfile. La build genera `dist/`, il menu JSON di riserva e il QR. `check` controlla i file e i dati necessari; `test` esegue i test delle pagine, delle interazioni e delle funzioni.

Per un’anteprima **statica** puoi servire `dist/` con un server HTTP, ad esempio:

```bash
python3 -m http.server 8080 --directory dist
```

In questa modalità il menu usa il JSON generato dalla build; login e salvataggio amministrativo richiedono le Functions di Netlify. Per il flusso completo in locale è possibile usare Netlify CLI con `netlify dev`, configurando in modo sicuro le variabili amministrative.

## Deploy completo su Netlify

Collega a Netlify un repository contenente tutti i sorgenti. `netlify.toml` configura:

- build: `npm run build`;
- cartella pubblicata: `dist`;
- funzioni: `netlify/functions`;
- Node.js: `22`.

Nelle variabili del progetto imposta, per Production e Functions:

- `ORONERO_ADMIN_PASSWORD`: password privata di almeno 10 caratteri;
- `ORONERO_SESSION_SECRET`: segreto casuale distinto di almeno 32 caratteri.

Non inserire i valori nel codice o nel repository. Dopo averli impostati, esegui il deploy. Il pannello `/admin/` consente di aggiornare menu, vini, degustazioni, eventi e immagini dei piatti condivisi con il menu pubblico.

Il solo caricamento di `dist/` serve per un’anteprima statica: non distribuisce le Functions e non abilita l’admin persistente. Lo ZIP dei sorgenti non è un pacchetto di deploy statico.

Il QR viene generato verso `${URL}/menu/`, usando l’URL fornito da Netlify durante la build. Fuori da Netlify, imposta `URL` al dominio definitivo prima della build; il valore di riserva è `https://oronero.netlify.app`. Controlla la destinazione prima di stampare il QR.

## Manutenzione e compatibilità

Sono stati rimossi gli entrypoint TypeScript `.mts` obsoleti che duplicavano le funzioni attive e importavano un modulo assente. Login, sessioni e validazione del menu gestiscono le richieste malformate senza interrompere il servizio.

La consegna contiene i file del progetto e la build statica. **Non è stato effettuato alcun deploy del sito su Netlify.** Per le istruzioni dettagliate consulta `README_NETLIFY.md`.

## Musica e nuove fotografie

La traccia fornita è inclusa in `site/assets/audio/vivaldi-winter.mp3`, ottimizzata a 128 kbit/s (circa 9 MB, 9 minuti e 23 secondi). Non viene scaricata prima dell’avvio. Il comando rimane disponibile anche durante l’intro. Navigando tra pagine, il lettore riparte dalla posizione salvata; il browser può richiedere un altro tocco per consentire l’audio. I caricamenti completi delle pagine possono causare una breve interruzione. La pausa esplicita viene rispettata.

Gli archivi fotografici ricevuti finora superano il limite di trasferimento di 32 MiB e non sono stati leggibili. Questa versione non contiene le nuove fotografie. Invia immagini singole o ZIP sotto i 32 MB per inserirle progressivamente. Le foto già presenti e i prezzi rimangono invariati.

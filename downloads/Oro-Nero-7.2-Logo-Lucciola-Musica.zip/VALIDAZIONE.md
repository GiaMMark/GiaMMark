# Oro Nero 7.2.0 · Verifica della consegna

## Modifiche

- Menu pubblico senza foto, segnaposti e lightbox; elenco testuale con prezzi, descrizioni, allergeni, filtri e abbinamenti. Anche la testata è priva di fotografie.
- Intro con solo emblema reale del logo, senza scritta: rotazione e ingrandimento per 3 secondi, seguiti da un’apertura luminosa con lucciola di 1,1 secondi.
- Salto, replay, Escape, movimento ridotto, gestione del focus e salvaguardia di chiusura.
- Musica Vivaldi fornita dall’utente su tutte le sette pagine, in loop al 22% del volume, con comando avvio/pausa accessibile anche durante l’intro.
- Posizione e scelta di pausa conservate nella sessione. La riproduzione rispetta i blocchi autoplay del browser e può richiedere un nuovo tocco dopo la navigazione.

## Verifiche automatiche

Build e controllo dei dati completati con Node.js 22.23.4: 13 categorie e 80 voci. Suite completa: **39 test superati**, nessun fallimento o test saltato, inclusi 6 test dell’intro e 7 del lettore audio. I test delle interazioni in jsdom simulano il motore audio; la riproduzione reale viene verificata separatamente in Chromium.

## Browser reale

Chromium: verificati logo senza scritte, intro automatica, salto, Escape, riproduzione del vero MP3, controllo audio sulle sette pagine, preferenza in pausa dopo ricaricamento e comportamento con movimento ridotto. A 320, 390 e 768 pixel non è stato rilevato scorrimento orizzontale. Nessun errore JavaScript nelle pagine provate.

La ripresa temporale del brano richiede che l’hosting supporti le richieste HTTP Range, come un hosting statico/CDN. La ripresa è stata verificata in Chromium usando un server con risposte 206 e Content-Range. Il semplice server `python3 -m http.server` permette l’anteprima ma non supporta il seeking audio.

## Fotografie

Gli ZIP caricati dall’utente superano il limite di trasferimento di 32 MiB e non sono stati aperti. Le nuove foto restano da inserire quando saranno disponibili in archivi più piccoli o come immagini singole. Le associazioni fotografiche nei dati restano archiviate; nel menu pubblico non compaiono foto né segnaposti, come richiesto dall’utente.

## Pubblicazione

Nessun deploy Netlify eseguito. La cartella dist contiene la build statica. Per le funzioni amministrative e la persistenza su Netlify Blobs occorrono il deploy completo e le variabili sicure descritte in README_NETLIFY.md.

# Oro Nero · 7.10.0 Galleria fotografica

Sito per Oro Nero Experience Bistrot, Chioggia. La direzione Laguna Nocturne unisce nero laguna, avorio e oro a un ingresso animato e un menu testuale senza foto, con navigazione musicale continua.

## Cosa include

- Pagina `/galleria/` dedicata alle fotografie, con griglia responsive nelle proporzioni originali, apertura ingrandita e scorrimento da pulsanti o tastiera. Collegamenti nella testata, nel footer e nella homepage.
- Selettore di lingua nella testata e nel footer di tutte le pagine: ricerca fra 249 lingue e varianti e apertura della pagina pubblica tramite Google Translate in una nuova scheda.
- Homepage con “La nostra storia” e “La squadra”: Chef, Aiuto chef, Sala e Accoglienza, con presentazioni dei ruoli e collegamento diretto dal racconto del ristorante.
- Solo emblema rotante nella testata, senza scritte laterali; titoli più compatti e senza interruzioni forzate.
- Intro visiva automatica e indipendente dalla musica: rotazione, ingrandimento e lucciola iniziano senza richiedere un clic e senza attendere il brano. La freccia salta sempre l’intro; × ed Escape consentono l’ingresso silenzioso e mettono in pausa la musica.
- Intro con il solo emblema del logo: simbolo leggibile, rotazione morbida di 48 gradi e ingrandimento per 3 secondi; un punto di luce dorata apre il sito con una transizione soffusa di 1,1 secondi. Nessuna scritta decorativa. Salto, ingresso silenzioso, replay e movimento ridotto supportati.
- Nuovo estratto fornito di Vivaldi, L’inverno (circa 6 minuti e 26 secondi), in loop, attenuato per un sottofondo discreto; lettore al 70%. Avvio automatico tentato senza richiedere un comando dedicato.
- Navigazione interna senza ricaricare il documento: il medesimo lettore rimane attivo tra homepage, menu, galleria, vini, recensioni, allergeni, privacy, QR e admin, anche con Indietro/Avanti.
- Slider fotografico con controlli manuali e galleria accessibile da tastiera.
- Navigazione e azioni rapide per smartphone; prenotazione guidata tramite WhatsApp.
- Menu senza fotografie né segnaposti, con nomi, descrizioni, prezzi, allergeni, ricerca, categorie e filtro vegetariano.
- Le foto gestibili dall’admin restano archiviate, ma non vengono mostrate nel menu pubblico.
- Carta vini, suggerimenti di abbinamento, degustazioni ed eventi.
- Area amministrativa in `/admin/`, con menu condiviso tramite Netlify Blobs.
- Cartello QR stampabile e scaricabile in `/qr/`.

Il menu pubblico è ora solo testuale, compresa la testata: non mostra fotografie, riquadri “Foto in arrivo” né finestre di ingrandimento. Nomi, prezzi, descrizioni e allergeni sono mantenuti. Le foto già presenti rimangono nella homepage e nella galleria. Le associazioni fotografiche archiviate dall’admin sono conservate nei dati, senza essere mostrate al pubblico. Il Sommelier propone abbinamenti attraverso regole locali e la carta vini disponibile: non usa un servizio AI esterno né richiede chiavi API.

I font **Cormorant Garamond** e **Manrope** sono serviti dal sito, senza richieste a servizi di font esterni. Le rispettive licenze SIL Open Font License sono incluse in `site/assets/fonts/`.

## Galleria fotografica

La pagina `/galleria/` raccoglie sei fotografie già presenti nel progetto: tre crudi di mare, la sala e due dessert. Le immagini mantengono le proporzioni originali; il visualizzatore mostra la foto completa, con precedente/successiva, frecce da tastiera, chiusura ed Escape. Tornando alla pagina, il focus rientra sulla foto aperta. La navigazione interna conserva lo stesso lettore musicale.

Le nuove fotografie inviate come ZIP non sono ancora state importate: anche gli ultimi archivi superano il limite di trasferimento di 32 MiB. Servono immagini singole o pacchetti sotto i 32 MB. Nessuna immagine è stata inventata per sostituirle.

Per aggiungere una fotografia, inserire il file ottimizzato in `site/assets/images/`, poi aggiungere una `figure.gallery-card.photo-gallery-item` in `site/galleria/index.html`, seguendo quelle esistenti e compilando percorso, testo alternativo, dimensioni reali e didascalia. L’ordine delle figure determina lo scorrimento nel visualizzatore. Il layout è in `site/assets/gallery-page.css`. L’editor delle fotografie dei piatti nell’admin riguarda l’archivio dei piatti e non pubblica immagini in questa galleria.

## Lingue e contenuti della homepage

Il selettore apre lo strumento pubblico di Google Translate in una nuova scheda; la pagina originale resta in italiano. Non richiede chiavi o abbonamenti. La copertura dipende dalle lingue e varianti disponibili nel servizio: non comprende letteralmente ogni lingua esistente. Non viene usato un endpoint di traduzione non documentato né il vecchio widget Website Translator.

Il collegamento segue la pagina pubblica corrente, compresi menu, galleria, allergeni, recensioni, privacy e QR. Non invia query string o frammenti. Pagine amministrative e indirizzi locali sono esclusi: nell’anteprima locale il selettore spiega che occorre il dominio pubblico. Le lingue sono ricercabili per nome italiano, inglese, codice e, dove disponibile nei dati del browser, nome nativo. Il catalogo statico e la relativa licenza MIT si trovano in `site/assets/languages-data.js`; non sono state aggiunte dipendenze di traduzione.

La navigazione verso Google è stata verificata nel browser con una destinazione simulata. La resa del servizio remoto e la traduzione dei contenuti caricati dinamicamente, come il menu, non sono state verificate da questo ambiente. Per una traduzione integrata e controllata di ogni contenuto è necessario un servizio supportato da configurare o un catalogo di traduzioni editoriali.

Il racconto del ristorante usa solo posizione e identità già presenti nel progetto. Non sono stati inventati anno di apertura, fondatori, nomi, fotografie o biografie dello staff. I testi delle quattro schede descrivono i ruoli e possono essere personalizzati in `site/index.html` quando saranno disponibili le informazioni reali.

## Sviluppo e controlli

Usa Node.js 22, la versione configurata anche per Netlify. Dalla cartella del progetto:

```bash
npm ci
npm run build
npm run check
npm test
```

`npm ci` installa le versioni del lockfile. La build genera `dist/`, il menu JSON di riserva e il QR. `check` controlla i file e i dati necessari; `test` esegue i test delle pagine, delle interazioni e delle funzioni.

Per un’anteprima **statica** puoi servire `dist/` con un server HTTP, ad esempio:

```bash
python3 -m http.server 8080 --directory dist
```

In questa modalità il menu usa il JSON generato dalla build; login e salvataggio amministrativo richiedono le Functions di Netlify. Per il flusso completo in locale è possibile usare Netlify CLI con `netlify dev`, configurando in modo sicuro le variabili amministrative.

## Deploy completo su Netlify

Collega a Netlify un repository contenente tutti i sorgenti. `netlify.toml` configura:

- build: `npm run build`;
- cartella pubblicata: `dist`;
- funzioni: `netlify/functions`;
- Node.js: `22`.

Nelle variabili del progetto imposta, per Production e Functions:

- `ORONERO_ADMIN_PASSWORD`: password privata di almeno 10 caratteri;
- `ORONERO_SESSION_SECRET`: segreto casuale distinto di almeno 32 caratteri.

Non inserire i valori nel codice o nel repository. Dopo averli impostati, esegui il deploy. Il pannello `/admin/` consente di aggiornare menu, vini, degustazioni, eventi e immagini dei piatti condivisi con il menu pubblico.

Il solo caricamento di `dist/` serve per un’anteprima statica: non distribuisce le Functions e non abilita l’admin persistente. Lo ZIP dei sorgenti non è un pacchetto di deploy statico.

Il QR viene generato verso `${URL}/menu/`, usando l’URL fornito da Netlify durante la build. Fuori da Netlify, imposta `URL` al dominio definitivo prima della build; il valore di riserva è `https://oronero.netlify.app`. Controlla la destinazione prima di stampare il QR.

## Manutenzione e compatibilità

Sono stati rimossi gli entrypoint TypeScript `.mts` obsoleti che duplicavano le funzioni attive e importavano un modulo assente. Login, sessioni e validazione del menu gestiscono le richieste malformate senza interrompere il servizio.

La consegna contiene i file del progetto e la build statica. **Non è stato effettuato alcun deploy del sito su Netlify.** Per le istruzioni dettagliate consulta `README_NETLIFY.md`.

## Musica e nuove fotografie

La nuova traccia fornita è inclusa in `site/assets/audio/vivaldi-winter.mp3`, ottimizzata a 160 kbit/s e attenuata di 12 dB rispetto alla versione 7.4. Il volume del lettore è al 70%; il volume fisico del dispositivo rimane quello impostato dall’ospite.

Il sito tenta la riproduzione automatica con audio udibile. Se il browser vieta l’autoplay sonoro, la prima interazione con il sito (tocco, clic o tastiera) avvia la musica senza richiedere un pulsante dedicato. Il comando rimane disponibile per mettere in pausa e la pausa esplicita viene rispettata.

I collegamenti interni alle pagine del sito vengono caricati senza sostituire il documento e il lettore: la musica continua sullo stesso elemento audio senza ripartire. I link esterni, i download e le nuove schede seguono il comportamento nativo. Un ricaricamento completo, l’apertura di una nuova scheda o l’uscita dal sito creano un nuovo documento e sono soggetti alle regole audio del browser. Posizione e pausa restano conservate nella sessione; il seeking dopo un ricaricamento richiede supporto HTTP Range dell’hosting.

Gli archivi fotografici ricevuti finora superano il limite di trasferimento di 32 MiB e non sono stati leggibili. Questa versione non contiene le nuove fotografie. Invia immagini singole o ZIP sotto i 32 MB per inserirle progressivamente. Le foto già presenti e i prezzi rimangono invariati.

## Caricamento iniziale e intro

L’intro visiva parte automaticamente, senza attendere il permesso audio, il caricamento del brano o un’interazione. La sequenza dura 3 secondi, seguita dall’apertura luminosa di 1,1 secondi. La freccia salta sempre l’intro: non è un comando di avvio. Il marchio, la lucciola e la grafica rimangono quelli della versione 7.7.

× oppure Escape consentono l’ingresso silenzioso e mettono in pausa la musica, annullando anche eventuali tentativi di riproduzione pendenti. Il movimento ridotto e i link diretti non obbligano all’animazione. Un errore audio o una pausa salvata non fermano l’intro e non impediscono l’accesso al sito.

Il tentativo di autoplay musicale avviene separatamente, dal modulo anticipato nella testata. Quando il browser nega l’audio senza interazione, un normale gesto sul sito può avviarlo: questo limite riguarda soltanto il suono e non tiene ferma l’intro. La pausa esplicita viene rispettata.

Ogni apertura completa o ricaricamento della homepage fa partire automaticamente l’intro, anche se vecchie versioni hanno salvato indicatori di visita nella sessione. Tornando alla home tramite navigazione interna nello stesso documento, l’intro non si ripete automaticamente; il comando di replay resta facoltativo. L’accesso diretto al menu, anche dal QR, non mostra l’intro.

## Primo fotogramma e avvio anticipato

La homepage non deve apparire prima dell’intro: una protezione inline nel documento copre la pagina fin dal primo disegno, prima del caricamento dei moduli. Il salto e il tasto Escape funzionano anche durante questa fase. La copertura viene mostrata a ogni apertura completa della homepage, indipendentemente dalle visite salvate dalle versioni precedenti. Movimento ridotto e link diretti con frammento non mostrano la copertura; senza JavaScript la pagina rimane accessibile. Se i moduli non arrivano, dopo otto secondi il sito viene sbloccato.

Il modulo leggero music-start.js inizializza il lettore prima degli altri script. L’autoplay sonoro viene tentato subito, ma resta soggetto alle regole del browser. In caso di blocco basta un normale tocco, clic o tasto sulla pagina: non occorre premere il controllo musicale. Anche componenti che interrompono la propagazione dei clic e i tentativi audio pendenti non devono far perdere l’interazione utile. Una pausa scelta dall’utente viene sempre rispettata.

Per mantenere il sottofondo basso anche sui dispositivi che ignorano il controllo volume JavaScript, è stato attenuato direttamente il file MP3. Il volume fisico rimane controllato dall’ospite.

## Marchio e titoli

La testata mostra solo il nuovo emblema quadrato e trasparente, senza ritagli né scritte, con rotazione lenta di 26 secondi. La rotazione si ferma quando l’ospite richiede movimento ridotto. Il link mantiene il nome accessibile per tornare alla homepage.

Il titolo principale è “Sapori di laguna, emozioni da vivere.”. Le interruzioni manuali sono state tolte dai titoli delle pagine pubbliche e le dimensioni sono più compatte; le righe si adattano naturalmente allo schermo.

## Marchio e finiture 7.7

L’emblema è stato ripulito graficamente a partire dal riferimento fornito, conservando rosetta intrecciata, cerchio centrale e terminali a rombo. Il nuovo file trasparente `site/assets/images/oronero-emblem.png` misura 1254 × 1254 pixel. È un PNG ad alta risoluzione, non un file vettoriale. Il vecchio logo piccolo rimane soltanto come asset storico e non viene più ingrandito nell’interfaccia.

Intro, testata, piè di pagina, icone e cartello QR condividono lo stesso emblema. Il nome nel piè di pagina e nel QR è composto con testo HTML e font del sito per mantenerlo nitido. Descrizione, griglia, separatori e pulsanti del footer sono stati rifiniti. Il menu senza foto, il sottofondo discreto e il flusso musicale restano quelli già verificati.

L’intro mostra un simbolo iniziale largo circa 114 pixel su mobile, invece del precedente marchio quasi invisibile. Rotazione più dolce, alone lieve, anello sottile e una sola lucciola con scia; sequenza di 3 secondi più apertura di 1,1 secondi.

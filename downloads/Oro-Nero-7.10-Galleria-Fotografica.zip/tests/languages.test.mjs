import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { LANGUAGE_CATALOG } from '../site/assets/languages-data.js';
import { publicTranslationPage, translationUrl, setupLanguages } from '../site/assets/languages.js';

function page(url = 'https://oronero.netlify.app/menu/?token=private#allergeni', options = {}) {
  const dom = new JSDOM('<!doctype html><html lang="it"><body><button data-language-open>Lingua</button><main>Menu in italiano</main><audio data-persistent-audio></audio></body></html>', { url, pretendToBeVisual: true });
  const controller = setupLanguages(dom.window.document, dom.window, options);
  return { dom, doc: dom.window.document, win: dom.window, controller, close() { controller.destroy(); dom.window.close(); } };
}

test('il catalogo contiene lingue comuni, regionali e meno diffuse senza codici duplicati', () => {
  assert.ok(LANGUAGE_CATALOG.length > 200);
  const codes = new Set(LANGUAGE_CATALOG.map((entry) => entry.code));
  assert.equal(codes.size, LANGUAGE_CATALOG.length);
  for (const code of ['it', 'en', 'ar', 'zh-CN', 'zh-TW', 'fr-CA', 'pt-PT', 'vec', 'yue', 'fa-AF']) assert.ok(codes.has(code), code);
  assert.equal(translationUrl('https://oronero.netlify.app/', 'invented-language'), null);
});

test('il collegamento usa lo strumento pubblico di Google e condivide solo la pagina pubblica senza query o frammenti', () => {
  const url = new URL(translationUrl('https://oronero.netlify.app/menu/?token=private#allergeni', 'de'));
  assert.equal(url.origin, 'https://translate.google.com');
  assert.equal(url.pathname, '/translate');
  assert.equal(url.searchParams.get('sl'), 'it');
  assert.equal(url.searchParams.get('tl'), 'de');
  assert.equal(url.searchParams.get('u'), 'https://oronero.netlify.app/menu/');
  assert.equal(url.href.includes('private'), false);
  assert.equal(translationUrl('https://oronero.netlify.app/index.html', 'it'), 'https://oronero.netlify.app/index.html');
  assert.equal(new URL(translationUrl('https://oronero.netlify.app/galleria/?private=1#foto', 'en')).searchParams.get('u'), 'https://oronero.netlify.app/galleria/');
});

test('pagine amministrative, credenziali, protocolli e indirizzi privati non vengono inviati al servizio', () => {
  for (const url of [
    'https://oronero.netlify.app/admin/', 'https://oronero.netlify.app/admin/index.html',
    'https://oronero.netlify.app/api/menu', 'https://oronero.netlify.app/.netlify/functions/admin-login',
    'https://oronero.netlify.app/private', 'https://name:password@oronero.netlify.app/menu/',
    'http://127.0.0.1:8080/menu/', 'http://localhost:8080/', 'http://10.2.3.4/menu/',
    'http://192.168.1.3/', 'http://172.20.0.1/', 'http://[::1]/', 'https://restaurant.local/',
    'https://oronero.test/', 'file:///menu/index.html', 'javascript:alert(1)',
  ]) assert.equal(publicTranslationPage(url), null, url);
  assert.equal(publicTranslationPage('http://localhost:8080/menu/?secret=x', { publicBase: 'https://oronero.netlify.app/' }), 'https://oronero.netlify.app/menu/');
  assert.equal(publicTranslationPage('http://localhost:8080/menu/', { publicBase: 'http://10.1.1.1' }), null);
});

test('il selettore apre una finestra accessibile, cerca i nomi nativi e ripristina il focus alla chiusura', () => {
  const p = page();
  try {
    const trigger = p.doc.querySelector('[data-language-open]');
    trigger.click();
    const { dialog } = p.controller;
    const search = dialog.querySelector('[data-language-search]');
    assert.equal(dialog.open, true);
    assert.equal(p.doc.activeElement, search);
    assert.equal(trigger.getAttribute('aria-expanded'), 'true');
    assert.match(dialog.querySelector('#language-note').textContent, /nuova scheda tramite Google Translate/);
    search.value = 'العربية';
    search.dispatchEvent(new p.win.Event('input'));
    assert.equal(dialog.querySelectorAll('[data-translation-code]').length, 1);
    const link = dialog.querySelector('[data-translation-code="ar"]');
    assert.equal(link.target, '_blank');
    assert.equal(link.rel, 'noopener noreferrer');
    assert.equal(new URL(link.href).searchParams.get('u'), 'https://oronero.netlify.app/menu/');
    dialog.querySelector('[data-language-close]').click();
    assert.equal(dialog.open, false);
    assert.equal(p.doc.activeElement, trigger);
    assert.equal(trigger.getAttribute('aria-expanded'), 'false');
    assert.equal(p.doc.documentElement.lang, 'it');
  } finally { p.close(); }
});

test('ricerca senza risultati e ritorno all’italiano non fingono una traduzione già applicata', () => {
  const p = page();
  try {
    p.controller.open();
    const input = p.controller.dialog.querySelector('[data-language-search]');
    input.value = 'not-a-language-zzzz'; input.dispatchEvent(new p.win.Event('input'));
    assert.equal(p.controller.dialog.querySelector('[data-language-empty]').hidden, false);
    input.value = 'Italiano'; input.dispatchEvent(new p.win.Event('input'));
    const link = p.controller.dialog.querySelector('[data-translation-code="it"]');
    const click = new p.win.MouseEvent('click', { bubbles: true, cancelable: true });
    link.dispatchEvent(click);
    assert.equal(click.defaultPrevented, true);
    assert.equal(p.controller.dialog.open, false);
    assert.equal(p.doc.querySelector('main').textContent, 'Menu in italiano');
    assert.equal(p.doc.documentElement.lang, 'it');
  } finally { p.close(); }
});

test('anteprima locale e area amministrativa mostrano il limite senza collegamenti esterni attivi', () => {
  for (const [url, message] of [['http://127.0.0.1:8080/menu/', /dominio pubblico/], ['https://oronero.netlify.app/admin/', /area amministrativa/]]) {
    const p = page(url);
    try {
      p.controller.open();
      const dialog = p.controller.dialog;
      assert.match(dialog.querySelector('[data-language-unavailable]').textContent, message);
      assert.equal(dialog.querySelectorAll('.language-choice[href]').length, 0);
      assert.equal(dialog.querySelectorAll('.language-choice[aria-disabled="true"]').length, LANGUAGE_CATALOG.length);
    } finally { p.close(); }
  }
});

test('riapertura e lifecycle usano il percorso corrente senza duplicare dialoghi o modificare il lettore musicale', () => {
  const p = page();
  try {
    const audio = p.doc.querySelector('audio');
    assert.equal(setupLanguages(p.doc, p.win), p.controller);
    assert.equal(p.doc.querySelectorAll('#language-dialog').length, 1);
    p.controller.open(); p.controller.close();
    p.win.history.pushState({}, '', '/privacy/?secret=x');
    p.controller.open();
    const link = p.controller.dialog.querySelector('[data-translation-code="en"]');
    assert.equal(new URL(link.href).searchParams.get('u'), 'https://oronero.netlify.app/privacy/');
    p.controller.destroy();
    assert.equal(p.doc.querySelector('#language-dialog'), null);
    assert.equal(p.doc.body.classList.contains('language-open'), false);
    p.doc.querySelector('[data-language-open]').click();
    assert.equal(p.doc.querySelector('#language-dialog'), null);
    assert.equal(p.doc.querySelector('audio'), audio);
  } finally { p.close(); }
});

test('aprire le lingue chiude prima la navigazione mobile e la tastiera può chiudere il dialogo', () => {
  const p = page();
  try {
    const toggle = p.doc.createElement('button');
    toggle.className = 'nav-toggle'; toggle.setAttribute('aria-expanded', 'true');
    let closed = 0;
    toggle.addEventListener('click', () => { closed++; toggle.setAttribute('aria-expanded', 'false'); });
    p.doc.body.prepend(toggle);
    p.controller.open();
    assert.equal(closed, 1);
    const event = new p.win.Event('cancel', { cancelable: true });
    p.controller.dialog.dispatchEvent(event);
    assert.equal(event.defaultPrevented, true);
    assert.equal(p.controller.dialog.open, false);
  } finally { p.close(); }
});

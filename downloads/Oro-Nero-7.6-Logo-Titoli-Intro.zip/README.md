# Oro Nero · 7.6.0 Logo, titoli e ingresso con musica

Sito per Oro Nero Experience Bistrot, Chioggia. La direzione Laguna Nocturne unisce nero laguna, avorio e oro a un ingresso animato e un menu testuale senza foto, con navigazione musicale continua.

## Cosa include

- Solo emblema rotante nella testata, senza scritte laterali; titoli più compatti e senza interruzioni forzate.
- Intro sincronizzata alla riproduzione effettiva: durante il caricamento resta il logo piccolo; se il browser chiede un gesto, logo e freccia avviano insieme musica e animazione. × ed Escape consentono l’ingresso senza musica.
- Intro con il solo emblema del logo: parte piccolo, ruota e si ingrandisce; una lucciola dorata apre il sito con un’apertura luminosa. Nessuna scritta decorativa. Ingresso silenzioso, replay e movimento ridotto supportati.
- Nuovo estratto fornito di Vivaldi, L’inverno (circa 6 minuti e 26 secondi), in loop, attenuato per un sottofondo discreto; lettore al 70%. Avvio automatico tentato senza richiedere un comando dedicato.
- Navigazione interna senza ricaricare il documento: il medesimo lettore rimane attivo tra homepage, menu, vini, recensioni, allergeni, privacy, QR e admin, anche con Indietro/Avanti.
- Slider fotografico con controlli manuali e galleria accessibile da tastiera.
- Navigazione e azioni rapide per smartphone; prenotazione guidata tramite WhatsApp.
- Menu senza fotografie né segnaposti, con nomi, descrizioni, prezzi, allergeni, ricerca, categorie e filtro vegetariano.
- Le foto gestibili dall’admin restano archiviate, ma non vengono mostrate nel menu pubblico.
- Carta vini, suggerimenti di abbinamento, degustazioni ed eventi.
- Area amministrativa in `/admin/`, con menu condiviso tramite Netlify Blobs.
- Cartello QR stampabile e scaricabile in `/qr/`.

Il menu pubblico è ora solo testuale, compresa la testata: non mostra fotografie, riquadri “Foto in arrivo” né finestre di ingrandimento. Nomi, prezzi, descrizioni e allergeni sono mantenuti. Le foto già presenti rimangono nella homepage e nella galleria. Le associazioni fotografiche archiviate dall’admin sono conservate nei dati, senza essere mostrate al pubblico. Il Sommelier propone abbinamenti attraverso regole locali e la carta vini disponibile: non usa un servizio AI esterno né richiede chiavi API.

I font **Cormorant Garamond** e **Manrope** sono serviti dal sito, senza richieste a servizi di font esterni. Le rispettive licenze SIL Open Font License sono incluse in `site/assets/fonts/`.

## Sviluppo e controlli

Usa Node.js 22, la versione configurata anche per Netlify. Dalla cartella del progetto:

```bash
npm ci
npm run build
npm run check
npm test
```

`npm ci` installa le versioni del lockfile. La build genera `dist/`, il menu JSON di riserva e il QR. `check` controlla i file e i dati necessari; `test` esegue i test delle pagine, delle interazioni e delle funzioni.

Per un’anteprima **statica** puoi servire `dist/` con un server HTTP, ad esempio:

```bash
python3 -m http.server 8080 --directory dist
```

In questa modalità il menu usa il JSON generato dalla build; login e salvataggio amministrativo richiedono le Functions di Netlify. Per il flusso completo in locale è possibile usare Netlify CLI con `netlify dev`, configurando in modo sicuro le variabili amministrative.

## Deploy completo su Netlify

Collega a Netlify un repository contenente tutti i sorgenti. `netlify.toml` configura:

- build: `npm run build`;
- cartella pubblicata: `dist`;
- funzioni: `netlify/functions`;
- Node.js: `22`.

Nelle variabili del progetto imposta, per Production e Functions:

- `ORONERO_ADMIN_PASSWORD`: password privata di almeno 10 caratteri;
- `ORONERO_SESSION_SECRET`: segreto casuale distinto di almeno 32 caratteri.

Non inserire i valori nel codice o nel repository. Dopo averli impostati, esegui il deploy. Il pannello `/admin/` consente di aggiornare menu, vini, degustazioni, eventi e immagini dei piatti condivisi con il menu pubblico.

Il solo caricamento di `dist/` serve per un’anteprima statica: non distribuisce le Functions e non abilita l’admin persistente. Lo ZIP dei sorgenti non è un pacchetto di deploy statico.

Il QR viene generato verso `${URL}/menu/`, usando l’URL fornito da Netlify durante la build. Fuori da Netlify, imposta `URL` al dominio definitivo prima della build; il valore di riserva è `https://oronero.netlify.app`. Controlla la destinazione prima di stampare il QR.

## Manutenzione e compatibilità

Sono stati rimossi gli entrypoint TypeScript `.mts` obsoleti che duplicavano le funzioni attive e importavano un modulo assente. Login, sessioni e validazione del menu gestiscono le richieste malformate senza interrompere il servizio.

La consegna contiene i file del progetto e la build statica. **Non è stato effettuato alcun deploy del sito su Netlify.** Per le istruzioni dettagliate consulta `README_NETLIFY.md`.

## Musica e nuove fotografie

La nuova traccia fornita è inclusa in `site/assets/audio/vivaldi-winter.mp3`, ottimizzata a 160 kbit/s e attenuata di 12 dB rispetto alla versione 7.4. Il volume del lettore è al 70%; il volume fisico del dispositivo rimane quello impostato dall’ospite.

Il sito tenta la riproduzione automatica con audio udibile. Se il browser vieta l’autoplay sonoro, la prima interazione con il sito (tocco, clic o tastiera) avvia la musica senza richiedere un pulsante dedicato. Il comando rimane disponibile per mettere in pausa e la pausa esplicita viene rispettata.

I collegamenti interni alle pagine del sito vengono caricati senza sostituire il documento e il lettore: la musica continua sullo stesso elemento audio senza ripartire. I link esterni, i download e le nuove schede seguono il comportamento nativo. Un ricaricamento completo, l’apertura di una nuova scheda o l’uscita dal sito creano un nuovo documento e sono soggetti alle regole audio del browser. Posizione e pausa restano conservate nella sessione; il seeking dopo un ricaricamento richiede supporto HTTP Range dell’hosting.

Gli archivi fotografici ricevuti finora superano il limite di trasferimento di 32 MiB e non sono stati leggibili. Questa versione non contiene le nuove fotografie. Invia immagini singole o ZIP sotto i 32 MB per inserirle progressivamente. Le foto già presenti e i prezzi rimangono invariati.

## Caricamento iniziale e intro

Con autoplay consentito, musica e animazione si avviano automaticamente. Con autoplay bloccato, l’intro resta pronta sul logo: un tocco sul logo o sulla freccia avvia il brano e la sequenza completa di rotazione, ingrandimento e lucciola. La prima freccia non chiude più l’intro proprio nel momento in cui il gesto sblocca l’audio.

× oppure Escape permettono di entrare senza musica, annullando anche richieste audio pendenti. Una pausa salvata o un errore audio permettono comunque la visualizzazione dell’intro; il caricamento dei dati ha un limite di otto secondi. La preferenza di movimento ridotto e i link diretti non obbligano all’animazione. Il browser continua a controllare il permesso di autoplay: non viene promesso audio senza gesto quando il browser lo vieta.

Il nuovo ingresso usa una chiave di sessione aggiornata per essere mostrato una prima volta anche dopo il passaggio dalle versioni precedenti.

## Primo fotogramma e avvio anticipato

La homepage non deve apparire prima dell’intro: una protezione inline nel documento copre la pagina fin dal primo disegno, prima del caricamento dei moduli. Il salto e il tasto Escape funzionano anche durante questa fase. Sessioni già viste, movimento ridotto e link diretti con frammento non mostrano la copertura; senza JavaScript la pagina rimane accessibile. Se i moduli non arrivano, dopo otto secondi il sito viene sbloccato.

Il modulo leggero music-start.js inizializza il lettore prima degli altri script. L’autoplay sonoro viene tentato subito, ma resta soggetto alle regole del browser. In caso di blocco basta un normale tocco, clic o tasto sulla pagina: non occorre premere il controllo musicale. Anche componenti che interrompono la propagazione dei clic e i tentativi audio pendenti non devono far perdere l’interazione utile. Una pausa scelta dall’utente viene sempre rispettata.

Per mantenere il sottofondo basso anche sui dispositivi che ignorano il controllo volume JavaScript, è stato attenuato direttamente il file MP3. Il volume fisico rimane controllato dall’ospite.

## Marchio e titoli

La testata mostra solo l’emblema del logo, ritagliato via CSS dall’asset originale senza scritte, con rotazione lenta di 26 secondi. La rotazione si ferma quando l’ospite richiede movimento ridotto. Il link mantiene il nome accessibile per tornare alla homepage.

Il titolo principale è “Sapori di laguna, emozioni da vivere.”. Le interruzioni manuali sono state tolte dai titoli delle pagine pubbliche e le dimensioni sono più compatte; le righe si adattano naturalmente allo schermo.

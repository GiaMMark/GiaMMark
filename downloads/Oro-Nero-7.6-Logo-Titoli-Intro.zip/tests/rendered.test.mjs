import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("la home Laguna Nocturne include navigazione fotografica, galleria ed esperienze", async () => {
  const html = await readFile(new URL("../dist/index.html", import.meta.url), "utf8");
  assert.match(html, /Cucina di laguna/);
  assert.match(html, /data-hero-showcase/);
  assert.match(html, /data-hero-prev/);
  assert.match(html, /data-hero-next/);
  assert.match(html, /gallery-card/);
  assert.match(html, /stage-links/);
  assert.match(html, /stage-cta/);
  assert.match(html, /class="skip-link"/);
  assert.doesNotMatch(html, /id="site-intro"/);
});

test("il menu esportato contiene Sommelier, carta vini e percorsi", async () => {
  const html = await readFile(new URL("../dist/menu/index.html", import.meta.url), "utf8");
  const script = await readFile(new URL("../dist/assets/menu.js", import.meta.url), "utf8");
  const styles = await readFile(new URL("../dist/assets/styles.css", import.meta.url), "utf8");
  assert.match(html, /sommelier-dialog/);
  assert.match(html, /wine-list/);
  assert.match(html, /degustation-list/);
  assert.match(html, /event-list/);
  assert.match(script, /class="menu-category"/);
  assert.match(script, /new URL\("default-menu\.json", import\.meta\.url\)/);
  assert.doesNotMatch(styles, /\.menu-category\s*\{[^}]*opacity:\s*0/);
  assert.match(html, /styles\.css\?v=7\.6\.0/);
  assert.match(html, /menu\.js\?v=7\.6\.0/);
});

test("il pannello admin gestisce tutte le sezioni", async () => {
  const html = await readFile(new URL("../dist/admin/index.html", import.meta.url), "utf8");
  assert.match(html, /data-admin-tab="wines"/);
  assert.match(html, /data-admin-tab="degustations"/);
  assert.match(html, /data-admin-tab="events"/);
  assert.match(html, /QR da stampare/);
});

test("il QR personalizzato viene esportato", async () => {
  const html = await readFile(new URL("../dist/qr/index.html", import.meta.url), "utf8");
  const svg = await readFile(new URL("../dist/assets/menu-qr.svg", import.meta.url), "utf8");
  assert.match(html, /Inquadra/);
  assert.match(svg, /<svg/);
});

test("le funzioni comuni includono prenotazione, barra mobile e credito", async () => {
  const script = await readFile(new URL("../dist/assets/site.js", import.meta.url), "utf8");
  assert.match(script, /booking-dialog/);
  assert.match(script, /mobile-dock/);
  assert.match(script, /gallery-dialog/);
  assert.match(script, /Developed by/);
  assert.match(script, /https:\/\/giammarkdev\.netlify\.app\//);
  assert.match(script, /class SocialStage/);
  assert.match(script, /brandIcon/);
  assert.match(script, /Instagram/);
  assert.match(script, /Facebook/);
  assert.match(script, /Tripadvisor/);
  assert.match(script, /WhatsApp/);
  assert.doesNotMatch(script, /pathPrefix/);
});

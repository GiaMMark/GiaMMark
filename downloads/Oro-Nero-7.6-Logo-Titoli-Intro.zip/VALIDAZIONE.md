# Oro Nero 7.6.0 · Logo, titoli e ingresso con musica

## Modifiche richieste dallo screenshot

- Testata con solo emblema del logo, senza scritte ORO NERO o Experience Bistrot accanto. L’immagine originale è ritagliata via CSS per mostrare solo il simbolo.
- Rotazione continua lenta dell’emblema, un giro ogni 26 secondi. Movimento ridotto rispettato e link alla home con nome accessibile.
- Titolo principale: “Sapori di laguna, emozioni da vivere.”. Nessun a capo manuale nei titoli pubblici: font più compatti e righe naturali anche nel resto delle sezioni.

## Musica dall’intro

Con autoplay consentito il brano avvia automaticamente la sequenza del logo. Quando il browser chiede un gesto, l’intro resta pronta sul simbolo invece di finire silenziosamente: un tocco sul logo o sulla freccia avvia musica e animazione insieme. Il primo clic che sblocca l’audio non salta più immediatamente alla homepage.

× ed Escape offrono ingresso senza musica e annullano le richieste audio pendenti. Il blocco dell’autoplay disabilita anche il tentativo nativo del browser, così un gesto di ingresso silenzioso non riavvia il brano implicitamente. Il sito non forza permessi audio vietati dal browser.

Il caricamento dei dati audio rimane limitato a otto secondi; errori e pause esplicite non bloccano l’accesso. Il controllo precoce copre il primo fotogramma ed è utilizzabile prima dei moduli principali. Il nuovo ingresso usa la chiave sessione v2 per non essere saltato automaticamente dalle sessioni delle versioni precedenti.

Musica discreta della 7.5 conservata: MP3 attenuato di 12 dB rispetto al master 7.4, lettore al 70%, circa 385,6 secondi e 160 kbit/s. Il file audio è identico a quello validato nella 7.5. Continuità del medesimo lettore tra le pagine e menu pubblico senza fotografie mantenuti.

## Verifiche

Node.js 22.23.4: build riuscita, controllo di 13 categorie e 80 voci; **68 test superati**, nessun fallimento o test saltato. Inclusi 17 test musicali, 14 dell’intro, 7 di avvio e 4 di navigazione.

Chromium con policy restrittiva e osservazioni CDP userGesture:false: dopo oltre 4,5 secondi senza gesto il logo resta visibile e l’audio a zero. Tocco sulla freccia, tocco sul logo e Enter avviano il brano lasciando visibile l’intera animazione; alla chiusura il brano ha già suonato per circa quattro secondi. × ed Escape entrano con audio in pausa e posizione zero. Nessun comando musicale dedicato è stato utilizzato in questi casi.

Layout provato a 320, 390, 768 e 1440 pixel: titolo principale su due righe naturali, nessun testo laterale al logo, nessun br nei titoli principali pubblici, nessun overflow orizzontale. Rotazione confermata confrontando i fotogrammi; con movimento ridotto l’animazione del marchio è disattivata.

Riconfermati primo fotogramma senza lampo della home, script ritardati, JavaScript disabilitato, ingresso silenzioso precoce e recupero quando il modulo principale manca. Verificati audio ritardato di cinque secondi, navigazione continua su tutte le pagine con Indietro/Avanti, ricerca menu, Sommelier, prenotazione e stampa QR. Nessun errore JavaScript nelle prove funzionali. La prova di modulo mancante provoca intenzionalmente HTTP 404 e verifica lo sblocco.

## Consegna

Nessun deploy Netlify eseguito. Gli ZIP aggiornati su GitHub contengono sorgenti e build, ma il sito online deve essere aggiornato pubblicando tutti i nuovi file. Non mescolare script e fogli stile di versioni diverse; refinements.css deve essere incluso dopo gli altri stili.

L’amministrazione persistente richiede il deploy completo e le variabili sicure descritte in README_NETLIFY.md. Il volume del dispositivo e il permesso autoplay rimangono sotto il controllo del browser e dell’ospite.

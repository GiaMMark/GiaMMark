# Oro Nero 7.4.0 · Intro sincronizzata alla musica

## Correzione

Con una risposta MP3 ritardata di cinque secondi, nella versione precedente l’intro si chiudeva mentre l’audio era ancora a zero. La sequenza visuale aveva un timer indipendente dalla riproduzione.

Ora, durante il caricamento audio richiesto dall’utente, il logo rimane piccolo e statico. Rotazione, ingrandimento, lucciola e timer di chiusura partono dall’effettivo stato playing del lettore. Questo evita di consumare l’intro mentre il brano sta ancora caricando.

L’attesa è limitata a otto secondi. Skip, Escape e uscita dalla pagina annullano l’attesa; un evento audio successivo non riapre l’intro. Pausa esplicita, errore e blocco autoplay del browser fanno proseguire l’intro senza aspettare. Il movimento ridotto e gli accessi diretti al menu rimangono immediati.

Il nuovo estratto di Vivaldi di circa 385,6 secondi rimane in loop, normalizzato a -14 LUFS con picco target -1,5 dBTP, codificato a 160 kbit/s e riprodotto al 100% del volume del lettore. La musica continua sullo stesso elemento audio tra le pagine interne. Il menu rimane senza foto né segnaposti.

## Verifiche

Node.js 22.23.4: build riuscita, controllo di 13 categorie e 80 voci; **53 test superati**, nessun fallimento o test saltato. Compresi 11 test dell’intro, 12 musicali e 4 di navigazione.

Chromium con MP3 reale: prove sia con caricamento rapido sia con risposta MP3 ritardata di cinque secondi. Nel secondo caso il logo resta in attesa prima dell’audio, poi la sequenza completa parte con la musica e termina dopo almeno 3,5 secondi di riproduzione. Nessuna interazione utente è stata simulata durante queste osservazioni: letture CDP con userGesture:false e navigator.userActivation.hasBeenActive=false.

Verificata separatamente la policy che vieta autoplay sonoro: stato blocked reale, tempo audio zero, nessuna attivazione artificiale; un tocco durante l’intro permette l’avvio audio. Il sito non può imporre un permesso che il browser nega.

Riconfermata la continuità tra menu, carta vini, recensioni, allergeni, privacy, QR e admin, anche con Indietro/Avanti; nessun evento pause/emptied/loadstart sui cambi di pagina. Menu, ricerca, Sommelier, prenotazione e stampa QR funzionanti. Provato accesso diretto mobile a 390 pixel, senza overflow. Nessun errore JavaScript nelle prove.

## Pubblicazione e limiti

Nessun deploy Netlify eseguito. Gli archivi GitHub contengono sorgenti e build aggiornati; pubblicare uno ZIP sul repository non aggiorna automaticamente un sito Netlify già esistente. Per verificare la versione online serve l’indirizzo effettivo del sito.

L’autoplay sonoro resta soggetto alla policy del browser. In caso di caricamento oltre otto secondi, skip, blocco autoplay, pausa o errore audio, non si garantisce musica durante l’intro. Il volume fisico resta quello del dispositivo. Una ricarica completa o una nuova scheda creano un nuovo documento; il ripristino dopo ricarica richiede supporto HTTP Range.

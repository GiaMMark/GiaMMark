import { dishImage, imageUrl, validImageFields } from "./dish-images.js";

const loginView = document.querySelector("#login-view");
const configView = document.querySelector("#config-view");
const editorView = document.querySelector("#editor-view");
const loginForm = document.querySelector("#login-form");
const loginError = document.querySelector("#login-error");
const adminCategories = document.querySelector("#admin-categories");
const adminWines = document.querySelector("#admin-wines");
const adminDegustations = document.querySelector("#admin-degustations");
const adminEvents = document.querySelector("#admin-events");
const status = document.querySelector("#save-status");
let menu;
let uploadingImages = 0;

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[character]);
}

async function api(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  let response;
  try {
    response = await fetch(path, {
      ...options,
      signal: controller.signal,
      headers: { accept: "application/json", ...(options.body ? { "content-type": "application/json" } : {}), ...(options.headers || {}) },
    });
  } catch (error) {
    throw new Error(error.name === "AbortError" ? "Il server sta impiegando troppo tempo. Riprova." : "Connessione al pannello non riuscita.");
  } finally {
    clearTimeout(timeout);
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Operazione non riuscita");
  return data;
}

function dirty() {
  status.textContent = "Modifiche non salvate";
}

async function start() {
  const session = await api("/api/admin/session");
  if (!session.configured) {
    configView.hidden = false;
    return;
  }
  if (!session.authenticated) {
    loginView.hidden = false;
    return;
  }
  await showEditor();
}

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  loginError.textContent = "";
  const submit = loginForm.querySelector("button[type=submit]");
  submit.disabled = true;
  submit.textContent = "Accesso…";
  try {
    await api("/api/admin/login", { method: "POST", body: JSON.stringify({ password: loginForm.password.value }) });
    loginView.hidden = true;
    await showEditor();
  } catch (error) {
    loginError.textContent = error.message;
  } finally {
    submit.disabled = false;
    submit.textContent = "Accedi";
  }
});

async function showEditor() {
  menu = await api("/api/menu");
  menu.wines ||= [];
  menu.degustations ||= [];
  menu.events ||= [];
  editorView.hidden = false;
  renderAll();
}

function menuItemTemplate(category, item) {
  return `<article class="admin-item" data-kind="menu" data-category="${escapeHtml(category.id)}" data-id="${escapeHtml(item.id)}">
    <label>Nome<input data-field="name" value="${escapeHtml(item.name)}"></label>
    <label>Descrizione<input data-field="description" value="${escapeHtml(item.description || "")}"></label>
    <label class="small-field">Prezzo €<input data-field="price" data-number type="number" step="0.10" min="0" value="${item.price ?? ""}"></label>
    <label class="small-field">Allergeni<input data-field="allergens" data-array value="${(item.allergens || []).join(", ")}"></label>
    ${imageEditor(item)}
    <label class="toggle-field"><input data-field="visible" data-boolean type="checkbox" ${item.visible ? "checked" : ""}> Visibile</label>
    <button class="admin-remove" type="button" data-remove>Rimuovi</button>
  </article>`;
}

function imageEditor(item) {
  const photo = dishImage(item);
  return `<div class="admin-image-editor">
    <div class="admin-image-preview">${photo.image ? `<img src="${escapeHtml(photo.image)}" alt="${escapeHtml(photo.imageAlt)}" loading="lazy">` : '<span>Foto in arrivo</span>'}</div>
    <div class="admin-image-controls">
      <label>Foto del piatto: URL o percorso<input data-field="image" inputmode="url" value="${escapeHtml(photo.image)}" placeholder="https://… oppure /assets/images/piatto.webp" maxlength="2048"></label>
      <label>Descrizione della foto<input data-field="imageAlt" value="${escapeHtml(photo.imageAlt)}" maxlength="240" placeholder="Descrivi il piatto fotografato"></label>
      <div class="admin-image-actions"><label class="image-upload-button">Carica foto dal dispositivo<input type="file" data-image-upload accept="image/jpeg,image/png,image/webp,image/avif"></label><button type="button" data-remove-image>Rimuovi foto</button></div>
      <p class="image-upload-status" role="status">JPEG, PNG, WebP o AVIF. La foto viene ottimizzata; premi Salva e pubblica per associarla al piatto.</p>
    </div>
  </div>`;
}

function updateImagePreview(row, record) {
  const preview = row.querySelector(".admin-image-preview");
  const photo = dishImage(record);
  if (!preview) return;
  preview.innerHTML = photo.image ? `<img src="${escapeHtml(photo.image)}" alt="${escapeHtml(photo.imageAlt)}" loading="lazy">` : "<span>Foto in arrivo</span>";
  preview.querySelector("img")?.addEventListener("error", () => {
    preview.innerHTML = "<span>Foto non raggiungibile</span>";
  }, { once: true });
}

async function optimizedPhoto(file) {
  if (!["image/jpeg", "image/png", "image/webp", "image/avif"].includes(file.type)) throw new Error("Scegli una foto JPEG, PNG, WebP o AVIF. Esporta prima le foto HEIC in JPEG.");
  if (file.size > 20 * 1024 * 1024) throw new Error("Scegli una foto inferiore a 20 MB.");
  const objectUrl = URL.createObjectURL(file);
  const image = new window.Image();
  try {
    await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error("La foto non può essere letta. Prova a esportarla in JPEG.")); image.src = objectUrl; });
    const scale = Math.min(1, 960 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Il browser non può ottimizzare la foto. Usa il collegamento URL oppure un altro browser.");
    context.fillStyle = "#f1eee5";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    let blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", .82));
    if (blob && blob.size > 450 * 1024) blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", .62));
    if (!blob || blob.size > 1024 * 1024) throw new Error("Non riesco a ridurre abbastanza questa foto. Prova con un’immagine più piccola.");
    return blob;
  } finally { URL.revokeObjectURL(objectUrl); }
}

editorView.addEventListener("change", async (event) => {
  const row = event.target.closest('[data-kind="menu"]');
  if (!row) return;
  const record = recordFor(row);
  if (!record) return;
  if (["image", "imageAlt"].includes(event.target.dataset.field)) {
    updateImagePreview(row, record);
    return;
  }
  if (!event.target.matches("[data-image-upload]")) return;
  const file = event.target.files?.[0];
  if (!file) return;
  const input = event.target;
  const message = row.querySelector(".image-upload-status");
  const save = document.querySelector("#save-menu");
  input.disabled = true;
  uploadingImages += 1;
  save.disabled = true;
  message.textContent = "Ottimizzazione e caricamento della foto…";
  try {
    const blob = await optimizedPhoto(file);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    let response;
    try { response = await fetch("/api/admin/image", { method: "POST", headers: { "content-type": blob.type }, body: blob, signal: controller.signal }); }
    finally { clearTimeout(timeout); }
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !imageUrl(result.image)) throw new Error(result.error || "Caricamento non disponibile. Serve il sito completo pubblicato su Netlify.");
    // If the record was removed while uploading, do not attach the result elsewhere.
    if (recordFor(row) !== record) throw new Error("Il piatto è stato rimosso durante il caricamento.");
    record.image = result.image;
    record.imageAlt = record.imageAlt || record.name;
    row.querySelector('[data-field="image"]').value = record.image;
    row.querySelector('[data-field="imageAlt"]').value = record.imageAlt;
    updateImagePreview(row, record);
    dirty();
    message.textContent = "Foto caricata. Premi Salva e pubblica per mostrarla nel menu.";
  } catch (error) {
    message.textContent = error.name === "AbortError" ? "Caricamento troppo lento. Riprova." : error.message;
  } finally {
    input.disabled = false;
    input.value = "";
    uploadingImages -= 1;
    save.disabled = uploadingImages > 0;
  }
});

function renderMenu() {
  adminCategories.innerHTML = menu.categories.map((category) => `
    <section class="admin-category" data-category-section="${escapeHtml(category.id)}">
      <header><div><p>Categoria</p><h2>${escapeHtml(category.title)}</h2></div><button type="button" data-add-menu="${escapeHtml(category.id)}">+ Aggiungi piatto</button></header>
      <div>${category.items.map((item) => menuItemTemplate(category, item)).join("")}</div>
    </section>`).join("");
}

function wineTemplate(wine) {
  return `<article class="admin-record wine-admin-record" data-kind="wines" data-id="${escapeHtml(wine.id)}">
    <label>Etichetta<input data-field="name" value="${escapeHtml(wine.name)}"></label>
    <label>Produttore<input data-field="producer" value="${escapeHtml(wine.producer || "")}"></label>
    <label>Regione<input data-field="region" value="${escapeHtml(wine.region || "")}"></label>
    <label>Tipologia<input data-field="type" value="${escapeHtml(wine.type || "")}" placeholder="Bianco, rosso, bollicine…"></label>
    <label>Annata<input data-field="vintage" value="${escapeHtml(wine.vintage || "")}"></label>
    <label class="wide-field">Descrizione<textarea data-field="description" rows="2">${escapeHtml(wine.description || "")}</textarea></label>
    <label>Calice €<input data-field="glassPrice" data-number type="number" step="0.10" min="0" value="${wine.glassPrice ?? ""}"></label>
    <label>Bottiglia €<input data-field="bottlePrice" data-number type="number" step="0.10" min="0" value="${wine.bottlePrice ?? ""}"></label>
    <label class="wide-field">Abbinamenti<input data-field="pairings" data-text-array value="${escapeHtml((wine.pairings || []).join(", "))}" placeholder="pesce, crudi, carne, dessert…"></label>
    <label class="toggle-field"><input data-field="visible" data-boolean type="checkbox" ${wine.visible ? "checked" : ""}> Visibile nella carta</label>
    <button class="admin-remove" type="button" data-remove>Rimuovi</button>
  </article>`;
}

function simpleRecordTemplate(kind, item) {
  const isEvent = kind === "events";
  return `<article class="admin-record" data-kind="${kind}" data-id="${escapeHtml(item.id)}">
    <label>Titolo<input data-field="${isEvent ? "title" : "title"}" value="${escapeHtml(item.title)}"></label>
    <label>${isEvent ? "Data o periodo" : "Sottotitolo"}<input data-field="${isEvent ? "dateText" : "subtitle"}" value="${escapeHtml(isEvent ? item.dateText || "" : item.subtitle || "")}"></label>
    <label class="wide-field">Descrizione<textarea data-field="description" rows="3">${escapeHtml(item.description || "")}</textarea></label>
    ${isEvent ? "" : `<label>Prezzo €<input data-field="price" data-number type="number" step="0.10" min="0" value="${item.price ?? ""}" placeholder="Vuoto = su richiesta"></label>`}
    <label class="toggle-field"><input data-field="visible" data-boolean type="checkbox" ${item.visible ? "checked" : ""}> Visibile</label>
    <button class="admin-remove" type="button" data-remove>Rimuovi</button>
  </article>`;
}

function renderAll() {
  renderMenu();
  adminWines.innerHTML = menu.wines.map(wineTemplate).join("");
  adminDegustations.innerHTML = menu.degustations.map((item) => simpleRecordTemplate("degustations", item)).join("");
  adminEvents.innerHTML = menu.events.map((item) => simpleRecordTemplate("events", item)).join("");
}

function recordFor(element) {
  const kind = element.dataset.kind;
  if (kind === "menu") {
    const category = menu.categories.find((entry) => entry.id === element.dataset.category);
    return category?.items.find((entry) => entry.id === element.dataset.id);
  }
  return menu[kind]?.find((entry) => entry.id === element.dataset.id);
}

editorView.addEventListener("input", (event) => {
  const row = event.target.closest("[data-kind]");
  const field = event.target.dataset.field;
  if (!row || !field) return;
  const record = recordFor(row);
  if (!record) return;
  if (event.target.hasAttribute("data-boolean")) record[field] = event.target.checked;
  else if (event.target.hasAttribute("data-number")) record[field] = event.target.value === "" ? null : Number(event.target.value);
  else if (event.target.hasAttribute("data-array")) record[field] = event.target.value.split(",").map(Number).filter((value) => value >= 1 && value <= 14);
  else if (event.target.hasAttribute("data-text-array")) record[field] = event.target.value.split(",").map((value) => value.trim().toLowerCase()).filter(Boolean);
  else record[field] = event.target.value;
  if (field === "image") {
    row.querySelector(".image-upload-status").textContent = event.target.value && !imageUrl(event.target.value) ? "Usa un URL HTTPS valido o un percorso /assets/images/…" : "Modifica pronta. Premi Salva e pubblica per aggiornare il menu.";
  }
  dirty();
});

editorView.addEventListener("click", (event) => {
  const removeImage = event.target.closest("[data-remove-image]");
  if (removeImage) {
    const row = removeImage.closest('[data-kind="menu"]');
    const record = recordFor(row);
    if (!record) return;
    record.image = "";
    record.imageAlt = "";
    row.querySelector('[data-field="image"]').value = "";
    row.querySelector('[data-field="imageAlt"]').value = "";
    updateImagePreview(row, record);
    row.querySelector(".image-upload-status").textContent = "Foto rimossa dal piatto. Premi Salva e pubblica per confermare.";
    dirty();
    return;
  }
  const tab = event.target.closest("[data-admin-tab]");
  if (tab) {
    document.querySelectorAll("[data-admin-tab]").forEach((button) => button.classList.toggle("active", button === tab));
    document.querySelectorAll("[data-admin-panel]").forEach((panel) => { panel.hidden = panel.dataset.adminPanel !== tab.dataset.adminTab; });
    return;
  }

  const addMenu = event.target.closest("[data-add-menu]");
  if (addMenu) {
    const category = menu.categories.find((entry) => entry.id === addMenu.dataset.addMenu);
    category.items.push({ id: `nuovo-${Date.now()}`, name: "Nuovo piatto", description: "", price: 0, allergens: [], visible: true });
    renderMenu();
    dirty();
    return;
  }

  if (event.target.closest("[data-add-wine]")) {
    menu.wines.push({ id: `vino-${Date.now()}`, name: "Nuova etichetta", producer: "", region: "", type: "", vintage: "", description: "", glassPrice: null, bottlePrice: null, pairings: [], visible: false });
    adminWines.innerHTML = menu.wines.map(wineTemplate).join("");
    dirty();
    return;
  }
  if (event.target.closest("[data-add-degustation]")) {
    menu.degustations.push({ id: `degustazione-${Date.now()}`, title: "Nuovo percorso", subtitle: "", description: "", price: null, visible: false });
    adminDegustations.innerHTML = menu.degustations.map((item) => simpleRecordTemplate("degustations", item)).join("");
    dirty();
    return;
  }
  if (event.target.closest("[data-add-event]")) {
    menu.events.push({ id: `evento-${Date.now()}`, title: "Nuovo evento", dateText: "", description: "", visible: false });
    adminEvents.innerHTML = menu.events.map((item) => simpleRecordTemplate("events", item)).join("");
    dirty();
    return;
  }

  const remove = event.target.closest("[data-remove]");
  if (remove) {
    const row = remove.closest("[data-kind]");
    const record = recordFor(row);
    if (!window.confirm(`Rimuovere “${record?.name || record?.title || "questa voce"}”? La modifica sarà effettiva dopo il salvataggio.`)) return;
    const kind = row.dataset.kind;
    if (kind === "menu") {
      const category = menu.categories.find((entry) => entry.id === row.dataset.category);
      category.items = category.items.filter((entry) => entry.id !== row.dataset.id);
      renderMenu();
    } else {
      menu[kind] = menu[kind].filter((entry) => entry.id !== row.dataset.id);
      renderAll();
    }
    dirty();
  }
});

document.querySelector("#save-menu").addEventListener("click", async () => {
  const saveButton = document.querySelector("#save-menu");
  if (uploadingImages) { status.textContent = "Attendi il completamento del caricamento delle foto"; return; }
  if (menu.categories.some((category) => category.items.some((item) => !validImageFields(item)))) {
    status.textContent = "Correggi i collegamenti delle foto: usa URL HTTPS validi o percorsi /assets/images/…";
    return;
  }
  const hasInvalidName = menu.categories.some((category) => category.items.some((item) => !String(item.name || "").trim())) ||
    menu.wines.some((wine) => !String(wine.name || "").trim()) ||
    menu.degustations.some((item) => !String(item.title || "").trim()) ||
    menu.events.some((item) => !String(item.title || "").trim());
  if (hasInvalidName) {
    status.textContent = "Completa tutti i nomi e i titoli prima di salvare";
    return;
  }
  status.textContent = "Salvataggio…";
  saveButton.disabled = true;
  try {
    menu = await api("/api/menu", { method: "PUT", body: JSON.stringify(menu) });
    status.textContent = `Salvato alle ${new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })}`;
  } catch (error) {
    status.textContent = error.message;
  } finally {
    saveButton.disabled = false;
  }
});

document.querySelector("#logout").addEventListener("click", async () => {
  await api("/api/admin/logout", { method: "POST", body: "{}" });
  location.reload();
});

start().catch((error) => {
  configView.hidden = false;
  document.querySelector("#config-title").textContent = "Pannello momentaneamente non disponibile";
  configView.querySelector(".admin-message").textContent = error.message;
  document.querySelector("#retry-admin").hidden = false;
});

document.querySelector("#retry-admin").addEventListener("click", () => location.reload());

document.querySelector("#print-qr")?.addEventListener("click", () => window.print());

if Config.Framework ~= "qb" then
    return
end

debugprint("Loading QB")

QB = exports["qb-core"]:GetCoreObject()

PlayerData = {}

while not LocalPlayer.state.isLoggedIn do
    Wait(500)
end

FrameworkLoaded = true

debugprint("QB loaded")

PlayerData = QB.Functions.GetPlayerData()

RegisterNetEvent("QBCore:Client:OnPlayerLoaded", function()
    PlayerData = QB.Functions.GetPlayerData()

    FetchPhone()
end)

RegisterNetEvent("QBCore:Client:OnPlayerUnload", function()
    PlayerData = {}

    LogOut()
end)

local function PlayerDataUpdated()
    local metadata = PlayerData.metadata or {}

    if (metadata.ishandcuffed or metadata.isdead or metadata.inlaststand) and phoneOpen then
        OnDeath()
    end

    if not Config.Item.Require or Config.Item.Unique then
        return
    end

    Wait(500)

    if currentPhone and not HasPhoneItem() then
        OnDeath()
    end
end

RegisterNetEvent("QBCore:Player:SetPlayerData", function(newData)
    PlayerData = newData

    PlayerDataUpdated()
end)

RegisterNetEvent("QBCore:Client:OnPlayerUpdated", function(key, value)
    if not PlayerData or key == "all" then
        return
    end

    PlayerData[key] = value

    PlayerDataUpdated()
end)

RegisterNetEvent("QBCore:Client:OnMoneyChange", function(moneyType)
    if moneyType ~= "bank" then
        return
    end

    SendNUIAction("wallet:setBalance", math.floor(PlayerData.money.bank))
end)

AddCheck("openPhone", function()
    local metadata = PlayerData.metadata or {}

    if metadata.ishandcuffed or metadata.isdead or metadata.inlaststand then
        return false
    end

    return true
end)

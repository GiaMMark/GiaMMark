# Oro Nero 7.7.0 · Marchio nitido e ingresso rifinito

## Miglioramenti visivi

- Nuovo emblema trasparente PNG 1254 × 1254 pixel, ripulito dal riferimento originale con generazione d’immagine. Identità floreale intrecciata, cerchio e rombi conservati; il file è un’immagine raster ad alta risoluzione, non un SVG.
- Emblema coordinato in intro, testata, footer, icone e QR. Nessun ingrandimento del vecchio asset da circa 104 pixel e nessun ritaglio del nuovo marchio.
- Testata con solo emblema in lenta rotazione; nel footer e sul QR il nome è testo HTML nitido con i font del sito.
- Intro con simbolo più leggibile in attesa (circa 114 pixel mobile), rotazione di 48 gradi, ingrandimento progressivo, alone lieve e anello sottile. Singolo punto di luce con scia discreta; apertura a bordo morbido, senza le precedenti ali o il lampo ampio.
- Footer con gerarchia più ordinata, descrizione a 13 pixel, marchio proporzionato, separatori e griglia responsive. Spazio finale per i controlli fissi e pulsanti più rifiniti.

## Comportamenti conservati

Sequenza dell’intro di 3 secondi più apertura di 1,1 secondi. Avvio con la musica, attesa del gesto quando il browser blocca autoplay, ingresso silenzioso con × o Escape, sincronizzazione al caricamento e protezione contro il lampo della homepage. Movimento ridotto rispettato.

Sottofondo discreto, stesso elemento audio tra le pagine, titoli compatti e menu senza fotografie conservati. Nessuna modifica a nomi, prezzi, allergeni o dati del menu.

## Verifiche

Node.js 22.23.4: build e controllo riusciti, 13 categorie e 80 voci. **68 test superati**, nessun fallimento o test saltato. Inclusi 17 test musicali, 14 dell’intro, 7 di avvio e 4 di navigazione.

Chromium: nuova intro registrata e schermate controllate. Footer e marchio provati a 320, 390, 768 e 1440 pixel: nessun overflow, blocco marchio contenuto nella colonna, descrizione a 13 pixel. Emblema effettivamente caricato a 1254 pixel; assenza di scritte accanto al logo della testata. Cartello QR verificato con nuovo marchio. Nessun errore JavaScript nelle prove visive.

Riconfermata navigazione musicale continua su tutte le pagine, Indietro/Avanti, menu e ricerca, Sommelier, prenotazione e stampa QR. Gli handler amministrativi e i dati restano quelli già validati; nessun salvataggio remoto o messaggio reale inviato.

Il video di anteprima è una registrazione del sito in Chromium, con traccia musicale del progetto allo stesso livello del lettore. È un’anteprima visiva, non una garanzia di autoplay sonoro su tutti i dispositivi.

## Pubblicazione

Nessun deploy Netlify eseguito. Gli archivi e le anteprime su GitHub devono essere pubblicati sull’hosting per aggiornare il sito online. Il browser mantiene il controllo sul permesso autoplay e l’ospite sul volume fisico del dispositivo. Usare l’intera build aggiornata, senza mescolare asset di versioni diverse.

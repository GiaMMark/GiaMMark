function Dispatch(source)
    local coords = GetEntityCoords(GetPlayerPed(source))
    local data = {
        title = Config.Dispatch.Title,
        message = Config.Dispatch.Message,
        code = Config.Dispatch.Code,
        coords = coords,
        jobs = Config.PoliceJobs,
        blip = {
            sprite = Config.Dispatch.Blip.Sprite,
            color = Config.Dispatch.Blip.Color,
            scale = Config.Dispatch.Blip.Scale,
            text = Config.Dispatch.Blip.Text,
        },
        time = Config.Dispatch.Time,
    }
    exports['projectx-bridge']:Dispatch(source, data)
end

function HasItem(source, item)
    return exports['projectx-bridge']:HasItem(source, item)
end

function AddItem(source, item, amount, info)
    return exports['projectx-bridge']:AddItem(source, item, amount, info)
end

function RemoveItem(source, item, amount)
    return exports['projectx-bridge']:RemoveItem(source, item, amount)
end

function AddMoney(source, account, amount, reason)
    return exports['projectx-bridge']:AddMoney(source, account, amount, reason)
end

function Notification(source, text, type, duration)
    exports['projectx-bridge']:Notify(source, text, type, duration)
end

function CheckPerms(source)
    return exports['projectx-bridge']:CheckPerms(source, GetCurrentResourceName())
end

function PoliceCount()
    return exports['projectx-bridge']:RequiredPoliceCount(Config.MinimumPolice, Config.PoliceJobs)
end

-- Logs
function GetIDs(src)
    return exports['projectx-bridge']:GetIDs(src, Loc[Config.Lan].logs)
end

function Log(title, msg)
    exports['projectx-bridge']:Log(title, msg, GetCurrentResourceName(), Logs)
end

-- Exp
function LevelCheck(source)
    return exports['projectx-bridge']:GetLevel(source, 'criminal')
end

function SuccessfulStep(source, location, step)
    if step == "Fusebox" then
        -- if Config.SkillSystem then exports['projectx-bridge']:AddExperience(source, 'criminal', 10) end
    elseif step == "Register" then
        -- if Config.SkillSystem then exports['projectx-bridge']:AddExperience(source, 'criminal', 10) end
        -- you can add different amounts of exp for each successful step, the steps are all listed in the config.lua
        -- You can also add whatever you want on each step if needed
    end

    -- Solo guida: la progressione resta interamente gestita dal core originale ProjectX.
    TriggerClientEvent('riverside:fleeca:guideStep', source, location, step)
end

function FailedStep(source, location, step)
    if step == "Fusebox" then
        -- You can add here whatever you want on each failed step, for example removing exp or money or items, its up to you
        -- Steps can be found in the config.lua
    elseif step == "Register" then
        -- You can check for all steps
    end
end

function InitialCheck(src, Location, Interaction)
    return true
    -- Add something here if you want to check something before the robbery can be starts, for example a group check or if you have a tablet you want to integrate.
end

function RobberyResetHook(location)
    -- This is called when a location is reset, you can add something here if you want to do something when a robbery is reset, for example updating a scoreboard or something like that.
    TriggerClientEvent('riverside:fleeca:resetGuide', -1, location)
end

RegisterCommand('projectxfleeca', function(source)
	if not CheckPerms(source) then return Notification(source, Loc[Config.Lan].error["permission"], 'error', Config.NotificationDuration) end
    local pos = GetEntityCoords(GetPlayerPed(source))
    for k, v in pairs(Config.Fleecas) do
        if Config.FleecaLocations[k] and #(pos - vector3(v["AlarmCoords"].x, v["AlarmCoords"].y, v["AlarmCoords"].z)) <= 50.0 then
            ResetHeist(k)
            break
        end
        Wait(50)
    end
end, false)
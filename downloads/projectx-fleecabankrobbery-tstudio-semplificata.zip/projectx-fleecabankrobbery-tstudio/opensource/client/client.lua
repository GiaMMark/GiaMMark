local zones = {}

function CreateCircleZones(data)
    exports['projectx-bridge']:CreateCircleZone(data, Config.debug)
end

function DestroyCircleZone(name)
    exports['projectx-bridge']:DestroyCircleZone(name)
end

function DrawTextUi(bool, text)
    exports['projectx-bridge']:DrawText(bool, text)
end

function CreateDrawtextZone(data)
    local zoneName = data.name
    if zones[zoneName] then
        zones[zoneName]:remove()
        zones[zoneName] = nil
    end
    zones[zoneName] = lib.zones.box({
        name = data.name,
        coords = data.interaction.drawtext,
        size = Config.DrawTextZoneSize,
        rotation = data.rotation,
        debug = Config.debug,
        onEnter = data.onEnter,
        onExit = function() DrawTextUi(false) Breaker(zoneName) end,
    })
end

function DrawtextZoneDestroy(name)
    if zones[name] then
        zones[name]:remove()
        zones[name] = nil
    end
end

function Evidence(pos, chance)
    exports['projectx-bridge']:DropFingerprint(pos, chance)
end

function AddStress(amount)
    exports['projectx-bridge']:AddStress(amount)
end

--------------------- Minigames ---------------------
------ You can return true to skip a minigame -------
-----------------------------------------------------

lib.callback.register('projectx-fleecabankrobbery-tstudio:client:Minigames', function(Step)
    local p = promise.new()
    if Step == "Fusebox" then
        if not exports['projectx-bridge']:MinigameCheck("SN-Hacking") then p:resolve(false) return Citizen.Await(p) end
        local success = exports['SN-Hacking']:MemoryCards('hard')
        p:resolve(success)
    elseif Step == "Fingerprint" then
        if not exports['projectx-bridge']:MinigameCheck("utk_fingerprint") then p:resolve(false) return Citizen.Await(p) end
        TriggerEvent("utk_fingerprint:Start", 4, 6, 2, function(success)
            p:resolve(success)
        end)
    elseif Step == "KeypadOne" then
        if not exports['projectx-bridge']:MinigameCheck("simonsays") then p:resolve(false) return Citizen.Await(p) end
        local success = exports['simonsays']:StartSimonSays(5, 5)
        p:resolve(success)
    elseif Step == "Printer" then
        if not exports['projectx-bridge']:MinigameCheck("lightsout") then p:resolve(false) return Citizen.Await(p) end
        local success = exports['lightsout']:StartLightsOut(4, 20)
        p:resolve(success)
    elseif Step == "ElectricBox" then
        if not exports['projectx-bridge']:MinigameCheck("SN-Hacking") then p:resolve(false) return Citizen.Await(p) end
        local success = exports['SN-Hacking']:MemoryCards('medium')
        p:resolve(success)
    elseif Step == "Vault" then
        if not exports['projectx-bridge']:MinigameCheck("utk_fingerprint") then p:resolve(false) return Citizen.Await(p) end
        TriggerEvent("utk_fingerprint:Start", 4, 6, 2, function(success)
            p:resolve(success)
        end)
    elseif Step == "JailDoor" then
        if not exports['projectx-bridge']:MinigameCheck("SN-Hacking") then p:resolve(false) return Citizen.Await(p) end
        local success = exports['SN-Hacking']:ColorPicker(5, 7000, 3000)
        p:resolve(success)
    else
        p:resolve(false)
    end
    return Citizen.Await(p)
end)

-- ============================================================
-- RIVERSIDE - AVVIO RAPINA TRAMITE IMPIEGATO
-- Punta un'arma contro un NPC impiegato all'interno della Fleeca.
-- Non sostituisce la logica ProjectX: dopo l'intimidazione il primo
-- step resta il Fusebox originale della rapina.
-- ============================================================

local riversideStartBlip = nil
local riversideStartBlipToken = 0
local riversideBankPedTriggered = {}
local riversideBankPedHintShown = {}
local riversideBankPedAimStarted = {}

local function RiversideClearStartBlip()
    riversideStartBlipToken = riversideStartBlipToken + 1
    if riversideStartBlip and DoesBlipExist(riversideStartBlip) then
        SetBlipRoute(riversideStartBlip, false)
        RemoveBlip(riversideStartBlip)
    end
    riversideStartBlip = nil
end

local function RiversidePointInsideBank(coords, zone)
    if not zone or #zone < 3 then return false end

    local inside = false
    local j = #zone
    for i = 1, #zone do
        local xi, yi = zone[i].x, zone[i].y
        local xj, yj = zone[j].x, zone[j].y
        local intersects = ((yi > coords.y) ~= (yj > coords.y))
            and (coords.x < (xj - xi) * (coords.y - yi) / ((yj - yi) + 0.000001) + xi)
        if intersects then inside = not inside end
        j = i
    end
    return inside
end

local function RiversideCurrentFleeca(coords)
    for location, enabled in pairs(Config.FleecaLocations or {}) do
        if enabled then
            local bank = Config.Fleecas and Config.Fleecas[location]
            if bank and bank.Zone and RiversidePointInsideBank(coords, bank.Zone) then
                return location
            end
        end
    end
    return nil
end

local function RiversideValidEmployeePed(entity, playerPed, location)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return false end
    if GetEntityType(entity) ~= 1 or IsPedAPlayer(entity) or IsEntityDead(entity) then return false end
    if IsPedInAnyVehicle(entity, false) or not IsPedHuman(entity) then return false end

    local bank = Config.Fleecas and Config.Fleecas[location]
    if not bank or not bank.Zone then return false end

    local pedCoords = GetEntityCoords(entity)
    if not RiversidePointInsideBank(pedCoords, bank.Zone) then return false end

    if #(GetEntityCoords(playerPed) - pedCoords) > (Config.IntuitiveStart.MaxPedDistance or 8.0) then
        return false
    end

    if Config.IntuitiveStart.RequireStationaryPed ~= false and GetEntitySpeed(entity) > 0.8 then
        return false
    end

    return true
end

local function RiversideRotationToDirection(rotation)
    local z = math.rad(rotation.z)
    local x = math.rad(rotation.x)
    local cosX = math.abs(math.cos(x))
    return vector3(-math.sin(z) * cosX, math.cos(z) * cosX, math.sin(x))
end

local function RiversideFindEmployeeInAimCone(playerPed, location)
    local camCoords = GetGameplayCamCoord()
    local camDirection = RiversideRotationToDirection(GetGameplayCamRot(2))
    local maxDistance = Config.IntuitiveStart.MaxPedDistance or 8.0
    local minDot = Config.IntuitiveStart.AimConeDot or 0.975
    local bestPed, bestScore = nil, minDot

    for _, ped in ipairs(GetGamePool('CPed')) do
        if ped ~= playerPed and RiversideValidEmployeePed(ped, playerPed, location) then
            local pedCoords = GetEntityCoords(ped)
            local target = vector3(pedCoords.x, pedCoords.y, pedCoords.z + 0.65)
            local delta = target - camCoords
            local distance = #delta

            if distance > 0.01 and distance <= maxDistance + 2.0 then
                local dir = delta / distance
                local dot = (camDirection.x * dir.x) + (camDirection.y * dir.y) + (camDirection.z * dir.z)
                local score = dot - (distance * 0.0005)
                if dot >= minDot and score > bestScore - (maxDistance * 0.0005) then
                    bestPed, bestScore = ped, score
                end
            end
        end
    end

    return bestPed
end

local function RiversideGetAimedEmployee(playerId, playerPed, location)
    if not IsPedArmed(playerPed, 4) or not IsPlayerFreeAiming(playerId) then return nil end

    local aiming, entity = GetEntityPlayerIsFreeAimingAt(playerId)
    if aiming and RiversideValidEmployeePed(entity, playerPed, location) then
        return entity
    end

    -- Fallback: il vetro del bancone puo' bloccare il rilevamento nativo.
    return RiversideFindEmployeeInAimCone(playerPed, location)
end

local function RiversideRequestPedControl(ped)
    if not NetworkGetEntityIsNetworked(ped) or NetworkHasControlOfEntity(ped) then return end
    NetworkRequestControlOfEntity(ped)
    local timeout = GetGameTimer() + 750
    while not NetworkHasControlOfEntity(ped) and GetGameTimer() < timeout do
        Wait(0)
        NetworkRequestControlOfEntity(ped)
    end
end

local function RiversideGuideToFusebox(location)
    local bank = Config.Fleecas and Config.Fleecas[location]
    local interaction = bank and bank.Interactions and bank.Interactions.Fusebox
    local coords = interaction and (interaction.drawtext or interaction.coords)
    if not coords then
        lib.notify({
            title = 'Rapina Fleeca',
            description = 'Rapina avviata: cerca il quadro elettrico esterno della banca.',
            type = 'inform',
            duration = 15000
        })
        return
    end

    RiversideClearStartBlip()
    local token = riversideStartBlipToken

    riversideStartBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(riversideStartBlip, 354)
    SetBlipColour(riversideStartBlip, 1)
    SetBlipScale(riversideStartBlip, 0.80)
    SetBlipAsShortRange(riversideStartBlip, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Quadro elettrico Fleeca')
    EndTextCommandSetBlipName(riversideStartBlip)
    SetBlipRoute(riversideStartBlip, true)
    SetBlipRouteColour(riversideStartBlip, 1)
    SetNewWaypoint(coords.x, coords.y)

    lib.notify({
        title = 'Impiegato intimidito',
        description = 'Rapina avviata. Raggiungi il quadro elettrico segnato sul GPS e taglia i fili.',
        type = 'success',
        duration = 15000
    })

    CreateThread(function()
        local timeout = GetGameTimer() + ((Config.IntuitiveStart.GuideDuration or 90) * 1000)
        while token == riversideStartBlipToken and riversideStartBlip and DoesBlipExist(riversideStartBlip) do
            Wait(500)
            if #(GetEntityCoords(PlayerPedId()) - coords) <= 2.2 or GetGameTimer() >= timeout then
                RiversideClearStartBlip()
                break
            end
        end
    end)
end

local function RiversideScareEmployee(location, ped)
    if riversideBankPedTriggered[location] or not DoesEntityExist(ped) then return end

    riversideBankPedTriggered[location] = true
    riversideBankPedAimStarted[location] = nil

    local playerPed = PlayerPedId()
    RiversideRequestPedControl(ped)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedFleeAttributes(ped, 0, false)
    SetPedCombatAttributes(ped, 17, true)
    SetPedCanRagdoll(ped, false)
    ClearPedTasksImmediately(ped)
    TaskTurnPedToFaceEntity(ped, playerPed, 500)
    Wait(450)
    TaskHandsUp(ped, 7000, playerPed, -1, true)
    PlayAmbientSpeech1(ped, 'GENERIC_FRIGHTENED_HIGH', 'SPEECH_PARAMS_FORCE')

    RiversideGuideToFusebox(location)

    CreateThread(function()
        Wait(7000)
        if DoesEntityExist(ped) then TaskCower(ped, -1) end
    end)
end

CreateThread(function()
    Wait(1500)
    while true do
        local sleep = 500
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local playerId = PlayerId()
        local location = nil

        if Config.IntuitiveStart and Config.IntuitiveStart.Enabled then
            location = RiversideCurrentFleeca(playerCoords)
        end

        if location and not riversideBankPedTriggered[location] then
            sleep = 0

            -- Notifica introduttiva disattivata: entrando in banca non viene più mostrato
            -- il messaggio "Per iniziare la rapina...". La logica di avvio resta invariata.
            if not riversideBankPedHintShown[location] then
                riversideBankPedHintShown[location] = true
            end

            local aimedPed = RiversideGetAimedEmployee(playerId, playerPed, location)
            if aimedPed then
                if not riversideBankPedAimStarted[location] or riversideBankPedAimStarted[location].ped ~= aimedPed then
                    riversideBankPedAimStarted[location] = { ped = aimedPed, started = GetGameTimer() }
                elseif GetGameTimer() - riversideBankPedAimStarted[location].started >= (Config.IntuitiveStart.AimHoldTime or 850) then
                    RiversideScareEmployee(location, aimedPed)
                end
            else
                riversideBankPedAimStarted[location] = nil
            end
        else
            for bankName in pairs(riversideBankPedHintShown) do
                if bankName ~= location and not riversideBankPedTriggered[bankName] then
                    riversideBankPedHintShown[bankName] = nil
                    riversideBankPedAimStarted[bankName] = nil
                end
            end
        end

        Wait(sleep)
    end
end)

-- ============================================================
-- GUIDA PROGRESSIONE RIVERSIDE
-- SOLO guida visiva: non modifica stati, requisiti, item, puzzle,
-- minigame, porte o logica della rapina ProjectX.
-- ============================================================

local riversideFleecaGuideBlip = nil
local riversideFleecaJailDoorCount = {}

local function RiversideClearFleecaGuide()
    if riversideFleecaGuideBlip and DoesBlipExist(riversideFleecaGuideBlip) then
        SetBlipRoute(riversideFleecaGuideBlip, false)
        RemoveBlip(riversideFleecaGuideBlip)
    end
    riversideFleecaGuideBlip = nil
end

local function RiversideGuideNotify(title, description, notifyType, duration)
    lib.notify({
        title = title or 'Rapina Fleeca',
        description = description or 'Segui il prossimo obiettivo indicato sul GPS.',
        type = notifyType or 'inform',
        duration = duration or 15000
    })
end

local function RiversideSetGuidePoint(location, interactionName, title, description)
    local bank = Config.Fleecas and Config.Fleecas[location]
    local interaction = bank and bank.Interactions and bank.Interactions[interactionName]
    if not interaction then
        RiversideGuideNotify(title, description, 'inform', 15000)
        return
    end

    local coords = interaction.drawtext or interaction.coords
    if not coords then
        RiversideGuideNotify(title, description, 'inform', 15000)
        return
    end

    RiversideClearFleecaGuide()

    riversideFleecaGuideBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(riversideFleecaGuideBlip, 1)
    SetBlipColour(riversideFleecaGuideBlip, 1)
    SetBlipScale(riversideFleecaGuideBlip, 0.75)
    SetBlipAsShortRange(riversideFleecaGuideBlip, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(title or 'Obiettivo rapina Fleeca')
    EndTextCommandSetBlipName(riversideFleecaGuideBlip)
    SetBlipRoute(riversideFleecaGuideBlip, true)
    SetBlipRouteColour(riversideFleecaGuideBlip, 1)
    SetNewWaypoint(coords.x, coords.y)

    RiversideGuideNotify(title, description, 'inform', 15000)
end

local function RiversideSetLootGuide(location)
    local trolley = Config.Trollys and Config.Trollys[location] and Config.Trollys[location][1]
    if not trolley then
        RiversideGuideNotify('Caveau aperto', 'Entra nel caveau e raccogli il bottino.', 'success', 15000)
        return
    end

    local coords = trolley.drawtext or trolley.coords
    if not coords then return end

    RiversideClearFleecaGuide()

    riversideFleecaGuideBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(riversideFleecaGuideBlip, 500)
    SetBlipColour(riversideFleecaGuideBlip, 2)
    SetBlipScale(riversideFleecaGuideBlip, 0.80)
    SetBlipAsShortRange(riversideFleecaGuideBlip, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Bottino Fleeca')
    EndTextCommandSetBlipName(riversideFleecaGuideBlip)
    SetBlipRoute(riversideFleecaGuideBlip, true)
    SetBlipRouteColour(riversideFleecaGuideBlip, 2)
    SetNewWaypoint(coords.x, coords.y)

    RiversideGuideNotify(
        'Caveau aperto',
        'I cancelli sono aperti. Entra nel caveau e raccogli il bottino. Assicurati di avere una borsa per raccoglierlo.',
        'success',
        15000
    )
end

RegisterNetEvent('riverside:fleeca:guideStep', function(location, step)
    if not location or not step then return end

    if step == 'Fusebox' then
        RiversideSetGuidePoint(location, 'Fingerprint', 'Sistema infiltrato', 'Ora raggiungi lo scanner e falsifica l’impronta digitale.')

    elseif step == 'Fingerprint' then
        RiversideSetGuidePoint(location, 'KeypadOne', 'Impronta acquisita', 'Raggiungi il tastierino interno e disabilitalo.')

    elseif step == 'KeypadOne' then
        if Config.DisableEmployeePuzzle then
            RiversideSetGuidePoint(location, 'ElectricBox', 'Accesso interno', 'Il puzzle dei dipendenti e disattivato. Raggiungi il fusibile del caveau per proseguire.')
        else
            RiversideSetGuidePoint(location, 'Printer', 'Accesso interno', 'Vai alla stampante e stampa le foto dei dipendenti.')
        end

    elseif step == 'Printer' then
        RiversideSetGuidePoint(
            location,
            'Board',
            'Foto stampate',
            'Controlla l’elenco dipendenti. Poi cerca tra i documenti sugli scaffali per ricavare il dato nascosto necessario al caveau.'
        )

    elseif step == 'Shelf1' or step == 'Shelf2' or step == 'Shelf3' or step == 'Shelf' then
        RiversideSetGuidePoint(
            location,
            'ElectricBox',
            'Documenti controllati',
            'Se hai trovato l’informazione utile, raggiungi il fusibile del caveau e abbassa il livello di sicurezza.'
        )

    elseif step == 'ElectricBox' then
        RiversideSetGuidePoint(
            location,
            'Vault',
            'Sicurezza caveau abbassata',
            'Raggiungi il lettore del caveau e completa lo stesso gioco delle impronte dello scanner.'
        )

    elseif step == 'Vault' then
        riversideFleecaJailDoorCount[location] = 0
        RiversideSetGuidePoint(location, 'JailDoorLeft', 'Caveau sbloccato', 'Sblocca il primo cancello interno.')

    elseif step == 'JailDoorLeft' then
        riversideFleecaJailDoorCount[location] = 1
        RiversideSetGuidePoint(location, 'JailDoorRight', 'Primo cancello aperto', 'Sblocca anche il secondo cancello interno.')

    elseif step == 'JailDoorRight' then
        riversideFleecaJailDoorCount[location] = 2
        RiversideSetLootGuide(location)

    elseif step == 'JailDoor' then
        riversideFleecaJailDoorCount[location] = (riversideFleecaJailDoorCount[location] or 0) + 1
        if riversideFleecaJailDoorCount[location] >= 2 then
            RiversideSetLootGuide(location)
        else
            RiversideSetGuidePoint(location, 'JailDoorRight', 'Primo cancello aperto', 'Rimane un altro cancello da sbloccare.')
        end
    end
end)

RegisterNetEvent('riverside:fleeca:resetGuide', function(location)
    if location then
        riversideFleecaJailDoorCount[location] = nil
        riversideBankPedTriggered[location] = nil
        riversideBankPedHintShown[location] = nil
        riversideBankPedAimStarted[location] = nil
    end
    RiversideClearStartBlip()
    RiversideClearFleecaGuide()
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    RiversideClearFleecaGuide()
end)


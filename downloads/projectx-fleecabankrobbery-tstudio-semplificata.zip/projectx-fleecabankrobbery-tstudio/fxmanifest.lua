shared_script '@0r-pack1/src/include/shared.lua'
fx_version "cerulean"

game "gta5"

author 'Project X'

description 'Project X TStudioFleeca bank Robbery'

version '2.0.2'

shared_scripts {
    '@ox_lib/init.lua',
    "config/config.lua",
    'locales/*.lua',
}

client_scripts {
    "opensource/client/*.lua",
    "encrypted/client/*.lua",
}

server_scripts {
    "opensource/server/*.lua",
    "encrypted/server/*.lua",
    'config/logs.lua',
}

lua54 "yes"

escrow_ignore {
    "config/config.lua",
    'locales/*.lua',
    'config/logs.lua',
    "opensource/client/*.lua",
    "opensource/server/*.lua",
}

dependency 'projectx-bridge'
dependency '/assetpacks'

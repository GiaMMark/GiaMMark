Config = Config or {}
Loc = {}
-- //////////////////////////////////////////////////
-- ///////////////// Our Discord ////////////////////
-- //////// https://discord.gg/bJNxYDAm5u ///////////
-- //////////////////////////////////////////////////
Config = {
    debug = false, -- Shows polyzones created inside the game
    Lan = 'it', -- Riverside: forza tutta la risorsa in italiano
    TestingMode = false, -- Enable/Disable Testing Mode (No Minigames)
    Dispatch = {
        -- If you wish to change the text and other data on the dispatch you can do it here, not all dispatch systems support everything below:
        Title = 'Rapina alla Fleeca Bank',
        Message = 'Rapina alla Fleeca Bank in corso',
        Code = '10-70',
        Time = 5, -- Time in seconds that the alert will appear for, most dispatch systems dont support this
        Blip = {
            Text = 'Rapina alla Fleeca Bank',
            Color = 1,
            Sprite = 41,
            Scale = 0.8
        }
    },
    -- Drawtext Options
    DrawtextButton = 38, -- [E] by default
    DrawTextZoneSize = vec3(0.8, 0.8, 2), -- Size of the drawtext zone
    Cooldown = {
        Global = true, -- Global cooldown (Set to false to have individual cooldowns on stores, true to have cooldowns on all stores when one is robbed)
        Timer = 180, -- (Minutes) timer duration
        PlayerCooldown = 0, -- (Minutes) Cooldown for a player after doing a robbery, set to 0 to disable
    },
    Limits = {
        TotalRobberiesPerRestart = 0, -- Maximum robberies that can be done in one server restart for shooting ranges, set to 0 to disable the limit (not per player).
        RobberiesPerPlayer = 0, -- Maximum robberies that a player can do in a single restart, set to 0 to disable the limit.
    },
    TotalActiveRobberies = 0, -- Maximum active robberies that can be done at the same time (If the cooldown allows it), set to 0 to disable the limit.
    SpawnNetworkedPropsServerSide = true, -- Spawn the networked props server side, if false the networked props will be spawned client side
    PoliceJobs = {"police"}, -- Jobs that can receive the dispatch, to add more follow this format: {"police", "fbi"}
    MinimumPolice = 4, -- Minimum police required to start the robbery
    RequiredPlayersNearby = {amount = 0, radius = 20.0}, -- Minimum players required nearby to start the robbery, set amount to 0 to disable it
    RequireBag = true, -- If you want to require a bag to rob crates
    ListLength = 12, -- Riverside FIX: lista corta per evitare il bug dello scroll del pannello
    DisableEmployeePuzzle = true, -- Puzzle dipendenti disattivato: accesso semplificato
    DisableParticles = false, -- Disable particles for the heist
    DisableRemovingWeapons = false, -- (only turn this on if you have a weapon wheel) Disable the removal of weapons while doing the robbery&#x20;
    GruppeSechsJob17mov = false, -- Enable/Disable GruppeSechs Job Compatibility by 17mov
    DisableLoudApproach = false, -- Disable loud approach
    DisableSilentApproach = false, -- Disable silent approach
    -- Strike System (Silent = High risk, Higher reward, Loud = No risk, Fixed reward)
    TotalTrolleys = 3, -- Total maximum amount of trolleys that could spawn, they spawn depending on the settings below
    Strikes = false, -- How many strikes players have to reach before having their reward cut (Set to false to disable the strike system)
    StrikeAmount = 2, -- (Silent Approach ONLY) How many trollys will be removed if they reach the strike limit
    StrikeLoud = 3, -- (Loud Approach ONLY) How many trollys will spawn (preferably less than TotalTrolleys by 1, to give them insentive to do the loud approach aswell)
    -- Progression item (Item that can be obtained at the end of the heist, can be used for the next heist)&#x20;
    Bonus = {
        Status = false, -- Enable/Disable Bonus items
        BonusChance = 15, -- Chance of an item being given
        ItemCount = 1, -- How many items can be given from the table below
        Items = { -- You can remove items and add items as you wish
            {Name = "x_device", Chance = 30, Amount = {min = 1, max = 1}}, -- Chance(%) -- Amount(Items given from that type)
            {Name = "x_phone", Chance = 50, Amount = {min = 1, max = 1}},
            {Name = "x_stethoscope", Chance = 20, Amount = {min = 1, max = 1}},
        },
    },
    -- Skill System
    SkillSystem = false, -- If want to use a skill system to initiate the heist set this to true
    MinimumLevel = 10, -- Minimum level required to start the heist
    -- Evidence and Stress Systems
    Evidence = {
        ["Status"] = true, -- Choose whether you want to have evidence dropped on the crime scene
        ["Chance"] = 50, -- Chance of fingerprints on the crime scene
    },
    Stress = { -- Stress gets applied on minigames failing only
        ["Status"] = true, -- Choose whether you want to have stress system
        ["Chance"] = 90, -- Chance of stress on the crime scene
        ["Amount"] = {min = 1, max = 3}, -- Amount of stress applied
    },
    Inputs = { -- All the ox_lib Input texts
        ["SecretCombination"] = {Title = 'Password nascosta', Label = 'Password', Description = 'Inserisci la password di accesso', Icon = 'fas fa-lock'},
    },
    DispatchLocation = { -- Choose where the alarm gets triggered, only one should be picked, not including ["Loud"] and ["Silent"]
        ["Loud"] = true, -- Enable/Disable dispatch on initiating the loud approach
        ["Silent"] = false, -- Enable/Disable dispatch on initiating the silent approach
        -------
        ["KeypadOne"] = true,
        ["ElectricBox"] = false,
        ["Vault"] = false,
    },
    -- Durations&#x20;
    NotificationDuration = 10000, -- Riverside: notifiche visibili per 10 secondi
    FingerprintDuration = 6000, -- Duration of the fingerprint progressbar
    FuseboxDuration = 6000, -- Duration of the fusebox progressbar
    ShelfDuration = 5000, -- Duration of the shelf progressbar
    KeypadOneDuration = 6000, -- Duration of the keypad progressbar
    SearchDuration = 6000, -- Duration of the search progressbar
    ElectricBoxDuration = 7500, -- Duration of the electricbox progressbar
    PrinterDuration = 7500, -- Duration of the printer progressbar
    VaultDuration = 6000, -- Duration of the vault progressbar
    JailDoorDuration = 5000, -- Duration of the jaildoor progressbar
}
Config.Items ={
    ["Device"] = "x_device",
    ["Pliers"] = "pliers",
    ["Pictures"] = "employeepictures",
    ["Bag"] = "backpack1",
    ["Keycard"] = "fleecacard",
    ["Laptop"] = "x_laptop",
}
Config.ItemsBreak = {
    ["Device"] = 0, -- % chance of breaking
    ["Pliers"] = 0, -- % chance of breaking
    ["Laptop"] = 0, -- % chance of breaking
}
Config.FleecaLocations = { -- Enable/Disable Fleeca locations here
    ["RockfordHills"] = true,
    ["Legion"] = true,
    ["Burton"] = true,
    ["Alta"] = true,
    ["GrandSenoraDesert"] = true,
    ["BanhamCanyon"] = true,
}
-- RIVERSIDE: avvio intuitivo tramite l'impiegato gia' presente nella banca.
-- Non spawna NPC aggiuntivi: usa il ped non-player che il rapinatore sta mirando.
Config.IntuitiveStart = {
    Enabled = true,
    AimHoldTime = 850,          -- ms di mira necessari per intimidire il dipendente
    GuideDuration = 90,         -- secondi massimi del GPS verso il primo obiettivo
    MaxPedDistance = 8.0,       -- distanza massima dal dipendente
    AimConeDot = 0.975,         -- permette il rilevamento anche attraverso il vetro del bancone
    RequireStationaryPed = true -- evita di attivarlo su ped che stanno passando
}
-- Fleeca: 3 carrelli x 50000 dirty_money = 150000 complessivi.
-- Attenzione: dirty_money deve essere un item valido nell'inventario e il codice
-- server deve assegnare StackAmount come quantita' dell'item, senza moltiplicatori.
Config.TableRewardcash = {
    ['Cash'] = false,
    ['Item'] = "dirty_money",
    ['StackAmount'] = {min = 0, max = 0}, -- nessun bonus extra dal tavolo
    ['ItemInfo'] = false,
}
Config.Rewardcash = {
    ["ObtainPerPickup"] = false, -- ricompensa unica al termine di ogni carrello
    ['Cash'] = false,
    ['Item'] = "dirty_money",
    ['StackAmount'] = {min = 50000, max = 50000},
    ['ItemInfo'] = false,
}
Config.Rewardgold = {
    ["ObtainPerPickup"] = false, -- Obtain the specified items below per gold bar pickup from the trolley, false - Obtain the item/cash specified below at the end of the trolley animation
    ['Cash'] = false, -- Set this to false to use a cash "item", or true to use cash
    ['Item'] = "goldbar", -- Item you want to use for cash (['Cash'] = false)
    ['StackAmount'] = {min = 3, max = 5}, -- Cash that is recieved from each cash stack, if you have ["ObtainPerPickup"] set to false, this will be the amount of gold bars you recieve at the end of the trolley animation
    ['ItemInfo'] = false, -- Item info for the cash item, this is used if you have markedbills that has random amount of money in info
}
Config.Rewarddiamond = {
    ["ObtainPerPickup"] = true, -- Obtain the specified items below per diamond box pickup from the trolley, false - Obtain the item/cash specified below at the end of the trolley animation
    ['Cash'] = false, -- Set this to false to use a cash "item", or true to use cash
    ['Item'] = "diamond", -- Item you want to use for cash (['Cash'] = false)
    ['StackAmount'] = {min = 1, max = 1}, -- Cash that is recieved from each cash stack, if you have ["ObtainPerPickup"] set to false, this will be the amount of diamonds you recieve at the end of the trolley animation
    ['ItemInfo'] = false, -- Item info for the cash item, this is used if you have markedbills that has random amount of money in info
}
Config.LootTables = {
    ["RockfordHills"] = {
        {
            coords = vector3(-1212.48, -341.86, 37.63),
            drawtext = vector3(-1211.82, -341.48, 37.78),
            heading = 293.83,
            icon = 'fas fa-coins',
            distance = 1.5, -- Target Distance
            size = 0.5, -- Circle Zone size
        },
    },
    ["Legion"] = {
        {
            coords = vector3(141.94, -1048.51, 29.22),
            drawtext = vector3(142.51, -1048.67, 29.37),
            heading = 254.43,
            icon = 'fas fa-coins',
            distance = 1.5, -- Target Distance
            size = 0.5, -- Circle Zone size
        },
    },
    ["Burton"] = {
        {
            coords = vector3(-358.76, -57.79, 48.89),
            drawtext = vector3(-357.94, -58.13, 49.04),
            heading = 250.65,
            icon = 'fas fa-coins',
            distance = 1.5, -- Target Distance
            size = 0.5, -- Circle Zone size
        },
    },
    ["Alta"] = {
        {
            coords = vector3(306.31, -286.88, 54.02),
            drawtext = vector3(306.91, -287.01, 54.16),
            heading = 251.26,
            icon = 'fas fa-coins',
            distance = 1.5, -- Target Distance
            size = 0.5, -- Circle Zone size
        },
    },
    ["GrandSenoraDesert"] = {
        {
            coords = vector3(1179.81, 2716.82, 37.94),
            drawtext = vector3(1179.25, 2716.81, 38.09),
            heading = 91.59,
            icon = 'fas fa-coins',
            distance = 1.5, -- Target Distance
            size = 0.5, -- Circle Zone size
        },
    },
    ["BanhamCanyon"] = {
        {
            coords = vector3(-2952.77, 477.67, 15.6),
            drawtext = vector3(-2952.75, 478.38, 15.7),
            heading = 358.21,
            icon = 'fas fa-coins',
            distance = 1.5, -- Target Distance
            size = 0.5, -- Circle Zone size
        },
    },
}
Config.Trollys = {
    ["RockfordHills"] = {
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-1205.74, -337.59, 36.78),
            drawtext = vector3(-1206.17, -338.25, 37.78),
            heading = 152.26,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-1205.13, -338.87, 36.78),
            drawtext = vector3(-1205.62, -338.74, 37.78),
            heading =  75.32,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-1213.11, -343.18, 36.78),
            drawtext = vector3(-1212.56, -342.94, 37.78),
            heading = 295.62,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-1213.82, -341.61, 36.78),
            drawtext = vector3(-1213.36, -341.39, 37.78),
            heading = 297.9,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
    },
    ["Legion"] = {
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(149.61, -1050.4, 28.37),
            drawtext = vector3(149.2, -1050.51, 29.37),
            heading = 105.26,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(149.02, -1051.85, 28.37),
            drawtext = vector3(148.77, -1051.17, 29.36),
            heading = 30.02,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(140.46, -1048.97, 28.37),
            drawtext = vector3(140.96, -1049.14, 29.37),
            heading = 249.07,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(141.22, -1047.22, 28.37),
            drawtext = vector3(141.65, -1047.43, 29.37),
            heading =  248.78,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
    },
    ["Burton"] = {
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-351.0, -59.51, 48.04),
            drawtext = vector3(-351.35, -59.61, 49.04),
            heading = 107.99,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-352.57, -59.02, 48.04),
            drawtext = vector3(-352.62, -59.49, 49.04),
            heading = 175.25,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-360.19, -58.24, 48.04),
            drawtext = vector3(-359.85, -58.34, 49.04),
            heading = 251.45,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-359.63, -56.5, 48.04),
            drawtext = vector3(-359.17, -56.64, 49.04),
            heading = 248.21,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
    },
    ["Alta"] = {
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(314.13, -288.69, 53.16),
            drawtext = vector3(313.61, -288.79, 54.16),
            heading = 108.41,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(312.43, -288.18, 53.16),
            drawtext = vector3(312.45, -288.84, 54.16),
            heading = 180.27,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(304.85, -287.3, 53.16),
            drawtext = vector3(305.25, -287.49, 54.16),
            heading = 253.59,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(305.41, -285.58, 53.16),
            drawtext = vector3(305.75, -285.74, 54.16),
            heading = 250.36,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
    },
    ["GrandSenoraDesert"] = {
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(1171.92, 2715.93, 37.09),
            drawtext = vector3(1172.2, 2716.09, 38.09),
            heading = 303.55,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(1173.65, 2715.84, 37.09),
            drawtext = vector3(1173.55, 2716.19, 38.09),
            heading = 12.28,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(1181.03, 2717.66, 37.09),
            drawtext = vector3(1180.58, 2717.69, 38.09),
            heading = 88.6,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(1181.09, 2716.0, 37.09),
            drawtext = vector3(1180.69, 2715.98, 38.09),
            heading = 95.4,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
    },
    ["BanhamCanyon"] = {
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-2953.36, 485.77, 14.7),
            drawtext = vector3(-2953.09, 485.32, 15.7),
            heading = 214.78,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-2951.48, 485.73, 14.7),
            drawtext = vector3(-2951.77, 485.43, 15.7),
            heading = 138.97,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-2951.96, 476.4, 14.7),
            drawtext = vector3(-2951.95, 476.9, 15.7),
            heading = 356.62,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
        {
            type = "cash", -- Type of loot (cash/gold/diamond)
            coords = vector3(-2953.66, 476.53, 14.7),
            drawtext = vector3(-2953.75, 476.94, 15.7),
            heading = 355.81,
            icon = 'fas fa-dollar-sign', -- Icon
            distance = 1.0, -- Target distance
            size = 0.5, -- Target size
        },
    },
}
Config.Fleecas = {
    ["RockfordHills"] = {
        ["Reset"] = 120, -- (Minutes) Resets the bank
        ["AlarmCoords"] = vector3(-1218.73, -329.83, 40.09),
        ["VaultDoorLeft"] = vector3(-1209.38, -338.02, 36.78), -- Vault Door Left
        ["VaultDoorRight"] = vector3(-1211.08, -338.9, 36.78), -- Vault Door Right
        ["JailDoorLeft"] = vector3(-1207.47, -339.34, 36.78), -- Jail Door Left
        ["JailDoorRight"] = vector3(-1211.14, -341.21, 36.78), -- Jail Door Right
        ["OnCooldown"] = false,
        ["DrawTextRotation"] = -60.0, -- Rotation of the drawtext
        Interactions = {
            ["Fusebox"] = {
                label = "Taglia i fili", -- Text that appears when you target
                coords = vector3(-1217.27, -332.98, 42.13), -- Circle Zone Coords
                drawtext = vector3(-1216.89, -332.87, 42.12),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Fingerprint"] = {
                label = "Falsifica impronta", -- Text that appears when you target
                coords = vector3(-1209.42, -333.87, 38.17), -- Circle Zone Coords
                drawtext = vector3(-1209.64, -333.5, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-fingerprint", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["KeypadOne"] = {
                label = "Disattiva tastierino", -- Text that appears when you target
                coords = vector3(-1208.58, -336.64, 38.17), -- Circle Zone Coords
                drawtext = vector3(-1208.2, -336.35, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Printer"] = {
                label = "Stampa foto dipendenti", -- Text that appears when you target
                coords = vector3(-1213.73, -337.18, 37.91), -- Circle Zone Coords
                drawtext = vector3(-1213.51, -337.61, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-print", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Board"] = {
                label = "Elenco dipendenti", -- Text that appears when you target
                coords = vector3(-1214.55, -339.79, 37.97), -- Circle Zone Coords
                drawtext = vector3(-1214.85, -339.16, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-paperclip", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Shelf1"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-1215.48, -335.02, 37.82), -- Circle Zone Coords
                drawtext = vector3(-1215.73, -335.52, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf2"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-1216.41, -333.18, 37.82), -- Circle Zone Coords
                drawtext = vector3(-1216.51, -333.80, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf3"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-1217.34, -331.33, 37.82), -- Circle Zone Coords
                drawtext = vector3(-1217.55, -331.88, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["ElectricBox"] = {
                label = "Disattiva fusibile caveau", -- Text that appears when you target
                coords = vector3(-1207.97, -336.70, 37.93), -- Circle Zone Coords
                drawtext = vector3(-1208.21, -336.29, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Vault"] = {
                label = "Scansiona impronta caveau", -- Text that appears when you target
                coords = vector3(-1211.83, -338.80, 38.11), -- Circle Zone Coords
                drawtext = vector3(-1212.01, -338.2, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorLeft"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(-1207.76, -339.12, 38.17), -- Circle Zone Coords
                drawtext = vector3(-1208.14, -339.27, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorRight"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(-1211.14, -340.86, 38.17), -- Circle Zone Coords
                drawtext = vector3(-1210.55, -340.6, 37.78),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
        },
        ["Zone"] = {vector3(-1211.42, -315.51, 37.74), vector3(-1228.35, -323.95, 37.74), vector3(-1216.77, -346.8, 37.74), vector3(-1200.45, -336.72, 37.74)},
    },
    ["Legion"] = {
        ["Reset"] = 120, -- (Minutes) Resets the bank
        ["AlarmCoords"] = vector3(148.76, -1036.29, 32.14),
        ["VaultDoorLeft"] = vector3(146.75, -1048.11, 28.37), -- Vault Door Left
        ["VaultDoorRight"] = vector3(144.96, -1047.45, 28.37), -- Vault Door Right
        ["JailDoorLeft"] = vector3(147.09, -1050.4, 28.37), -- Jail Door Left
        ["JailDoorRight"] = vector3(143.22, -1048.98, 28.37), -- Jail Door Right
        ["OnCooldown"] = false,
        ["DrawTextRotation"] = -110.0, -- Rotation of the drawtext
        Interactions = {
            ["Fusebox"] = {
                label = "Taglia i fili", -- Text that appears when you target
                coords = vector3(135.64, -1046.56, 29.84), -- Circle Zone Coords
                drawtext = vector3(135.41, -1046.76, 29.33),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Fingerprint"] = {
                label = "Falsifica impronta", -- Text that appears when you target
                coords = vector3(149.75, -1045.24, 29.70), -- Circle Zone Coords
                drawtext = vector3(149.95, -1044.74, 29.37),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-fingerprint", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["KeypadOne"] = {
                label = "Disattiva tastierino", -- Text that appears when you target
                coords = vector3(148.32, -1047.72, 29.78), -- Circle Zone Coords
                drawtext = vector3(148.8, -1047.8, 29.37),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Printer"] = {
                label = "Stampa foto dipendenti", -- Text that appears when you target
                coords = vector3(144.37, -1044.32, 29.50), -- Circle Zone Coords
                drawtext = vector3(144.24, -1044.73, 29.36),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-print", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Board"] = {
                label = "Elenco dipendenti", -- Text that appears when you target
                coords = vector3(141.92, -1045.53, 29.56), -- Circle Zone Coords
                drawtext = vector3(142.09, -1044.90, 29.36),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-paperclip", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Shelf1"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(144.83, -1041.56, 29.41), -- Circle Zone Coords
                drawtext = vector3(144.28, -1041.83, 29.36),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf2"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(145.52, -1039.66, 29.41), -- Circle Zone Coords
                drawtext = vector3(144.99, -1040.00, 29.36),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf3"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(146.22, -1037.73, 29.41), -- Circle Zone Coords
                drawtext = vector3(145.72, -1038.02, 29.36),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["ElectricBox"] = {
                label = "Disattiva fusibile caveau", -- Text that appears when you target
                coords = vector3(148.69, -1048.24, 29.55), -- Circle Zone Coords
                drawtext = vector3(148.8, -1047.8, 29.37),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Vault"] = {
                label = "Scansiona impronta caveau", -- Text that appears when you target
                coords = vector3(144.50, -1046.83, 29.72), -- Circle Zone Coords
                drawtext = vector3(144.67, -1046.28, 29.37),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorLeft"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(147.05, -1050.04, 29.74), -- Circle Zone Coords
                drawtext = vector3(146.6, -1049.85, 29.37),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorRight"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(143.47, -1048.76, 29.76), -- Circle Zone Coords
                drawtext = vector3(144.0, -1048.87, 29.37),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
        },
        ["Zone"] = {vector3(156.71, -1033.39, 29.26), vector3(149.98, -1052.85, 29.26), vector3(131.86, -1050.59, 29.26), vector3(140.1, -1027.78, 29.26)},
    },
    ["Burton"] = {
        ["Reset"] = 120, -- (Minutes) Resets the bank
        ["AlarmCoords"] = vector3(-353.73, -42.97, 52.5),
        ["VaultDoorLeft"] = vector3(-353.94, -57.34, 48.04), -- Vault Door Left
        ["VaultDoorRight"] = vector3(-355.75, -56.71, 48.04), -- Vault Door Right
        ["JailDoorLeft"] = vector3(-353.57, -59.62, 48.04), -- Jail Door Left
        ["JailDoorRight"] = vector3(-357.46, -58.27, 48.04), -- Jail Door Right
        ["OnCooldown"] = false,
        ["DrawTextRotation"] = -110.0, -- Rotation of the drawtext
        Interactions = {
            ["Fusebox"] = {
                label = "Taglia i fili", -- Text that appears when you target
                coords = vector3(-365.26, -71.52, 45.69), -- Circle Zone Coords
                drawtext = vector3(-365.39, -71.92, 45.66),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Fingerprint"] = {
                label = "Falsifica impronta", -- Text that appears when you target
                coords = vector3(-350.98, -54.43, 49.38), -- Circle Zone Coords
                drawtext = vector3(-350.81, -53.87, 49.04),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-fingerprint", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["KeypadOne"] = {
                label = "Disattiva tastierino", -- Text that appears when you target
                coords = vector3(-352.37, -56.90, 49.43), -- Circle Zone Coords
                drawtext = vector3(-351.86, -56.95, 49.04),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Printer"] = {
                label = "Stampa foto dipendenti", -- Text that appears when you target
                coords = vector3(-356.39, -53.61, 49.17), -- Circle Zone Coords
                drawtext = vector3(-356.50, -54.06, 49.03),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-print", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Board"] = {
                label = "Elenco dipendenti", -- Text that appears when you target
                coords = vector3(-358.79, -54.78, 49.22), -- Circle Zone Coords
                drawtext = vector3(-358.63, -54.17, 49.03),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-paperclip", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Shelf1"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-355.99, -50.84, 49.07), -- Circle Zone Coords
                drawtext = vector3(-356.52, -51.09, 49.03),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf2"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-355.32, -48.92, 49.07), -- Circle Zone Coords
                drawtext = vector3(-355.84, -49.27, 49.03),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf3"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-354.64, -46.98, 49.07), -- Circle Zone Coords
                drawtext = vector3(-355.20, -47.18, 49.03),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["ElectricBox"] = {
                label = "Disattiva fusibile caveau", -- Text that appears when you target
                coords = vector3(-352.02, -57.43, 49.23), -- Circle Zone Coords
                drawtext = vector3(-351.86, -56.95, 49.04),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Vault"] = {
                label = "Scansiona impronta caveau", -- Text that appears when you target
                coords = vector3(-356.22, -56.10, 49.41), -- Circle Zone Coords
                drawtext = vector3(-356.12, -55.68, 49.04),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorLeft"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(-353.62, -59.29, 49.44), -- Circle Zone Coords
                drawtext = vector3(-354.01, -59.07, 49.04),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorRight"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(-357.21, -58.02, 49.43), -- Circle Zone Coords
                drawtext = vector3(-356.65, -58.25, 49.04),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
        },
        ["Zone"] = {vector3(-355.27, -38.79, 49.02), vector3(-343.72, -43.26, 49.02), vector3(-357.65, -80.43, 49.02), vector3(-374.09, -72.37, 49.02)},
    },
    ["Alta"] = {
        ["Reset"] = 120, -- (Minutes) Resets the bank
        ["AlarmCoords"] = vector3(318.57, -275.84, 58.7),
        ["VaultDoorLeft"] = vector3(311.08, -286.47, 53.16), -- Vault Door Left
        ["VaultDoorRight"] = vector3(309.29, -285.82, 53.16), -- Vault Door Right
        ["JailDoorLeft"] = vector3(311.42, -288.77, 53.16), -- Jail Door Left
        ["JailDoorRight"] = vector3(307.55, -287.35, 53.16), -- Jail Door Right
        ["OnCooldown"] = false,
        ["DrawTextRotation"] = -110.0, -- Rotation of the drawtext
        Interactions = {
            ["Fusebox"] = {
                label = "Taglia i fili", -- Text that appears when you target
                coords = vector3(258.69, -308.01, 49.76), -- Circle Zone Coords
                drawtext = vector3(258.79, -307.66, 49.65),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Fingerprint"] = {
                label = "Falsifica impronta", -- Text that appears when you target
                coords = vector3(314.10, -283.61, 54.54), -- Circle Zone Coords
                drawtext = vector3(314.32, -283.2, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-fingerprint", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["KeypadOne"] = {
                label = "Disattiva tastierino", -- Text that appears when you target
                coords = vector3(312.66, -286.07, 54.60), -- Circle Zone Coords
                drawtext = vector3(313.15, -286.15, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Printer"] = {
                label = "Stampa foto dipendenti", -- Text that appears when you target
                coords = vector3(308.71, -282.70, 54.30), -- Circle Zone Coords
                drawtext = vector3(308.56, -283.15, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-print", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Board"] = {
                label = "Elenco dipendenti", -- Text that appears when you target
                coords = vector3(306.25, -283.88, 54.35), -- Circle Zone Coords
                drawtext = vector3(306.50, -283.22, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-paperclip", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Shelf1"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(309.15, -279.94, 54.20), -- Circle Zone Coords
                drawtext = vector3(308.61, -280.11, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf2"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(309.84, -278.02, 54.20), -- Circle Zone Coords
                drawtext = vector3(309.33, -278.39, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf3"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(310.57, -276.11, 54.20), -- Circle Zone Coords
                drawtext = vector3(309.99, -276.27, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["ElectricBox"] = {
                label = "Disattiva fusibile caveau", -- Text that appears when you target
                coords = vector3(313.00, -286.60, 54.35), -- Circle Zone Coords
                drawtext = vector3(313.15, -286.15, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Vault"] = {
                label = "Scansiona impronta caveau", -- Text that appears when you target
                coords = vector3(308.84, -285.20, 54.51), -- Circle Zone Coords
                drawtext = vector3(309.02, -284.79, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorLeft"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(311.38, -288.41, 54.55), -- Circle Zone Coords
                drawtext = vector3(310.95, -288.21, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorRight"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(307.80, -287.14, 54.54), -- Circle Zone Coords
                drawtext = vector3(308.35, -287.32, 54.16),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
        },
        ["Zone"] = {vector3(306.58, -265.0, 53.96), vector3(326.7, -272.52, 53.93), vector3(305.96, -324.91, 53.93), vector3(252.51, -307.26, 53.93)},
    },
    ["GrandSenoraDesert"] = {
        ["Reset"] = 120, -- (Minutes) Resets the bank
        ["AlarmCoords"] = vector3(1171.15, 2702.71, 40.67), -- Alarm coords
        ["VaultDoorLeft"] = vector3(1175.45, 2714.81, 37.09), -- Vault Door Left
        ["VaultDoorRight"] = vector3(1177.36, 2714.81, 37.09), -- Vault Door Right
        ["JailDoorLeft"] = vector3(1174.34, 2716.85, 37.09), -- Jail Door Left
        ["JailDoorRight"] = vector3(1178.46, 2716.85, 37.09), -- Jail Door Right
        ["OnCooldown"] = false,
        ["DrawTextRotation"] = -90.0, -- Rotation of the drawtext
        Interactions = {
            ["Fusebox"] = {
                label = "Taglia i fili", -- Text that appears when you target
                coords = vector3(1158.14, 2708.95, 37.98), -- Circle Zone Coords
                drawtext = vector3(1157.68, 2708.98, 37.98),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Fingerprint"] = {
                label = "Falsifica impronta", -- Text that appears when you target
                coords = vector3(1173.62, 2711.09, 38.47), -- Circle Zone Coords
                drawtext = vector3(1173.57, 2710.58, 38.09),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-fingerprint", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["KeypadOne"] = {
                label = "Disattiva tastierino", -- Text that appears when you target
                coords = vector3(1174.11, 2713.89, 38.49), -- Circle Zone Coords
                drawtext = vector3(1173.64, 2713.83, 38.09),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Printer"] = {
                label = "Stampa foto dipendenti", -- Text that appears when you target
                coords = vector3(1178.97, 2712.05, 38.22), -- Circle Zone Coords
                drawtext = vector3(1178.97, 2712.54, 38.08),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-print", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Board"] = {
                label = "Elenco dipendenti", -- Text that appears when you target
                coords = vector3(1180.87, 2714.01, 38.28), -- Circle Zone Coords
                drawtext = vector3(1180.88, 2713.37, 38.08),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-paperclip", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Shelf1"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(1179.50, 2709.35, 38.13), -- Circle Zone Coords
                drawtext = vector3(1179.94, 2709.77, 38.08),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf2"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(1179.51,2707.30,38.13), -- Circle Zone Coords
                drawtext = vector3(1179.87, 2707.82, 38.08),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf3"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(1179.50, 2705.25, 38.13), -- Circle Zone Coords
                drawtext = vector3(1179.94, 2705.55, 38.08),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["ElectricBox"] = {
                label = "Disattiva fusibile caveau", -- Text that appears when you target
                coords = vector3(1173.62, 2714.27, 38.32), -- Circle Zone Coords
                drawtext = vector3(1173.64, 2713.83, 38.09),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Vault"] = {
                label = "Scansiona impronta caveau", -- Text that appears when you target
                coords = vector3(1178.00, 2714.39, 38.44), -- Circle Zone Coords
                drawtext = vector3(1177.99, 2713.84, 38.09),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorLeft"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(1174.50, 2716.53, 38.47), -- Circle Zone Coords
                drawtext = vector3(1175.04, 2716.54, 38.09),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorRight"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(1178.31, 2716.54, 38.47), -- Circle Zone Coords
                drawtext = vector3(1177.67, 2716.54, 38.09),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
        },
        ["Zone"] = {vector3(1181.73, 2698.29, 38.0), vector3(1155.92, 2698.7, 38.0), vector3(1156.3, 2721.58, 38.0), vector3(1181.54, 2721.39, 38.0)},
    },
    ["BanhamCanyon"] = {
        ["Reset"] = 120, -- (Minutes) Resets the bank
        ["AlarmCoords"] = vector3(-2966.54, 480.14, 18.35), -- Alarm coords
        ["VaultDoorLeft"] = vector3(-2954.58, 482.2, 14.7), -- Vault Door Left
        ["VaultDoorRight"] = vector3(-2954.67, 480.28, 14.7), -- Vault Door Right
        ["JailDoorLeft"] = vector3(-2952.5, 483.21, 14.7), -- Jail Door Left
        ["JailDoorRight"] = vector3(-2952.68, 479.09, 14.7), -- Jail Door Right
        ["OnCooldown"] = false,
        ["DrawTextRotation"] = -90.0, -- Rotation of the drawtext
        Interactions = {
            ["Fusebox"] = {
                label = "Taglia i fili", -- Text that appears when you target
                coords = vector3(-2948.08, 481.18, 15.44), -- Circle Zone Coords
                drawtext = vector3(-2947.67, 481.29, 15.44),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Fingerprint"] = {
                label = "Falsifica impronta", -- Text that appears when you target
                coords = vector3(-2958.23, 484.16, 16.08), -- Circle Zone Coords
                drawtext = vector3(-2958.74, 484.2, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-fingerprint", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["KeypadOne"] = {
                label = "Disattiva tastierino", -- Text that appears when you target
                coords = vector3(-2955.44, 483.57, 16.08), -- Circle Zone Coords
                drawtext = vector3(-2955.59, 484.1, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Printer"] = {
                label = "Stampa foto dipendenti", -- Text that appears when you target
                coords = vector3(-2957.59, 478.37, 15.79), -- Circle Zone Coords
                drawtext = vector3(-2957.04, 478.17, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-print", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Board"] = {
                label = "Elenco dipendenti", -- Text that appears when you target
                coords = vector3(-2955.77, 476.85, 15.88), -- Circle Zone Coords
                drawtext = vector3(-2956.19, 476.96, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-paperclip", -- Icon
                size = 0.5, -- Circle Zone size
            },
            ["Shelf1"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-2960.15, 478.32, 15.71), -- Circle Zone Coords
                drawtext = vector3(-2960.02, 477.87, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf2"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-2962.29, 478.40, 15.74), -- Circle Zone Coords
                drawtext = vector3(-2961.77, 478.07, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Shelf3"] = {
                label = "Cerca tra i documenti", -- Text that appears when you target
                coords = vector3(-2964.27, 478.56, 15.74), -- Circle Zone Coords
                drawtext = vector3(-2964.16, 478.05, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-sheet-plastic", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["ElectricBox"] = {
                label = "Disattiva fusibile caveau", -- Text that appears when you target
                coords = vector3(-2955.05, 484.03, 15.91), -- Circle Zone Coords
                drawtext = vector3(-2955.59, 484.1, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-bolt", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["Vault"] = {
                label = "Scansiona impronta caveau", -- Text that appears when you target
                coords = vector3(-2955.12, 479.66, 16.07), -- Circle Zone Coords
                drawtext = vector3(-2955.75, 479.69, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-keyboard", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorLeft"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(-2952.84, 483.07, 16.07), -- Circle Zone Coords
                drawtext = vector3(-2952.79, 482.49, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
            ["JailDoorRight"] = {
                label = "Sblocca cancello", -- Text that appears when you target
                coords = vector3(-2952.97, 479.26, 16.06), -- Circle Zone Coords
                drawtext = vector3(-2952.91, 479.84, 15.7),
                distance = 1.0, -- How far will you be able to interact with it
                icon = "fas fa-lock", -- Icon
                size = 0.3, -- Circle Zone size
            },
        },
        ["Zone"] = {vector3(-2972.54, 490.35, 15.3), vector3(-2942.93, 488.71, 15.3), vector3(-2944.23, 468.44, 15.3), vector3(-2973.19, 469.75, 15.3)},
    },
}
Config.Sounds = {
    ["AlarmDuration"] = 15, -- (Minutes) How long the alarm will last
    ["AudioName"] = "Alarm_Interior", -- Alarm sound name
    ["AudioRef"] = "DLC_H3_FM_FIB_Raid_Sounds", -- Alarm soundset
    ["Range"] = 10.0, -- How far the alarm can be heard
}
Config.PuzzleSettings = {
    ["ShowFirstLetter"] = {
        ["Status"] = true, -- Show the first letter of the hidden word
        ["Replace"] = "?" -- If ["Status"] is false, replace the hidden word with the chosen string
    },
    ["ShowLastLetter"] = {
        ["Status"] = false, -- Show the first letter of the hidden word
        ["Replace"] = "?" -- If ["Status"] is false, replace the hidden word with the chosen string
    },
    ["HideOneClue"] = {
        ["Status"] = true, -- Hide one of the clues
        ["Replace"] = "* **Mancante** *" -- If ["Status"] is false, replace the hidden word with the chosen string
    }
}
Config.Employees = {
    [1] = {first = "Olivia", last = "Roberts", residence = "Hawaii", age = "27"},
    [2] = {first = "Ethan", last = "Parker", residence = "Kentucky", age = "34"},
    [3] = {first = "Sophia", last = "Adams", residence = "Mississippi", age = "45"},
    [4] = {first = "Benjamin", last = "Taylor", residence = "Montana", age = "19"},
    [5] = {first = "Ava", last = "Wright", residence = "SouthDakota", age = "31"},
    [6] = {first = "Liam", last = "Davis", residence = "Arizona", age = "40"},
    [7] = {first = "Emma", last = "Wilson", residence = "Connecticut", age = "22"},
    [8] = {first = "Noah", last = "Martinez", residence = "WestVirginia", age = "29"},
    [9] = {first = "Isabella", last = "Anderson", residence = "Delaware", age = "36"},
    [10] = {first = "Alexander", last = "Nelson", residence = "Maryland", age = "50"},
    [11] = {first = "Mia", last = "Johnson", residence = "Iowa", age = "25"},
    [12] = {first = "Elijah", last = "Garcia", residence = "NewMexico", age = "33"},
}
-------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------
-- |   |   |   |   |   |   |   |   |   |   |    DO NOT TOUCH ANYTHING UNDER THIS LINE  |   |   |   |   |   |   |   |   |   |   |    |
-------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------
Config.DoorList = {
    ["RockfordHills"] = {
            -- First Door
        {
            objYaw = 117.42,
            objCoords = vector3(-1207.92, -333.24, 37.93),
            objHash = 1138019403,
            locked = true,
        },
            -- Second Door
        {
            objYaw = 206.61,
            objCoords = vector3(-1209.52, -335.12, 37.93),
            objHash = 1138019403,
            locked = true,
        },
    },
    ["Legion"] = {
            -- First Door
        {
            objYaw = 69.85,
            objCoords = vector3(151.25, -1045.92, 29.52),
            objHash = 1138019403,
            locked = true,
        },
            -- Second Door
        {
            objYaw = 159.85,
            objCoords = vector3(148.79, -1046.03, 29.52),
            objHash = 1138019403,
            locked = true,
        },
    },
    ["Burton"] = {
            -- First Door
        {
            objYaw = 70.86,
            objCoords = vector3(-349.49, -55.07, 49.19),
            objHash = 1138019403,
            locked = true,
        },
            -- Second Door
        {
            objYaw = 161.27,
            objCoords = vector3(-351.95, -55.22, 49.19),
            objHash = 1138019403,
            locked = true,
        },
    },
    ["Alta"] = {
            -- First Door
        {
            objYaw = 69.87,
            objCoords = vector3(315.58, -284.29, 54.31),
            objHash = 1138019403,
            locked = true,
        },
            -- Second Door
        {
            objYaw = 159.87,
            objCoords = vector3(313.12, -284.4, 54.31),
            objHash = 1138019403,
            locked = true,
        },
    },
    ["GrandSenoraDesert"] = {
            -- First Door
        {
            objYaw = 270.0,
            objCoords = vector3(1171.98, 2711.21, 38.24),
            objHash = 1138019403,
            locked = true,
        },
            -- Second Door
        {
            objYaw = 0.0,
            objCoords = vector3(1174.25, 2712.16, 38.24),
            objHash = 1138019403,
            locked = true,
        },
    },
    ["BanhamCanyon"] = {
            -- First Door
        {
            objYaw = 177.54,
            objCoords = vector3(-2958.03, 485.81, 15.85),
            objHash = 1138019403,
            locked = true,
        },
            -- Second Door
        {
            objYaw = 267.54,
            objCoords = vector3(-2957.18, 483.5, 15.85),
            objHash = 1138019403,
            locked = true,
        },
    },
}

const printButton = document.querySelector("#print-qr");
const print = () => window.print();
printButton?.addEventListener("click", print);

export function cleanup() {
  printButton?.removeEventListener("click", print);
}

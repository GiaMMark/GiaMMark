// Shared by the public menu, editor and server validation.
const localImage = /^\/assets\/images\/[A-Za-z0-9_./-]+\.(?:jpe?g|png|webp|avif|gif)$/i;
const uploadedImage = /^\/api\/images\/[a-f0-9]{64}\.(?:jpg|png|webp|avif)$/;
const initialPhotos = {
  "crudo-oronero": { image: "/assets/images/crudo-mare-1.webp", imageAlt: "Il crudo di pesce dell’Oro Nero con crostacei, capesante e pesce" },
};

export function imageUrl(value) {
  if (typeof value !== "string" || value.length > 2048 || /[\u0000-\u0020\\<>"']/.test(value)) return "";
  const path = value.startsWith("assets/images/") ? `/${value}` : value;
  if (!path.includes("..") && (localImage.test(path) || uploadedImage.test(path))) return path;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password ? url.href : "";
  } catch { return ""; }
}

export function validImageFields(item) {
  return (item.image === undefined || item.image === "" || imageUrl(item.image) !== "") &&
    (item.imageAlt === undefined || (typeof item.imageAlt === "string" && item.imageAlt.length <= 240));
}

export function dishImage(item) {
  const initial = item.image === undefined ? initialPhotos[item.id] : null;
  return {
    image: imageUrl(item.image ?? initial?.image ?? ""),
    imageAlt: String(item.imageAlt || initial?.imageAlt || item.name || "Foto del piatto").slice(0, 240),
  };
}

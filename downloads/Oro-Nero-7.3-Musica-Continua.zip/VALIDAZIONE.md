# Oro Nero 7.3.0 · Verifica della consegna

## Modifiche

- Menu pubblico testuale senza foto, segnaposti e lightbox, compresa la testata. Prezzi, descrizioni, allergeni, filtri e abbinamenti restano disponibili.
- Intro con solo emblema reale, senza scritta: rotazione e ingrandimento per 3 secondi, poi apertura luminosa con lucciola di 1,1 secondi. Salto, replay, Escape, movimento ridotto, focus e salvaguardia conservati.
- Nuovo estratto MP3 fornito dall’utente, durata circa 385,6 secondi, codifica 160 kbit/s, normalizzazione intorno a -14 LUFS con obiettivo di picco -1,5 dBTP. Lettore in loop al 100% del volume; il volume del dispositivo resta controllato dall’ospite.
- Tentativo automatico di riproduzione sonora. Quando il browser lo blocca, la prima interazione consentita avvia la musica. Il comando avvio/pausa è sempre disponibile e la pausa esplicita viene rispettata.
- Navigazione interna senza ricaricare il documento: lo stesso elemento audio rimane connesso e continua a riprodurre durante il cambio pagina, i frammenti e la cronologia avanti/indietro.

## Verifiche automatiche

Build e controllo dei dati completati con Node.js 22.23.4: 13 categorie e 80 voci. Suite completa: **44 test superati**, nessun fallimento o test saltato, inclusi 8 test del lettore audio, 6 dell’intro e 4 della navigazione. I test in jsdom simulano il motore audio; la riproduzione reale è stata verificata separatamente in Chromium.

## Browser reale

Il rapporto `qa/continuous-report.json` registra la verifica Chromium della continuità audio: home → menu → carta vini → recensioni → allergeni → privacy → QR → admin → indietro QR → avanti admin → home/contatti. Il medesimo elemento audio è rimasto connesso e in riproduzione, senza eventi pause, emptied o loadstart durante questi passaggi. Verificati anche ricerca del menu, Sommelier, stampa QR e prenotazione dopo la navigazione. Nessun errore JavaScript nelle pagine provate.

Su smartphone a 390 pixel: accesso diretto al menu → home → menu con lo stesso lettore e nessuno scorrimento orizzontale. Verificati due comportamenti autoplay: avvio sonoro automatico quando consentito; avvio al normale tocco sull’intro con policy restrittiva.

Il ricaricamento completo, una nuova scheda e l’uscita dal sito creano un nuovo documento e non conservano la stessa riproduzione attiva. La posizione e la pausa sono salvate nella sessione; il seeking dopo ricaricamento richiede HTTP Range. Il server usato per la verifica supporta risposte 206 e Content-Range. Il semplice `python3 -m http.server` permette l’anteprima, ma non supporta il seeking audio.

## Fotografie

Gli ZIP caricati dall’utente superano il limite di trasferimento di 32 MiB e non sono stati aperti. Le nuove foto restano da inserire quando disponibili in archivi più piccoli o come immagini singole. Le associazioni fotografiche nei dati restano archiviate; il menu pubblico non mostra foto né segnaposti.

## Pubblicazione

Nessun deploy Netlify eseguito. La cartella `dist/` contiene la build statica. Per le funzioni amministrative e la persistenza su Netlify Blobs occorrono il deploy completo e le variabili sicure descritte in `README_NETLIFY.md`. Il caricamento degli ZIP su GitHub rende scaricabili i pacchetti, senza pubblicare automaticamente un sito Netlify.

/** A brief, skippable welcome. The restaurant remains usable if JS is unavailable. */
export function setupArrival(doc = document, win = window) {
  const overlay = doc.querySelector('[data-arrival]');
  if (!overlay) return null;
  const skip = overlay.querySelector('[data-arrival-skip]');
  const replay = doc.querySelector('[data-replay-arrival]');
  const key = 'oronero-arrival-seen-v1';
  const motion = win.matchMedia?.('(prefers-reduced-motion: reduce)');
  let active = false;
  let closing = false;
  let timer;
  let cleanupTimer;
  let safeguard;
  let previousFocus;
  let siblings = [];

  const clearTimers = () => {
    [timer, cleanupTimer, safeguard].forEach((id) => win.clearTimeout(id));
  };
  const restore = (focus = true) => {
    clearTimers();
    overlay.hidden = true;
    overlay.classList.remove('is-active', 'is-closing', 'is-skipped');
    doc.body.classList.remove('arrival-open', 'arrival-revealing');
    siblings.forEach(([element, inert]) => { element.inert = inert; });
    siblings = [];
    active = false;
    closing = false;
    if (focus && doc.activeElement === skip) {
      const target = previousFocus?.matches?.('[data-replay-arrival]') ? previousFocus : doc.querySelector('main');
      if (target) {
        const hadTabindex = target.hasAttribute('tabindex');
        if (!hadTabindex) target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
        if (!hadTabindex) target.removeAttribute('tabindex');
      }
    }
  };
  const finish = (immediate = true) => {
    if (!active || closing) return;
    closing = true;
    win.clearTimeout(timer);
    try { win.sessionStorage.setItem(key, '1'); } catch { /* Optional storage. */ }
    overlay.classList.add('is-closing');
    if (immediate || motion?.matches) overlay.classList.add('is-skipped');
    doc.body.classList.add('arrival-revealing');
    cleanupTimer = win.setTimeout(() => restore(), immediate || motion?.matches ? 160 : 900);
  };
  const open = () => {
    if (active || closing) return;
    previousFocus = doc.activeElement;
    siblings = [...doc.body.children].filter((element) => element !== overlay && !['SCRIPT', 'STYLE'].includes(element.tagName)).map((element) => [element, element.inert]);
    siblings.forEach(([element]) => { element.inert = true; });
    overlay.hidden = false;
    overlay.classList.remove('is-closing', 'is-skipped');
    // Restart the same animation cleanly when the guest chooses to replay it.
    void overlay.offsetWidth;
    overlay.classList.add('is-active');
    doc.body.classList.add('arrival-open');
    active = true;
    skip.focus({ preventScroll: true });
    timer = win.setTimeout(() => finish(false), motion?.matches ? 500 : 2500);
    safeguard = win.setTimeout(() => restore(), 4500);
  };
  const onSkip = () => finish(true);
  const onKey = (event) => {
    if (!active) return;
    if (event.key === 'Escape') { event.preventDefault(); finish(true); }
    if (event.key === 'Tab') { event.preventDefault(); skip.focus(); }
  };
  const onVisibility = () => { if (doc.hidden && active) finish(true); };
  const onPageHide = () => restore(false);
  const onReplay = () => open();
  skip.addEventListener('click', onSkip);
  overlay.addEventListener('keydown', onKey);
  replay?.addEventListener('click', onReplay);
  doc.addEventListener('visibilitychange', onVisibility);
  win.addEventListener('pagehide', onPageHide);
  let seen = false;
  try { seen = win.sessionStorage.getItem(key) === '1'; } catch { /* Storage is optional. */ }
  // Direct menu/QR visits never wait for this welcome. Reduced motion bypasses it.
  if (!seen && !motion?.matches && !win.location.hash) open();
  return {
    open, finish,
    destroy() {
      restore(false);
      skip.removeEventListener('click', onSkip);
      overlay.removeEventListener('keydown', onKey);
      replay?.removeEventListener('click', onReplay);
      doc.removeEventListener('visibilitychange', onVisibility);
      win.removeEventListener('pagehide', onPageHide);
    },
  };
}

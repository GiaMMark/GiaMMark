import { dishImage } from "./dish-images.js";

const state = { menu: null, category: "all", query: "", vegetarian: false };

const euro = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" });
const shell = document.querySelector("#menu-sections");
const chips = document.querySelector("#category-chips");
const search = document.querySelector("#menu-search");
const veggie = document.querySelector("#vegetarian-filter");
const updated = document.querySelector("#menu-updated");
const wineShell = document.querySelector("#wine-list");
const tastingShell = document.querySelector("#degustation-list");
const eventShell = document.querySelector("#event-list");
const allergenUrl = new URL("../allergeni/", import.meta.url).href;
const fallbackMenuUrl = new URL("default-menu.json", import.meta.url).href;

async function fetchMenu(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, { headers: { accept: "application/json" }, signal: controller.signal });
    if (!response.ok) throw new Error("Menu non disponibile");
    const menu = await response.json();
    if (!menu || !Array.isArray(menu.categories)) throw new Error("Formato menu non valido");
    return menu;
  } finally {
    clearTimeout(timeout);
  }
}

async function getMenu() {
  try {
    return await fetchMenu("/api/menu");
  } catch {
    return fetchMenu(fallbackMenuUrl);
  }
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[character]);
}

function normalized(value = "") {
  return String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function formatPrice(value, emptyLabel = "Su richiesta") {
  if (value === null || value === undefined || value === "") return emptyLabel;
  return euro.format(Number(value));
}

function menuPrice(item) {
  if (item.price === null || item.price === undefined || item.price === "") return "—";
  const amount = euro.format(Number(item.price));
  if (item.priceSuffix === " da") return `da ${amount}`;
  return `${amount}${item.priceSuffix || ""}`;
}

function matches(item) {
  if (!item.visible) return false;
  if (state.vegetarian && !item.vegetarian) return false;
  if (!state.query) return true;
  return normalized(`${item.name} ${item.description || ""}`).includes(normalized(state.query));
}

function renderChips() {
  chips.innerHTML = [
    `<button class="chip active" data-category="all" type="button">Tutto</button>`,
    ...state.menu.categories.map((category) => `<button class="chip" data-category="${escapeHtml(category.id)}" type="button">${escapeHtml(category.title)}</button>`),
    `<a class="chip chip-link" href="#degustazioni">Degustazioni</a>`,
    `<a class="chip chip-link" href="#carta-vini">Carta vini</a>`,
  ].join("");
  chips.addEventListener("click", (event) => {
    const button = event.target.closest("[data-category]");
    if (!button) return;
    state.category = button.dataset.category;
    chips.querySelectorAll(".chip").forEach((chip) => chip.classList.toggle("active", chip === button));
    renderMenu();
  });
}

function dishTone(category) {
  if (/vegetarian|contorni/.test(category.id)) return "garden";
  if (category.id.includes("carne")) return "earth";
  if (category.id.includes("dessert")) return "sweet";
  if (/aperitivi|bevande|amari/.test(category.id)) return "drinks";
  return "sea";
}

function placeholderMarkup(category, index = 0) {
  const tone = dishTone(category);
  const drawings = {
    sea: `<path d="M81 99c31-37 74-37 102 0-28 37-71 37-102 0Zm102 0 27-23v46l-27-23ZM66 140c18-10 29 10 47 0s29 10 47 0 29 10 47 0"/><circle cx="105" cy="94" r="2"/>`,
    earth: `<path d="M91 117c-32-41 31-78 56-46 32-25 75 26 38 53-16 16-54 15-94-7Z"/><path d="m104 86 34 35m-11-43 36 37m-10-35 29 29M70 145h150"/>`,
    garden: `<path d="M142 146c-58-13-76-66-50-83 49 2 74 37 50 83Zm0 0c5-54 24-78 60-86 14 46-9 73-60 86Zm0 0-32-57m32 57 38-63"/>`,
    sweet: `<path d="m88 136 15-64 89 40v24H88Zm0-22h104M106 82l73 33M150 75c-9-15 8-20 11-28"/><path d="M67 151h152"/><circle cx="156" cy="65" r="9"/>`,
    drinks: `<path d="M105 54h80l-8 47c-5 31-59 31-64 0l-8-47Zm40 70v33m-32 0h64M110 81h69"/><path d="m199 48 15-15m-9 34h18"/>`,
  };
  return `<div class="dish-visual dish-placeholder tone-${tone}" role="img" aria-label="Fotografia del piatto non ancora disponibile">
    <span class="dish-visual-index" aria-hidden="true">${String(index + 1).padStart(2, "0")}</span>
    <svg class="dish-illustration" viewBox="0 0 280 190" fill="none" aria-hidden="true"><ellipse cx="143" cy="104" rx="101" ry="65"/>${drawings[tone]}</svg>
    <span class="dish-placeholder-label">Foto in arrivo</span>
  </div>`;
}

function dishVisual(item, category, index) {
  const photo = dishImage(item);
  if (!photo.image) return placeholderMarkup(category, index);
  return `<button class="dish-visual dish-photo" type="button" data-dish-photo="${escapeHtml(photo.image)}" data-photo-alt="${escapeHtml(photo.imageAlt)}" data-photo-title="${escapeHtml(item.name)}" data-photo-category="${escapeHtml(category.id)}" data-photo-index="${index}" aria-label="Ingrandisci la foto di ${escapeHtml(item.name)}">
    <img class="dish-image" src="${escapeHtml(photo.image)}" alt="${escapeHtml(photo.imageAlt)}" width="720" height="540" loading="lazy" decoding="async">
    <span class="dish-visual-index" aria-hidden="true">${String(index + 1).padStart(2, "0")}</span><span class="dish-visual-action">Ingrandisci <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg></span>
  </button>`;
}

function renderMenu() {
  if (!state.menu) return;
  const categories = state.menu.categories.filter((category) => state.category === "all" || state.category === category.id);
  const html = categories.map((category) => {
    const items = category.items.filter(matches);
    if (!items.length) return "";
    return `
      <section class="menu-category" id="${escapeHtml(category.id)}">
        <header class="menu-category-heading">
          <p>${escapeHtml(category.eyebrow || "Oro Nero")}</p>
          <h2>${escapeHtml(category.title)}</h2>
          <span>${items.length} proposte</span>
        </header>
        <div class="menu-items dish-grid">
          ${items.map((item, index) => `
            <article class="menu-item dish-card${item.featured ? " featured" : ""}">
              ${dishVisual(item, category, index)}
              <div class="dish-card-body">
                <div class="dish-card-heading"><h3>${escapeHtml(item.name)}${item.vegetarian ? " <small>Vegetariano</small>" : ""}</h3><strong class="dish-price">${menuPrice(item)}</strong></div>
                ${item.description ? `<p class="dish-description">${escapeHtml(item.description)}</p>` : ""}
                <div class="dish-card-footer">${item.allergens?.length ? `<a class="allergen-link" href="${allergenUrl}" aria-label="Consulta gli allergeni di ${escapeHtml(item.name)}">Allergeni: ${item.allergens.join(", ")}</a>` : "<span></span>"}
                <button class="pairing-button" type="button" data-pairing="${escapeHtml(item.name)}">Abbina un vino</button></div>
              </div>
            </article>`).join("")}
        </div>
      </section>`;
  }).join("");
  shell.innerHTML = html || `<div class="empty-state"><h2>Nessun piatto trovato</h2><p>Prova a cambiare ricerca o filtro.</p></div>`;
  shell.querySelectorAll(".dish-image").forEach((image) => image.addEventListener("error", () => {
    const button = image.closest("[data-dish-photo]");
    if (!button) return;
    const category = state.menu.categories.find((entry) => entry.id === button.dataset.photoCategory);
    button.insertAdjacentHTML("afterend", placeholderMarkup(category, Number(button.dataset.photoIndex)));
    button.remove();
  }, { once: true }));
  document.querySelectorAll("[data-pairing]").forEach((button) => button.addEventListener("click", () => openSommelier(`Cosa abbino a ${button.dataset.pairing}?`)));
}

// One lightbox for the whole menu; only genuine, available photos are clickable.
document.body.insertAdjacentHTML("beforeend", `<dialog class="dish-photo-dialog" id="dish-photo-dialog" aria-labelledby="dish-photo-title"><figure class="dish-photo-card"><button class="dish-photo-close" type="button" aria-label="Chiudi la fotografia">×</button><img alt=""><figcaption id="dish-photo-title"></figcaption></figure></dialog>`);
const photoDialog = document.querySelector("#dish-photo-dialog");
let photoTrigger;
function closeDishPhoto() {
  if (typeof photoDialog.close === "function") photoDialog.close();
  else { photoDialog.removeAttribute("open"); photoDialog.dispatchEvent(new window.Event("close")); }
}
shell.addEventListener("click", (event) => {
  const button = event.target.closest("[data-dish-photo]");
  if (!button) return;
  photoTrigger = button;
  photoDialog.querySelector("img").src = button.dataset.dishPhoto;
  photoDialog.querySelector("img").alt = button.dataset.photoAlt;
  photoDialog.querySelector("figcaption").textContent = button.dataset.photoTitle;
  try { photoDialog.showModal(); } catch { photoDialog.setAttribute("open", ""); }
  document.body.classList.add("dialog-open");
});
photoDialog.querySelector(".dish-photo-close").addEventListener("click", closeDishPhoto);
photoDialog.addEventListener("click", (event) => { if (event.target === photoDialog) closeDishPhoto(); });
photoDialog.addEventListener("keydown", (event) => { if (event.key === "Escape") { event.preventDefault(); closeDishPhoto(); } });
photoDialog.addEventListener("close", () => {
  document.body.classList.remove("dialog-open");
  photoTrigger?.focus();
});
photoDialog.querySelector("img").addEventListener("error", closeDishPhoto);

function renderWines() {
  const wines = (state.menu.wines || []).filter((wine) => wine.visible);
  wineShell.innerHTML = wines.length ? wines.map((wine) => `
    <article class="wine-card">
      <div class="wine-card-top"><span>${escapeHtml(wine.type || "Vino")}</span>${wine.vintage ? `<strong>${escapeHtml(wine.vintage)}</strong>` : ""}</div>
      <h3>${escapeHtml(wine.name)}</h3>
      <p class="wine-producer">${escapeHtml([wine.producer, wine.region].filter(Boolean).join(" · "))}</p>
      ${wine.description ? `<p>${escapeHtml(wine.description)}</p>` : ""}
      <div class="wine-prices">
        ${wine.glassPrice !== null && wine.glassPrice !== undefined ? `<span>Calice <strong>${formatPrice(wine.glassPrice)}</strong></span>` : ""}
        ${wine.bottlePrice !== null && wine.bottlePrice !== undefined ? `<span>Bottiglia <strong>${formatPrice(wine.bottlePrice)}</strong></span>` : ""}
      </div>
      <button class="pairing-button" type="button" data-wine-question="${escapeHtml(wine.name)}">Con cosa lo abbino?</button>
    </article>`).join("") : `<p class="empty-state">La carta vini è in aggiornamento. Chiedi la selezione disponibile al personale.</p>`;
  document.querySelectorAll("[data-wine-question]").forEach((button) => button.addEventListener("click", () => openSommelier(`Con cosa posso abbinare ${button.dataset.wineQuestion}?`)));
}

function renderDegustations() {
  const degustations = (state.menu.degustations || []).filter((item) => item.visible);
  tastingShell.innerHTML = degustations.map((item) => `
    <article class="experience-card">
      <p>${escapeHtml(item.subtitle || "Esperienza Oro Nero")}</p>
      <h3>${escapeHtml(item.title)}</h3>
      <div>${escapeHtml(item.description || "")}</div>
      <strong>${formatPrice(item.price, "Prezzo su richiesta")}</strong>
      <button type="button" class="button button-gold" data-booking data-booking-note="${escapeHtml(item.title)}">Richiedi il percorso</button>
    </article>`).join("");
}

function renderEvents() {
  const events = (state.menu.events || []).filter((item) => item.visible);
  eventShell.innerHTML = events.map((item) => `
    <article class="event-card">
      <p>${escapeHtml(item.dateText || "In aggiornamento")}</p>
      <h3>${escapeHtml(item.title)}</h3>
      <div>${escapeHtml(item.description || "")}</div>
      <button type="button" class="text-link" data-booking data-booking-note="${escapeHtml(item.title)}">Chiedi informazioni →</button>
    </article>`).join("");
}

search.addEventListener("input", () => { state.query = search.value; renderMenu(); });
veggie.addEventListener("change", () => { state.vegetarian = veggie.checked; renderMenu(); });

const dialog = document.querySelector("#sommelier-dialog");
const launcher = document.querySelector(".sommelier-launcher");
const closeButton = document.querySelector("#sommelier-close");
const form = document.querySelector("#sommelier-form");
const input = document.querySelector("#sommelier-input");
const messages = document.querySelector("#sommelier-messages");

function winePrice(wine) {
  const prices = [];
  if (wine.glassPrice !== null && wine.glassPrice !== undefined) prices.push(`calice ${formatPrice(wine.glassPrice)}`);
  if (wine.bottlePrice !== null && wine.bottlePrice !== undefined) prices.push(`bottiglia ${formatPrice(wine.bottlePrice)}`);
  return prices.length ? ` (${prices.join(", ")})` : "";
}

function requestedBudget(text) {
  const query = normalized(text);
  const budgetMatch = query.match(/(?:entro|budget|massimo|fino a)?\s*(\d{1,3})\s*(?:€|euro)/);
  return budgetMatch ? Number(budgetMatch[1]) : null;
}

function wineRecommendations(text) {
  const query = normalized(text);
  const budget = requestedBudget(text);
  const intent = [];
  if (/crudo|tartare|cappesant|vongol/.test(query)) intent.push("crudi", "pesce");
  if (/fritt|calamar|gamber/.test(query)) intent.push("frittura", "pesce");
  if (/pesce|mare|scamp|orata|tonno|merluzzo|triglia/.test(query)) intent.push("pesce");
  if (/manzo|filetto|roast|carne|fiorentina|maiale|faraona/.test(query)) intent.push("carne", "manzo");
  if (/veget|tofu|ceci|pesto|verdure/.test(query)) intent.push("vegetariano");
  if (/dolce|dessert|tiramisu|profiterol|torta/.test(query)) intent.push("dessert");
  if (/aperitivo|spritz/.test(query)) intent.push("aperitivo");

  const allVisible = (state.menu?.wines || []).filter((wine) => wine.visible);
  const withinBudget = budget === null ? allVisible : allVisible.filter((wine) => {
    const relevantPrice = /calice/.test(query) ? wine.glassPrice : wine.bottlePrice ?? wine.glassPrice;
    return relevantPrice !== null && relevantPrice !== undefined && Number(relevantPrice) <= budget;
  });
  const visible = withinBudget;
  const scored = visible.map((wine) => {
    const haystack = normalized(`${wine.name} ${wine.producer || ""} ${wine.type || ""} ${(wine.pairings || []).join(" ")}`);
    const score = intent.reduce((total, tag) => total + (haystack.includes(normalized(tag)) ? 2 : 0), 0) + (query.includes(normalized(wine.name)) ? 5 : 0);
    return { wine, score };
  }).sort((a, b) => b.score - a.score);
  const selected = (scored.some((entry) => entry.score > 0) ? scored.filter((entry) => entry.score > 0) : scored).slice(0, 2).map((entry) => entry.wine);
  return selected;
}

function reply(text) {
  const query = normalized(text);
  const namedWine = (state.menu?.wines || []).find((wine) => wine.visible && query.includes(normalized(wine.name)));
  if (namedWine) {
    const pairings = (namedWine.pairings || []).slice(0, 4).join(", ");
    return `${namedWine.name}${winePrice(namedWine)} è indicato con ${pairings || "i piatti consigliati dalla sala"}. Chiedi al personale quale portata del giorno lo valorizza meglio.`;
  }
  const selected = wineRecommendations(text);
  if (!selected.length && requestedBudget(text) !== null && (state.menu?.wines || []).some((wine) => wine.visible)) {
    return `Non ho trovato etichette disponibili entro il budget di ${formatPrice(requestedBudget(text))}. Chiedi alla sala un’alternativa oppure indica un altro budget.`;
  }
  if (!selected.length) return "La carta vini è in aggiornamento. Comunica il piatto e il budget alla sala per ricevere la proposta del giorno.";
  const suggestions = selected.map((wine) => `${wine.name}${winePrice(wine)}`).join(" oppure ");
  return `Dalla carta Oro Nero ti consiglio ${suggestions}. La disponibilità dell’etichetta viene confermata dalla sala.`;
}

function bubble(role, text) {
  const element = document.createElement("p");
  element.className = `sommelier-message ${role}`;
  element.textContent = text;
  messages.append(element);
  messages.scrollTop = messages.scrollHeight;
}

function openSommelier(prompt = "") {
  if (!dialog.open) {
    try {
      dialog.showModal();
    } catch {
      dialog.setAttribute("open", "");
    }
  }
  document.body.classList.add("dialog-open");
  if (prompt) {
    bubble("user", prompt);
    setTimeout(() => bubble("assistant", reply(prompt)), 280);
  }
  setTimeout(() => input.focus(), 50);
}

launcher.addEventListener("click", () => openSommelier());
closeButton.addEventListener("click", () => dialog.close());
dialog.addEventListener("close", () => document.body.classList.remove("dialog-open"));
dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); });
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  bubble("user", text);
  input.value = "";
  setTimeout(() => bubble("assistant", reply(text)), 320);
});

const footer = document.querySelector("#site-footer");
if (footer) {
  new IntersectionObserver(
    ([entry]) => launcher.classList.toggle("footer-near", entry.isIntersecting),
    { rootMargin: "0px 0px 80px 0px", threshold: 0.01 },
  ).observe(footer);
}

getMenu()
  .then((menu) => {
    if (!menu || !Array.isArray(menu.categories)) throw new Error("Formato menu non valido");
    state.menu = menu;
    renderChips();
    renderMenu();
    renderWines();
    renderDegustations();
    renderEvents();
    document.dispatchEvent(new CustomEvent("oronero:dynamic-content"));
    const date = menu.updatedAt ? new Date(menu.updatedAt) : null;
    updated.textContent = date && !Number.isNaN(date.valueOf()) ? `Aggiornato il ${date.toLocaleDateString("it-IT")}` : "Prezzi aggiornati";
  })
  .catch(() => {
    shell.innerHTML = `<div class="empty-state"><h2>Menu momentaneamente non disponibile</h2><p>Riprova tra qualche istante oppure contatta Oro Nero.</p></div>`;
    updated.textContent = "Caricamento non riuscito";
  });

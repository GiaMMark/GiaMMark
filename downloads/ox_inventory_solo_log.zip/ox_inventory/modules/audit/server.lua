-- Server-only Discord audit logging. Never list this module in shared/client files.
if not IsDuplicityVersion() then return {} end

local Audit = {}
local webhook = GetConvar('inventory:discordWebhook', GetConvar('inventory:webhook', ''))
local enabled = GetConvarInt('inventory:discordLogs', 1) == 1 and webhook ~= ''
local queue, first, last = {}, 1, 0
local scheduled, sending, attempts = false, false, 0
local maxQueue = 10000
local headers = { ['Content-Type'] = 'application/json' }
local reportedFailure, reportedOverflow = false, false

local function shorten(value, limit)
    value = tostring(value)
    if #value <= limit then return value end
    -- Avoid cutting a UTF-8 character in half (Discord requires valid JSON text).
    return value:sub(1, limit - 3):gsub('[\194-\244][\128-\191]*$', '') .. '...'
end

local function snapshot(value, depth, seen)
    local kind = type(value)
    if kind == 'string' then return shorten(value, 700) end
    if kind == 'number' or kind == 'boolean' or kind == 'nil' then return value end
    if kind ~= 'table' then return tostring(value) end
    if seen[value] then return '[circular]' end
    if depth > 5 then return '[nested data]' end

    seen[value] = true
    local result, count = {}, 0
    for key, entry in pairs(value) do
        count = count + 1
        if count > 80 then result['...'] = 'additional entries omitted'; break end
        result[tostring(key)] = snapshot(entry, depth + 1, seen)
    end
    seen[value] = nil
    return result
end

local function inventoryInfo(inv)
    if type(inv) ~= 'table' then return inv end
    return { id = inv.id, label = inv.label, type = inv.type, owner = inv.owner }
end

function Audit.Inventory(inv)
    return inventoryInfo(inv)
end

function Audit.Snapshot(value)
    local ok, result = pcall(snapshot, value, 0, {})
    return ok and result or '[unavailable]'
end

local function actorInfo(actor)
    local inv = type(actor) == 'table' and actor or nil
    -- A stash/backpack can have a numeric-looking ID. It is never a player.
    local id = inv and inv.player and tonumber(inv.id) or (not inv and tonumber(actor))
    if not id or id <= 0 then
        return inv and inventoryInfo(inv) or { id = actor, name = id == 0 and 'Console' or 'Server / resource' }
    end

    local result = { id = id, name = GetPlayerName(id) or (inv and inv.label) or 'Disconnected player' }
    if inv then result.owner = inv.owner end
    local identifiers = GetPlayerIdentifiers(id) or {}
    for i = 1, #identifiers do
        local identifier = identifiers[i]
        if identifier:match('^license:') then result.license = identifier
        elseif identifier:match('^discord:') then result.discord = identifier end
    end
    local ped = GetPlayerPed(id)
    if ped and ped ~= 0 then
        local coords = GetEntityCoords(ped)
        result.coords = { x = coords.x, y = coords.y, z = coords.z }
    end
    return result
end

local flush
local function schedule(delay)
    if scheduled or sending or first > last then return end
    scheduled = true
    SetTimeout(delay, function()
        scheduled = false
        flush()
    end)
end

local function warnOnce(message)
    if reportedFailure then return end
    reportedFailure = true
    print('[ox_inventory:discordLogs] ' .. message)
end

flush = function()
    if sending or first > last then return end
    local embeds, size, count = {}, 0, 0
    -- Discord allows at most 10 embeds and 6000 total embed characters per request.
    for i = first, math.min(last, first + 9) do
        local embed = queue[i]
        local length = #embed.title + #embed.description + #embed.footer.text
        if size + length > 5800 then break end
        count = count + 1
        embeds[count], size = embed, size + length
    end
    local ok, body = pcall(json.encode, {
        username = 'ox_inventory Logs', allowed_mentions = { parse = {} }, embeds = embeds
    })
    if not ok then
        warnOnce('Unable to encode audit logs; pending entries retained.')
        schedule(10000)
        return
    end

    sending = true
    local started = pcall(PerformHttpRequest, webhook, function(status, response, responseHeaders)
        sending = false
        if status >= 200 and status < 300 then
            for i = first, first + count - 1 do queue[i] = nil end
            first = first + count
            attempts, reportedFailure, reportedOverflow = 0, false, false
            if first > last then queue, first, last = {}, 1, 0 end
            schedule(1000)
            return
        end

        attempts = attempts + 1
        local delay = math.min(60000, 1000 * 2 ^ math.min(attempts, 6))
        if status == 429 then
            local decoded, rate = pcall(json.decode, response or '')
            local retry = decoded and type(rate) == 'table' and tonumber(rate.retry_after)
            if not retry and responseHeaders then
                retry = tonumber(responseHeaders['Retry-After'] or responseHeaders['retry-after'])
            end
            delay = math.max(1000, math.ceil((retry or 5) * 1000) + 250)
        else
            -- Never print the response, URL or token: errors may contain credentials.
            warnOnce(('Discord HTTP %s; queued logs will be retried.'):format(tostring(status)))
        end
        schedule(delay)
    end, 'POST', body, headers)

    if not started then
        sending = false
        warnOnce('HTTP request failed to start; queued logs will be retried.')
        schedule(10000)
    end
end

local outcomes = {
    completed = 'Completato', denied = 'Rifiutato', failed = 'Fallito',
    queued = 'In coda', requested = 'Richiesto', delegated = 'Delegato',
    confirmed = 'Confermato', payment_failed = 'Pagamento fallito',
}

-- All formatting, native calls and queuing are protected: logging cannot fail an action.
-- Only this module sends HTTP, asynchronously, with rate-limit/backoff handling.
function Audit.Log(action, actor, details, outcome)
    if not enabled then return end
    local ok = pcall(function()
        if last - first + 1 >= maxQueue then
            if not reportedOverflow then
                print('[ox_inventory:discordLogs] Queue full (10000); new logs discarded until Discord recovers.')
                reportedOverflow = true
            end
            return
        end
        outcome = outcome or 'completed'
        local context = {
            actor = actorInfo(actor),
            resource = GetInvokingResource() or GetCurrentResourceName(),
            details = snapshot(details or {}, 0, {}),
        }
        local description = ('**Esito:** %s\n```json\n%s\n```'):format(
            outcomes[outcome] or outcome, shorten(json.encode(context), 3600):gsub('```', "'''")
        )
        local embed = {
            title = shorten(action, 180), description = description,
            color = (outcome == 'denied' or outcome == 'failed' or outcome == 'payment_failed') and 15158332 or 3066993,
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
            footer = { text = 'ox_inventory | ' .. GetCurrentResourceName() },
        }
        last = last + 1
        queue[last] = embed
        schedule(1000)
    end)
    if not ok then warnOnce('Unable to format an audit entry; inventory operation unchanged.') end
end

return Audit

-- Align the existing pinkFrog preview with ox_inventory's fixed central clothing panel.
-- This uses the addon's supported configuration; it does not replace its ped renderer.
local DEFAULT_X = 0.555

local function copy(value)
    if type(value) ~= 'table' then return value end
    local result = {}
    for key, entry in pairs(value) do result[key] = copy(entry) end
    return result
end

local function merge(source, target)
    for key, value in pairs(source) do
        if type(value) == 'table' then
            if type(target[key]) ~= 'table' then target[key] = {} end
            merge(value, target[key])
        else
            target[key] = value
        end
    end
end

local settings = Config.clonedPedSettings
local presets = settings and settings.positionPresets
local centerRotation = presets and presets.center and copy(presets.center.rotation)

local function align(x)
    if type(x) ~= 'number' or x ~= x or x < 0.05 or x > 0.95 then return false end
    if type(presets) ~= 'table' then return false end

    Config.uiSettings = Config.uiSettings or {}
    Config.uiSettings.whereIsClothingPlacedInUI = 'center'

    -- The grid keeps clothing in the center even when an old saved preference says
    -- left/right. Keep all those presets aligned, so that preference cannot move the ped.
    for _, preset in pairs(presets) do
        if type(preset) == 'table' then
            preset.position = preset.position or {}
            preset.position.x = x
            -- Preserve y/depth/lighting and any custom fields; use the existing frontal
            -- center rotation, keeping tables alive if the renderer retained a reference.
            if type(centerRotation) == 'table' then
                preset.rotation = preset.rotation or {}
                merge(centerRotation, preset.rotation)
            end
        end
    end
    return true
end

align(DEFAULT_X)

-- Return an acknowledgement so ox can detect a missing patch before restarting the preview.
exports('alignGridPedPreview', align)

-- Local event only. ox_inventory sends the actual divider midpoint after layout/resize.
AddEventHandler('pinkFrog:gridPedBounds', function(bounds)
    if type(bounds) ~= 'table' then return end
    align(bounds.x)
end)

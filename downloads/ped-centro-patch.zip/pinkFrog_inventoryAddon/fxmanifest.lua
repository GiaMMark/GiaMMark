fx_version 'cerulean'
author 'pinkfrog.io - froggy to Conor'
games { 'gta5' }

version 'v2.1.4'

client_script {
'client/custom/grid_ped_alignment.lua',
'client/custom/client_editable.lua',
'client/client.lua',
'client/modules/client_throwing.lua',
'client/modules/client_backPack.lua',
'client/modules/client_damage.lua',
'client/modules/client_weight.lua',
'client/modules/client_bagClothes.lua',
'client/modules/client_armour.lua',
}

server_scripts {
    'server/server.lua',
    'server/modules/server_throwing.lua',
    'server/modules/server_backPack.lua',
    'server/modules/server_damage.lua',
    'server/modules/server_weight.lua',
    'server/modules/server_bagClothes.lua',
    'server/modules/server_armour.lua',
}

shared_script {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

escrow_ignore {
    'client/custom/grid_ped_alignment.lua',
    "shared/config.lua",
    'client/custom/client_editable.lua', 
}


lua54 'yes'

dependency '/assetpacks'